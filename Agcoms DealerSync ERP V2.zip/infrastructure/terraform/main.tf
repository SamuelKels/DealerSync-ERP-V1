# ============================================================
# AGCOMS DealerSync ERP — Terraform Root Module
# Production Infrastructure — AWS (primary: eu-west-1 / Lagos proximity)
# Stage 3 of Deployment Maturity Model (Section 4)
# ============================================================
# Resources provisioned:
#   VPC + subnets (public/private/database tiers)
#   ECS Fargate cluster + services (backend, frontend, portal)
#   RDS PostgreSQL 16 Multi-AZ with read replica
#   ElastiCache Redis cluster (multi-AZ)
#   Application Load Balancer + WAF v2
#   CloudFront CDN
#   S3 (assets, backups, exports)
#   Secrets Manager (JWT keys, DB credentials)
#   Route53 + ACM
#   CloudWatch + Container Insights
# ============================================================

terraform {
  required_version = ">= 1.7.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.40"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  backend "s3" {
    bucket         = "agcoms-tfstate-prod"
    key            = "dealersync/production/terraform.tfstate"
    region         = "eu-west-1"
    encrypt        = true
    dynamodb_table = "agcoms-tfstate-lock"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = "AGCOMS-DealerSync-ERP"
      Environment = var.environment
      ManagedBy   = "Terraform"
      Owner       = "AGCOMS-Engineering"
    }
  }
}

# Secondary region for DR
provider "aws" {
  alias  = "dr"
  region = var.dr_region
  default_tags {
    tags = {
      Project     = "AGCOMS-DealerSync-ERP"
      Environment = "${var.environment}-dr"
      ManagedBy   = "Terraform"
    }
  }
}

# ── Variables ─────────────────────────────────────────────────────────────

variable "aws_region" {
  description = "Primary AWS region"
  type        = string
  default     = "eu-west-1"
}

variable "dr_region" {
  description = "Disaster recovery region"
  type        = string
  default     = "eu-west-2"
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "production"
}

variable "project_name" {
  description = "Project identifier"
  type        = string
  default     = "agcoms-dealersync"
}

variable "domain_name" {
  description = "Root domain"
  type        = string
  default     = "agcoms-erp.agcomsinternational.com"
}

variable "db_instance_class" {
  description = "RDS instance type"
  type        = string
  default     = "db.r6g.xlarge"
}

variable "redis_node_type" {
  description = "ElastiCache node type"
  type        = string
  default     = "cache.r6g.large"
}

variable "backend_cpu" {
  description = "Backend Fargate CPU units"
  type        = number
  default     = 2048
}

variable "backend_memory" {
  description = "Backend Fargate memory (MiB)"
  type        = number
  default     = 4096
}

variable "backend_desired_count" {
  description = "Desired number of backend tasks"
  type        = number
  default     = 3
}

variable "backend_min_count" {
  description = "Minimum backend tasks for autoscaling"
  type        = number
  default     = 2
}

variable "backend_max_count" {
  description = "Maximum backend tasks for autoscaling"
  type        = number
  default     = 20
}

# ── Data ──────────────────────────────────────────────────────────────────

data "aws_caller_identity" "current" {}
data "aws_availability_zones" "available" { state = "available" }

# ── VPC ───────────────────────────────────────────────────────────────────

resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags                 = { Name = "${var.project_name}-vpc" }
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "${var.project_name}-igw" }
}

# Public subnets (3 AZs)
resource "aws_subnet" "public" {
  count                   = 3
  vpc_id                  = aws_vpc.main.id
  cidr_block              = cidrsubnet("10.0.0.0/16", 8, count.index)
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags                    = { Name = "${var.project_name}-public-${count.index + 1}", Tier = "Public" }
}

# Private subnets (3 AZs — ECS tasks, NAT-egress only)
resource "aws_subnet" "private" {
  count             = 3
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet("10.0.0.0/16", 8, count.index + 10)
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags              = { Name = "${var.project_name}-private-${count.index + 1}", Tier = "Private" }
}

# Database subnets (3 AZs — no internet route)
resource "aws_subnet" "database" {
  count             = 3
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet("10.0.0.0/16", 8, count.index + 20)
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags              = { Name = "${var.project_name}-db-${count.index + 1}", Tier = "Database" }
}

# NAT Gateways (one per AZ for HA)
resource "aws_eip" "nat" {
  count  = 3
  domain = "vpc"
  tags   = { Name = "${var.project_name}-nat-eip-${count.index + 1}" }
}

resource "aws_nat_gateway" "main" {
  count         = 3
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
  tags          = { Name = "${var.project_name}-nat-${count.index + 1}" }
  depends_on    = [aws_internet_gateway.main]
}

# Route tables
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route { cidr_block = "0.0.0.0/0"; gateway_id = aws_internet_gateway.main.id }
  tags   = { Name = "${var.project_name}-rt-public" }
}

resource "aws_route_table" "private" {
  count  = 3
  vpc_id = aws_vpc.main.id
  route { cidr_block = "0.0.0.0/0"; nat_gateway_id = aws_nat_gateway.main[count.index].id }
  tags   = { Name = "${var.project_name}-rt-private-${count.index + 1}" }
}

resource "aws_route_table_association" "public"   { count = 3; subnet_id = aws_subnet.public[count.index].id;   route_table_id = aws_route_table.public.id }
resource "aws_route_table_association" "private"  { count = 3; subnet_id = aws_subnet.private[count.index].id;  route_table_id = aws_route_table.private[count.index].id }
resource "aws_route_table_association" "database" { count = 3; subnet_id = aws_subnet.database[count.index].id; route_table_id = aws_route_table.private[count.index].id }

# ── Security Groups ───────────────────────────────────────────────────────

resource "aws_security_group" "alb" {
  name        = "${var.project_name}-alb-sg"
  description = "ALB — HTTPS only from internet"
  vpc_id      = aws_vpc.main.id
  ingress { from_port = 443; to_port = 443; protocol = "tcp"; cidr_blocks = ["0.0.0.0/0"] }
  ingress { from_port = 80;  to_port = 80;  protocol = "tcp"; cidr_blocks = ["0.0.0.0/0"] }
  egress  { from_port = 0;   to_port = 0;   protocol = "-1";  cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_security_group" "backend" {
  name        = "${var.project_name}-backend-sg"
  description = "Backend ECS tasks — only from ALB"
  vpc_id      = aws_vpc.main.id
  ingress { from_port = 3000; to_port = 3000; protocol = "tcp"; security_groups = [aws_security_group.alb.id] }
  egress  { from_port = 0;    to_port = 0;    protocol = "-1";  cidr_blocks    = ["0.0.0.0/0"] }
}

resource "aws_security_group" "rds" {
  name        = "${var.project_name}-rds-sg"
  description = "RDS — only from backend and bastion"
  vpc_id      = aws_vpc.main.id
  ingress { from_port = 5432; to_port = 5432; protocol = "tcp"; security_groups = [aws_security_group.backend.id] }
}

resource "aws_security_group" "redis" {
  name        = "${var.project_name}-redis-sg"
  description = "ElastiCache Redis — only from backend"
  vpc_id      = aws_vpc.main.id
  ingress { from_port = 6379; to_port = 6379; protocol = "tcp"; security_groups = [aws_security_group.backend.id] }
}

# ── ACM / TLS ─────────────────────────────────────────────────────────────

resource "aws_acm_certificate" "main" {
  domain_name               = var.domain_name
  subject_alternative_names = ["*.${var.domain_name}"]
  validation_method         = "DNS"
  lifecycle { create_before_destroy = true }
}

# ── WAF v2 ────────────────────────────────────────────────────────────────

resource "aws_wafv2_web_acl" "main" {
  name        = "${var.project_name}-waf"
  description = "WAF protecting ALB — OWASP Top 10 managed rules + rate limiting"
  scope       = "REGIONAL"

  default_action { allow {} }

  rule {
    name     = "AWSManagedRulesCommonRuleSet"
    priority = 1
    override_action { none {} }
    statement { managed_rule_group_statement { name = "AWSManagedRulesCommonRuleSet"; vendor_name = "AWS" } }
    visibility_config { cloudwatch_metrics_enabled = true; metric_name = "CommonRuleSet"; sampled_requests_enabled = true }
  }

  rule {
    name     = "AWSManagedRulesSQLiRuleSet"
    priority = 2
    override_action { none {} }
    statement { managed_rule_group_statement { name = "AWSManagedRulesSQLiRuleSet"; vendor_name = "AWS" } }
    visibility_config { cloudwatch_metrics_enabled = true; metric_name = "SQLiRuleSet"; sampled_requests_enabled = true }
  }

  rule {
    name     = "RateLimitRule"
    priority = 3
    action { block {} }
    statement { rate_based_statement { limit = 2000; aggregate_key_type = "IP" } }
    visibility_config { cloudwatch_metrics_enabled = true; metric_name = "RateLimit"; sampled_requests_enabled = true }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "${var.project_name}-waf"
    sampled_requests_enabled   = true
  }
}

# ── Application Load Balancer ─────────────────────────────────────────────

resource "aws_lb" "main" {
  name               = "${var.project_name}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = aws_subnet.public[*].id
  drop_invalid_header_fields = true
  tags               = { Name = "${var.project_name}-alb" }
}

resource "aws_wafv2_web_acl_association" "main" {
  resource_arn = aws_lb.main.arn
  web_acl_arn  = aws_wafv2_web_acl.main.arn
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.main.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = aws_acm_certificate.main.arn
  default_action { type = "forward"; target_group_arn = aws_lb_target_group.backend.arn }
}

resource "aws_lb_listener" "http_redirect" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"
  default_action { type = "redirect"; redirect { port = "443"; protocol = "HTTPS"; status_code = "HTTP_301" } }
}

resource "aws_lb_target_group" "backend" {
  name        = "${var.project_name}-backend-tg"
  port        = 3000
  protocol    = "HTTP"
  vpc_id      = aws_vpc.main.id
  target_type = "ip"
  health_check {
    path                = "/api/v1/health"
    interval            = 30
    timeout             = 10
    healthy_threshold   = 2
    unhealthy_threshold = 3
    matcher             = "200"
  }
  deregistration_delay = 30
}

# ── RDS PostgreSQL 16 Multi-AZ ────────────────────────────────────────────

resource "aws_db_subnet_group" "main" {
  name       = "${var.project_name}-db-subnet-group"
  subnet_ids = aws_subnet.database[*].id
}

resource "random_password" "db" {
  length  = 32
  special = false
}

resource "aws_secretsmanager_secret" "db_password" {
  name                    = "${var.project_name}/${var.environment}/db-password"
  recovery_window_in_days = 7
}

resource "aws_secretsmanager_secret_version" "db_password" {
  secret_id     = aws_secretsmanager_secret.db_password.id
  secret_string = random_password.db.result
}

resource "aws_db_instance" "primary" {
  identifier              = "${var.project_name}-${var.environment}-primary"
  engine                  = "postgres"
  engine_version          = "16.2"
  instance_class          = var.db_instance_class
  allocated_storage       = 100
  max_allocated_storage   = 1000
  storage_type            = "gp3"
  storage_encrypted       = true
  db_name                 = "dealersync"
  username                = "dealersync_admin"
  password                = random_password.db.result
  db_subnet_group_name    = aws_db_subnet_group.main.name
  vpc_security_group_ids  = [aws_security_group.rds.id]
  multi_az                = true
  backup_retention_period = 30
  backup_window           = "02:00-03:00"
  maintenance_window      = "Mon:03:00-Mon:04:00"
  deletion_protection     = true
  skip_final_snapshot     = false
  final_snapshot_identifier = "${var.project_name}-${var.environment}-final"
  enabled_cloudwatch_logs_exports = ["postgresql", "upgrade"]
  performance_insights_enabled    = true
  monitoring_interval             = 60
  monitoring_role_arn             = aws_iam_role.rds_monitoring.arn
  parameter_group_name            = aws_db_parameter_group.pg16.name
  tags                            = { Name = "${var.project_name}-primary-db" }
}

resource "aws_db_parameter_group" "pg16" {
  name   = "${var.project_name}-pg16"
  family = "postgres16"
  parameter { name = "log_min_duration_statement"; value = "1000" }  # log slow queries > 1s
  parameter { name = "log_connections";             value = "1" }
  parameter { name = "log_disconnections";          value = "1" }
  parameter { name = "shared_preload_libraries";    value = "pg_stat_statements" }
  parameter { name = "pg_stat_statements.track";    value = "all" }
}

# Read replica
resource "aws_db_instance" "read_replica" {
  identifier             = "${var.project_name}-${var.environment}-replica"
  instance_class         = var.db_instance_class
  replicate_source_db    = aws_db_instance.primary.identifier
  storage_encrypted      = true
  vpc_security_group_ids = [aws_security_group.rds.id]
  skip_final_snapshot    = true
  tags                   = { Name = "${var.project_name}-read-replica" }
}

# IAM for RDS Enhanced Monitoring
resource "aws_iam_role" "rds_monitoring" {
  name               = "${var.project_name}-rds-monitoring"
  assume_role_policy = jsonencode({ Version = "2012-10-17"; Statement = [{ Action = "sts:AssumeRole"; Effect = "Allow"; Principal = { Service = "monitoring.rds.amazonaws.com" } }] })
}
resource "aws_iam_role_policy_attachment" "rds_monitoring" {
  role       = aws_iam_role.rds_monitoring.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonRDSEnhancedMonitoringRole"
}

# ── ElastiCache Redis 7 (cluster mode) ────────────────────────────────────

resource "aws_elasticache_subnet_group" "main" {
  name       = "${var.project_name}-redis-subnet-group"
  subnet_ids = aws_subnet.database[*].id
}

resource "aws_elasticache_replication_group" "main" {
  replication_group_id       = "${var.project_name}-redis"
  description                = "Redis cluster for DealerSync — queues, caching, feature flags, sessions"
  node_type                  = var.redis_node_type
  port                       = 6379
  parameter_group_name       = "default.redis7.cluster.on"
  automatic_failover_enabled = true
  multi_az_enabled           = true
  num_cache_clusters         = 3
  subnet_group_name          = aws_elasticache_subnet_group.main.name
  security_group_ids         = [aws_security_group.redis.id]
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  snapshot_retention_limit   = 7
  snapshot_window            = "03:00-04:00"
  tags                       = { Name = "${var.project_name}-redis" }
}

# ── ECS Fargate Cluster ───────────────────────────────────────────────────

resource "aws_ecs_cluster" "main" {
  name = "${var.project_name}-${var.environment}"
  setting { name = "containerInsights"; value = "enabled" }
}

resource "aws_ecs_cluster_capacity_providers" "main" {
  cluster_name       = aws_ecs_cluster.main.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]
  default_capacity_provider_strategy {
    base              = 2
    weight            = 80
    capacity_provider = "FARGATE"
  }
  default_capacity_provider_strategy {
    weight            = 20
    capacity_provider = "FARGATE_SPOT"
  }
}

# Task execution role
resource "aws_iam_role" "ecs_task_execution" {
  name               = "${var.project_name}-ecs-task-execution"
  assume_role_policy = jsonencode({ Version = "2012-10-17"; Statement = [{ Action = "sts:AssumeRole"; Effect = "Allow"; Principal = { Service = "ecs-tasks.amazonaws.com" } }] })
}
resource "aws_iam_role_policy_attachment" "ecs_task_execution" {
  role       = aws_iam_role.ecs_task_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

# Task role (runtime permissions — Secrets Manager, S3, CloudWatch)
resource "aws_iam_role" "ecs_task" {
  name               = "${var.project_name}-ecs-task"
  assume_role_policy = jsonencode({ Version = "2012-10-17"; Statement = [{ Action = "sts:AssumeRole"; Effect = "Allow"; Principal = { Service = "ecs-tasks.amazonaws.com" } }] })
}
resource "aws_iam_role_policy" "ecs_task_policy" {
  name = "${var.project_name}-ecs-task-policy"
  role = aws_iam_role.ecs_task.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      { Effect = "Allow"; Action = ["secretsmanager:GetSecretValue"]; Resource = "arn:aws:secretsmanager:${var.aws_region}:${data.aws_caller_identity.current.account_id}:secret:${var.project_name}/*" },
      { Effect = "Allow"; Action = ["s3:GetObject","s3:PutObject","s3:DeleteObject"]; Resource = "${aws_s3_bucket.assets.arn}/*" },
      { Effect = "Allow"; Action = ["logs:CreateLogGroup","logs:CreateLogStream","logs:PutLogEvents"]; Resource = "*" },
      { Effect = "Allow"; Action = ["xray:PutTraceSegments","xray:PutTelemetryRecords"]; Resource = "*" },
    ]
  })
}

# ECS Backend Service
resource "aws_ecs_task_definition" "backend" {
  family                   = "${var.project_name}-backend"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.backend_cpu
  memory                   = var.backend_memory
  execution_role_arn       = aws_iam_role.ecs_task_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    {
      name      = "backend"
      image     = "${data.aws_caller_identity.current.account_id}.dkr.ecr.${var.aws_region}.amazonaws.com/${var.project_name}-backend:latest"
      essential = true
      portMappings = [{ containerPort = 3000; protocol = "tcp" }]
      environment = [
        { name = "NODE_ENV";      value = "production" },
        { name = "PORT";          value = "3000" },
        { name = "REDIS_HOST";    value = aws_elasticache_replication_group.main.primary_endpoint_address },
        { name = "REDIS_PORT";    value = "6379" },
        { name = "DB_HOST";       value = aws_db_instance.primary.endpoint },
        { name = "DB_READ_HOST";  value = aws_db_instance.read_replica.endpoint },
      ]
      secrets = [
        { name = "DB_PASSWORD";       valueFrom = aws_secretsmanager_secret.db_password.arn },
        { name = "JWT_PRIVATE_KEY";   valueFrom = "${aws_secretsmanager_secret.jwt_keys.arn}:private_key::" },
        { name = "JWT_PUBLIC_KEY";    valueFrom = "${aws_secretsmanager_secret.jwt_keys.arn}:public_key::" },
        { name = "PORTAL_JWT_SECRET"; valueFrom = "${aws_secretsmanager_secret.portal_secret.arn}:secret::" },
      ]
      healthCheck = {
        command     = ["CMD-SHELL", "curl -f http://localhost:3000/api/v1/health || exit 1"]
        interval    = 30
        timeout     = 10
        retries     = 3
        startPeriod = 60
      }
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = "/ecs/${var.project_name}/backend"
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "backend"
        }
      }
      readonlyRootFilesystem = true
      user                   = "1000:1000"  # non-root container (Section 11)
      linuxParameters = { capabilities = { drop = ["ALL"] } }
    },
    {
      name      = "otel-collector"
      image     = "public.ecr.aws/aws-observability/aws-otel-collector:latest"
      essential = false
      command   = ["--config=/etc/ecs/ecs-default-config.yaml"]
      logConfiguration = {
        logDriver = "awslogs"
        options = { "awslogs-group" = "/ecs/${var.project_name}/otel"; "awslogs-region" = var.aws_region; "awslogs-stream-prefix" = "otel" }
      }
    }
  ])
}

resource "aws_ecs_service" "backend" {
  name                               = "${var.project_name}-backend"
  cluster                            = aws_ecs_cluster.main.id
  task_definition                    = aws_ecs_task_definition.backend.arn
  desired_count                      = var.backend_desired_count
  health_check_grace_period_seconds  = 120
  force_new_deployment               = true
  enable_execute_command             = false # disabled in production for security

  capacity_provider_strategy {
    base              = var.backend_min_count
    weight            = 80
    capacity_provider = "FARGATE"
  }
  capacity_provider_strategy {
    weight            = 20
    capacity_provider = "FARGATE_SPOT"
  }

  network_configuration {
    subnets          = aws_subnet.private[*].id
    security_groups  = [aws_security_group.backend.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.backend.arn
    container_name   = "backend"
    container_port   = 3000
  }

  deployment_circuit_breaker { enable = true; rollback = true }
  deployment_controller { type = "ECS" }

  lifecycle { ignore_changes = [desired_count] }
}

# ── Autoscaling (Section 6 — Scale progressively) ─────────────────────────

resource "aws_appautoscaling_target" "backend" {
  max_capacity       = var.backend_max_count
  min_capacity       = var.backend_min_count
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.backend.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

# Scale on CPU utilisation
resource "aws_appautoscaling_policy" "backend_cpu" {
  name               = "${var.project_name}-backend-cpu-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.backend.resource_id
  scalable_dimension = aws_appautoscaling_target.backend.scalable_dimension
  service_namespace  = aws_appautoscaling_target.backend.service_namespace
  target_tracking_scaling_policy_configuration {
    predefined_metric_specification { predefined_metric_type = "ECSServiceAverageCPUUtilization" }
    target_value       = 65.0
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
  }
}

# Scale on memory utilisation
resource "aws_appautoscaling_policy" "backend_memory" {
  name               = "${var.project_name}-backend-memory-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.backend.resource_id
  scalable_dimension = aws_appautoscaling_target.backend.scalable_dimension
  service_namespace  = aws_appautoscaling_target.backend.service_namespace
  target_tracking_scaling_policy_configuration {
    predefined_metric_specification { predefined_metric_type = "ECSServiceAverageMemoryUtilization" }
    target_value       = 75.0
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
  }
}

# ── S3 Buckets ────────────────────────────────────────────────────────────

resource "aws_s3_bucket" "assets" {
  bucket        = "${var.project_name}-${var.environment}-assets-${data.aws_caller_identity.current.account_id}"
  force_destroy = false
}
resource "aws_s3_bucket_versioning" "assets" { bucket = aws_s3_bucket.assets.id; versioning_configuration { status = "Enabled" } }
resource "aws_s3_bucket_server_side_encryption_configuration" "assets" {
  bucket = aws_s3_bucket.assets.id
  rule { apply_server_side_encryption_by_default { sse_algorithm = "aws:kms" } }
}
resource "aws_s3_bucket_public_access_block" "assets" {
  bucket = aws_s3_bucket.assets.id
  block_public_acls = true; block_public_policy = true
  ignore_public_acls = true; restrict_public_buckets = true
}

resource "aws_s3_bucket" "backups" {
  bucket        = "${var.project_name}-${var.environment}-backups-${data.aws_caller_identity.current.account_id}"
  force_destroy = false
}
resource "aws_s3_bucket_lifecycle_configuration" "backups" {
  bucket = aws_s3_bucket.backups.id
  rule {
    id     = "backup-lifecycle"
    status = "Enabled"
    transition         { days = 30;  storage_class = "STANDARD_IA" }
    transition         { days = 90;  storage_class = "GLACIER" }
    expiration         { days = 365 }
    filter { prefix = "daily/" }
  }
}

# ── Secrets Manager ───────────────────────────────────────────────────────

resource "aws_secretsmanager_secret" "jwt_keys" {
  name                    = "${var.project_name}/${var.environment}/jwt-keys"
  recovery_window_in_days = 7
}

resource "aws_secretsmanager_secret" "portal_secret" {
  name                    = "${var.project_name}/${var.environment}/portal-jwt-secret"
  recovery_window_in_days = 7
}

# ── CloudWatch Log Groups ─────────────────────────────────────────────────

resource "aws_cloudwatch_log_group" "backend" {
  name              = "/ecs/${var.project_name}/backend"
  retention_in_days = 90
}

# ── CloudFront CDN ────────────────────────────────────────────────────────

resource "aws_cloudfront_distribution" "frontend" {
  enabled             = true
  is_ipv6_enabled     = true
  default_root_object = "index.html"
  aliases             = [var.domain_name]

  origin {
    domain_name = aws_lb.main.dns_name
    origin_id   = "alb-origin"
    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "https-only"
      origin_ssl_protocols   = ["TLSv1.2"]
    }
  }

  default_cache_behavior {
    target_origin_id       = "alb-origin"
    viewer_protocol_policy = "redirect-to-https"
    allowed_methods        = ["DELETE","GET","HEAD","OPTIONS","PATCH","POST","PUT"]
    cached_methods         = ["GET","HEAD"]
    compress               = true
    cache_policy_id        = "658327ea-f89d-4fab-a63d-7e88639e58f6" # CachingOptimized
  }

  # No caching for API calls
  ordered_cache_behavior {
    path_pattern           = "/api/*"
    target_origin_id       = "alb-origin"
    viewer_protocol_policy = "redirect-to-https"
    allowed_methods        = ["DELETE","GET","HEAD","OPTIONS","PATCH","POST","PUT"]
    cached_methods         = ["GET","HEAD"]
    cache_policy_id        = "4135ea2d-6df8-44a3-9df3-4b5a84be39ad" # CachingDisabled
  }

  restrictions { geo_restriction { restriction_type = "none" } }
  viewer_certificate { acm_certificate_arn = aws_acm_certificate.main.arn; ssl_support_method = "sni-only"; minimum_protocol_version = "TLSv1.2_2021" }
}

# ── Outputs ───────────────────────────────────────────────────────────────

output "alb_dns_name"                 { value = aws_lb.main.dns_name }
output "cloudfront_domain"            { value = aws_cloudfront_distribution.frontend.domain_name }
output "rds_primary_endpoint"         { value = aws_db_instance.primary.endpoint; sensitive = true }
output "rds_replica_endpoint"         { value = aws_db_instance.read_replica.endpoint; sensitive = true }
output "redis_primary_endpoint"       { value = aws_elasticache_replication_group.main.primary_endpoint_address; sensitive = true }
output "ecs_cluster_name"             { value = aws_ecs_cluster.main.name }
output "assets_bucket"                { value = aws_s3_bucket.assets.bucket }
output "backups_bucket"               { value = aws_s3_bucket.backups.bucket }
output "vpc_id"                       { value = aws_vpc.main.id }
