#!/usr/bin/env bash
# AGCOMS DealerSync ERP — Terraform State Bootstrap
# Sprint 6 / S6-C: Creates the S3 bucket for Terraform remote state storage.
#
# This script must be run ONCE before `terraform init`.
# main.tf references s3://agcoms-tfstate-prod which must exist first.
#
# Prerequisites:
#   - AWS CLI configured: aws configure
#   - Sufficient IAM permissions: s3:CreateBucket, dynamodb:CreateTable
#
# Usage:
#   bash infrastructure/terraform/bootstrap/create-tfstate-bucket.sh
#   bash infrastructure/terraform/bootstrap/create-tfstate-bucket.sh --region eu-west-1

set -euo pipefail

AWS_REGION="${1:-eu-west-1}"
BUCKET_NAME="agcoms-tfstate-prod"
LOCK_TABLE="agcoms-tfstate-lock"
ENVIRONMENT="production"

echo "🚀 AGCOMS DealerSync ERP — Terraform State Bootstrap"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "  AWS Region:    ${AWS_REGION}"
echo "  S3 Bucket:     ${BUCKET_NAME}"
echo "  DynamoDB lock: ${LOCK_TABLE}"
echo ""

# Check AWS CLI
if ! command -v aws &>/dev/null; then
  echo "❌ AWS CLI not found. Install: https://aws.amazon.com/cli/"
  exit 1
fi

# Verify credentials
echo "  Verifying AWS credentials..."
AWS_ACCOUNT=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
if [ -z "$AWS_ACCOUNT" ]; then
  echo "❌ AWS credentials not configured. Run: aws configure"
  exit 1
fi
echo "  ✓ AWS Account: ${AWS_ACCOUNT}"
echo ""

# ── Create S3 bucket ──────────────────────────────────────────────────────
echo "  [1/4] Creating S3 state bucket..."
if aws s3api head-bucket --bucket "${BUCKET_NAME}" 2>/dev/null; then
  echo "  ✓ Bucket already exists: ${BUCKET_NAME}"
else
  if [ "${AWS_REGION}" = "us-east-1" ]; then
    aws s3api create-bucket \
      --bucket "${BUCKET_NAME}" \
      --region "${AWS_REGION}"
  else
    aws s3api create-bucket \
      --bucket "${BUCKET_NAME}" \
      --region "${AWS_REGION}" \
      --create-bucket-configuration LocationConstraint="${AWS_REGION}"
  fi
  echo "  ✓ Bucket created: ${BUCKET_NAME}"
fi

# Enable versioning (allows rollback of state files)
aws s3api put-bucket-versioning \
  --bucket "${BUCKET_NAME}" \
  --versioning-configuration Status=Enabled
echo "  ✓ Versioning enabled"

# Enable server-side encryption (AES-256)
aws s3api put-bucket-encryption \
  --bucket "${BUCKET_NAME}" \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "AES256"
      },
      "BucketKeyEnabled": true
    }]
  }'
echo "  ✓ Server-side encryption (AES-256)"

# Block all public access
aws s3api put-public-access-block \
  --bucket "${BUCKET_NAME}" \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
echo "  ✓ Public access blocked"

# Tag the bucket
aws s3api put-bucket-tagging \
  --bucket "${BUCKET_NAME}" \
  --tagging "TagSet=[{Key=Project,Value=DealerSync},{Key=Environment,Value=${ENVIRONMENT}},{Key=ManagedBy,Value=terraform}]"
echo "  ✓ Tags applied"

# ── Create DynamoDB lock table ─────────────────────────────────────────────
echo ""
echo "  [2/4] Creating DynamoDB lock table..."
if aws dynamodb describe-table --table-name "${LOCK_TABLE}" --region "${AWS_REGION}" 2>/dev/null; then
  echo "  ✓ Lock table already exists: ${LOCK_TABLE}"
else
  aws dynamodb create-table \
    --table-name "${LOCK_TABLE}" \
    --attribute-definitions AttributeName=LockID,AttributeType=S \
    --key-schema AttributeName=LockID,KeyType=HASH \
    --billing-mode PAY_PER_REQUEST \
    --region "${AWS_REGION}" \
    --tags Key=Project,Value=DealerSync Key=Environment,Value=${ENVIRONMENT}
  echo "  ✓ DynamoDB lock table created: ${LOCK_TABLE}"
fi

# ── Create Secrets Manager entries (empty — to be populated) ──────────────
echo ""
echo "  [3/4] Creating Secrets Manager entries..."
SECRETS=(
  "dealersync/prod/database-url"
  "dealersync/prod/jwt-keys"
  "dealersync/prod/anthropic-api-key"
  "dealersync/prod/whatsapp-credentials"
)

for secret in "${SECRETS[@]}"; do
  if aws secretsmanager describe-secret --secret-id "$secret" --region "${AWS_REGION}" 2>/dev/null; then
    echo "  ✓ Already exists: $secret"
  else
    aws secretsmanager create-secret \
      --name "$secret" \
      --description "AGCOMS DealerSync ERP production secret" \
      --region "${AWS_REGION}" \
      --tags Key=Project,Value=DealerSync Key=Environment,Value=production \
      > /dev/null
    echo "  ✓ Created (empty): $secret"
  fi
done

# ── Terraform init ─────────────────────────────────────────────────────────
echo ""
echo "  [4/4] Running terraform init..."
cd "$(dirname "$0")/.."
terraform init \
  -backend-config="bucket=${BUCKET_NAME}" \
  -backend-config="key=dealersync/production/terraform.tfstate" \
  -backend-config="region=${AWS_REGION}" \
  -backend-config="dynamodb_table=${LOCK_TABLE}" \
  -backend-config="encrypt=true"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Bootstrap complete"
echo ""
echo "  Next steps:"
echo "  1. Populate secrets in AWS Secrets Manager:"
echo "     aws secretsmanager put-secret-value --secret-id dealersync/prod/database-url --secret-string '...'"
echo "  2. Review and update variables in infrastructure/terraform/terraform.tfvars"
echo "  3. Run: terraform plan"
echo "  4. Run: terraform apply"
echo ""
echo "  S3 state: s3://${BUCKET_NAME}/dealersync/production/terraform.tfstate"
echo "  Lock table: ${LOCK_TABLE} (${AWS_REGION})"
