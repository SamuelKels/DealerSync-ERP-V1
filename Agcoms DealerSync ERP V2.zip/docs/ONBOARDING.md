# AGCOMS DealerSync ERP — Developer Onboarding Guide

**Version:** 3.0 · **Stack:** NestJS + Next.js 15 + PostgreSQL 16 + Redis 7  
**Company:** AGCOMS International Trading Limited · **HQ:** Abuja, Nigeria

---

## Quick start (7 steps)

### Step 1 — Prerequisites

Install these tools before cloning:

| Tool | Minimum version | Install |
|------|----------------|---------|
| Node.js | 20 LTS | [nodejs.org](https://nodejs.org) |
| pnpm | 9.x | `npm i -g pnpm` |
| Docker Desktop | 4.x | [docker.com](https://docker.com) |
| Git | 2.40+ | system package |

### Step 2 — Clone and install

```bash
git clone git@github.com:agcoms/dealersync-erp.git
cd dealersync-erp
pnpm install
```

### Step 3 — Start infrastructure

Start PostgreSQL, Redis, and MinIO locally with a single command:

```bash
cd infrastructure/docker
docker compose up -d postgres redis minio
```

Verify services are healthy:

```bash
docker compose ps
# All three should show "healthy"
```

### Step 4 — Environment variables

Copy the example env file and fill in secrets:

```bash
cp apps/backend/.env.example apps/backend/.env
cp apps/frontend/.env.example apps/frontend/.env.local
```

**Required backend variables:**

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://dealersync:secret@localhost:5432/dealersync_dev` |
| `REDIS_URL` | Redis connection | `redis://localhost:6379` |
| `JWT_PRIVATE_KEY` | RS256 private key (PEM) | Generate with script below |
| `JWT_PUBLIC_KEY` | RS256 public key (PEM) | Generated alongside private key |
| `AWS_S3_BUCKET` | S3 or MinIO bucket name | `dealersync-dev` |
| `S3_ENDPOINT` | MinIO endpoint (dev only) | `http://localhost:9000` |
| `NODE_ENV` | Environment | `development` |

Generate JWT RS256 key pair:

```bash
bash scripts/generate-keys.sh
# Writes keys to .keys/ directory — add to .env manually
```

### Step 5 — Database setup

Run migrations and seed demo data:

```bash
# Run Prisma migrations
pnpm --filter backend run db:migrate

# Seed all 14 modules with demo data
pnpm --filter backend run db:seed

# Create the first admin user
pnpm --filter backend run create:admin
```

### Step 6 — Start development servers

```bash
# Start everything in watch mode (Turborepo)
pnpm dev

# Or start individually:
pnpm --filter backend dev    # http://localhost:3001
pnpm --filter frontend dev   # http://localhost:3000
pnpm --filter portal dev     # http://localhost:3002
```

### Step 7 — Log in

| Role | Email | Password |
|------|-------|----------|
| Super Admin | `admin@agcoms.ng` | `DealerSync@2025!` |
| Finance Manager | `finance@agcoms.ng` | `DealerSync@2025!` |
| Sales Manager | `sales@agcoms.ng` | `DealerSync@2025!` |
| HR Manager | `hr@agcoms.ng` | `DealerSync@2025!` |
| Workshop Tech | `tech@agcoms.ng` | `DealerSync@2025!` |

> **Important:** Change all demo passwords in production. The seed script creates these for development only.

---

## Project structure

```
dealersync-erp/                 ← Turborepo monorepo root
├── apps/
│   ├── backend/                ← NestJS API (port 3001)
│   │   ├── src/
│   │   │   ├── modules/        ← 14 ERP domain modules
│   │   │   ├── common/         ← Guards, interceptors, decorators
│   │   │   ├── prisma/         ← Database service
│   │   │   └── main.ts
│   │   ├── prisma/
│   │   │   └── schema.prisma   ← Database schema
│   │   └── test/               ← Integration + unit tests
│   ├── frontend/               ← Next.js 15 ERP UI (port 3000)
│   │   └── src/app/(erp)/     ← All ERP pages
│   └── portal/                 ← Customer-facing portal (port 3002)
├── packages/
│   ├── ui/                     ← Shared React components + design tokens
│   ├── types/                  ← Shared TypeScript types (all 14 modules)
│   ├── validators/             ← Shared Zod schemas
│   └── config/                 ← Shared ESLint, Prettier, TS config
├── infrastructure/
│   ├── docker/                 ← docker-compose files
│   ├── terraform/              ← AWS ECS/Fargate IaC
│   └── nginx/                  ← Reverse proxy config
├── docs/
│   ├── adr/                    ← Architecture Decision Records (ADR-001–006)
│   ├── c4/                     ← C4 architecture diagrams
│   └── DEVELOPER.md            ← Full developer reference
└── scripts/                    ← Seed, migration, key-gen, health-check scripts
```

---

## Troubleshooting

| Problem | Likely cause | Fix |
|---------|-------------|-----|
| `ECONNREFUSED` to PostgreSQL | Docker not running | `docker compose up -d postgres` |
| `PrismaClientInitializationError` | Wrong `DATABASE_URL` | Check `.env` — port and DB name |
| JWT errors on login | Missing or wrong key files | Re-run `scripts/generate-keys.sh` |
| `Cannot find module '@agcoms/types'` | Packages not built | `pnpm build --filter @agcoms/types` |
| Frontend shows blank page | Backend not running | Start `pnpm --filter backend dev` |
| S3 upload fails in dev | MinIO not running | `docker compose up -d minio` |
| Migrations fail | DB schema drift | `pnpm --filter backend run db:reset` (dev only) |

---

## First PR checklist

Before opening a pull request:

- [ ] `pnpm lint` — zero errors
- [ ] `pnpm type-check` — zero errors  
- [ ] `pnpm test:unit` — all tests pass, coverage ≥ 80%
- [ ] New service-layer code has unit tests
- [ ] Prisma schema changes include a migration (`pnpm db:migrate`)
- [ ] Sensitive fields in response DTOs use `@Sensitive()` decorator
- [ ] Commits follow conventional format: `feat(crm): add lead scoring`
- [ ] Branch name: `feat/module-description` or `fix/issue-description`

---

## Getting help

- **Slack:** `#dealersync-engineering`
- **Architecture questions:** Read `docs/adr/` first
- **API docs:** [http://localhost:3001/api/docs](http://localhost:3001/api/docs) (Swagger)
- **Database schema:** Run `pnpm --filter backend run db:studio` for Prisma Studio

---

*Maintained by the AGCOMS Engineering team. Last updated: 2025.*
