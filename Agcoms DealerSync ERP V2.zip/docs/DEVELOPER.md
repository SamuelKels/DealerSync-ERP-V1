# AGCOMS DealerSync ERP — Developer Reference

**Version:** 3.0 · **Architecture:** Modular Monolith (NestJS) · **API:** REST / OpenAPI 3.0

---

## API conventions

### Base URL and versioning

All API routes are prefixed with `/api/v1`. This follows the master prompt §13 directive to use `/api/v1` with a future deprecation strategy.

```
https://api.dealersync.agcoms.ng/api/v1
```

### Authentication

Every protected endpoint requires a Bearer token:

```http
Authorization: Bearer <access_token>
```

Tokens are JWT RS256-signed (asymmetric). The `accessToken` (15-minute TTL) is returned in the login response body. The `refreshToken` (30-day TTL) is set as an `HttpOnly; SameSite=Strict` cookie and rotated on every `/auth/refresh` call.

### Pagination

All list endpoints use cursor-based pagination with a consistent envelope:

```json
{
  "data": {
    "items": [...],
    "total": 1234,
    "hasMore": true,
    "nextCursor": "eyJpZCI6..."
  }
}
```

Query parameters: `limit` (default 25, max 100), `cursor` (opaque string), `page` (integer, alternative to cursor).

### Response envelope

```json
{
  "data":      { ... },
  "meta":      { "timestamp": "...", "requestId": "..." },
  "error":     null
}
```

Error responses:

```json
{
  "data":  null,
  "error": {
    "code":    "VALIDATION_ERROR",
    "message": "Credit limit must be a positive number",
    "details": [...]
  }
}
```

### HTTP status codes used

| Code | Meaning |
|------|---------|
| 200 | Success (GET, PATCH) |
| 201 | Created (POST) |
| 204 | No content (DELETE) |
| 400 | Validation error / business rule violation |
| 401 | Missing or invalid authentication |
| 403 | Authenticated but lacks permission |
| 404 | Resource not found |
| 409 | Conflict (duplicate, concurrency violation) |
| 422 | Unprocessable entity (e.g., locked accounting period) |
| 429 | Rate limit exceeded |
| 500 | Internal server error |

---

## RBAC — permission reference

### Permission format

`module:action` — e.g. `crm:read`, `finance:write`, `hr:read_sensitive`.

### Built-in roles and their permissions

| Role | Key permissions |
|------|----------------|
| `SUPER_ADMIN` | All permissions, bypasses all guards |
| `DIRECTOR` | All read + most write + large discount approval |
| `FINANCE_MANAGER` | `finance:*`, `hr:read_sensitive`, journal approvals |
| `SALES_MANAGER` | `sales:*`, `crm:*`, discount up to 15% |
| `SALES_REP` | `sales:read`, `crm:read`, quote create, discount up to 5% |
| `PROCUREMENT_OFFICER` | `procurement:*`, `inventory:read` |
| `WORKSHOP_MANAGER` | `workshop:*`, `inventory:read` |
| `TECHNICIAN` | `workshop:job_cards:write`, `workshop:service_requests:read` |
| `HR_MANAGER` | `hr:*`, `hr:read_sensitive`, `hr:read_contact` |
| `STORE_KEEPER` | `inventory:*`, `procurement:grn:write` |
| `ACCOUNTANT` | `finance:read`, `finance:journals:write`, `ar:*`, `ap:*` |
| `CUSTOMER_PORTAL` | Portal-only permissions |

### Sensitive field permissions (§5 field-level masking)

| Permission | Fields revealed |
|-----------|----------------|
| `hr:read_sensitive` | grossSalary, basicSalary, netPay, paye, nhf, pension, bankAccountNo, nin, bvn, taxIdentification, pensionPin, cra, taxableIncome |
| `hr:read_contact` | personalEmail, personalPhone, homeAddress, nextOfKinName, nextOfKinPhone |
| `customers:read_financial` | creditLimit, creditUsed, availableCredit |

Fields without the required permission are replaced with `0` (numeric) or `"***"` (string) by `PiiMaskInterceptor`.

### Branch isolation

Every query that is not from a `SUPER_ADMIN` or `DIRECTOR` is automatically scoped to `branchId = user.branchId`. This is enforced at the service layer — not only at the guard level.

---

## Nigerian compliance reference

### PAYE — PITA 2011 tax bands

| Band | Taxable income | Rate |
|------|---------------|------|
| 1 | First ₦300,000 | 7% |
| 2 | Next ₦300,000 | 11% |
| 3 | Next ₦500,000 | 15% |
| 4 | Next ₦500,000 | 19% |
| 5 | Next ₦1,600,000 | 21% |
| 6 | Above ₦3,200,000 | 24% |

**CRA (Consolidated Relief Allowance):** `max(₦200,000, 1% of gross) + 20% of gross`  
Taxable income = gross salary − CRA − pension contributions.

Implementation: `FinanceService.calculateAnnualPaye()` and `calculateMonthlyPaye()`.

### Pension — PenCom Regulations

- **Employee contribution:** 8% of gross salary (minimum)
- **Employer contribution:** 10% of gross salary (minimum, PenCom 2014 amendment)
- **Deducted monthly** from payroll before PAYE calculation

Implementation: `HrService.computeNetPay()`.

### NHF — National Housing Fund

- **Rate:** 2.5% of basic salary (not gross)
- **Applicable to:** all employees earning above ₦3,000/month
- Remitted to Federal Mortgage Bank of Nigeria monthly

### VAT — Finance Act 2020

- **Standard rate:** 7.5% (increased from 5% by Finance Act 2019, effective 2020)
- Applied to: sales invoices, service invoices (where applicable)
- **VAT-exempt:** basic food items, medical services, educational materials, exported services

Implementation: `FinanceService.calculateVat()`.

### WHT — Withholding Tax

| Transaction type | Rate |
|-----------------|------|
| Contracts (supply of goods) | 5% |
| Consultancy / professional services | 10% |
| Technical services | 10% |
| Rent | 10% |

WHT is deducted at source by the paying entity. Implementation: `FinanceService.calculateWht()`.

---

## Service layer patterns

### Creating a new module

1. Generate the NestJS module: `nest generate module modules/your-module`
2. Create service, controller in `src/modules/your-module/`
3. Register in `AppModule`
4. Add Prisma model to `prisma/schema.prisma`
5. Run `pnpm --filter backend run db:migrate`
6. Add types to `packages/types/src/your-module.ts`
7. Add Zod validators to `packages/validators/src/schemas/your-module.ts`
8. Write unit tests in `src/modules/your-module/your-module.service.spec.ts`
9. Add integration tests in `test/integration/your-module/`

### Standard service method signature

```typescript
async createSomething(dto: CreateSomethingDto, actor: JwtPayload): Promise<Something> {
  // 1. Validate business rules
  // 2. ACID transaction (prisma.$transaction)
  // 3. Emit domain event (this.events.emit)
  // 4. Write audit log (this.audit.log)
  // 5. Return response DTO
}
```

### Audit logging

Every write operation must call `AuditService.log()`:

```typescript
await this.audit.log({
  action:      'customer.created',       // module.action format
  resource:    'Customer',
  entityId:    customer.id,
  actorId:     actor.sub,
  actorRole:   actor.roles[0],
  ipAddress:   actor.ipAddress,
  beforeState: null,                     // null for creates
  afterState:  { name, email, ... },
});
```

Audit entries are append-only (`AuditEntry` model has no update/delete).

### Domain events

Emit events after successful commits so other modules can react:

```typescript
this.events.emit('invoice.paid', {
  invoiceId:   invoice.id,
  invoiceNo:   invoice.invoiceNo,
  amountPaid:  payment.amount,
  branchId:    invoice.branchId,
});
```

Listeners are in `*.listener.ts` files in the relevant module directories.

### Financial transactions (ACID)

All financial operations use `prisma.$transaction()`:

```typescript
const result = await this.prisma.$transaction(async (tx) => {
  // All reads and writes within one transaction
  // If any step throws, the entire transaction rolls back
  const journal = await tx.journalEntry.create({ ... });
  await tx.journalLine.createMany({ ... });
  await tx.invoice.update({ ... });
  return journal;
});
```

**Never** update financial records outside a transaction. **Never** allow AI to trigger financial writes directly — all AI-generated financial actions must go through a human approval step first.

---

## AI governance

The `AiService` enforces these rules from §7 M13:

**Permitted actions** (AI may perform autonomously):
`summarize`, `recommend`, `draft`, `forecast`, `classify`

**Blocked actions** (always throw `ForbiddenException`):
`approve_financial_transaction`, `modify_inventory`, `alter_accounting_records`, `override_approval`, `bypass_rbac`

All AI responses are wrapped in an advisory envelope:

```json
{
  "recommendation": "...",
  "human_action_required": true,
  "governance": {
    "generated_at": "2025-01-15T10:30:00Z",
    "model":        "claude-sonnet-4-20250514",
    "disclaimer":   "This is an AI advisory only. Human approval required before any operational action."
  }
}
```

---

## Testing standards

### Unit tests

- Location: `src/**/*.service.spec.ts` (co-located with the service)
- Coverage target: ≥ 80% globally, ≥ 90% for `finance.service.ts`
- Run: `pnpm --filter backend test:unit`
- Mock all external dependencies (Prisma, Redis, events) — never hit real DB

### Integration tests (Supertest)

- Location: `test/integration/**/*.integration.spec.ts`
- Run against real test PostgreSQL (`DATABASE_URL` must contain `_test`)
- Run: `pnpm --filter backend test:integration`
- Use `globalThis.adminToken`, `globalThis.salesToken` for auth

### E2E tests (Playwright)

- Location: `tests/e2e/`
- Run: `pnpm --filter frontend test:e2e`
- Requires both backend and frontend running

---

*Questions? See `docs/adr/` for architectural decisions, or ping `#dealersync-engineering` on Slack.*
