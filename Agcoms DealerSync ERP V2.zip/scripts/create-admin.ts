/**
 * AGCOMS DealerSync ERP — Create Admin User
 * §12 /scripts directory
 *
 * Creates the first SuperAdmin user for a fresh installation.
 * Interactive — prompts for email and password securely.
 * Idempotent — updates existing user if email already exists.
 *
 * Usage:
 *   npx ts-node scripts/create-admin.ts
 *   # Or with pre-set env vars (for CI):
 *   ADMIN_EMAIL=admin@agcoms.ng ADMIN_PASS=SecureP@ss123 npx ts-node scripts/create-admin.ts --non-interactive
 */

import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as readline from 'readline';

const prisma = new PrismaClient();

function question(rl: readline.Interface, prompt: string): Promise<string> {
  return new Promise(resolve => rl.question(prompt, resolve));
}

function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(password: string): { valid: boolean; reason?: string } {
  if (password.length < 12)              return { valid: false, reason: 'Must be at least 12 characters' };
  if (!/[A-Z]/.test(password))          return { valid: false, reason: 'Must contain at least one uppercase letter' };
  if (!/[a-z]/.test(password))          return { valid: false, reason: 'Must contain at least one lowercase letter' };
  if (!/[0-9]/.test(password))          return { valid: false, reason: 'Must contain at least one number' };
  if (!/[!@#$%^&*()_+\-=\[\]{}]/.test(password)) return { valid: false, reason: 'Must contain at least one special character' };
  return { valid: true };
}

async function main() {
  const nonInteractive = process.argv.includes('--non-interactive');

  console.log('');
  console.log('👤 AGCOMS DealerSync ERP — Create Super Admin');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('');

  let email    = process.env['ADMIN_EMAIL'] ?? '';
  let password = process.env['ADMIN_PASS']  ?? '';
  let firstName = process.env['ADMIN_FIRST'] ?? 'System';
  let lastName  = process.env['ADMIN_LAST']  ?? 'Administrator';

  if (!nonInteractive) {
    const rl = readline.createInterface({
      input:  process.stdin,
      output: process.stdout,
    });

    // Email
    while (!validateEmail(email)) {
      email = (await question(rl, '  Email address: ')).trim();
      if (!validateEmail(email)) console.log('  ⚠️  Invalid email format. Try again.');
    }

    // Names
    firstName = (await question(rl, `  First name [${firstName}]: `)).trim() || firstName;
    lastName  = (await question(rl, `  Last name  [${lastName}]: `)).trim()  || lastName;

    // Password (hidden input via process.stdout manipulation)
    let passwordValid = false;
    while (!passwordValid) {
      process.stdout.write('  Password (min 12 chars, mixed case, number, special): ');
      password = (await question(rl, '')).trim();
      const { valid, reason } = validatePassword(password);
      if (!valid) {
        console.log(`  ⚠️  ${reason}. Try again.`);
      } else {
        const confirm = (await question(rl, '  Confirm password: ')).trim();
        if (confirm !== password) {
          console.log('  ⚠️  Passwords do not match. Try again.');
        } else {
          passwordValid = true;
        }
      }
    }

    rl.close();
  } else {
    // Non-interactive: validate from env
    if (!validateEmail(email)) {
      console.error('❌ ADMIN_EMAIL is not a valid email address');
      process.exit(1);
    }
    const { valid, reason } = validatePassword(password);
    if (!valid) {
      console.error(`❌ ADMIN_PASS is invalid: ${reason}`);
      process.exit(1);
    }
  }

  console.log('');
  console.log('  Creating admin user…');

  // Ensure SUPER_ADMIN role exists
  const role = await prisma.role.upsert({
    where:  { name: 'SUPER_ADMIN' },
    update: {},
    create: { name: 'SUPER_ADMIN', displayName: 'Super Administrator' },
  });

  // Ensure HQ branch exists
  const branch = await prisma.branch.upsert({
    where:  { code: 'ABJ' },
    update: {},
    create: { name: 'Abuja HQ', code: 'ABJ', address: 'Abuja, Nigeria', isActive: true, isHeadquarters: true },
  });

  // Create or update admin user
  const hashedPassword = bcrypt.hashSync(password, 12);
  const user = await prisma.user.upsert({
    where:  { email },
    update: {
      firstName,
      lastName,
      password:    hashedPassword,
      roleId:      role.id,
      isSuperAdmin: true,
      isActive:    true,
    },
    create: {
      email,
      firstName,
      lastName,
      password:    hashedPassword,
      roleId:      role.id,
      branchId:    branch.id,
      isSuperAdmin: true,
      isActive:    true,
      mfaEnabled:  false,
    },
  });

  console.log('');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('✅ Super Admin created successfully');
  console.log('');
  console.log(`  ID:         ${user.id}`);
  console.log(`  Email:      ${user.email}`);
  console.log(`  Name:       ${user.firstName} ${user.lastName}`);
  console.log(`  Role:       SUPER_ADMIN`);
  console.log(`  Branch:     ${branch.name}`);
  console.log('');
  console.log('  Log in at:  http://localhost:3000/login');
  console.log('');
  console.log('  ⚠️  Store the password securely — it cannot be recovered.');
}

main()
  .catch(e => {
    console.error('❌ Failed to create admin:', e instanceof Error ? e.message : e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
