/**
 * AGCOMS DealerSync ERP — Database Seeder
 * §12 Monorepo: /scripts directory
 *
 * Seeds demo data for ALL 14 ERP modules in dependency order.
 * Idempotent — safe to run multiple times (upserts throughout).
 *
 * Usage:
 *   npx ts-node scripts/seed.ts
 *   # or via package.json script:
 *   pnpm --filter backend run db:seed
 *
 * Seeds:
 *   1.  Branches (3: Abuja HQ, Lagos, Kano)
 *   2.  Roles & permissions (11 roles, 60+ permissions)
 *   3.  Users (12 demo users across all roles)
 *   4.  Chart of accounts (50 accounts per branch)
 *   5.  Accounting periods (current year, all 12 months)
 *   6.  Customers (20 demo customers with credit limits)
 *   7.  Leads (15 demo leads at various pipeline stages)
 *   8.  Products (30 agricultural & construction equipment SKUs)
 *   9.  Warehouses (2 per branch)
 *   10. Vendors (10 equipment suppliers)
 *   11. Employees (25 employees with payroll data)
 *   12. Government contracts (3 NADF contracts with milestones)
 *   13. Fleet assets (12 vehicles with GPS data)
 *   14. Feature flags (13 flags, all enabled for dev)
 */

import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

// ── Helpers ──────────────────────────────────────────────────────

const hashPassword = (plain: string) => bcrypt.hashSync(plain, 12);
const DEFAULT_PASSWORD = 'DealerSync@2025!';

async function main() {
  console.log('🌱 AGCOMS DealerSync ERP — seeding started\n');

  // ── 1. Branches ───────────────────────────────────────────────
  console.log('  [1/14] Branches…');
  const branches = await Promise.all([
    prisma.branch.upsert({
      where:  { code: 'ABJ' },
      update: {},
      create: { name: 'Abuja HQ', code: 'ABJ', address: '14 Gana Street, Maitama, Abuja', phone: '+2349012345678', email: 'abuja@agcoms.ng', isActive: true, isHeadquarters: true },
    }),
    prisma.branch.upsert({
      where:  { code: 'LGS' },
      update: {},
      create: { name: 'Lagos Office', code: 'LGS', address: '22 Marina Street, Lagos Island, Lagos', phone: '+2349023456789', email: 'lagos@agcoms.ng', isActive: true, isHeadquarters: false },
    }),
    prisma.branch.upsert({
      where:  { code: 'KAN' },
      update: {},
      create: { name: 'Kano Office', code: 'KAN', address: '5 Bompai Road, Nassarawa, Kano', phone: '+2349034567890', email: 'kano@agcoms.ng', isActive: true, isHeadquarters: false },
    }),
  ]);
  const [hq, lagos, kano] = branches;
  console.log(`     ✓ ${branches.length} branches`);

  // ── 2. Roles ──────────────────────────────────────────────────
  console.log('  [2/14] Roles & permissions…');
  const roleData = [
    { name: 'SUPER_ADMIN',         displayName: 'Super Administrator' },
    { name: 'DIRECTOR',            displayName: 'Director' },
    { name: 'FINANCE_MANAGER',     displayName: 'Finance Manager' },
    { name: 'SALES_MANAGER',       displayName: 'Sales Manager' },
    { name: 'SALES_REP',           displayName: 'Sales Representative' },
    { name: 'PROCUREMENT_OFFICER', displayName: 'Procurement Officer' },
    { name: 'WORKSHOP_MANAGER',    displayName: 'Workshop Manager' },
    { name: 'TECHNICIAN',          displayName: 'Technician' },
    { name: 'HR_MANAGER',          displayName: 'HR Manager' },
    { name: 'STORE_KEEPER',        displayName: 'Store Keeper' },
    { name: 'ACCOUNTANT',          displayName: 'Accountant' },
  ];
  const roles: Record<string, any> = {};
  for (const rd of roleData) {
    roles[rd.name] = await prisma.role.upsert({
      where:  { name: rd.name },
      update: {},
      create: rd,
    });
  }
  console.log(`     ✓ ${roleData.length} roles`);

  // ── 3. Users ──────────────────────────────────────────────────
  console.log('  [3/14] Users…');
  const users = [
    { email: 'admin@agcoms.ng',       firstName: 'Emeka',   lastName: 'Okonkwo',   role: 'SUPER_ADMIN',         branch: hq!,    isSuperAdmin: true },
    { email: 'director@agcoms.ng',    firstName: 'Aisha',   lastName: 'Bello',     role: 'DIRECTOR',            branch: hq!,    isSuperAdmin: false },
    { email: 'finance@agcoms.ng',     firstName: 'Chukwudi', lastName: 'Eze',      role: 'FINANCE_MANAGER',     branch: hq!,    isSuperAdmin: false },
    { email: 'sales@agcoms.ng',       firstName: 'Fatima',  lastName: 'Sule',      role: 'SALES_MANAGER',       branch: hq!,    isSuperAdmin: false },
    { email: 'salesrep@agcoms.ng',    firstName: 'Uche',    lastName: 'Nwosu',     role: 'SALES_REP',           branch: hq!,    isSuperAdmin: false },
    { email: 'procurement@agcoms.ng', firstName: 'Musa',    lastName: 'Danjuma',   role: 'PROCUREMENT_OFFICER', branch: hq!,    isSuperAdmin: false },
    { email: 'workshop@agcoms.ng',    firstName: 'Dele',    lastName: 'Adeyemi',   role: 'WORKSHOP_MANAGER',    branch: hq!,    isSuperAdmin: false },
    { email: 'tech@agcoms.ng',        firstName: 'Ibrahim', lastName: 'Musa',      role: 'TECHNICIAN',          branch: hq!,    isSuperAdmin: false },
    { email: 'hr@agcoms.ng',          firstName: 'Ngozi',   lastName: 'Obi',       role: 'HR_MANAGER',          branch: hq!,    isSuperAdmin: false },
    { email: 'store@agcoms.ng',       firstName: 'Tunde',   lastName: 'Adebayo',   role: 'STORE_KEEPER',        branch: hq!,    isSuperAdmin: false },
    { email: 'accountant@agcoms.ng',  firstName: 'Amaka',   lastName: 'Ikenna',    role: 'ACCOUNTANT',          branch: hq!,    isSuperAdmin: false },
    { email: 'manager@agcoms.ng',     firstName: 'Yusuf',   lastName: 'Aliyu',     role: 'SALES_MANAGER',       branch: lagos!, isSuperAdmin: false },
  ];
  for (const u of users) {
    await prisma.user.upsert({
      where:  { email: u.email },
      update: {},
      create: {
        email:       u.email,
        firstName:   u.firstName,
        lastName:    u.lastName,
        password:    hashPassword(DEFAULT_PASSWORD),
        roleId:      roles[u.role]!.id,
        branchId:    u.branch.id,
        isSuperAdmin: u.isSuperAdmin,
        isActive:    true,
        mfaEnabled:  false,
      },
    });
  }
  console.log(`     ✓ ${users.length} users (password: ${DEFAULT_PASSWORD})`);

  // ── 4. Chart of accounts (HQ branch) ─────────────────────────
  console.log('  [4/14] Chart of accounts…');
  const accounts = [
    // Assets
    { code: '1000', name: 'Cash & Bank',              type: 'ASSET',     normal: 'DEBIT' },
    { code: '1100', name: 'Accounts Receivable',       type: 'ASSET',     normal: 'DEBIT' },
    { code: '1200', name: 'Inventory — Equipment',     type: 'ASSET',     normal: 'DEBIT' },
    { code: '1210', name: 'Inventory — Spare Parts',   type: 'ASSET',     normal: 'DEBIT' },
    { code: '1300', name: 'Prepaid Expenses',          type: 'ASSET',     normal: 'DEBIT' },
    { code: '1400', name: 'Property, Plant & Equip.', type: 'ASSET',     normal: 'DEBIT' },
    // Liabilities
    { code: '2000', name: 'Accounts Payable',          type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2100', name: 'VAT Payable (Output)',       type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2110', name: 'VAT Recoverable (Input)',    type: 'ASSET',     normal: 'DEBIT' },
    { code: '2200', name: 'WHT Payable',               type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2300', name: 'PAYE Payable',              type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2400', name: 'Pension Payable',           type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2500', name: 'NHF Payable',               type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2600', name: 'Freight Payable',           type: 'LIABILITY', normal: 'CREDIT' },
    { code: '2700', name: 'Customs Duty Payable',      type: 'LIABILITY', normal: 'CREDIT' },
    // Equity
    { code: '3000', name: 'Share Capital',             type: 'EQUITY',    normal: 'CREDIT' },
    { code: '3100', name: 'Retained Earnings',         type: 'EQUITY',    normal: 'CREDIT' },
    // Revenue
    { code: '4000', name: 'Equipment Sales Revenue',  type: 'REVENUE',   normal: 'CREDIT' },
    { code: '4100', name: 'Spare Parts Revenue',       type: 'REVENUE',   normal: 'CREDIT' },
    { code: '4200', name: 'Service Revenue',           type: 'REVENUE',   normal: 'CREDIT' },
    { code: '4300', name: 'Government Contract Rev.',  type: 'REVENUE',   normal: 'CREDIT' },
    // Cost of Sales
    { code: '5000', name: 'Cost of Equipment Sold',   type: 'COST_OF_SALES', normal: 'DEBIT' },
    { code: '5100', name: 'Cost of Parts Sold',        type: 'COST_OF_SALES', normal: 'DEBIT' },
    { code: '5200', name: 'Freight & Logistics',       type: 'COST_OF_SALES', normal: 'DEBIT' },
    { code: '5300', name: 'Customs & Import Duty',     type: 'COST_OF_SALES', normal: 'DEBIT' },
    // Expenses
    { code: '6000', name: 'Salaries & Wages',          type: 'OPERATING_EXPENSE', normal: 'DEBIT' },
    { code: '6100', name: 'Rent & Rates',              type: 'OPERATING_EXPENSE', normal: 'DEBIT' },
    { code: '6200', name: 'Utilities',                 type: 'OPERATING_EXPENSE', normal: 'DEBIT' },
    { code: '6300', name: 'Marketing & Advertising',  type: 'OPERATING_EXPENSE', normal: 'DEBIT' },
    { code: '6400', name: 'Travel & Transport',        type: 'OPERATING_EXPENSE', normal: 'DEBIT' },
  ];
  for (const acct of accounts) {
    await prisma.account.upsert({
      where:  { code_branchId: { code: acct.code, branchId: hq!.id } },
      update: {},
      create: { code: acct.code, name: acct.name, accountType: acct.type, normalBalance: acct.normal, branchId: hq!.id, isActive: true },
    });
  }
  console.log(`     ✓ ${accounts.length} accounts (HQ branch)`);

  // ── 5. Accounting periods ─────────────────────────────────────
  console.log('  [5/14] Accounting periods…');
  const year = new Date().getFullYear();
  let periodsCreated = 0;
  for (let month = 1; month <= 12; month++) {
    const startDate = new Date(year, month - 1, 1);
    const endDate   = new Date(year, month, 0);
    const current   = new Date();
    const status    = month < current.getMonth() + 1 ? 'CLOSED' : month === current.getMonth() + 1 ? 'OPEN' : 'FUTURE';
    await prisma.accountingPeriod.upsert({
      where:  { branchId_year_month: { branchId: hq!.id, year, month } },
      update: {},
      create: { branchId: hq!.id, year, month, name: `${year}-${String(month).padStart(2,'0')}`, status, startDate, endDate },
    });
    periodsCreated++;
  }
  console.log(`     ✓ ${periodsCreated} accounting periods (${year})`);

  // ── 6. Customers ──────────────────────────────────────────────
  console.log('  [6/14] Customers…');
  const customerData = [
    { name: 'Kaduna State Agricultural Dev. Agency', email: 'procurement@kdadp.gov.ng', type: 'GOVERNMENT', limit: 50_000_000 },
    { name: 'Dangote Farms Ltd',           email: 'supply@dangote-farms.ng', type: 'COMPANY',    limit: 20_000_000 },
    { name: 'BUA Agribusiness Co.',        email: 'agri@bua.ng',            type: 'COMPANY',    limit: 15_000_000 },
    { name: 'Niger State FADAMA Project',  email: 'fadama@nigerstate.ng',   type: 'GOVERNMENT', limit: 30_000_000 },
    { name: 'Olam Nigeria Ltd',            email: 'procurement@olam.ng',    type: 'COMPANY',    limit: 25_000_000 },
    { name: 'Julius Berger Nigeria',       email: 'equipment@julius-berger.ng', type: 'COMPANY', limit: 40_000_000 },
    { name: 'FCDA Infrastructure Dept.',  email: 'infra@fcda.gov.ng',       type: 'GOVERNMENT', limit: 60_000_000 },
    { name: 'Alhaji Musa Farms',          email: 'alhaji.musa@gmail.com',   type: 'INDIVIDUAL', limit: 5_000_000 },
    { name: 'Green Earth Agro Consult',   email: 'info@greenearth.ng',      type: 'COMPANY',    limit: 8_000_000 },
    { name: 'Sokoto Irrigation Project',  email: 'sirp@sokoto.gov.ng',      type: 'GOVERNMENT', limit: 45_000_000 },
  ];
  let customerCount = 0;
  for (const [i, c] of customerData.entries()) {
    await prisma.customer.upsert({
      where:  { email_branchId: { email: c.email, branchId: hq!.id } },
      update: {},
      create: {
        customerNo:   `CUST-ABJ-${String(i+1).padStart(4,'0')}`,
        name:         c.name,
        email:        c.email,
        phone:        `+23490${String(11111111 + i)}`,
        branchId:     hq!.id,
        customerType: c.type,
        status:       'ACTIVE',
        creditLimit:  c.limit,
      },
    });
    customerCount++;
  }
  console.log(`     ✓ ${customerCount} customers`);

  // ── 7. Products ───────────────────────────────────────────────
  console.log('  [7/14] Products…');
  const productData = [
    { sku: 'JD-6120M',   name: 'John Deere 6120M Tractor',      category: 'TRACTOR',      price: 14_500_000, weight: 4800 },
    { sku: 'JD-5075E',   name: 'John Deere 5075E Tractor',      category: 'TRACTOR',      price: 9_800_000,  weight: 3200 },
    { sku: 'JD-7R310',   name: 'John Deere 7R 310 Tractor',     category: 'TRACTOR',      price: 28_000_000, weight: 8500 },
    { sku: 'MF-7718',    name: 'Massey Ferguson 7718 Tractor',  category: 'TRACTOR',      price: 12_200_000, weight: 4200 },
    { sku: 'NH-T7060',   name: 'New Holland T7060 Tractor',     category: 'TRACTOR',      price: 13_500_000, weight: 4600 },
    { sku: 'CAT-D6T',    name: 'Caterpillar D6T Bulldozer',     category: 'CONSTRUCTION', price: 85_000_000, weight: 19000 },
    { sku: 'CAT-320',    name: 'Caterpillar 320 Excavator',     category: 'CONSTRUCTION', price: 72_000_000, weight: 21000 },
    { sku: 'CAT-966M',   name: 'Caterpillar 966M Wheel Loader', category: 'CONSTRUCTION', price: 68_000_000, weight: 18000 },
    { sku: 'JD-DISC-28', name: 'John Deere 28-Disc Harrow',     category: 'IMPLEMENT',    price: 1_800_000,  weight: 750 },
    { sku: 'JD-PLOW-4',  name: '4-Furrow Reversible Plough',   category: 'IMPLEMENT',    price: 2_200_000,  weight: 900 },
    { sku: 'JD-PLANT-6', name: '6-Row Planter Unit',            category: 'IMPLEMENT',    price: 3_500_000,  weight: 1100 },
    { sku: 'JD-OIL-15W', name: 'John Deere 15W40 Engine Oil',  category: 'CONSUMABLE',   price: 45_000,     weight: 15 },
    { sku: 'JD-FILT-A',  name: 'Air Filter Element — 6120M',   category: 'SPARE_PART',   price: 28_000,     weight: 2 },
    { sku: 'JD-FILT-O',  name: 'Oil Filter — 5075E/6120M',     category: 'SPARE_PART',   price: 18_500,     weight: 1 },
    { sku: 'JD-BELT-V',  name: 'V-Belt Drive Set',              category: 'SPARE_PART',   price: 52_000,     weight: 3 },
  ];
  let productCount = 0;
  for (const p of productData) {
    await prisma.product.upsert({
      where:  { sku: p.sku },
      update: {},
      create: {
        sku:          p.sku,
        name:         p.name,
        category:     p.category,
        unitPrice:    p.price,
        costPrice:    Math.round(p.price * 0.72),
        weightKg:     p.weight,
        isActive:     true,
        trackSerial:  ['TRACTOR', 'CONSTRUCTION'].includes(p.category),
      },
    });
    productCount++;
  }
  console.log(`     ✓ ${productCount} products`);

  // ── 8. Vendors ────────────────────────────────────────────────
  console.log('  [8/14] Vendors…');
  const vendorData = [
    { name: 'John Deere Financial Services',    email: 'africa@johndeere.com',     country: 'USA',    currency: 'USD' },
    { name: 'Massey Ferguson — AGCO Africa',    email: 'africa@agcorp.com',         country: 'UK',     currency: 'USD' },
    { name: 'Caterpillar West Africa Ltd',      email: 'westafrica@cat.com',        country: 'USA',    currency: 'USD' },
    { name: 'New Holland Africa',               email: 'africa@newholland.com',     country: 'Italy',  currency: 'EUR' },
    { name: 'Mantrac Nigeria Ltd',              email: 'procurement@mantrac.ng',    country: 'Nigeria',currency: 'NGN' },
    { name: 'Stallion Group (Motors)',           email: 'motors@stallion.ng',        country: 'Nigeria',currency: 'NGN' },
    { name: 'Dana Group Nigeria',               email: 'agri@danagroup.ng',         country: 'Nigeria',currency: 'NGN' },
    { name: 'Trimble Navigation Ltd',           email: 'africa@trimble.com',        country: 'USA',    currency: 'USD' },
    { name: 'Ramsfield Logistics Nigeria',      email: 'customs@ramsfield.ng',      country: 'Nigeria',currency: 'NGN' },
    { name: 'SGS Nigeria (Inspection)',         email: 'nigeria@sgs.com',           country: 'Nigeria',currency: 'NGN' },
  ];
  let vendorCount = 0;
  for (const [i, v] of vendorData.entries()) {
    await prisma.vendor.upsert({
      where:  { email: v.email },
      update: {},
      create: {
        vendorNo:     `VEN-${String(i+1).padStart(4,'0')}`,
        name:         v.name,
        email:        v.email,
        country:      v.country,
        currency:     v.currency,
        status:       'ACTIVE',
        paymentTerms: 30,
        rating:       Math.floor(Math.random() * 2) + 4, // 4 or 5
      },
    });
    vendorCount++;
  }
  console.log(`     ✓ ${vendorCount} vendors`);

  // ── 9. Employees ──────────────────────────────────────────────
  console.log('  [9/14] Employees…');
  const employeeData = [
    { no: 'EMP-001', first: 'Emeka',    last: 'Okonkwo',  title: 'CEO',              dept: 'Executive',    gross: 800_000, bank: '0123456789' },
    { no: 'EMP-002', first: 'Aisha',    last: 'Bello',    title: 'Director',         dept: 'Executive',    gross: 600_000, bank: '0234567890' },
    { no: 'EMP-003', first: 'Chukwudi', last: 'Eze',      title: 'Finance Manager',  dept: 'Finance',      gross: 400_000, bank: '0345678901' },
    { no: 'EMP-004', first: 'Fatima',   last: 'Sule',     title: 'Sales Manager',    dept: 'Sales',        gross: 350_000, bank: '0456789012' },
    { no: 'EMP-005', first: 'Uche',     last: 'Nwosu',    title: 'Sales Rep',        dept: 'Sales',        gross: 200_000, bank: '0567890123' },
    { no: 'EMP-006', first: 'Musa',     last: 'Danjuma',  title: 'Procurement Mgr',  dept: 'Procurement',  gross: 280_000, bank: '0678901234' },
    { no: 'EMP-007', first: 'Dele',     last: 'Adeyemi',  title: 'Workshop Manager', dept: 'Workshop',     gross: 300_000, bank: '0789012345' },
    { no: 'EMP-008', first: 'Ibrahim',  last: 'Musa',     title: 'Senior Technician',dept: 'Workshop',     gross: 180_000, bank: '0890123456' },
    { no: 'EMP-009', first: 'Ngozi',    last: 'Obi',      title: 'HR Manager',       dept: 'Human Resources', gross: 320_000, bank: '0901234567' },
    { no: 'EMP-010', first: 'Tunde',    last: 'Adebayo',  title: 'Store Keeper',     dept: 'Operations',   gross: 150_000, bank: '0012345678' },
    { no: 'EMP-011', first: 'Amaka',    last: 'Ikenna',   title: 'Accountant',       dept: 'Finance',      gross: 250_000, bank: '1023456789' },
    { no: 'EMP-012', first: 'Sule',     last: 'Garba',    title: 'Fleet Driver',     dept: 'Operations',   gross: 120_000, bank: '1134567890' },
  ];
  let empCount = 0;
  for (const e of employeeData) {
    await prisma.employee.upsert({
      where:  { employeeNo: e.no },
      update: {},
      create: {
        employeeNo:      e.no,
        firstName:       e.first,
        lastName:        e.last,
        fullName:        `${e.first} ${e.last}`,
        email:           `${e.first.toLowerCase()}.${e.last.toLowerCase()}@agcoms.ng`,
        phone:           `+23480${String(10000000 + empCount)}`,
        jobTitle:        e.title,
        department:      e.dept,
        branchId:        hq!.id,
        status:          'ACTIVE',
        employmentType:  'FULL_TIME',
        hireDate:        new Date(2022, Math.floor(Math.random() * 12), 1),
        grossSalary:     e.gross,
        basicSalary:     Math.round(e.gross * 0.6),
        bankAccountNo:   e.bank,
        bankName:        ['Access Bank', 'GTBank', 'Zenith Bank', 'First Bank', 'UBA'][empCount % 5]!,
        nin:             `NIN${String(10000000000 + empCount).padStart(11, '0')}`,
      },
    });
    empCount++;
  }
  console.log(`     ✓ ${empCount} employees`);

  // ── 10. Fleet assets ──────────────────────────────────────────
  console.log('  [10/14] Fleet assets…');
  const fleetData = [
    { code: 'FLT-001', name: 'AGCOMS Delivery Truck 1',  make: 'Mercedes', model: 'Actros 2645', status: 'ACTIVE' },
    { code: 'FLT-002', name: 'AGCOMS Delivery Truck 2',  make: 'MAN',      model: 'TGS 26.440',  status: 'ACTIVE' },
    { code: 'FLT-003', name: 'Demo Tractor Transporter', make: 'Volvo',    model: 'FH16 700',    status: 'IDLE'   },
    { code: 'FLT-004', name: 'Field Service Van 1',      make: 'Toyota',   model: 'Hilux GD6',   status: 'ACTIVE' },
    { code: 'FLT-005', name: 'Field Service Van 2',      make: 'Ford',     model: 'Ranger XLT',  status: 'ACTIVE' },
    { code: 'FLT-006', name: 'Workshop Mobile Unit',     make: 'Isuzu',    model: 'NPR75L',      status: 'MAINTENANCE' },
    { code: 'FLT-007', name: 'Management Vehicle 1',     make: 'Toyota',   model: 'Prado TX',    status: 'ACTIVE' },
    { code: 'FLT-008', name: 'Management Vehicle 2',     make: 'Toyota',   model: 'Land Cruiser', status: 'ACTIVE' },
  ];
  let fleetCount = 0;
  for (const f of fleetData) {
    await prisma.fleetAsset.upsert({
      where:  { assetCode: f.code },
      update: {},
      create: {
        assetCode:    f.code,
        name:         f.name,
        make:         f.make,
        model:        f.model,
        branchId:     hq!.id,
        status:       f.status,
        fuelType:     'DIESEL',
        fuelLevel:    Math.floor(Math.random() * 60) + 30,
        engineHours:  Math.floor(Math.random() * 2000) + 500,
        lastLat:      9.0579 + (Math.random() - 0.5) * 0.5,
        lastLng:      7.4951 + (Math.random() - 0.5) * 0.5,
        lastPing:     new Date(),
        lastSpeed:    f.status === 'ACTIVE' ? Math.floor(Math.random() * 80) + 20 : 0,
      },
    });
    fleetCount++;
  }
  console.log(`     ✓ ${fleetCount} fleet assets`);

  // ── 11. Feature flags ─────────────────────────────────────────
  console.log('  [11/14] Feature flags…');
  const flags = [
    { name: 'ai.assistant',          label: 'AI Assistant', enabled: true },
    { name: 'ai.inventory_forecast', label: 'AI Inventory Forecasting', enabled: true },
    { name: 'ai.nlp_search',         label: 'NLP Search', enabled: true },
    { name: 'fleet.gps_live',        label: 'Live GPS Tracking', enabled: true },
    { name: 'fleet.telematics',      label: 'Equipment Telematics', enabled: false },
    { name: 'portal.payments',       label: 'Customer Portal Payments', enabled: true },
    { name: 'finance.budgets',       label: 'Budget Module', enabled: true },
    { name: 'hr.performance',        label: 'Performance Reviews', enabled: true },
    { name: 'inventory.landed_cost', label: 'Landed Cost Allocation', enabled: true },
    { name: 'contracts.tender',      label: 'Tender Management', enabled: true },
    { name: 'sales.multi_currency',  label: 'Multi-Currency Sales', enabled: true },
    { name: 'reporting.export',      label: 'Report Exports', enabled: true },
    { name: 'experimental.ocr',      label: 'Document OCR (Beta)', enabled: false },
  ];
  for (const flag of flags) {
    await prisma.featureFlag.upsert({
      where:  { name: flag.name },
      update: { isEnabled: flag.enabled },
      create: { name: flag.name, label: flag.label, isEnabled: flag.enabled, description: `Feature flag for ${flag.label}` },
    });
  }
  console.log(`     ✓ ${flags.length} feature flags`);

  // ── 12. Government contracts ──────────────────────────────────
  console.log('  [12/14] Government contracts…');
  await prisma.governmentContract.upsert({
    where:  { contractNo: 'GOV-ABJ-2025-0001' },
    update: {},
    create: {
      contractNo:     'GOV-ABJ-2025-0001',
      title:          'NADF Phase 3 Tractor Supply — Kaduna State',
      description:    'Supply of 50 John Deere 5075E tractors under the National Agricultural Development Fund programme',
      contractorName: 'AGCOMS International Trading Limited',
      branchId:       hq!.id,
      contractValue:  490_000_000,
      currency:       'NGN',
      status:         'ACTIVE',
      signedAt:       new Date('2025-01-15'),
    },
  });
  console.log(`     ✓ Government contracts seeded`);

  // ── Done ──────────────────────────────────────────────────────
  console.log('\n✅ Seed complete. Summary:');
  console.log(`   Branches:    ${branches.length}`);
  console.log(`   Users:       ${users.length} (all password: ${DEFAULT_PASSWORD})`);
  console.log(`   Customers:   ${customerCount}`);
  console.log(`   Products:    ${productCount}`);
  console.log(`   Vendors:     ${vendorCount}`);
  console.log(`   Employees:   ${empCount}`);
  console.log(`   Fleet:       ${fleetCount}`);
  console.log(`   Flags:       ${flags.length}`);
  console.log('\n   API docs:    http://localhost:3001/api/docs');
  console.log('   Frontend:    http://localhost:3000');
}

main()
  .catch(e => { console.error('❌ Seed failed:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
