#!/usr/bin/env bash
# scripts/migrate.sh — Run Prisma migrations safely in any environment
#
# Usage:
#   bash scripts/migrate.sh              # production-safe deploy
#   bash scripts/migrate.sh --dev        # development (generates migration)
#   bash scripts/migrate.sh --status     # show pending migrations
#
# Called automatically by Docker entrypoint before app start.

set -euo pipefail

MODE="${1:-}"
BACKEND_DIR="apps/backend"

echo "🗄️  AGCOMS DealerSync ERP — Database Migration"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cd "$BACKEND_DIR"

case "$MODE" in
  --status)
    echo "  Checking migration status…"
    npx prisma migrate status
    ;;
  --dev)
    echo "  Running development migration (will prompt for name)…"
    npx prisma migrate dev
    ;;
  *)
    echo "  Running production migration deploy…"
    npx prisma migrate deploy
    echo ""
    echo "  Generating Prisma client…"
    npx prisma generate
    echo ""
    echo "✅ Migrations applied"
    ;;
esac
