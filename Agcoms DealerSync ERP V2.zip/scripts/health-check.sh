#!/usr/bin/env bash
# scripts/health-check.sh — Verify all services are healthy before deployment
#
# Checks: PostgreSQL, Redis, backend API, frontend, MinIO/S3
# Exit code 0 = all healthy. Exit code 1 = one or more unhealthy.
# Used by CI/CD smoke step and Docker HEALTHCHECK.
#
# Usage:
#   bash scripts/health-check.sh
#   bash scripts/health-check.sh --api-only
#   bash scripts/health-check.sh --wait 60    # wait up to 60s

set -euo pipefail

API_URL="${API_URL:-http://localhost:3001}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
MAX_WAIT="${2:-30}"
API_ONLY=false
PASS=0
FAIL=0

[ "${1:-}" = "--api-only" ] && API_ONLY=true

check() {
  local name="$1"
  local cmd="$2"
  printf "  %-30s" "$name"
  if eval "$cmd" &>/dev/null; then
    echo "✓ HEALTHY"
    PASS=$((PASS+1))
  else
    echo "✗ UNHEALTHY"
    FAIL=$((FAIL+1))
  fi
}

wait_for() {
  local url="$1"
  local elapsed=0
  until curl -sf "$url" &>/dev/null || [ $elapsed -ge $MAX_WAIT ]; do
    sleep 2; elapsed=$((elapsed+2))
  done
}

echo "🏥 AGCOMS DealerSync ERP — Health Check"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [ "$API_ONLY" = false ]; then
  # Infrastructure
  check "PostgreSQL"    "pg_isready -h ${DB_HOST:-localhost} -p ${DB_PORT:-5432} -U ${DB_USER:-dealersync}"
  check "Redis"         "redis-cli -h ${REDIS_HOST:-localhost} -p ${REDIS_PORT:-6379} ping | grep -q PONG"
fi

# API
wait_for "$API_URL/api/v1/health"
check "Backend API /health"  "curl -sf '$API_URL/api/v1/health' | grep -q '\"status\":\"ok\"'"
check "Backend readiness"    "curl -sf '$API_URL/api/v1/health/ready' | grep -q 'ready'"
check "Swagger docs"         "curl -sf '$API_URL/api/docs-json' | grep -q 'openapi'"

if [ "$API_ONLY" = false ]; then
  # Frontend
  wait_for "$FRONTEND_URL"
  check "Frontend"           "curl -sf '$FRONTEND_URL' | grep -q 'DealerSync'"

  # Storage
  check "MinIO/S3 bucket"    "curl -sf '${S3_ENDPOINT:-http://localhost:9000}/minio/health/live'"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Passed: $PASS   Failed: $FAIL"

if [ $FAIL -gt 0 ]; then
  echo "❌ Health check FAILED ($FAIL service(s) unhealthy)"
  exit 1
else
  echo "✅ All services healthy"
  exit 0
fi
