#!/usr/bin/env bash
# AGCOMS DealerSync ERP — JWT RS256 Key Generator
# §5 Security: JWT RS256 asymmetric signing
#
# Generates a 4096-bit RSA key pair for JWT signing.
# Private key signs access tokens (backend only).
# Public key verifies tokens (backend + any future API gateway).
#
# Usage:
#   bash scripts/generate-keys.sh
#   bash scripts/generate-keys.sh --env          # also writes to .env
#   bash scripts/generate-keys.sh --env staging  # writes to .env.staging
#
# Output:
#   .keys/jwt-private.pem   (KEEP SECRET — never commit)
#   .keys/jwt-public.pem    (safe to share)
#   .keys/jwt-private.b64   (base64 — for env var injection)
#   .keys/jwt-public.b64    (base64 — for env var injection)

set -euo pipefail

KEYS_DIR=".keys"
ENV_FILE=".env"
WRITE_ENV=false
ENV_SUFFIX=""

# Parse args
while [[ $# -gt 0 ]]; do
  case $1 in
    --env)
      WRITE_ENV=true
      if [[ $# -gt 1 && ! "$2" =~ ^-- ]]; then
        ENV_SUFFIX=".$2"
        shift
      fi
      shift ;;
    *) shift ;;
  esac
done

TARGET_ENV="${ENV_FILE}${ENV_SUFFIX}"

echo "🔑 AGCOMS DealerSync ERP — JWT Key Generator"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Check openssl
if ! command -v openssl &>/dev/null; then
  echo "❌ openssl not found. Install with: apt-get install openssl"
  exit 1
fi

# Create .keys directory (gitignored)
mkdir -p "$KEYS_DIR"
chmod 700 "$KEYS_DIR"

# Ensure .keys is gitignored
if [ -f .gitignore ]; then
  if ! grep -q "^\.keys/" .gitignore 2>/dev/null; then
    echo ".keys/" >> .gitignore
    echo "   ✓ Added .keys/ to .gitignore"
  fi
fi

# Generate 4096-bit private key
echo ""
echo "  Generating 4096-bit RSA private key…"
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:4096 \
  -out "$KEYS_DIR/jwt-private.pem" 2>/dev/null
chmod 600 "$KEYS_DIR/jwt-private.pem"

# Extract public key
echo "  Extracting public key…"
openssl rsa -pubout -in "$KEYS_DIR/jwt-private.pem" \
  -out "$KEYS_DIR/jwt-public.pem" 2>/dev/null
chmod 644 "$KEYS_DIR/jwt-public.pem"

# Base64-encode for env var injection (single-line, no line breaks)
base64 -w 0 "$KEYS_DIR/jwt-private.pem" > "$KEYS_DIR/jwt-private.b64"
base64 -w 0 "$KEYS_DIR/jwt-public.pem"  > "$KEYS_DIR/jwt-public.b64"

echo ""
echo "  ✓ Private key: $KEYS_DIR/jwt-private.pem"
echo "  ✓ Public key:  $KEYS_DIR/jwt-public.pem"
echo "  ✓ Base64 encoded versions in $KEYS_DIR/*.b64"

# Optionally write to .env
if [ "$WRITE_ENV" = true ]; then
  echo ""
  echo "  Writing to $TARGET_ENV…"

  PRIVATE_B64=$(cat "$KEYS_DIR/jwt-private.b64")
  PUBLIC_B64=$(cat "$KEYS_DIR/jwt-public.b64")

  # Remove existing JWT key lines if present
  if [ -f "$TARGET_ENV" ]; then
    sed -i '/^JWT_PRIVATE_KEY=/d' "$TARGET_ENV"
    sed -i '/^JWT_PUBLIC_KEY=/d'  "$TARGET_ENV"
  fi

  # Append new keys
  {
    echo "JWT_PRIVATE_KEY=$PRIVATE_B64"
    echo "JWT_PUBLIC_KEY=$PUBLIC_B64"
  } >> "$TARGET_ENV"

  echo "  ✓ JWT_PRIVATE_KEY and JWT_PUBLIC_KEY written to $TARGET_ENV"
fi

# Print fingerprint for verification
FINGERPRINT=$(openssl rsa -pubout -in "$KEYS_DIR/jwt-private.pem" 2>/dev/null \
  | openssl pkey -pubin -outform DER 2>/dev/null \
  | openssl dgst -sha256 -hex 2>/dev/null \
  | awk '{print $2}' | head -c 16)

echo ""
echo "  Key fingerprint (first 16 chars SHA-256): $FINGERPRINT"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Keys generated successfully"
echo ""
echo "  Next steps:"
echo "  1. Add to your .env:   JWT_PRIVATE_KEY=\$(cat .keys/jwt-private.b64)"
echo "  2. For AWS:            Store in AWS Secrets Manager"
echo "  3. For CI/CD:          Set as GitHub Actions secrets"
echo ""
echo "  ⚠️  NEVER commit .keys/ to version control"
