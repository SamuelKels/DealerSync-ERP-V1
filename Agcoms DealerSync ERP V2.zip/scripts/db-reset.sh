#!/usr/bin/env bash
# scripts/db-reset.sh — Development database reset (DANGER: drops all data)
# Usage: bash scripts/db-reset.sh
# NEVER run against production. Guarded by NODE_ENV check.

set -euo pipefail

echo "⚠️  AGCOMS DealerSync ERP — Database Reset"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Production guard
if [ "${NODE_ENV:-}" = "production" ]; then
  echo "❌ Refusing to reset a PRODUCTION database. Set NODE_ENV=development."
  exit 1
fi

# Require explicit confirmation unless --yes flag passed
if [[ "${1:-}" != "--yes" ]]; then
  echo ""
  echo "  This will DROP and recreate the database: $DATABASE_URL"
  echo "  ALL data will be permanently lost."
  echo ""
  read -rp "  Type 'RESET' to confirm: " confirm
  if [ "$confirm" != "RESET" ]; then
    echo "  Cancelled."
    exit 0
  fi
fi

echo ""
echo "  [1/3] Dropping and recreating schema…"
cd apps/backend
npx prisma migrate reset --force --skip-seed 2>&1 | tail -5

echo "  [2/3] Running migrations…"
npx prisma migrate deploy 2>&1 | tail -5

echo "  [3/3] Seeding demo data…"
npx ts-node ../../scripts/seed.ts

echo ""
echo "✅ Database reset complete"
