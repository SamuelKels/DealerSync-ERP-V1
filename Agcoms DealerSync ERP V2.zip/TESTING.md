# AGCOMS DealerSync ERP v1.0 — Testing Guide

## Prerequisites

Ensure the following are installed on your machine:

- **Node.js 20 LTS** — [nodejs.org](https://nodejs.org)
- **pnpm 9.x** — `npm install -g pnpm`
- **Docker Desktop 4.x** — [docker.com](https://www.docker.com/products/docker-desktop/)
- **Git 2.40+**

---

## Step 1 — Install dependencies

```bash
pnpm install
```

Expected output: packages installed with no errors.

---

## Step 2 — Start infrastructure

```bash
docker compose up -d
```

Wait 30 seconds, then verify all services are healthy:

```bash
docker compose ps
```

All services should show `healthy` or `running`:
- `dealersync-postgres` (port 5432)
- `dealersync-redis` (port 6379)
- `dealersync-minio` (port 9000/9001)
- `dealersync-typesense` (port 8108)
- `dealersync-prometheus` (port 9090)
- `dealersync-grafana` (port 3003)

---

## Step 3 — Configure environment

```bash
# Copy example env files
cp apps/backend/.env.example apps/backend/.env
cp apps/frontend/.env.example apps/frontend/.env.local

# Generate JWT RS256 key pair
bash scripts/generate-keys.sh --env
```

The script writes `JWT_PRIVATE_KEY` and `JWT_PUBLIC_KEY` directly to `apps/backend/.env`.

---

## Step 4 — Set up database

```bash
# Run Prisma migrations
pnpm db:migrate

# Seed all 14 modules with demo data
pnpm db:seed

# Create Super Admin (interactive)
pnpm create:admin
```

The seed script takes ~30 seconds. It creates 3 branches, 12 users, 10 customers, 15 products, 8 fleet assets, and feature flags for all 14 modules.

---

## Step 5 — Start development servers

```bash
pnpm dev
```

This starts all three apps concurrently via Turborepo:

| Service | URL |
|---------|-----|
| ERP Frontend | **http://localhost:3000** |
| Backend API | http://localhost:3001 |
| API Documentation | **http://localhost:3001/api/docs** |
| Customer Portal | http://localhost:3002 |
| Grafana Dashboards | http://localhost:3003 (user: `admin`, pass: `dealersync_grafana`) |
| MinIO Console | http://localhost:9001 (user: `minioadmin`, pass: `minioadmin123`) |

---

## Step 6 — Log in and test

Open **http://localhost:3000** and log in with any demo credential:

| Role | Email | Password |
|------|-------|----------|
| **Super Admin** | admin@agcoms.ng | DealerSync@2025! |
| Finance Manager | finance@agcoms.ng | DealerSync@2025! |
| Sales Manager | sales@agcoms.ng | DealerSync@2025! |
| HR Manager | hr@agcoms.ng | DealerSync@2025! |
| Store Keeper | store@agcoms.ng | DealerSync@2025! |
| Technician | tech@agcoms.ng | DealerSync@2025! |

---

## Module testing checklist

### Module 1 — Auth & RBAC
- [ ] Login with admin credentials
- [ ] MFA setup and verification
- [ ] Log out; confirm refresh token cleared
- [ ] Login as Sales Rep; confirm admin routes return 403

### Module 2 — Dashboard
- [ ] KPI cards load with real data
- [ ] Real-time alerts panel shows data
- [ ] Branch selector works for Super Admin

### Module 3 — CRM
- [ ] Create a new customer (test credit limit)
- [ ] Check credit utilisation at `/crm/customers/:id/credit-check`
- [ ] Add a lead and advance pipeline stage
- [ ] Submit an RFQ

### Module 4 — Inventory
- [ ] Browse products and warehouses
- [ ] Start a stock count
- [ ] Create a landed cost allocation (requires a posted GRN)

### Module 5 — Sales
- [ ] Create a quotation (selects customer, adds product)
- [ ] Try a 20% discount — should trigger approval workflow
- [ ] Convert quotation to invoice
- [ ] Generate PDF

### Module 6 — Procurement
- [ ] Create a purchase order
- [ ] Receive GRN against PO
- [ ] Test 3-way invoice match

### Module 7 — Workshop
- [ ] Create a service request
- [ ] Create a job card and assign technician
- [ ] Complete checklist and generate service invoice

### Module 8 — Finance
- [ ] Post a balanced journal entry
- [ ] Attempt to post unbalanced entry — expect 400
- [ ] View trial balance
- [ ] Create a budget and run variance report

### Module 9 — HR
- [ ] View employee list (PII masked for non-HR roles)
- [ ] Log in as HR Manager — confirm salary figures visible
- [ ] Submit leave request
- [ ] View org chart

### Module 10 — Government Contracts
- [ ] View active NADF contract
- [ ] Register a beneficiary
- [ ] Allocate a tractor
- [ ] Confirm delivery with GPS coordinates
- [ ] Generate NADF compliance report

### Module 11 — Reports
- [ ] View KPI dashboard with Tremor charts
- [ ] View AR aging report
- [ ] Export to Excel/PDF

### Module 12 — Customer Portal
- [ ] Open http://localhost:3002
- [ ] Log in with a customer email
- [ ] View outstanding quotations

### Module 13 — AI
- [ ] Open /ai page
- [ ] Request inventory forecast (expect human_action_required: true)
- [ ] Attempt to approve a transaction via AI — expect 403

### Module 14 — Fleet
- [ ] View fleet assets list
- [ ] Open live GPS tracking page
- [ ] Confirm WebSocket connection indicator

---

## Running automated tests

```bash
# Unit tests (80% coverage enforced)
pnpm test:unit

# Integration tests (requires running PostgreSQL)
DATABASE_URL="postgresql://dealersync:dealersync_dev_secret@localhost:5432/dealersync_test" \
  pnpm test:integration

# E2E tests (requires running frontend + backend)
pnpm test:e2e
```

---

## Health check

```bash
bash scripts/health-check.sh
```

All services should show `✓ HEALTHY`.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `ECONNREFUSED localhost:5432` | `docker compose up -d postgres` |
| JWT errors on login | Re-run `bash scripts/generate-keys.sh --env` |
| `Cannot find module '@agcoms/types'` | `pnpm build --filter @agcoms/types` |
| Blank frontend page | Ensure backend is running: `pnpm --filter backend dev` |
| Prisma migration fails | `pnpm --filter backend run db:migrate:dev` |
| Port 3000 already in use | `kill $(lsof -ti:3000)` then retry |

---

*AGCOMS DealerSync ERP v1.0 — Ready for testing*
