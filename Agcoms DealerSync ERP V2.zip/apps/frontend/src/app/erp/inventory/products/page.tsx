'use client';
// app/(erp)/inventory/products/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, ChevronRight, Package, AlertCircle } from 'lucide-react';
import Link from 'next/link';
import { api, queryKeys } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface Product {
  id: string; sku: string; name: string; description?: string;
  category: { name: string }; vatRate: number;
  reorderPoint: number; isSerialized: boolean; isActive: boolean;
  totalStock?: number; belowReorder?: boolean;
}
interface PagedProducts { items: Product[]; total: number; hasMore: boolean; }

export default function ProductsPage() {
  const { user }   = useAuthStore();
  const [q, setQ]  = useState('');
  const [active, setActive] = useState('');
  const [page, setPage] = useState(1);

  const params = buildSearchParams({ q, isActive: active, limit: 25, page });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.products.list({ q, active, page }),
    queryFn:  () => api.get<PagedProducts>(`/inventory/products?${params}`),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Product Catalogue</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} products` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/inventory/products/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Product
        </Link>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            placeholder="Search by name or SKU…"
            className="pl-8 pr-3 h-8 w-[240px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
          />
        </div>
        <select
          value={active}
          onChange={(e) => { setActive(e.target.value); setPage(1); }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All</option>
          <option value="true">Active</option>
          <option value="false">Inactive</option>
        </select>
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['SKU', 'Name', 'Category', 'VAT', 'Serialised', 'Status', ''].map((h) => (
                <th key={h} className="px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading
              ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-3 py-3">
                        <div className="h-4 bg-[#F3F4F6] rounded animate-pulse w-3/4" />
                      </td>
                    ))}
                  </tr>
                ))
              : (data?.items ?? []).map((product) => (
                  <tr key={product.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                    <td className="px-3 py-2.5">
                      <span className="font-mono text-[11px] font-semibold" style={{ color: '#1A4D2E' }}>
                        {product.sku}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        {product.belowReorder && (
                          <AlertCircle className="h-3.5 w-3.5 text-[#DC2626] flex-shrink-0" />
                        )}
                        <Link
                          href={`/inventory/products/${product.id}`}
                          className="text-[13px] font-medium text-[#1A4D2E] hover:underline"
                        >
                          {product.name}
                        </Link>
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="text-[11px] text-[#6B7280]">{product.category.name}</span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="font-mono text-[12px] text-[#1A1A1A]">{Number(product.vatRate)}%</span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={product.isSerialized ? { background: '#E0F2FE', color: '#0369A1' } : { background: '#F3F4F6', color: '#6B7280' }}
                      >
                        {product.isSerialized ? 'Yes' : 'No'}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={product.isActive ? { background: '#DCFCE7', color: '#15803D' } : { background: '#F3F4F6', color: '#6B7280' }}
                      >
                        {product.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/inventory/products/${product.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E] transition-colors"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                ))}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total?.toLocaleString()} products</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">← Prev</button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button onClick={() => setPage((p) => p + 1)} disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
