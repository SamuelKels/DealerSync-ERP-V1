'use client';
// app/(erp)/finance/trial-balance/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Download, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN } from '../../../../lib/utils';

interface TrialBalanceLine {
  accountCode: string; accountName: string; accountType: string;
  openingDebit: number; openingCredit: number;
  periodDebit:  number; periodCredit:  number;
  closingDebit: number; closingCredit: number;
}
interface TrialBalance {
  periodId: string; periodName: string; asAt: string;
  lines: TrialBalanceLine[];
  totals: { openingDebit: number; openingCredit: number; periodDebit: number; periodCredit: number; closingDebit: number; closingCredit: number };
  isBalanced: boolean;
}

const TYPE_GROUPS = ['ASSET','LIABILITY','EQUITY','REVENUE','COST_OF_SALES','OPERATING_EXPENSE','OTHER_INCOME','OTHER_EXPENSE','TAX'];
const TYPE_LABELS: Record<string, string> = {
  ASSET: 'Assets', LIABILITY: 'Liabilities', EQUITY: 'Equity', REVENUE: 'Revenue',
  COST_OF_SALES: 'Cost of Sales', OPERATING_EXPENSE: 'Operating Expenses',
  OTHER_INCOME: 'Other Income', OTHER_EXPENSE: 'Other Expenses', TAX: 'Tax',
};

export default function TrialBalancePage() {
  const [periodId, setPeriodId] = useState('');
  const { user } = useAuthStore();

  const { data: periods = [] } = useQuery({
    queryKey: ['accounting-periods'],
    queryFn:  () => api.get<{ id: string; name: string; status: string }[]>('/finance/periods'),
    staleTime: 300_000,
  });

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['trial-balance', periodId, user?.branchId],
    queryFn:  () => api.get<TrialBalance>(`/finance/reports/trial-balance?periodId=${periodId}&branchId=${user?.branchId ?? ''}`),
    enabled:  !!periodId,
    staleTime: 60_000,
  });

  const grouped = TYPE_GROUPS.reduce<Record<string, TrialBalanceLine[]>>((acc, type) => {
    const lines = data?.lines.filter(l => l.accountType === type) ?? [];
    if (lines.length) acc[type] = lines;
    return acc;
  }, {});

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Trial Balance</h1>
          {data && (
            <p className="text-[12px] text-[#6B7280] mt-0.5">
              {data.periodName} · As at {data.asAt}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <select value={periodId} onChange={e => setPeriodId(e.target.value)}
            className="h-9 px-3 text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]">
            <option value="">Select period…</option>
            {periods.map(p => (
              <option key={p.id} value={p.id}>{p.name} {p.status === 'LOCKED' ? '🔒' : ''}</option>
            ))}
          </select>
          <button onClick={() => refetch()} disabled={!periodId || isFetching}
            className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium rounded-md border border-[#D1D5DB] hover:bg-[#F7F4EF] disabled:opacity-50 transition-colors">
            <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button disabled={!data}
            className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium text-white rounded-md disabled:opacity-50 transition-colors"
            style={{ background: '#1A4D2E' }}>
            <Download className="h-3.5 w-3.5" /> Export Excel
          </button>
        </div>
      </div>

      {/* Balance indicator */}
      {data && (
        <div className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-[12px] font-medium ${data.isBalanced ? 'bg-[#DCFCE7] text-[#15803D]' : 'bg-[#FEE2E2] text-[#B91C1C]'}`}>
          {data.isBalanced
            ? <><CheckCircle2 className="h-4 w-4" /> Trial balance is balanced</>
            : <><AlertCircle className="h-4 w-4" /> Trial balance is NOT balanced — investigate immediately</>}
        </div>
      )}

      {!periodId ? (
        <div className="bg-white rounded-lg border border-[#E5E7EB] py-16 text-center">
          <p className="text-[13px] text-[#9CA3AF]">Select an accounting period to view the trial balance</p>
        </div>
      ) : isLoading ? (
        <div className="bg-white rounded-lg border border-[#E5E7EB] p-6 space-y-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-5 bg-[#F3F4F6] rounded animate-pulse" style={{ width: `${40 + i * 10}%` }} />
          ))}
        </div>
      ) : data ? (
        <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ background: '#F9FAFB', borderBottom: '2px solid #E5E7EB' }}>
                <th className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280]" rowSpan={2}>Code</th>
                <th className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280]" rowSpan={2}>Account Name</th>
                <th className="px-3 py-2 text-center text-[9px] font-semibold uppercase tracking-wider text-[#6B7280] border-b border-[#E5E7EB]" colSpan={2}>Opening Balance</th>
                <th className="px-3 py-2 text-center text-[9px] font-semibold uppercase tracking-wider text-[#6B7280] border-b border-[#E5E7EB]" colSpan={2}>Period Movement</th>
                <th className="px-3 py-2 text-center text-[9px] font-semibold uppercase tracking-wider text-[#6B7280] border-b border-[#E5E7EB]" colSpan={2}>Closing Balance</th>
              </tr>
              <tr style={{ background: '#F9FAFB', borderBottom: '1px solid #E5E7EB' }}>
                {['Dr', 'Cr', 'Dr', 'Cr', 'Dr', 'Cr'].map((h, i) => (
                  <th key={i} className="px-3 py-1.5 text-[9px] font-semibold uppercase tracking-wider text-right text-[#9CA3AF]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Object.entries(grouped).map(([type, lines]) => (
                <>
                  <tr key={`group-${type}`} style={{ background: '#F9FAFB', borderTop: '1px solid #E5E7EB', borderBottom: '1px solid #E5E7EB' }}>
                    <td colSpan={8} className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wide text-[#6B7280]">
                      {TYPE_LABELS[type] ?? type}
                    </td>
                  </tr>
                  {lines.map(line => (
                    <tr key={line.accountCode} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]">
                      <td className="px-3 py-2 font-mono text-[11px] font-semibold text-[#1A4D2E]">{line.accountCode}</td>
                      <td className="px-3 py-2 text-[12px] text-[#1A1A1A]">{line.accountName}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right text-[#1A1A1A]">{line.openingDebit > 0 ? formatNGN(line.openingDebit) : ''}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right text-[#1A1A1A]">{line.openingCredit > 0 ? formatNGN(line.openingCredit) : ''}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right text-[#1A1A1A]">{line.periodDebit > 0 ? formatNGN(line.periodDebit) : ''}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right text-[#1A1A1A]">{line.periodCredit > 0 ? formatNGN(line.periodCredit) : ''}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right font-semibold text-[#1A1A1A]">{line.closingDebit > 0 ? formatNGN(line.closingDebit) : ''}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-right font-semibold text-[#1A1A1A]">{line.closingCredit > 0 ? formatNGN(line.closingCredit) : ''}</td>
                    </tr>
                  ))}
                </>
              ))}
            </tbody>
            {/* Grand totals */}
            <tfoot>
              <tr style={{ background: '#1A4D2E', borderTop: '2px solid #1A4D2E' }}>
                <td colSpan={2} className="px-3 py-2.5 text-[11px] font-bold uppercase tracking-wide text-white">Grand Totals</td>
                {[data.totals.openingDebit, data.totals.openingCredit, data.totals.periodDebit, data.totals.periodCredit, data.totals.closingDebit, data.totals.closingCredit].map((v, i) => (
                  <td key={i} className="px-3 py-2.5 font-mono text-[11px] font-bold text-right text-white">{formatNGN(v)}</td>
                ))}
              </tr>
            </tfoot>
          </table>
        </div>
      ) : null}
    </div>
  );
}
