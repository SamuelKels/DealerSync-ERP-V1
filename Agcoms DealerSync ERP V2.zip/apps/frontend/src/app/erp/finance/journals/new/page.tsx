'use client';
// app/(erp)/finance/journals/new/page.tsx
import { useState, useCallback } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Plus, Trash2, AlertCircle, CheckCircle2 } from 'lucide-react';
import { z } from 'zod';
import { api } from '../../../../../lib/api';
import { useAuthStore } from '../../../../../stores/auth.store';
import { formatNGN } from '../../../../../lib/utils';

const LineSchema = z.object({
  accountId:    z.string().min(1, 'Account required'),
  description:  z.string().optional(),
  debitAmount:  z.coerce.number().min(0),
  creditAmount: z.coerce.number().min(0),
  costCentre:   z.string().optional(),
});

const JournalSchema = z.object({
  entryDate:   z.string().min(1, 'Date required'),
  description: z.string().min(3, 'Description required'),
  entryType:   z.string().default('MANUAL'),
  reference:   z.string().optional(),
  notes:       z.string().optional(),
  lines:       z.array(LineSchema).min(2, 'At least 2 lines required'),
}).refine(d => {
  const dr = d.lines.reduce((s, l) => s + l.debitAmount, 0);
  const cr = d.lines.reduce((s, l) => s + l.creditAmount, 0);
  return Math.abs(dr - cr) < 0.01;
}, { message: 'Journal entry must balance: debits must equal credits', path: ['lines'] });

type JournalForm = z.infer<typeof JournalSchema>;

interface Account { id: string; code: string; name: string; accountType: string; normalBalance: string; }

export default function NewJournalPage() {
  const router      = useRouter();
  const qc          = useQueryClient();
  const { user }    = useAuthStore();

  const { data: accounts = [] } = useQuery({
    queryKey: ['accounts', 'list'],
    queryFn:  () => api.get<Account[]>('/finance/accounts?isActive=true&limit=500'),
    staleTime: 300_000,
  });

  const { register, control, handleSubmit, watch, formState: { errors } } = useForm<JournalForm>({
    resolver: zodResolver(JournalSchema),
    defaultValues: {
      entryDate:   new Date().toISOString().split('T')[0],
      entryType:   'MANUAL',
      lines: [
        { accountId: '', description: '', debitAmount: 0, creditAmount: 0 },
        { accountId: '', description: '', debitAmount: 0, creditAmount: 0 },
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'lines' });
  const lines = watch('lines');

  const totalDebits  = lines.reduce((s, l) => s + (Number(l.debitAmount) || 0), 0);
  const totalCredits = lines.reduce((s, l) => s + (Number(l.creditAmount) || 0), 0);
  const balanced     = Math.abs(totalDebits - totalCredits) < 0.01 && totalDebits > 0;
  const difference   = totalDebits - totalCredits;

  const { mutate: save, isPending } = useMutation({
    mutationFn: (data: JournalForm) =>
      api.post('/finance/journals', { ...data, branchId: user?.branchId }),
    onSuccess: () => {
      toast.success('Journal entry created successfully');
      qc.invalidateQueries({ queryKey: ['journals'] });
      router.push('/finance/journals');
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const addLine = useCallback(() => {
    append({ accountId: '', description: '', debitAmount: 0, creditAmount: 0 });
  }, [append]);

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-5">
      <div>
        <h1 className="font-heading text-xl text-[#1A1A1A]">New Journal Entry</h1>
        <p className="text-[12px] text-[#6B7280] mt-0.5">Double-entry · Debits must equal Credits</p>
      </div>

      <form onSubmit={handleSubmit(d => save(d))} className="space-y-5">
        {/* Header fields */}
        <div className="bg-white rounded-lg border border-[#E5E7EB] p-5 grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">Entry Date *</label>
            <input {...register('entryDate')} type="date"
              className="h-9 px-3 text-sm rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]" />
            {errors.entryDate && <p className="text-[11px] text-[#DC2626]">⚠ {errors.entryDate.message}</p>}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">Entry Type</label>
            <select {...register('entryType')}
              className="h-9 px-3 text-sm rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]">
              {['MANUAL', 'ADJUSTMENT', 'OPENING', 'DEPRECIATION'].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div className="col-span-2 flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">Description *</label>
            <input {...register('description')} placeholder="Describe this journal entry…"
              className="h-9 px-3 text-sm rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]" />
            {errors.description && <p className="text-[11px] text-[#DC2626]">⚠ {errors.description.message}</p>}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">Reference (optional)</label>
            <input {...register('reference')} placeholder="e.g. INV-2025-001"
              className="h-9 px-3 text-sm rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">Notes</label>
            <input {...register('notes')} placeholder="Internal notes"
              className="h-9 px-3 text-sm rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]" />
          </div>
        </div>

        {/* Lines */}
        <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <div className="px-4 py-3 flex items-center justify-between border-b border-[#E5E7EB]">
            <h2 className="font-heading text-[15px] text-[#1A1A1A]">Journal Lines</h2>
            <button type="button" onClick={addLine}
              className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded border border-[#D1D5DB] hover:bg-[#F7F4EF] text-[#1A1A1A] transition-colors">
              <Plus className="h-3.5 w-3.5" /> Add Line
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="border-b border-[#E5E7EB]">
                  {['#', 'Account', 'Description', 'Debit (₦)', 'Credit (₦)', 'Cost Centre', ''].map(h => (
                    <th key={h} className="px-3 py-2 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {fields.map((field, i) => (
                  <tr key={field.id} className="border-b border-[#F3F4F6]">
                    <td className="px-3 py-2 text-[11px] text-[#9CA3AF] w-8">{i + 1}</td>
                    <td className="px-3 py-2 min-w-[200px]">
                      <select {...register(`lines.${i}.accountId`)}
                        className="w-full h-8 px-2 text-[12px] rounded border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]">
                        <option value="">Select account…</option>
                        {accounts.map(a => (
                          <option key={a.id} value={a.id}>{a.code} — {a.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-2 min-w-[180px]">
                      <input {...register(`lines.${i}.description`)} placeholder="Line description"
                        className="w-full h-8 px-2 text-[12px] rounded border border-[#D1D5DB] bg-white focus:outline-none focus:ring-1 focus:ring-[#1A4D2E]" />
                    </td>
                    <td className="px-3 py-2 w-[130px]">
                      <input {...register(`lines.${i}.debitAmount`)} type="number" step="0.01" min="0"
                        className="w-full h-8 px-2 text-[12px] font-mono rounded border border-[#D1D5DB] bg-white focus:outline-none focus:ring-1 focus:ring-[#1A4D2E] text-right" />
                    </td>
                    <td className="px-3 py-2 w-[130px]">
                      <input {...register(`lines.${i}.creditAmount`)} type="number" step="0.01" min="0"
                        className="w-full h-8 px-2 text-[12px] font-mono rounded border border-[#D1D5DB] bg-white focus:outline-none focus:ring-1 focus:ring-[#1A4D2E] text-right" />
                    </td>
                    <td className="px-3 py-2 w-[110px]">
                      <input {...register(`lines.${i}.costCentre`)} placeholder="e.g. HQ"
                        className="w-full h-8 px-2 text-[12px] rounded border border-[#D1D5DB] bg-white focus:outline-none focus:ring-1 focus:ring-[#1A4D2E]" />
                    </td>
                    <td className="px-3 py-2 w-8">
                      {fields.length > 2 && (
                        <button type="button" onClick={() => remove(i)}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#FEE2E2] text-[#9CA3AF] hover:text-[#DC2626] transition-colors">
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
              {/* Totals */}
              <tfoot>
                <tr style={{ background: '#F9FAFB', borderTop: '2px solid #E5E7EB' }}>
                  <td colSpan={3} className="px-3 py-2.5 text-[11px] font-semibold text-[#6B7280] uppercase tracking-wide text-right">Totals</td>
                  <td className="px-3 py-2.5 font-mono text-[12px] font-bold text-right text-[#1A1A1A]">{formatNGN(totalDebits)}</td>
                  <td className="px-3 py-2.5 font-mono text-[12px] font-bold text-right text-[#1A1A1A]">{formatNGN(totalCredits)}</td>
                  <td colSpan={2} className="px-3 py-2.5">
                    <div className={`flex items-center gap-1.5 text-[11px] font-semibold ${balanced ? 'text-[#16A34A]' : 'text-[#DC2626]'}`}>
                      {balanced ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                      {balanced ? 'Balanced ✓' : `Difference: ${formatNGN(Math.abs(difference))}`}
                    </div>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          {errors.lines?.root && (
            <div className="px-4 py-2 bg-[#FEF2F2] border-t border-[#FEE2E2]">
              <p className="text-[12px] text-[#DC2626]">⚠ {errors.lines.root.message}</p>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <button type="button" onClick={() => router.back()}
            className="px-4 py-2 text-sm font-medium rounded-md border border-[#D1D5DB] hover:bg-[#F7F4EF] text-[#1A1A1A] transition-colors">
            Cancel
          </button>
          <div className="flex items-center gap-3">
            <button type="submit" name="action" value="draft" disabled={isPending}
              className="px-4 py-2 text-sm font-medium rounded-md border border-[#D1D5DB] hover:bg-[#F7F4EF] text-[#1A1A1A] transition-colors disabled:opacity-60">
              Save as Draft
            </button>
            <button type="submit" disabled={isPending || !balanced}
              className="px-5 py-2 text-sm font-medium text-white rounded-md flex items-center gap-2 disabled:opacity-60 transition-all"
              style={{ background: balanced ? '#1A4D2E' : '#9CA3AF' }}>
              {isPending && <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />}
              Post Journal Entry
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
