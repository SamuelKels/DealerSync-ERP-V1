'use client';
// app/(erp)/finance/journals/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, ChevronRight, BookOpen, Lock } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface JournalEntry {
  id: string; entryNo: string; entryDate: string; description: string;
  entryType: string; status: 'DRAFT' | 'POSTED' | 'VOIDED';
  totalDebits: number; totalCredits: number; currency: string;
  branch: { name: string }; createdBy: { fullName: string };
  linesCount: number; createdAt: string;
}
interface PagedJournals { items: JournalEntry[]; total: number; hasMore: boolean; }

export default function JournalsPage() {
  const [q, setQ]      = useState('');
  const [status, setStatus] = useState('');
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);
  const { user }        = useAuthStore();

  const params = buildSearchParams({
    q, status, entryType: type,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 25, page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['journals', 'list', { q, status, type, page }],
    queryFn:  () => api.get<PagedJournals>(`/finance/journals?${params}`),
    staleTime: 30_000,
    placeholderData: prev => prev,
  });

  const TYPES = ['MANUAL', 'SALES', 'PROCUREMENT', 'PAYROLL', 'DEPRECIATION', 'ADJUSTMENT', 'OPENING'];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Journal Entries</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            Double-entry accounting ledger · {data?.total !== undefined ? `${data.total.toLocaleString()} entries` : 'Loading…'}
          </p>
        </div>
        <Link href="/finance/journals/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}>
          <Plus className="h-4 w-4" /> New Journal Entry
        </Link>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input value={q} onChange={e => { setQ(e.target.value); setPage(1); }}
            placeholder="Search by ref or description…"
            className="pl-8 pr-3 h-8 w-[240px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]" />
        </div>
        {['DRAFT', 'POSTED', 'VOIDED'].map(s => {
          const st = getStatusStyle(s);
          return (
            <button key={s} onClick={() => { setStatus(status === s ? '' : s); setPage(1); }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={status === s ? { background: st.bg, color: st.color, borderColor: 'transparent' }
                : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }}>
              {s}
            </button>
          );
        })}
        <select value={type} onChange={e => { setType(e.target.value); setPage(1); }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]">
          <option value="">All types</option>
          {TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['Entry #', 'Date', 'Description', 'Type', 'Status', 'Debits', 'Credits', 'Balanced', 'Lines', ''].map(h => (
                <th key={h} className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading
              ? Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 10 }).map((_, j) => (
                      <td key={j} className="px-3 py-3"><div className="h-4 bg-[#F3F4F6] rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              : (data?.items ?? []).length === 0
              ? (
                <tr>
                  <td colSpan={10} className="py-16 text-center">
                    <BookOpen className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                    <p className="text-[13px] text-[#9CA3AF]">No journal entries found</p>
                  </td>
                </tr>
              )
              : (data?.items ?? []).map(j => {
                  const st = getStatusStyle(j.status);
                  const balanced = Math.abs(j.totalDebits - j.totalCredits) < 0.01;
                  return (
                    <tr key={j.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                      <td className="px-3 py-2.5">
                        <Link href={`/finance/journals/${j.id}`}
                          className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline">
                          {j.entryNo}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#6B7280] whitespace-nowrap">{formatDate(j.entryDate)}</td>
                      <td className="px-3 py-2.5">
                        <p className="text-[12px] text-[#1A1A1A] max-w-[200px] truncate">{j.description}</p>
                        <p className="text-[10px] text-[#9CA3AF]">{j.createdBy.fullName}</p>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide bg-[#EDF4EF] text-[#1A4D2E]">
                          {j.entryType}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-1">
                          {j.status === 'POSTED' && <Lock className="h-3 w-3 text-[#16A34A]" />}
                          <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                            style={{ background: st.bg, color: st.color }}>{j.status}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-right">{formatNGN(j.totalDebits)}</td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-right">{formatNGN(j.totalCredits)}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span className={`text-[10px] font-bold ${balanced ? 'text-[#16A34A]' : 'text-[#DC2626]'}`}>
                          {balanced ? '✓' : '✗'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#6B7280] text-center">{j.linesCount}</td>
                      <td className="px-3 py-2.5">
                        <Link href={`/finance/journals/${j.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]">
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total?.toLocaleString()} entries</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">← Prev</button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
