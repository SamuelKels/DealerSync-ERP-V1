'use client';
// app/(erp)/hr/performance-reviews/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Star, Plus, ChevronRight, TrendingUp } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatDate, buildSearchParams } from '../../../../lib/utils';

interface PerformanceReview {
  id: string; reviewNo: string; reviewPeriod: string; reviewType: string; status: string;
  employee: { firstName: string; lastName: string; employeeNo: string; jobTitle?: string };
  reviewer: { firstName: string; lastName: string };
  selfScore?: number; managerScore?: number; overallRating?: string;
  promotionRecommended?: boolean; dueDate: string; createdAt: string;
}
interface PagedReviews { items: PerformanceReview[]; total: number; hasMore: boolean; }

const RATING_COLORS: Record<string, string> = {
  OUTSTANDING:           '#1A4D2E',
  EXCEEDS_EXPECTATIONS:  '#16A34A',
  MEETS_EXPECTATIONS:    '#0369A1',
  NEEDS_IMPROVEMENT:     '#B45309',
  POOR:                  '#B91C1C',
};

function StarScore({ score }: { score?: number }) {
  if (!score) return <span className="text-[11px] text-[#9CA3AF]">—</span>;
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className="h-3 w-3"
          style={{ color: i < Math.round(score) ? '#F5C518' : '#E5E7EB', fill: i < Math.round(score) ? '#F5C518' : 'transparent' }} />
      ))}
      <span className="text-[11px] font-mono text-[#6B7280] ml-0.5">{score}</span>
    </div>
  );
}

export default function PerformanceReviewsPage() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    status, branchId: user?.isSuperAdmin ? undefined : user?.branchId, limit: 20, page,
  });

  const { data, isLoading } = useQuery({
    queryKey: ['performance-reviews', { status, page }],
    queryFn:  () => api.get<PagedReviews>(`/hr/performance-reviews?${params}`),
    staleTime: 60_000,
    placeholderData: prev => prev,
  });

  const STATUS_STEPS = ['DRAFT', 'SELF_ASSESSMENT', 'MANAGER_REVIEW', 'APPROVED', 'ACKNOWLEDGED'];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Performance Reviews</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total} reviews` : 'Loading…'}
          </p>
        </div>
        <Link href="/hr/performance-reviews/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}>
          <Plus className="h-4 w-4" /> New Review
        </Link>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        <button onClick={() => setStatus('')}
          className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors ${!status ? 'bg-[#1A4D2E] text-white border-transparent' : 'bg-white text-[#6B7280] border-[#E5E7EB]'}`}>
          All
        </button>
        {STATUS_STEPS.map(s => (
          <button key={s} onClick={() => { setStatus(s); setPage(1); }}
            className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
            style={status === s ? { background: '#EDF4EF', color: '#1A4D2E', borderColor: 'transparent' }
              : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }}>
            {s.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['Review #', 'Employee', 'Period', 'Type', 'Status', 'Self Score', 'Mgr Score', 'Overall Rating', 'Promo?', 'Due', ''].map(h => (
                <th key={h} className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 11 }).map((_, j) => (
                      <td key={j} className="px-3 py-3"><div className="h-4 bg-[#F3F4F6] rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              : (data?.items ?? []).length === 0
              ? (
                <tr>
                  <td colSpan={11} className="py-16 text-center">
                    <TrendingUp className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                    <p className="text-[13px] text-[#9CA3AF]">No performance reviews found</p>
                  </td>
                </tr>
              )
              : (data?.items ?? []).map(review => {
                  const ratingColor = RATING_COLORS[review.overallRating ?? ''] ?? '#9CA3AF';
                  const isOverdue   = new Date(review.dueDate) < new Date() && !['APPROVED','ACKNOWLEDGED'].includes(review.status);
                  return (
                    <tr key={review.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                      <td className="px-3 py-2.5">
                        <Link href={`/hr/performance-reviews/${review.id}`}
                          className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline">
                          {review.reviewNo}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="text-[12px] font-medium text-[#1A1A1A]">
                          {review.employee.firstName} {review.employee.lastName}
                        </div>
                        <div className="text-[10px] text-[#9CA3AF]">{review.employee.jobTitle}</div>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{review.reviewPeriod}</td>
                      <td className="px-3 py-2.5">
                        <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold bg-[#EDF4EF] text-[#1A4D2E]">
                          {review.reviewType}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide bg-[#F3F4F6] text-[#6B7280]">
                          {review.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5"><StarScore score={review.selfScore} /></td>
                      <td className="px-3 py-2.5"><StarScore score={review.managerScore} /></td>
                      <td className="px-3 py-2.5">
                        {review.overallRating ? (
                          <span className="text-[9.5px] font-bold uppercase tracking-wide" style={{ color: ratingColor }}>
                            {review.overallRating.replace(/_/g, ' ')}
                          </span>
                        ) : '—'}
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        {review.promotionRecommended
                          ? <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#FEF3C7] text-[#B45309]">YES</span>
                          : <span className="text-[11px] text-[#9CA3AF]">—</span>}
                      </td>
                      <td className="px-3 py-2.5 text-[11px]" style={{ color: isOverdue ? '#DC2626' : '#9CA3AF' }}>
                        {formatDate(review.dueDate)} {isOverdue && '⚠'}
                      </td>
                      <td className="px-3 py-2.5">
                        <Link href={`/hr/performance-reviews/${review.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]">
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total} reviews</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">← Prev</button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
