'use client';
import { useQuery } from '@tanstack/react-query';
import { Users, ChevronDown, ChevronRight } from 'lucide-react';
import { useState } from 'react';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';

interface OrgNode {
  id: string; firstName: string; lastName: string; jobTitle: string;
  department: string; employeeNo: string; status: string;
  reportsTo?: string; directReports: OrgNode[];
  avatarInitials: string;
}

interface Department {
  id: string; name: string; headCount: number;
  manager?: { firstName: string; lastName: string; jobTitle: string };
  members: OrgNode[];
}

function EmployeeNode({ node, depth = 0 }: { node: OrgNode; depth?: number }) {
  const [expanded, setExpanded] = useState(depth < 2);
  const hasReports = node.directReports?.length > 0;

  const bgColors = ['#1A4D2E', '#2D6A4A', '#3D8B6B', '#4DA882', '#5DC49A'];
  const bg = bgColors[Math.min(depth, bgColors.length - 1)] ?? '#1A4D2E';

  return (
    <div className="flex flex-col items-center">
      <div className="relative">
        <button
          onClick={() => hasReports && setExpanded(!expanded)}
          className={`flex flex-col items-center gap-1 px-4 py-3 rounded-xl border-2 min-w-[140px] transition-all ${hasReports ? 'cursor-pointer hover:shadow-md' : 'cursor-default'}`}
          style={{ borderColor: bg, background: depth === 0 ? bg : '#fff' }}>
          {/* Avatar */}
          <div className="h-10 w-10 rounded-full flex items-center justify-center text-white text-[13px] font-semibold flex-shrink-0"
            style={{ background: depth === 0 ? 'rgba(255,255,255,0.25)' : bg }}>
            {node.avatarInitials}
          </div>
          <div className="text-center">
            <p className="text-[12px] font-semibold leading-tight" style={{ color: depth === 0 ? '#fff' : '#1A1A1A' }}>
              {node.firstName} {node.lastName}
            </p>
            <p className="text-[10px] leading-tight mt-0.5" style={{ color: depth === 0 ? 'rgba(255,255,255,0.8)' : '#6B7280' }}>
              {node.jobTitle}
            </p>
          </div>
          {hasReports && (
            <div className="mt-1">
              {expanded
                ? <ChevronDown className="h-3.5 w-3.5" style={{ color: depth === 0 ? 'rgba(255,255,255,0.8)' : '#9CA3AF' }} />
                : <ChevronRight className="h-3.5 w-3.5" style={{ color: depth === 0 ? 'rgba(255,255,255,0.8)' : '#9CA3AF' }} />}
            </div>
          )}
        </button>
        {hasReports && (
          <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full text-[9px] font-bold flex items-center justify-center text-white"
            style={{ background: bg }}>
            {node.directReports.length}
          </span>
        )}
      </div>

      {/* Children */}
      {hasReports && expanded && (
        <div className="relative mt-4">
          {/* Vertical connector from parent */}
          <div className="absolute top-0 left-1/2 -translate-x-px w-px h-4 bg-[#E5E7EB]" />
          <div className="flex items-start gap-4 mt-4 relative">
            {/* Horizontal connector bar */}
            {node.directReports.length > 1 && (
              <div className="absolute top-0 left-0 right-0 h-px bg-[#E5E7EB]" />
            )}
            {node.directReports.map(child => (
              <div key={child.id} className="flex flex-col items-center relative">
                <div className="w-px h-4 bg-[#E5E7EB]" />
                <EmployeeNode node={child} depth={depth + 1} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function OrgChartPage() {
  const [viewMode, setViewMode] = useState<'tree' | 'department'>('department');
  const { user }  = useAuthStore();
  const branchParam = user?.branchId && !user.isSuperAdmin ? `?branchId=${user.branchId}` : '';

  const { data: treeData, isLoading: loadingTree } = useQuery({
    queryKey: ['org-tree'],
    queryFn:  () => api.get<{ tree: OrgNode[] }>(`/hr/org-chart${branchParam}`),
    staleTime: 300_000,
    enabled: viewMode === 'tree',
  });

  const { data: deptData, isLoading: loadingDept } = useQuery({
    queryKey: ['org-departments'],
    queryFn:  () => api.get<{ departments: Department[]; totalHeadcount: number }>(`/hr/departments${branchParam}`),
    staleTime: 300_000,
    enabled: viewMode === 'department',
  });

  const isLoading = viewMode === 'tree' ? loadingTree : loadingDept;

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Organisation Chart</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {deptData ? `${deptData.totalHeadcount} employees · ${deptData.departments.length} departments` : 'Loading…'}
          </p>
        </div>
        <div className="flex items-center gap-1 bg-[#F7F4EF] rounded-lg p-1">
          {(['department', 'tree'] as const).map(m => (
            <button key={m} onClick={() => setViewMode(m)}
              className="px-4 py-1.5 rounded-md text-[12px] font-medium capitalize transition-all"
              style={viewMode === m
                ? { background: '#fff', color: '#1A4D2E', boxShadow: '0 1px 3px rgba(0,0,0,0.08)' }
                : { color: '#6B7280' }}>
              {m === 'department' ? 'By department' : 'Reporting tree'}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-white rounded-xl border border-[#E5E7EB] p-5 h-48 animate-pulse" />
          ))}
        </div>
      ) : viewMode === 'department' ? (
        /* Department card view */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(deptData?.departments ?? []).map(dept => (
            <div key={dept.id} className="bg-white rounded-xl border border-[#E5E7EB] p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-[14px] font-semibold text-[#1A1A1A]">{dept.name}</h3>
                  {dept.manager && (
                    <p className="text-[11px] text-[#6B7280] mt-0.5">
                      Head: {dept.manager.firstName} {dept.manager.lastName}
                    </p>
                  )}
                </div>
                <div className="h-9 w-9 rounded-full flex items-center justify-center text-white text-[13px] font-semibold"
                  style={{ background: '#1A4D2E' }}>
                  {dept.headCount}
                </div>
              </div>

              {/* Member avatars */}
              <div className="flex items-center gap-1 flex-wrap mt-3">
                {dept.members.slice(0, 8).map(m => (
                  <div key={m.id} title={`${m.firstName} ${m.lastName}`}
                    className="h-7 w-7 rounded-full flex items-center justify-center text-white text-[9px] font-semibold"
                    style={{ background: '#2D6A4A' }}>
                    {m.avatarInitials}
                  </div>
                ))}
                {dept.headCount > 8 && (
                  <div className="h-7 w-7 rounded-full flex items-center justify-center text-[9px] font-semibold bg-[#F3F4F6] text-[#6B7280]">
                    +{dept.headCount - 8}
                  </div>
                )}
              </div>

              <div className="mt-3 pt-3 border-t border-[#F3F4F6]">
                <span className="text-[10px] text-[#9CA3AF]">{dept.headCount} member{dept.headCount !== 1 ? 's' : ''}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Tree view */
        <div className="bg-white rounded-xl border border-[#E5E7EB] p-8 overflow-x-auto">
          {(treeData?.tree ?? []).length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
              <p className="text-[13px] text-[#9CA3AF]">No org chart data available</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-6">
              {(treeData?.tree ?? []).map(root => (
                <EmployeeNode key={root.id} node={root} depth={0} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
