'use client';
// app/(erp)/sales/credit-notes/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileX, Plus, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface CreditNote {
  id: string; creditNoteNo: string; reason: string; creditType: string; status: string;
  customer: { name: string };
  originalInvoice: { invoiceNo: string };
  totalAmount: number; amountApplied: number; currency: string;
  createdAt: string; issuedAt?: string;
}
interface PagedNotes { items: CreditNote[]; total: number; hasMore: boolean; }

export default function CreditNotesPage() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    status, branchId: user?.isSuperAdmin ? undefined : user?.branchId, limit: 20, page,
  });

  const { data, isLoading } = useQuery({
    queryKey: ['credit-notes', { status, page }],
    queryFn:  () => api.get<PagedNotes>(`/sales/credit-notes?${params}`),
    staleTime: 30_000,
    placeholderData: prev => prev,
  });

  const STATUSES = ['DRAFT', 'ISSUED', 'APPLIED', 'REFUNDED'];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Credit Notes</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total} credit notes` : 'Loading…'}
          </p>
        </div>
        <Link href="/sales/credit-notes/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}>
          <Plus className="h-4 w-4" /> New Credit Note
        </Link>
      </div>

      <div className="flex items-center gap-2">
        <button onClick={() => setStatus('')}
          className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors ${!status ? 'bg-[#1A4D2E] text-white border-transparent' : 'bg-white text-[#6B7280] border-[#E5E7EB]'}`}>
          All
        </button>
        {STATUSES.map(s => {
          const ss = getStatusStyle(s);
          return (
            <button key={s} onClick={() => { setStatus(s); setPage(1); }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={status === s ? { background: ss.bg, color: ss.color, borderColor: 'transparent' }
                : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }}>
              {s}
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['CN#', 'Customer', 'Original Invoice', 'Type', 'Status', 'Total', 'Applied', 'Balance', 'Date', ''].map(h => (
                <th key={h} className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 10 }).map((_, j) => (
                      <td key={j} className="px-3 py-3"><div className="h-4 bg-[#F3F4F6] rounded animate-pulse" /></td>
                    ))}
                  </tr>
                ))
              : (data?.items ?? []).length === 0
              ? (
                <tr>
                  <td colSpan={10} className="py-16 text-center">
                    <FileX className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                    <p className="text-[13px] text-[#9CA3AF]">No credit notes found</p>
                  </td>
                </tr>
              )
              : (data?.items ?? []).map(cn => {
                  const ss = getStatusStyle(cn.status);
                  const balance = cn.totalAmount - cn.amountApplied;
                  return (
                    <tr key={cn.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                      <td className="px-3 py-2.5">
                        <Link href={`/sales/credit-notes/${cn.id}`}
                          className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline">
                          {cn.creditNoteNo}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#1A1A1A]">{cn.customer.name}</td>
                      <td className="px-3 py-2.5">
                        <span className="font-mono text-[11px] text-[#6B7280]">{cn.originalInvoice.invoiceNo}</span>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold bg-[#EDE9FE] text-[#6D28D9]">
                          {cn.creditType}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                          style={{ background: ss.bg, color: ss.color }}>{cn.status}</span>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[12px] font-semibold text-right" style={{ color: '#DC2626' }}>
                        ({formatNGN(cn.totalAmount)})
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-right text-[#6B7280]">
                        {cn.amountApplied > 0 ? formatNGN(cn.amountApplied) : '—'}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[11px] text-right"
                        style={{ color: balance > 0 ? '#D97706' : '#16A34A', fontWeight: 600 }}>
                        {balance > 0 ? formatNGN(balance) : '✓'}
                      </td>
                      <td className="px-3 py-2.5 text-[11px] text-[#9CA3AF]">{formatDate(cn.createdAt)}</td>
                      <td className="px-3 py-2.5">
                        <Link href={`/sales/credit-notes/${cn.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]">
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total} credit notes</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">← Prev</button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
