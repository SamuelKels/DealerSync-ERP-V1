'use client';
// app/(erp)/ai/page.tsx
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Brain, Search, TrendingUp, Lightbulb, AlertTriangle, CheckCircle2, ChevronRight, Sparkles } from 'lucide-react';
import { api } from '../../../lib/api';
import { useAuthStore } from '../../../stores/auth.store';
import { formatNGN } from '../../../lib/utils';

interface AiInsight {
  id: string; category: string; title: string; summary: string;
  confidence: number; actionRequired: boolean; suggestedAction?: string;
  createdAt: string;
}
interface InventoryForecast {
  productId: string; sku: string; productName: string;
  currentStock: number; forecastedDemand: number; forecastedReorderDate: string;
  confidence: number; recommendation: string;
}
interface AiAdvisory<T> {
  advisory: T;
  human_action_required: true;
  suggested_human_action: string;
  governance: { ai_action: string; model: string; generated_at: string; disclaimer: string };
}
interface FeatureFlags { [key: string]: boolean; }

const FEATURE_LABELS: Record<string, string> = {
  FEATURE_AI_ASSISTANT:          'AI Assistant',
  FEATURE_AI_INVENTORY_FORECAST: 'Inventory Forecasting',
  FEATURE_AI_NLP_SEARCH:         'NLP Search',
  FEATURE_AI_RECOMMENDATIONS:    'AI Recommendations',
  FEATURE_AI_SUMMARIZATION:      'Workflow Summarisation',
  FEATURE_AI_PREDICTIVE_ANALYTICS: 'Predictive Analytics',
};

const CONFIDENCE_COLOR = (c: number) =>
  c >= 80 ? '#16A34A' : c >= 60 ? '#D97706' : '#DC2626';

export default function AiPage() {
  const { user } = useAuthStore();
  const [searchQ, setSearchQ] = useState('');
  const [searchResult, setSearchResult] = useState<string | null>(null);

  const { data: flags } = useQuery({
    queryKey: ['feature-flags'],
    queryFn:  () => api.get<FeatureFlags>('/feature-flags'),
    staleTime: 30_000,
  });

  const { data: insightsAdvisory, isLoading: insightsLoading } = useQuery({
    queryKey: ['ai-insights', user?.branchId],
    queryFn:  () => api.get<AiAdvisory<AiInsight[]>>(`/ai/insights?branchId=${user?.branchId ?? ''}`),
    enabled:  !!flags?.FEATURE_AI_ASSISTANT,
    staleTime: 300_000,
  });

  const { data: forecastAdvisory, isLoading: forecastLoading } = useQuery({
    queryKey: ['ai-forecast', user?.branchId],
    queryFn:  () => api.get<AiAdvisory<InventoryForecast[]>>(`/ai/inventory-forecast?branchId=${user?.branchId ?? ''}`),
    enabled:  !!flags?.FEATURE_AI_INVENTORY_FORECAST,
    staleTime: 300_000,
  });

  const { mutate: nlpSearch, isPending: searching } = useMutation({
    mutationFn: (q: string) => api.post<AiAdvisory<{ answer: string; sources: string[] }>>('/ai/search', { query: q, branchId: user?.branchId }),
    onSuccess:  (data) => setSearchResult(data.advisory.answer),
  });

  const insights  = insightsAdvisory?.advisory ?? [];
  const forecasts = forecastAdvisory?.advisory ?? [];
  const anyAiEnabled = Object.entries(flags ?? {}).some(([k, v]) => k.startsWith('FEATURE_AI') && v);

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: '#EDE9FE' }}>
          <Brain className="h-5 w-5" style={{ color: '#6D28D9' }} />
        </div>
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">AI Intelligence Layer</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">Advisory only · All actions require human approval</p>
        </div>
      </div>

      {/* AI Governance notice */}
      <div className="flex items-start gap-3 px-4 py-3 rounded-lg border"
        style={{ background: '#FFFBEB', borderColor: '#FDE68A' }}>
        <AlertTriangle className="h-4 w-4 text-[#B45309] flex-shrink-0 mt-0.5" />
        <div className="text-[12px] text-[#B45309]">
          <strong>AI Governance:</strong> All AI outputs are advisory. The AI may summarise, recommend, draft, forecast, and classify —
          but may never approve financial transactions, modify inventory, alter accounting records, override approvals, or bypass RBAC.
          Every AI suggestion requires human confirmation before taking effect.
        </div>
      </div>

      {/* Feature flags panel */}
      <div className="bg-white rounded-lg border border-[#E5E7EB] p-4">
        <h2 className="font-heading text-[15px] text-[#1A1A1A] mb-3">AI Feature Flags</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {Object.entries(FEATURE_LABELS).map(([flag, label]) => {
            const enabled = flags?.[flag] ?? false;
            return (
              <div key={flag} className="flex items-center justify-between px-3 py-2.5 rounded-md border border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${enabled ? 'bg-[#16A34A]' : 'bg-[#D1D5DB]'}`} />
                  <span className="text-[12px] text-[#1A1A1A]">{label}</span>
                </div>
                <span className={`text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded ${
                  enabled ? 'bg-[#DCFCE7] text-[#15803D]' : 'bg-[#F3F4F6] text-[#9CA3AF]'}`}>
                  {enabled ? 'On' : 'Off'}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {!anyAiEnabled ? (
        <div className="bg-white rounded-lg border border-[#E5E7EB] py-14 text-center">
          <Sparkles className="h-10 w-10 mx-auto mb-3 text-[#D1D5DB]" />
          <h3 className="font-heading text-base text-[#1A1A1A] mb-1">AI features are disabled</h3>
          <p className="text-[12px] text-[#9CA3AF] max-w-xs mx-auto">
            Enable AI features from Admin → Feature Flags to activate the intelligence layer.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

          {/* NLP Search */}
          {flags?.FEATURE_AI_NLP_SEARCH && (
            <div className="bg-white rounded-lg border border-[#E5E7EB] p-4 lg:col-span-2">
              <div className="flex items-center gap-2 mb-3">
                <Search className="h-4 w-4 text-[#6D28D9]" />
                <h2 className="font-heading text-[15px] text-[#1A1A1A]">NLP Business Search</h2>
                <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#EDE9FE] text-[#6D28D9]">ADVISORY</span>
              </div>
              <div className="flex gap-2">
                <input value={searchQ} onChange={e => setSearchQ(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && searchQ.length >= 3 && nlpSearch(searchQ)}
                  placeholder="Ask anything about your ERP data… e.g. 'What are my top 5 customers by revenue this quarter?'"
                  className="flex-1 h-10 px-4 text-[13px] rounded-lg border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#6D28D9]" />
                <button onClick={() => nlpSearch(searchQ)} disabled={searching || searchQ.length < 3}
                  className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white rounded-lg disabled:opacity-60"
                  style={{ background: '#6D28D9' }}>
                  {searching ? <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" /> : <Brain className="h-4 w-4" />}
                  Ask AI
                </button>
              </div>
              {searchResult && (
                <div className="mt-3 p-3 rounded-lg" style={{ background: '#F5F3FF', border: '1px solid #DDD6FE' }}>
                  <p className="text-[12px] text-[#4C1D95] leading-relaxed">{searchResult}</p>
                  <p className="text-[10px] text-[#7C3AED] mt-2 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" /> This is an AI-generated advisory. Verify with source data before acting.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* AI Insights feed */}
          {flags?.FEATURE_AI_ASSISTANT && (
            <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
              <div className="px-4 py-3 flex items-center justify-between border-b border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-[#D97706]" />
                  <h2 className="font-heading text-[15px] text-[#1A1A1A]">AI Insights</h2>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#FEF3C7] text-[#B45309]">ADVISORY</span>
              </div>
              <div className="divide-y divide-[#F3F4F6] max-h-[400px] overflow-y-auto">
                {insightsLoading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="px-4 py-3 space-y-1.5">
                      <div className="h-3.5 w-3/4 bg-[#F3F4F6] rounded animate-pulse" />
                      <div className="h-3 w-full bg-[#F3F4F6] rounded animate-pulse" />
                    </div>
                  ))
                ) : insights.length === 0 ? (
                  <div className="px-4 py-10 text-center text-[12px] text-[#9CA3AF]">No insights generated yet</div>
                ) : insights.map(insight => (
                  <div key={insight.id} className="px-4 py-3">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="text-[9px] font-bold uppercase tracking-wide px-1.5 py-0.5 rounded bg-[#EDE9FE] text-[#6D28D9]">
                        {insight.category}
                      </span>
                      <span className="text-[10px] font-semibold" style={{ color: CONFIDENCE_COLOR(insight.confidence) }}>
                        {insight.confidence}% confidence
                      </span>
                    </div>
                    <h3 className="text-[12px] font-semibold text-[#1A1A1A] mb-0.5">{insight.title}</h3>
                    <p className="text-[11px] text-[#6B7280] leading-relaxed">{insight.summary}</p>
                    {insight.suggestedAction && (
                      <div className="mt-2 flex items-start gap-1.5 text-[11px] text-[#B45309]">
                        <AlertTriangle className="h-3 w-3 flex-shrink-0 mt-0.5" />
                        <span>Suggested: {insight.suggestedAction} (requires human approval)</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Inventory forecast */}
          {flags?.FEATURE_AI_INVENTORY_FORECAST && (
            <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
              <div className="px-4 py-3 flex items-center justify-between border-b border-[#E5E7EB]">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-[#0EA5E9]" />
                  <h2 className="font-heading text-[15px] text-[#1A1A1A]">Inventory Forecast</h2>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#E0F2FE] text-[#0369A1]">ADVISORY</span>
              </div>
              <div className="divide-y divide-[#F3F4F6] max-h-[400px] overflow-y-auto">
                {forecastLoading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="px-4 py-3 space-y-1.5 animate-pulse">
                      <div className="h-3.5 w-3/4 bg-[#F3F4F6] rounded" />
                      <div className="h-3 w-1/2 bg-[#F3F4F6] rounded" />
                    </div>
                  ))
                ) : forecasts.length === 0 ? (
                  <div className="px-4 py-10 text-center text-[12px] text-[#9CA3AF]">No forecasts available</div>
                ) : forecasts.map(f => (
                  <div key={f.productId} className="px-4 py-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[10px] font-semibold text-[#1A4D2E]">{f.sku}</span>
                      <span className="text-[10px] font-semibold" style={{ color: CONFIDENCE_COLOR(f.confidence) }}>
                        {f.confidence}%
                      </span>
                    </div>
                    <p className="text-[12px] font-medium text-[#1A1A1A] mb-1">{f.productName}</p>
                    <div className="flex gap-4 text-[11px] text-[#6B7280]">
                      <span>Stock: <strong>{f.currentStock}</strong></span>
                      <span>Forecasted demand: <strong>{f.forecastedDemand}</strong></span>
                    </div>
                    <p className="text-[11px] text-[#B45309] mt-1">
                      Reorder by {f.forecastedReorderDate} · {f.recommendation}
                    </p>
                  </div>
                ))}
              </div>
              {forecastAdvisory && (
                <div className="px-4 py-2.5 border-t border-[#E5E7EB]">
                  <p className="text-[10px] text-[#9CA3AF]">
                    {forecastAdvisory.governance.disclaimer}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
