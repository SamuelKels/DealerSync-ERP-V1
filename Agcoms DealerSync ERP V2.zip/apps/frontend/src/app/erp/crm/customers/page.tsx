'use client';
// app/(erp)/crm/customers/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { Search, Plus, Phone, Mail, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api, queryKeys } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface Customer {
  id: string; name: string; tradingName?: string;
  customerType: string; status: string;
  email?: string; phone: string;
  city?: string; state?: string;
  creditLimit: number; branchId: string; createdAt: string;
}
interface PagedCustomers { items: Customer[]; total: number; hasMore: boolean; nextCursor?: string; }

const col = createColumnHelper<Customer>();

export default function CustomersPage() {
  const { user }     = useAuthStore();
  const [q, setQ]    = useState('');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const limit = 25;

  const params = buildSearchParams({
    q, customerType: type, status,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit, page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.customers.list({ q, type, status, page }),
    queryFn:  () => api.get<PagedCustomers>(`/crm/customers?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  const columns = [
    col.accessor('name', {
      header: 'Customer',
      cell:   (info) => (
        <div>
          <Link
            href={`/crm/customers/${info.row.original.id}`}
            className="text-[13px] font-medium text-[#1A4D2E] hover:underline"
          >
            {info.getValue()}
          </Link>
          {info.row.original.tradingName && (
            <div className="text-[11px] text-[#6B7280]">{info.row.original.tradingName}</div>
          )}
        </div>
      ),
    }),
    col.accessor('customerType', {
      header: 'Type',
      cell:   (info) => (
        <span
          className="px-1.5 py-0.5 rounded text-[9.5px] font-semibold uppercase tracking-wide"
          style={{ background: '#EDF4EF', color: '#1A4D2E' }}
        >
          {info.getValue()}
        </span>
      ),
    }),
    col.accessor('status', {
      header: 'Status',
      cell:   (info) => {
        const s = getStatusStyle(info.getValue());
        return (
          <span
            className="px-1.5 py-0.5 rounded text-[9.5px] font-semibold uppercase tracking-wide"
            style={{ background: s.bg, color: s.color }}
          >
            {info.getValue()}
          </span>
        );
      },
    }),
    col.accessor('phone', {
      header: 'Contact',
      cell:   (info) => (
        <div className="space-y-0.5">
          <div className="flex items-center gap-1 text-[12px] text-[#1A1A1A]">
            <Phone className="h-3 w-3 text-[#9CA3AF]" />
            {info.getValue()}
          </div>
          {info.row.original.email && (
            <div className="flex items-center gap-1 text-[11px] text-[#6B7280]">
              <Mail className="h-3 w-3 text-[#9CA3AF]" />
              {info.row.original.email}
            </div>
          )}
        </div>
      ),
    }),
    col.accessor('city', {
      header: 'Location',
      cell:   (info) => (
        <span className="text-[12px] text-[#6B7280]">
          {[info.getValue(), info.row.original.state].filter(Boolean).join(', ') || '—'}
        </span>
      ),
    }),
    col.accessor('creditLimit', {
      header: 'Credit Limit',
      cell:   (info) => (
        <span className="font-mono text-[12px] font-semibold text-right block">
          {formatNGN(info.getValue())}
        </span>
      ),
    }),
    col.accessor('createdAt', {
      header: 'Since',
      cell:   (info) => <span className="text-[11px] text-[#9CA3AF]">{formatDate(info.getValue())}</span>,
    }),
    col.display({
      id:   'actions',
      cell: (info) => (
        <Link
          href={`/crm/customers/${info.row.original.id}`}
          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E] transition-colors"
        >
          <ChevronRight className="h-4 w-4" />
        </Link>
      ),
    }),
  ];

  const table = useReactTable({
    data:            data?.items ?? [],
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      {/* ── Page header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Customers</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} total` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/crm/customers/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white transition-all active:scale-[.98]"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Customer
        </Link>
      </div>

      {/* ── Filters ── */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input
            value={q}
            onChange={(e) => { setQ(e.target.value); setPage(1); }}
            placeholder="Search customers…"
            className="pl-8 pr-3 h-8 w-[220px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
          />
        </div>
        <select
          value={type}
          onChange={(e) => { setType(e.target.value); setPage(1); }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All types</option>
          {['INDIVIDUAL', 'CORPORATE', 'GOVERNMENT', 'NGO'].map((t) => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
        <select
          value={status}
          onChange={(e) => { setStatus(e.target.value); setPage(1); }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All statuses</option>
          {['ACTIVE', 'INACTIVE', 'BLACKLISTED', 'PROSPECT'].map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      {/* ── Table ── */}
      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              {table.getHeaderGroups().map((hg) => (
                <tr key={hg.id} className="border-b-2 border-[#E5E7EB]">
                  {hg.headers.map((h) => (
                    <th
                      key={h.id}
                      className="px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-[#6B7280] bg-white whitespace-nowrap"
                    >
                      {flexRender(h.column.columnDef.header, h.getContext())}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {isLoading
                ? Array.from({ length: 8 }).map((_, i) => (
                    <tr key={i} className="border-b border-[#F3F4F6]">
                      {columns.map((_, j) => (
                        <td key={j} className="px-3 py-3">
                          <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" style={{ width: `${60 + Math.random() * 30}%` }} />
                        </td>
                      ))}
                    </tr>
                  ))
                : table.getRowModel().rows.length === 0
                ? (
                  <tr>
                    <td colSpan={columns.length} className="py-16 text-center text-[13px] text-[#9CA3AF]">
                      No customers found
                    </td>
                  </tr>
                )
                : table.getRowModel().rows.map((row) => (
                  <tr
                    key={row.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    {row.getVisibleCells().map((cell) => (
                      <td key={cell.id} className="px-3 py-2.5 align-middle">
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">
            {data?.total !== undefined ? `${data.total.toLocaleString()} customers` : ''}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF] transition-colors"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] min-w-[40px] text-center">Page {page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF] transition-colors"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
