'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Users, Plus, ChevronRight, Phone, Mail } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatDate, getStatusStyle } from '../../../../lib/utils';

interface Lead {
  id: string; leadNo: string; name: string; company?: string;
  email?: string; phone?: string; source: string; stage: string;
  assignedTo?: { firstName: string; lastName: string };
  estimatedValue?: number; createdAt: string;
}

export default function LeadsPage() {
  const [stage, setStage]   = useState('');
  const [source, setSource] = useState('');
  const [page, setPage]     = useState(1);
  const { user }            = useAuthStore();

  const params = new URLSearchParams({
    ...(stage  ? { stage }  : {}),
    ...(source ? { source } : {}),
    ...(user?.branchId && !user.isSuperAdmin ? { branchId: user.branchId } : {}),
    limit: '25', page: String(page),
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['leads', { stage, source, page }],
    queryFn:  () => api.get<{ items: Lead[]; total: number; hasMore: boolean }>(`/crm/leads?${params}`),
    staleTime: 30_000, placeholderData: prev => prev,
  });

  const STAGES  = ['NEW', 'CONTACTED', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION', 'WON', 'LOST'];
  const SOURCES = ['REFERRAL', 'WEBSITE', 'TRADE_SHOW', 'COLD_CALL', 'NADF_PROGRAMME', 'GOVERNMENT', 'OTHER'];

  const stageColor: Record<string, { bg: string; color: string }> = {
    NEW:         { bg: '#E6F1FB', color: '#0C447C' },
    CONTACTED:   { bg: '#EAF3DE', color: '#27500A' },
    QUALIFIED:   { bg: '#EEEDFE', color: '#3C3489' },
    PROPOSAL:    { bg: '#FAEEDA', color: '#633806' },
    NEGOTIATION: { bg: '#FEF3C7', color: '#92400E' },
    WON:         { bg: '#DCFCE7', color: '#15803D' },
    LOST:        { bg: '#FEE2E2', color: '#B91C1C' },
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Leads</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data ? `${data.total.toLocaleString()} leads` : 'Loading…'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isFetching && !isLoading && (
            <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
          )}
          <Link href="/crm/leads/new"
            className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
            style={{ background: '#1A4D2E' }}>
            <Plus className="h-4 w-4" /> Add Lead
          </Link>
        </div>
      </div>

      {/* Stage pipeline bar */}
      <div className="bg-white rounded-lg border border-[#E5E7EB] p-3">
        <div className="flex items-center gap-1 overflow-x-auto pb-1">
          {STAGES.map(s => {
            const count = (data?.items ?? []).filter(l => l.stage === s).length;
            const sc = stageColor[s] ?? { bg: '#F3F4F6', color: '#6B7280' };
            return (
              <button key={s}
                onClick={() => { setStage(stage === s ? '' : s); setPage(1); }}
                className="flex flex-col items-center px-4 py-2 rounded-lg flex-1 min-w-[80px] transition-all"
                style={stage === s ? { background: sc.bg } : { background: '#FAFAFA' }}>
                <span className="text-[18px] font-semibold" style={{ color: sc.color }}>
                  {isLoading ? '—' : count}
                </span>
                <span className="text-[9px] font-semibold uppercase tracking-wider mt-0.5"
                  style={{ color: stage === s ? sc.color : '#9CA3AF' }}>
                  {s.replace(/_/g, ' ')}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[11px] text-[#6B7280] font-medium">Source:</span>
        {SOURCES.map(s => (
          <button key={s}
            onClick={() => { setSource(source === s ? '' : s); setPage(1); }}
            className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
            style={source === s
              ? { background: '#E6F1FB', color: '#0C447C', borderColor: 'transparent' }
              : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }}>
            {s.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['Lead', 'Company', 'Contact', 'Source', 'Stage', 'Assigned', 'Est. Value', 'Date', ''].map(h => (
                <th key={h} className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 9 }).map((_, j) => (
                    <td key={j} className="px-3 py-3"><div className="h-4 bg-[#F3F4F6] rounded animate-pulse" /></td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr><td colSpan={9} className="py-16 text-center">
                <Users className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                <p className="text-[13px] text-[#9CA3AF]">No leads found</p>
                <Link href="/crm/leads/new" className="mt-2 inline-block text-[12px] text-[#1A4D2E] underline">Add your first lead</Link>
              </td></tr>
            ) : (data?.items ?? []).map(lead => {
              const sc = stageColor[lead.stage] ?? { bg: '#F3F4F6', color: '#6B7280' };
              return (
                <tr key={lead.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                  <td className="px-3 py-2.5">
                    <Link href={`/crm/leads/${lead.id}`}
                      className="font-medium text-[12px] text-[#1A4D2E] hover:underline block">{lead.name}</Link>
                    <span className="font-mono text-[10px] text-[#9CA3AF]">{lead.leadNo}</span>
                  </td>
                  <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{lead.company ?? '—'}</td>
                  <td className="px-3 py-2.5">
                    <div className="flex flex-col gap-0.5">
                      {lead.email && <span className="flex items-center gap-1 text-[11px] text-[#6B7280]"><Mail className="h-3 w-3" />{lead.email}</span>}
                      {lead.phone && <span className="flex items-center gap-1 text-[11px] text-[#6B7280]"><Phone className="h-3 w-3" />{lead.phone}</span>}
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#F3F4F6] text-[#6B7280] font-semibold">
                      {lead.source.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                      style={{ background: sc.bg, color: sc.color }}>{lead.stage.replace(/_/g, ' ')}</span>
                  </td>
                  <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                    {lead.assignedTo ? `${lead.assignedTo.firstName} ${lead.assignedTo.lastName}` : '—'}
                  </td>
                  <td className="px-3 py-2.5 font-mono text-[11px] text-right">
                    {lead.estimatedValue ? `₦${Number(lead.estimatedValue).toLocaleString()}` : '—'}
                  </td>
                  <td className="px-3 py-2.5 text-[11px] text-[#6B7280] whitespace-nowrap">{formatDate(lead.createdAt)}</td>
                  <td className="px-3 py-2.5">
                    <Link href={`/crm/leads/${lead.id}`}
                      className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]">
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total?.toLocaleString()} leads</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">← Prev</button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">Page {page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]">Next →</button>
          </div>
        </div>
      </div>
    </div>
  );
}
