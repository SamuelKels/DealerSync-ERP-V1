'use client';
// app/(erp)/dashboard/page.tsx
import type { Metadata } from 'next';
import { useQuery } from '@tanstack/react-query';
import { TrendingUp, TrendingDown, Package, Users, ShoppingCart, Truck, AlertTriangle, CheckCircle2, Clock } from 'lucide-react';
import { api, queryKeys } from '../../../lib/api';
import { useAuthStore } from '../../../stores/auth.store';
import { formatNGN, formatRelative } from '../../../lib/utils';

// ── Types ─────────────────────────────────────────────────────
interface DashboardKpis {
  revenue:         { current: number; previous: number };
  openInvoices:    { count: number; value: number };
  activeContracts: { count: number; value: number };
  pendingPOs:      { count: number; value: number };
  stockAlerts:     number;
  openJobCards:    number;
  fleetActive:     number;
  activeEmployees: number;
}

interface DashboardAlert {
  id:       string;
  type:     'warning' | 'danger' | 'info' | 'success';
  message:  string;
  module:   string;
  createdAt: string;
}

// ── Skeleton ──────────────────────────────────────────────────
function KpiSkeleton() {
  return (
    <div className="bg-white rounded-lg border border-[#E5E7EB] p-3.5 space-y-2">
      <div className="h-2.5 w-24 bg-[#F3F4F6] rounded animate-pulse" />
      <div className="h-7 w-20 bg-[#F3F4F6] rounded animate-pulse" />
      <div className="h-2.5 w-16 bg-[#F3F4F6] rounded animate-pulse" />
    </div>
  );
}

// ── KPI Card ──────────────────────────────────────────────────
function KpiCard({
  label, value, subValue, trend, icon: Icon, iconColor,
}: {
  label:      string;
  value:      string;
  subValue?:  string;
  trend?:     { value: number; label: string };
  icon:       React.ElementType;
  iconColor:  string;
}) {
  const isUp = (trend?.value ?? 0) >= 0;
  return (
    <div className="bg-white rounded-lg border border-[#E5E7EB] p-3.5 animate-fade-up hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">{label}</div>
          <div className="font-heading text-2xl text-[#1A1A1A] mt-1 leading-none">{value}</div>
          {subValue && <div className="text-[11px] text-[#6B7280] mt-1">{subValue}</div>}
          {trend && (
            <div className={`flex items-center gap-1 mt-1.5 text-[11px] ${isUp ? 'text-[#16A34A]' : 'text-[#DC2626]'}`}>
              {isUp ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {Math.abs(trend.value)}% {trend.label}
            </div>
          )}
        </div>
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center"
          style={{ background: `${iconColor}15` }}
        >
          <Icon className="h-4 w-4" style={{ color: iconColor }} />
        </div>
      </div>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────
export default function DashboardPage() {
  const { user } = useAuthStore();
  const branchId = user?.branchId ?? '';

  const { data: kpis, isLoading: kpisLoading } = useQuery({
    queryKey: queryKeys.dashboard.kpis(branchId),
    queryFn:  () => api.get<DashboardKpis>(`/dashboard/kpis?branchId=${branchId}`),
    enabled:  !!branchId,
    staleTime: 60_000,
  });

  const { data: alerts = [], isLoading: alertsLoading } = useQuery({
    queryKey: queryKeys.dashboard.alerts(branchId),
    queryFn:  () => api.get<DashboardAlert[]>(`/dashboard/alerts?branchId=${branchId}`),
    enabled:  !!branchId,
    staleTime: 30_000,
  });

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const trendPct = (curr: number, prev: number) =>
    prev > 0 ? Math.round(((curr - prev) / prev) * 100) : 0;

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-6">
      {/* ── Header ── */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-heading text-2xl text-[#1A1A1A]">
            {greeting()}, {user?.firstName ?? 'there'}
          </h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {new Date().toLocaleDateString('en-NG', {
              weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
            })}
          </p>
        </div>
        <div
          className="text-[11px] px-2.5 py-1 rounded-full font-medium"
          style={{ background: '#EDF4EF', color: '#1A4D2E' }}
        >
          All systems operational
        </div>
      </div>

      {/* ── KPI Grid ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpisLoading ? (
          Array.from({ length: 8 }).map((_, i) => <KpiSkeleton key={i} />)
        ) : kpis ? (
          <>
            <KpiCard
              label="Revenue (MTD)"
              value={formatNGN(kpis.revenue.current, true)}
              trend={{ value: trendPct(kpis.revenue.current, kpis.revenue.previous), label: 'vs last month' }}
              icon={TrendingUp}
              iconColor="#1A4D2E"
            />
            <KpiCard
              label="Open Invoices"
              value={String(kpis.openInvoices.count)}
              subValue={formatNGN(kpis.openInvoices.value, true) + ' outstanding'}
              icon={ShoppingCart}
              iconColor="#E8A020"
            />
            <KpiCard
              label="Active Contracts"
              value={String(kpis.activeContracts.count)}
              subValue={formatNGN(kpis.activeContracts.value, true) + ' value'}
              icon={Package}
              iconColor="#0EA5E9"
            />
            <KpiCard
              label="Pending POs"
              value={String(kpis.pendingPOs.count)}
              subValue={formatNGN(kpis.pendingPOs.value, true) + ' value'}
              icon={Truck}
              iconColor="#D97706"
            />
            <KpiCard
              label="Stock Alerts"
              value={String(kpis.stockAlerts)}
              subValue="items below reorder point"
              icon={Package}
              iconColor={kpis.stockAlerts > 0 ? '#DC2626' : '#16A34A'}
            />
            <KpiCard
              label="Open Job Cards"
              value={String(kpis.openJobCards)}
              icon={Clock}
              iconColor="#6D28D9"
            />
            <KpiCard
              label="Fleet Active"
              value={String(kpis.fleetActive)}
              subValue="assets in field"
              icon={Truck}
              iconColor="#1A4D2E"
            />
            <KpiCard
              label="Employees"
              value={String(kpis.activeEmployees)}
              icon={Users}
              iconColor="#0EA5E9"
            />
          </>
        ) : (
          <div className="col-span-4 py-12 text-center text-[13px] text-[#9CA3AF]">
            Dashboard data unavailable. Please refresh.
          </div>
        )}
      </div>

      {/* ── Alerts panel ── */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-lg border border-[#E5E7EB]">
          <div className="px-4 py-3 border-b border-[#F3F4F6] flex items-center justify-between">
            <h2 className="font-heading text-[15px] text-[#1A1A1A]">System Alerts</h2>
            <span className="text-[10px] text-[#6B7280]">{alerts.length} active</span>
          </div>
          <div className="divide-y divide-[#F3F4F6]">
            {alertsLoading
              ? Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="px-4 py-3 space-y-1">
                    <div className="h-3 w-3/4 bg-[#F3F4F6] rounded animate-pulse" />
                    <div className="h-2.5 w-1/2 bg-[#F3F4F6] rounded animate-pulse" />
                  </div>
                ))
              : alerts.length === 0
              ? (
                <div className="flex flex-col items-center py-8 text-center">
                  <CheckCircle2 className="h-8 w-8 text-[#16A34A] mb-2" />
                  <p className="text-[13px] text-[#6B7280]">No active alerts</p>
                </div>
              )
              : alerts.slice(0, 6).map((alert) => (
                <div key={alert.id} className="px-4 py-3 flex items-start gap-3">
                  <AlertTriangle
                    className="h-4 w-4 flex-shrink-0 mt-0.5"
                    style={{ color: alert.type === 'danger' ? '#DC2626' : '#D97706' }}
                  />
                  <div>
                    <p className="text-[12px] text-[#1A1A1A]">{alert.message}</p>
                    <p className="text-[10px] text-[#9CA3AF] mt-0.5">
                      {alert.module} · {formatRelative(alert.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Quick links */}
        <div className="bg-white rounded-lg border border-[#E5E7EB]">
          <div className="px-4 py-3 border-b border-[#F3F4F6]">
            <h2 className="font-heading text-[15px] text-[#1A1A1A]">Quick Actions</h2>
          </div>
          <div className="p-3 grid grid-cols-2 gap-2">
            {[
              { label: 'New Quotation',    href: '/sales/quotations/new',          color: '#1A4D2E' },
              { label: 'New PO',           href: '/procurement/purchase-orders/new', color: '#D97706' },
              { label: 'Log Service Job',  href: '/workshop/service-requests/new', color: '#6D28D9' },
              { label: 'Record Payment',   href: '/sales/invoices',                color: '#0EA5E9' },
              { label: 'Stock Transfer',   href: '/inventory/stock',               color: '#E8A020' },
              { label: 'Run Payroll',      href: '/hr/payroll/run',               color: '#16A34A' },
            ].map(({ label, href, color }) => (
              <a
                key={label}
                href={href}
                className="flex items-center gap-2 p-2.5 rounded-md text-[12px] font-medium text-[#1A1A1A] hover:bg-[#F7F4EF] border border-[#E5E7EB] transition-colors"
              >
                <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                {label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
