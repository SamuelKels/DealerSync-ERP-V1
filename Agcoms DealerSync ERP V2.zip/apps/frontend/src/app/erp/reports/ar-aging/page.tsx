'use client';
// app/(erp)/reports/ar-aging/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Download, RefreshCw, TrendingDown } from 'lucide-react';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, buildSearchParams } from '../../../../lib/utils';

interface AgingBucket {
  label: string; days: string; count: number; amount: number; percentage: number;
}
interface AgingCustomer {
  customerId: string; customerName: string;
  current: number; days1_30: number; days31_60: number; days61_90: number; over90: number;
  total: number; oldestInvoice: string;
}
interface ArAgingReport {
  asAt: string; currency: string;
  buckets: AgingBucket[];
  customers: AgingCustomer[];
  grandTotal: number;
}

const BUCKET_COLORS = ['#16A34A', '#D97706', '#EA580C', '#DC2626', '#7F1D1D'];

export default function ArAgingPage() {
  const [branchId, setBranchId] = useState('');
  const { user }   = useAuthStore();
  const effectiveBranch = user?.isSuperAdmin ? branchId : (user?.branchId ?? '');

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['ar-aging', effectiveBranch],
    queryFn:  () => api.get<ArAgingReport>(`/reports/ar-aging?branchId=${effectiveBranch}`),
    staleTime: 300_000,
  });

  const chartData = data?.buckets.map((b, i) => ({
    name:    b.label,
    amount:  b.amount,
    count:   b.count,
    color:   BUCKET_COLORS[i] ?? '#9CA3AF',
  })) ?? [];

  const formatTooltip = (v: number) => formatNGN(v);

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">AR Aging Report</h1>
          {data && <p className="text-[12px] text-[#6B7280] mt-0.5">As at {data.asAt} · {data.currency}</p>}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => refetch()} disabled={isFetching}
            className="flex items-center gap-1.5 px-3 py-2 text-[12px] rounded-md border border-[#D1D5DB] hover:bg-[#F7F4EF] transition-colors">
            <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button disabled={!data}
            className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium text-white rounded-md disabled:opacity-50"
            style={{ background: '#1A4D2E' }}>
            <Download className="h-3.5 w-3.5" /> Export Excel
          </button>
        </div>
      </div>

      {/* Bucket summary cards */}
      {isLoading ? (
        <div className="grid grid-cols-5 gap-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="bg-white rounded-lg border border-[#E5E7EB] p-3 space-y-2 animate-pulse">
              <div className="h-3 w-16 bg-[#F3F4F6] rounded" />
              <div className="h-6 w-20 bg-[#F3F4F6] rounded" />
            </div>
          ))}
        </div>
      ) : data ? (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {data.buckets.map((b, i) => (
              <div key={b.label} className="bg-white rounded-lg border border-[#E5E7EB] p-3">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="w-2 h-2 rounded-full" style={{ background: BUCKET_COLORS[i] }} />
                  <span className="text-[10px] font-semibold uppercase tracking-wide text-[#6B7280]">{b.label}</span>
                </div>
                <div className="font-heading text-lg leading-none" style={{ color: BUCKET_COLORS[i] }}>
                  {formatNGN(b.amount, true)}
                </div>
                <div className="text-[10px] text-[#9CA3AF] mt-0.5">{b.count} inv · {b.percentage.toFixed(0)}%</div>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="flex items-center gap-3 px-4 py-3 rounded-lg border"
            style={{ background: '#FEF3C7', borderColor: '#FDE68A' }}>
            <TrendingDown className="h-5 w-5 text-[#B45309]" />
            <div>
              <span className="text-[12px] font-semibold text-[#B45309]">Total Outstanding AR: </span>
              <span className="font-mono text-[14px] font-bold text-[#B45309]">{formatNGN(data.grandTotal)}</span>
            </div>
          </div>

          {/* Chart */}
          <div className="bg-white rounded-lg border border-[#E5E7EB] p-4">
            <h2 className="font-heading text-[15px] text-[#1A1A1A] mb-4">Aging Breakdown</h2>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData} margin={{ top: 0, right: 0, bottom: 0, left: 60 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#6B7280' }} />
                <YAxis tick={{ fontSize: 11, fill: '#6B7280' }} tickFormatter={v => `₦${(v / 1_000_000).toFixed(0)}M`} />
                <Tooltip formatter={formatTooltip} labelStyle={{ color: '#1A1A1A' }} contentStyle={{ borderRadius: 6, border: '1px solid #E5E7EB', fontSize: 12 }} />
                <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Customer detail table */}
          <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
            <div className="px-4 py-3 border-b border-[#E5E7EB]">
              <h2 className="font-heading text-[15px] text-[#1A1A1A]">By Customer</h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b border-[#E5E7EB]">
                    {['Customer', 'Current', '1–30 Days', '31–60 Days', '61–90 Days', '>90 Days', 'Total', 'Oldest Inv.'].map(h => (
                      <th key={h} className="px-3 py-2 text-right text-[9px] font-semibold uppercase tracking-wider text-[#6B7280] first:text-left whitespace-nowrap">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.customers.map(c => (
                    <tr key={c.customerId} className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]">
                      <td className="px-3 py-2.5 text-[13px] font-medium text-[#1A4D2E]">{c.customerName}</td>
                      {[c.current, c.days1_30, c.days31_60, c.days61_90, c.over90].map((v, i) => (
                        <td key={i} className="px-3 py-2.5 font-mono text-[11px] text-right"
                          style={{ color: v > 0 ? (i === 0 ? '#16A34A' : BUCKET_COLORS[i + 1] ?? '#DC2626') : '#D1D5DB' }}>
                          {v > 0 ? formatNGN(v) : '—'}
                        </td>
                      ))}
                      <td className="px-3 py-2.5 font-mono text-[11px] font-bold text-right text-[#1A1A1A]">{formatNGN(c.total)}</td>
                      <td className="px-3 py-2.5 text-[11px] text-right text-[#9CA3AF] whitespace-nowrap">{formatDate(c.oldestInvoice)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr style={{ background: '#1A4D2E' }}>
                    <td className="px-3 py-2.5 text-[11px] font-bold text-white">Grand Total</td>
                    {data.buckets.map(b => (
                      <td key={b.label} className="px-3 py-2.5 font-mono text-[11px] font-bold text-right text-white">{formatNGN(b.amount)}</td>
                    ))}
                    <td className="px-3 py-2.5 font-mono text-[11px] font-bold text-right text-white">{formatNGN(data.grandTotal)}</td>
                    <td />
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
