'use client';
// app/(auth)/login/page.tsx
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { z } from 'zod';
import { Eye, EyeOff, Mail, Lock, LogIn } from 'lucide-react';
import { useState } from 'react';
import { useAuthStore } from '../../../stores/auth.store';

const LoginSchema = z.object({
  email:    z.string().email('Enter a valid email address').toLowerCase().trim(),
  password: z.string().min(1, 'Password is required'),
});
type LoginForm = z.infer<typeof LoginSchema>;

export default function LoginPage() {
  const router       = useRouter();
  const { login, step, error, clearError, isLoading } = useAuthStore();
  const [showPass, setShowPass] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver:      zodResolver(LoginSchema),
    defaultValues: { email: '', password: '' },
  });

  // Redirect after login
  useEffect(() => {
    if (step === 'mfa')           router.push('/mfa');
    if (step === 'authenticated') router.push('/dashboard');
  }, [step, router]);

  useEffect(() => {
    if (error) {
      toast.error(error);
      clearError();
    }
  }, [error, clearError]);

  return (
    <div className="animate-fade-up">
      <div className="mb-8">
        <h2 className="font-heading text-[26px] text-[#1A1A1A]">Sign in</h2>
        <p className="mt-1 text-[13px] text-[#6B7280]">Enter your credentials to continue</p>
      </div>

      <form onSubmit={handleSubmit(({ email, password }) => login(email, password))} className="space-y-4">
        {/* Email */}
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            Email Address <span className="text-[#DC2626]">*</span>
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
            <input
              {...register('email')}
              type="email"
              placeholder="you@agcoms.ng"
              autoComplete="email"
              className="w-full h-9 pl-9 pr-3 text-sm rounded-md border border-[#D1D5DB] bg-white text-[#1A1A1A] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1A4D2E] transition-colors"
            />
          </div>
          {errors.email && <p className="text-[11px] text-[#DC2626]">⚠ {errors.email.message}</p>}
        </div>

        {/* Password */}
        <div className="flex flex-col gap-1">
          <label className="text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]">
            Password <span className="text-[#DC2626]">*</span>
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
            <input
              {...register('password')}
              type={showPass ? 'text' : 'password'}
              placeholder="••••••••••••"
              autoComplete="current-password"
              className="w-full h-9 pl-9 pr-9 text-sm rounded-md border border-[#D1D5DB] bg-white text-[#1A1A1A] placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 focus:ring-[#1A4D2E] transition-colors"
            />
            <button
              type="button"
              onClick={() => setShowPass((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#9CA3AF] hover:text-[#6B7280]"
              aria-label={showPass ? 'Hide password' : 'Show password'}
            >
              {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          </div>
          {errors.password && <p className="text-[11px] text-[#DC2626]">⚠ {errors.password.message}</p>}
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full h-10 rounded-md text-sm font-medium text-white flex items-center justify-center gap-2 transition-all active:scale-[.98] disabled:opacity-60"
          style={{ background: '#1A4D2E' }}
        >
          {isLoading ? (
            <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
          ) : (
            <LogIn className="h-4 w-4" />
          )}
          {isLoading ? 'Signing in…' : 'Sign in'}
        </button>
      </form>

      <div className="mt-5 text-center">
        <a
          href="/reset-password"
          className="text-[12px] text-[#6B7280] underline underline-offset-2"
        >
          Forgot password?
        </a>
      </div>

      {/* Demo credentials helper */}
      <div
        className="mt-7 p-3 rounded-lg border text-[12px]"
        style={{ background: 'rgba(26,77,46,.06)', borderColor: 'rgba(26,77,46,.12)' }}
      >
        <p className="text-[10px] font-semibold uppercase tracking-wide text-[#6B7280] mb-1">
          Demo credentials
        </p>
        <code className="font-mono text-[#1A1A1A]">admin@agcoms.ng · SecureP@ssword123</code>
      </div>
    </div>
  );
}
