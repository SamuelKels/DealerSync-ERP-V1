'use client';
/**
 * AGCOMS DealerSync ERP — Offline fallback page
 * Sprint 4 / S4-C: Served by the Workbox service worker when a navigation
 * request fails and no cached version is available.
 *
 * Shows sync status and any pending offline mutations.
 */
import { WifiOff, RefreshCw, ClipboardList, Truck } from 'lucide-react';
import { useOfflineSync } from '../../lib/offline/use-offline-sync';
import { SyncStatusIndicator } from '../../components/pwa/SyncStatusIndicator';
import { Button } from '../../components/ui/button';

export default function OfflinePage() {
  const { pendingCount, syncNow, isSyncing, isOnline } = useOfflineSync();

  return (
    <div className="min-h-screen bg-[#F7F4EF] flex flex-col items-center justify-center p-6 text-center">
      {/* Icon */}
      <div className="h-20 w-20 rounded-2xl bg-white border border-[#E5E7EB] flex items-center justify-center mb-6 shadow-sm">
        <WifiOff className="h-10 w-10 text-[#9CA3AF]" aria-hidden="true" />
      </div>

      {/* Heading */}
      <h1 className="font-heading text-[24px] text-[#1A4D2E] mb-2">Working offline</h1>
      <p className="text-[14px] text-[#6B7280] max-w-[320px] leading-relaxed mb-6">
        You are not connected to the internet.
        Your field actions are being saved locally and will sync automatically when you reconnect.
      </p>

      {/* What still works offline */}
      <div className="bg-white rounded-xl border border-[#E5E7EB] p-4 w-full max-w-[380px] mb-6 text-left">
        <p className="text-[12px] font-semibold text-[#1A1A1A] mb-3">Available offline:</p>
        <div className="space-y-2">
          {[
            { icon: ClipboardList, label: 'Complete job card checklists' },
            { icon: Truck,         label: 'Confirm NADF tractor deliveries (GPS)' },
          ].map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2.5 text-[12px] text-[#374151]">
              <div className="h-7 w-7 rounded-lg bg-[#EAF3DE] flex items-center justify-center flex-shrink-0">
                <Icon className="h-3.5 w-3.5 text-[#1A4D2E]" aria-hidden="true" />
              </div>
              {label}
            </div>
          ))}
        </div>
      </div>

      {/* Sync status */}
      <SyncStatusIndicator compact={false} className="w-full max-w-[380px] mb-4" />

      {/* Actions */}
      <div className="flex gap-3">
        {isOnline && pendingCount > 0 && (
          <Button onClick={syncNow} loading={isSyncing}>
            <RefreshCw className="h-4 w-4 mr-1.5" aria-hidden="true" />
            Sync {pendingCount} action{pendingCount > 1 ? 's' : ''}
          </Button>
        )}
        <Button variant="outline" onClick={() => window.location.reload()}>
          Try reconnecting
        </Button>
      </div>
    </div>
  );
}
