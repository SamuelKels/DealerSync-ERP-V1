/**
 * AGCOMS DealerSync ERP — API Client
 * Typed axios wrapper for all backend API calls.
 */
import axios, { type AxiosError, type AxiosRequestConfig } from 'axios';

const BASE_URL = process.env['NEXT_PUBLIC_API_URL'] ?? 'http://localhost:3001';

// ── In-memory token store (S2-08: no localStorage for access tokens) ──
// Access token lives only in memory. On page refresh, refreshTokenOnMount()
// restores it from the httpOnly refresh cookie via /auth/refresh.
let _memoryToken: string | null = null;
export const setMemoryToken = (t: string | null) => { _memoryToken = t; };
export const getMemoryToken = (): string | null => _memoryToken;

const client = axios.create({
  baseURL:         `${BASE_URL}/api/v1`,
  withCredentials: true,           // Send cookies (refresh token)
  timeout:         30_000,
  headers: {
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  },
});

// ── Request interceptor — attach access token ───────────────────
client.interceptors.request.use(config => {
  if (_memoryToken) config.headers['Authorization'] = `Bearer ${_memoryToken}`;
  return config;
});

// ── Response interceptor — handle 401 / token refresh ──────────
client.interceptors.response.use(
  res => res,
  async (error: AxiosError) => {
    const original = error.config as AxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const { data } = await client.post<{ data: { accessToken: string } }>('/auth/refresh');
        const token = data.data.accessToken;
        setMemoryToken(token); // In-memory only — S2-08 security fix
        if (original.headers) original.headers['Authorization'] = `Bearer ${token}`;
        return client(original);
      } catch {
        setMemoryToken(null);
        window.location.href = '/auth/login';
      }
    }
    return Promise.reject(error);
  },
);

// ── Typed API helpers ────────────────────────────────────────────
export const api = {
  get:    <T>(url: string, config?: AxiosRequestConfig) =>
    client.get<{ data: T }>(url, config).then(r => r.data.data),
  post:   <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    client.post<{ data: T }>(url, data, config).then(r => r.data.data),
  patch:  <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    client.patch<{ data: T }>(url, data, config).then(r => r.data.data),
  put:    <T>(url: string, data?: unknown, config?: AxiosRequestConfig) =>
    client.put<{ data: T }>(url, data, config).then(r => r.data.data),
  delete: <T>(url: string, config?: AxiosRequestConfig) =>
    client.delete<{ data: T }>(url, config).then(r => r.data.data),
};

export default client;

// ── S2-09 / S2-08: Token refresh on page load ─────────────────────────────
// Since access tokens are no longer stored in localStorage (S2-08 fix),
// they live only in Zustand memory. On page refresh the memory is cleared.
// Call this once in the ERP layout to silently restore the access token
// using the httpOnly refresh cookie.
export async function refreshTokenOnMount(): Promise<string | null> {
  try {
    const res = await client.post<{ data: { accessToken: string } }>('/auth/refresh');
    const token = res.data.data.accessToken;
    if (token && typeof window !== 'undefined') {
      // Update Zustand store via the store's updateToken action
      const { useAuthStore } = await import('../stores/auth.store');
      useAuthStore.getState().updateToken(token);
    }
    return token;
  } catch {
    // No valid refresh cookie — user must log in
    return null;
  }
}

// ── Query key factory — used by TanStack Query across all pages ───────────
export const queryKeys = {
  auth:     { profile: ['auth', 'profile'] as const },
  crm:      {
    customers: (params?: object) => ['crm', 'customers', params] as const,
    leads:     (params?: object) => ['crm', 'leads', params] as const,
    customer:  (id: string)      => ['crm', 'customers', id] as const,
  },
  sales:    {
    quotations: (params?: object) => ['sales', 'quotations', params] as const,
    invoices:   (params?: object) => ['sales', 'invoices', params] as const,
    orders:     (params?: object) => ['sales', 'orders', params] as const,
  },
  inventory: {
    products:   (params?: object) => ['inventory', 'products', params] as const,
    warehouses: () => ['inventory', 'warehouses'] as const,
    stock:      (productId: string) => ['inventory', 'stock', productId] as const,
  },
  finance: {
    accounts:    () => ['finance', 'accounts'] as const,
    journals:    (params?: object) => ['finance', 'journals', params] as const,
    trialBalance: (periodId: string) => ['finance', 'trial-balance', periodId] as const,
    arAging:     () => ['finance', 'ar-aging'] as const,
    budgets:     (params?: object) => ['finance', 'budgets', params] as const,
  },
  hr: {
    employees:  (params?: object) => ['hr', 'employees', params] as const,
    leave:      (params?: object) => ['hr', 'leave', params] as const,
    payroll:    (params?: object) => ['hr', 'payroll', params] as const,
  },
  fleet: {
    assets:      (params?: object) => ['fleet', 'assets', params] as const,
    riskSummary: () => ['fleet', 'risk-summary'] as const,
  },
  firs: {
    schedule:   (year: number) => ['firs', 'schedule', year] as const,
    vatReturns: (params?: object) => ['firs', 'vat-returns', params] as const,
  },
  exchangeRates: {
    all:     () => ['exchange-rates', 'all'] as const,
    rate:    (currency: string) => ['exchange-rates', currency] as const,
    history: (currency: string) => ['exchange-rates', 'history', currency] as const,
  },
  dashboard: {
    kpis:     (periodId?: string) => ['dashboard', 'kpis', periodId] as const,
    recent:   () => ['dashboard', 'recent'] as const,
    alerts:   (branchId?: string) => ['dashboard', 'alerts', branchId] as const,
  },
  ai: {
    forecast: () => ['ai', 'forecast'] as const,
    risk:     () => ['ai', 'risk'] as const,
  },

  procurement: {
    vendors:       (params?: object) => ['procurement', 'vendors', params] as const,
    purchaseOrders: (params?: object) => ['procurement', 'pos', params] as const,
  },
  workshop: {
    serviceRequests: (params?: object) => ['workshop', 'service-requests', params] as const,
    jobCards:        (params?: object) => ['workshop', 'job-cards', params] as const,
  },
  reports: {
    arAging:     () => ['reports', 'ar-aging'] as const,
    kpis:        (params?: object) => ['reports', 'kpis', params] as const,
    trialBalance: (periodId?: string) => ['reports', 'trial-balance', periodId] as const,
  },
  contracts: {
    list:         (params?: object) => ['contracts', params] as const,
    beneficiaries: (contractId: string) => ['contracts', contractId, 'beneficiaries'] as const,
  },
  passkeys: { list: () => ['passkeys'] as const },

  // ── Flat aliases used by page-level queries (`queryKeys.customers.list({...})` style) ──
  customers:       { list: (params?: object) => ['crm', 'customers', params] as const },
  leads:           { list: (params?: object) => ['crm', 'leads', params] as const },
  products:        { list: (params?: object) => ['inventory', 'products', params] as const },
  quotations:      { list: (params?: object) => ['sales', 'quotations', params] as const },
  invoices:        { list: (params?: object) => ['sales', 'invoices', params] as const },
  fleetAssets:     { list: (params?: object) => ['fleet', 'assets', params] as const },
  vendors:         { list: (params?: object) => ['procurement', 'vendors', params] as const },
  serviceRequests: { list: (params?: object) => ['workshop', 'service-requests', params] as const },
};
