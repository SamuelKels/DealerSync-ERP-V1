/**
 * AGCOMS DealerSync ERP — cn utility
 * Merges Tailwind classes safely (clsx + tailwind-merge).
 */
import { clsx, type ClassValue } from 'clsx';
import { twMerge }               from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
