/**
 * AGCOMS DealerSync ERP — Frontend Utilities
 * Shared helpers used across all 35+ pages.
 */

// ── Number formatting ────────────────────────────────────────────

/** Format Nigerian Naira with ₦ symbol and thousands separator */
export function formatNGN(amount: number | string | null | undefined, decimalsOrAbbr: number | boolean = 2): string {
  const decimals = typeof decimalsOrAbbr === 'boolean' ? (decimalsOrAbbr ? 0 : 2) : decimalsOrAbbr;
  const abbreviate = decimalsOrAbbr === true;
  if (amount === null || amount === undefined) return '₦0';
  const n = typeof amount === 'string' ? parseFloat(amount) : amount;
  if (isNaN(n)) return '₦0';
  return `₦${n.toLocaleString('en-NG', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`;
}

/** Format USD */
export function formatUSD(amount: number): string {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
}

/** Format a number with thousands separator */
export function formatNumber(n: number | null | undefined): string {
  if (n === null || n === undefined) return '0';
  return n.toLocaleString('en-NG');
}

// ── Date formatting ──────────────────────────────────────────────

/** Format date as DD MMM YYYY (e.g. 15 Jan 2025) */
export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return '—';
  try {
    return new Date(date).toLocaleDateString('en-NG', {
      day: '2-digit', month: 'short', year: 'numeric',
    });
  } catch { return '—'; }
}

/** Format datetime as DD MMM YYYY HH:mm */
export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return '—';
  try {
    return new Date(date).toLocaleString('en-NG', {
      day: '2-digit', month: 'short', year: 'numeric',
      hour: '2-digit', minute: '2-digit', hour12: false,
    });
  } catch { return '—'; }
}

/** How long ago (relative time) */
export function timeAgo(date: string | Date): string {
  const now     = new Date();
  const then    = new Date(date);
  const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);
  if (seconds < 60)   return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return formatDate(date);
}

// ── Status styling ───────────────────────────────────────────────

/** Return badge background + text colour for a given status string */
export function getStatusStyle(status: string): { bg: string; color: string } {
  const s = status?.toUpperCase() ?? '';
  if (['ACTIVE', 'PAID', 'DELIVERED', 'COMPLETED', 'APPROVED', 'POSTED', 'AWARDED', 'HEALTHY'].some(x => s.includes(x))) {
    return { bg: '#DCFCE7', color: '#15803D' };
  }
  if (['DRAFT', 'PENDING', 'NEW', 'OPEN', 'FUTURE'].some(x => s.includes(x))) {
    return { bg: '#E6F1FB', color: '#0C447C' };
  }
  if (['WARNING', 'PARTIAL', 'IN_PROGRESS', 'PROCESSING', 'ALLOCATED', 'SUBMITTED', 'IN_REVIEW'].some(x => s.includes(x))) {
    return { bg: '#FEF3C7', color: '#92400E' };
  }
  if (['CANCELLED', 'REJECTED', 'BLOCKED', 'FAILED', 'TERMINATED', 'OVERDUE', 'LOST'].some(x => s.includes(x))) {
    return { bg: '#FEE2E2', color: '#B91C1C' };
  }
  if (['LOCKED', 'CLOSED', 'VOIDED', 'OFFLINE', 'MAINTENANCE'].some(x => s.includes(x))) {
    return { bg: '#F3F4F6', color: '#6B7280' };
  }
  if (['ISSUED', 'CONFIRMED', 'QUOTED', 'EVALUATING'].some(x => s.includes(x))) {
    return { bg: '#EEEDFE', color: '#3C3489' };
  }
  return { bg: '#F3F4F6', color: '#6B7280' };
}

// ── Query string builder ─────────────────────────────────────────

/** Build URLSearchParams from an object, skipping nullish/empty values */
export function buildSearchParams(params: Record<string, string | number | boolean | undefined | null>): string {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== null && v !== undefined && v !== '') {
      sp.set(k, String(v));
    }
  }
  return sp.toString();
}

// ── String utilities ─────────────────────────────────────────────

/** Get initials from a full name (up to 2 chars) */
export function getInitials(name: string): string {
  return name.split(' ').slice(0, 2).map(n => n[0]?.toUpperCase() ?? '').join('');
}

/** Truncate text with ellipsis */
export function truncate(text: string, maxLength: number): string {
  return text.length > maxLength ? `${text.slice(0, maxLength)}…` : text;
}

/** Format a percentage */
export function formatPct(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`;
}

// ── Validation helpers ───────────────────────────────────────────

/** Valid Nigerian phone number (starts with +234 or 0, 11 digits) */
export function isValidNigerianPhone(phone: string): boolean {
  return /^(\+234|0)[789]\d{9}$/.test(phone.replace(/\s/g, ''));
}

/** Valid email */
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** Format a date relative to today (today/yesterday/N days ago) */
export function formatRelative(date: string | Date | null | undefined): string {
  if (!date) return '—';
  const d = new Date(date);
  const now = new Date();
  const days = Math.floor((now.getTime() - d.getTime()) / 86400_000);
  if (days === 0) return 'Today';
  if (days === 1) return 'Yesterday';
  if (days < 7)  return `${days} days ago`;
  return formatDate(date);
}

/** Format a currency amount with the correct symbol */
export function formatCurrency(amount: number, currency: 'NGN' | 'USD' | 'EUR' | 'GBP' = 'NGN'): string {
  if (currency === 'NGN') return formatNGN(amount);
  const symbols: Record<string, string> = { USD: '$', EUR: '€', GBP: '£' };
  return `${symbols[currency] ?? ''}${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** Clamp a value between min and max */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
