'use client';
/**
 * AGCOMS DealerSync ERP — QueryProvider
 * Sprint 2 Fix: No QueryClientProvider existed — all useQuery() calls threw
 * "No QueryClient set, use QueryClientProvider to set one".
 *
 * Configured for ERP workloads:
 *   - staleTime 30s  (most lists stay fresh between navigations)
 *   - gcTime   5min  (keep cached data in memory)
 *   - retry 1        (reduced from default 3 — ERP errors are usually real)
 *   - refetchOnWindowFocus: false (avoids re-fetching on tab switch in dense UIs)
 */
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState, type ReactNode }          from 'react';

function makeQueryClient(): QueryClient {
  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime:           30_000,
        gcTime:              5 * 60_000,
        retry:               1,
        refetchOnWindowFocus: false,
        refetchOnReconnect:  true,
      },
      mutations: {
        retry: 0,
      },
    },
  });
}

let browserQueryClient: QueryClient | undefined;

function getQueryClient(): QueryClient {
  if (typeof window === 'undefined') {
    // Server: always create a new client
    return makeQueryClient();
  }
  // Browser: re-use the same client across renders
  if (!browserQueryClient) browserQueryClient = makeQueryClient();
  return browserQueryClient;
}

export function QueryProvider({ children }: { children: ReactNode }) {
  // Avoid creating a new client on every render
  const [queryClient] = useState(() => getQueryClient());
  return (
    <QueryClientProvider client={queryClient}>
      {children}
    </QueryClientProvider>
  );
}
