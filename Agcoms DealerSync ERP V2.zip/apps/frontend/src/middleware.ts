/**
 * AGCOMS DealerSync ERP — Next.js Middleware
 * Sprint 2 Fix: No frontend auth protection existed at the route level.
 *
 * Runs on every request to /erp/* routes.
 * Redirects unauthenticated users to /auth/login.
 * Does NOT verify the JWT (that happens in the backend) — only checks
 * for the presence of the refresh cookie as a lightweight proxy.
 *
 * Note: The ERP layout.tsx also has a client-side auth guard as defence-in-depth.
 * This middleware provides the server-side layer that prevents even the page HTML
 * from being sent to unauthenticated users.
 */
import { type NextRequest, NextResponse } from 'next/server';

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Only protect /erp/* routes
  if (!pathname.startsWith('/erp')) {
    return NextResponse.next();
  }

  // Check for the httpOnly refresh cookie as a proxy for "authenticated"
  // The actual token validation happens in the NestJS backend per request.
  const hasRefreshCookie = request.cookies.has('refresh_token');

  if (!hasRefreshCookie) {
    const loginUrl = new URL('/auth/login', request.url);
    loginUrl.searchParams.set('redirect', pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/erp/:path*',
    // Exclude static files and API routes
    '/((?!_next/static|_next/image|favicon.ico|api/).*)',
  ],
};
