/**
 * AGCOMS DealerSync ERP — useUndoMutation
 * §8 UX Principles: "undo workflows"
 *
 * Wraps TanStack Query's useMutation with a 5-second undo window.
 * Shows a Sonner toast with an Undo button. If the user clicks Undo
 * within the window, the mutation is cancelled and the cache rolled back.
 *
 * Usage:
 *   const { mutate: deleteCustomer } = useUndoMutation({
 *     mutationFn: (id) => api.delete(`/crm/customers/${id}`),
 *     queryKey:   ['customers'],
 *     undoLabel:  'Customer deleted',
 *   });
 */

import { useMutation, useQueryClient, type MutationFunction } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useRef, useCallback } from 'react';

const UNDO_WINDOW_MS = 5_000;

interface UseUndoMutationOptions<TData, TError, TVariables> {
  /** The actual API call */
  mutationFn:  MutationFunction<TData, TVariables>;
  /** Query key(s) to invalidate on success */
  queryKey:    unknown[];
  /** Toast message shown during undo window */
  undoLabel:   string;
  /** Optional: callback before mutation executes (for optimistic updates) */
  onMutate?:   (variables: TVariables) => Promise<unknown> | unknown;
  /** Optional: rollback on undo or error */
  onRollback?: (context: unknown) => void;
  /** Called after successful commit (undo window elapsed, not cancelled) */
  onCommit?:   (data: TData) => void;
}

export function useUndoMutation<TData = unknown, TError = Error, TVariables = void>({
  mutationFn,
  queryKey,
  undoLabel,
  onMutate,
  onRollback,
  onCommit,
}: UseUndoMutationOptions<TData, TError, TVariables>) {
  const queryClient = useQueryClient();
  const undoneRef   = useRef(false);
  const timerRef    = useRef<ReturnType<typeof setTimeout> | null>(null);

  const mutation = useMutation<TData, TError, TVariables>({
    mutationFn: async (variables) => {
      // Wrap in a deferred promise — actual API call is delayed by UNDO_WINDOW_MS
      return new Promise<TData>((resolve, reject) => {
        undoneRef.current = false;

        const toastId = toast(undoLabel, {
          duration: UNDO_WINDOW_MS,
          action: {
            label: 'Undo',
            onClick: () => {
              undoneRef.current = true;
              if (timerRef.current) clearTimeout(timerRef.current);
              toast.dismiss(toastId);

              // Roll back optimistic update if provided
              if (onRollback) {
                // Context from onMutate is passed via mutation context
                // We use queryClient snapshot approach here
                queryClient.cancelQueries({ queryKey });
                queryClient.invalidateQueries({ queryKey });
                onRollback(variables);
              } else {
                queryClient.invalidateQueries({ queryKey });
              }

              reject(new Error('Undone by user'));
            },
          },
        });

        timerRef.current = setTimeout(async () => {
          if (undoneRef.current) return;
          toast.dismiss(toastId);
          try {
            const result = await (mutationFn as any)(variables, { client: queryClient, meta: undefined, mutationKey: undefined, signal: new AbortController().signal });
            resolve(result);
            if (onCommit) onCommit(result);
          } catch (err) {
            reject(err);
          }
        }, UNDO_WINDOW_MS);
      });
    },

    onMutate: async (variables) => {
      // Cancel any in-flight fetches for this query key
      await queryClient.cancelQueries({ queryKey });
      // Snapshot for rollback
      const snapshot = queryClient.getQueryData(queryKey);
      // Run caller's optimistic update
      if (onMutate) await onMutate(variables);
      return { snapshot };
    },

    onError: (_err, _variables, context) => {
      // Roll back optimistic update on error OR on undo
      const ctx = context as { snapshot?: unknown } | undefined;
      if (ctx?.snapshot !== undefined) {
        queryClient.setQueryData(queryKey, ctx.snapshot);
      }
    },

    onSuccess: () => {
      // Invalidate fresh data after the undo window has elapsed and mutation committed
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const mutateWithUndo = useCallback(
    (variables: TVariables) => {
      mutation.mutate(variables);
    },
    [mutation],
  );

  return {
    ...mutation,
    mutate:  mutateWithUndo,
    isUndoable: true,
  };
}

// ── Convenience wrappers for common operations ─────────────────

/** Undo-able delete with standard "X deleted" message */
export function useUndoDelete<TId = string>(options: {
  entityName:  string;
  mutationFn:  (id: TId) => Promise<unknown>;
  queryKey:    unknown[];
}) {
  return useUndoMutation({
    mutationFn: options.mutationFn,
    queryKey:   options.queryKey,
    undoLabel:  `${options.entityName} deleted`,
  });
}

/** Undo-able status change with custom message */
export function useUndoStatusChange<TVariables = { id: string; status: string }>(options: {
  label:       string;
  mutationFn:  MutationFunction<unknown, TVariables>;
  queryKey:    unknown[];
}) {
  return useUndoMutation({
    mutationFn: options.mutationFn,
    queryKey:   options.queryKey,
    undoLabel:  options.label,
  });
}
