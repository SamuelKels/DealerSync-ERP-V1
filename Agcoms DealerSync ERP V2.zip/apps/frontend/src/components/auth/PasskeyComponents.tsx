'use client';
/**
 * AGCOMS DealerSync ERP — Passkey Components
 * Sprint 5 / S5-C: Frontend FIDO2 WebAuthn passkey management.
 *
 * PasskeySetup:      Register new passkeys, list existing, revoke old ones.
 *                    Shown on the user profile / security settings page.
 *
 * PasskeyLoginButton: One-click passkey authentication on the login page.
 *                     Falls back to password+TOTP if passkeys unavailable.
 *
 * Uses @simplewebauthn/browser for the browser-side WebAuthn ceremony.
 * The library handles: credential creation, biometric prompt, assertion signing.
 */

import { useState, useCallback }    from 'react';
import { useMutation, useQuery }    from '@tanstack/react-query';
import {
  startRegistration,
  startAuthentication,
  browserSupportsWebAuthn,
}                                   from '@simplewebauthn/browser';
import type {
  PublicKeyCredentialCreationOptionsJSON,
  PublicKeyCredentialRequestOptionsJSON,
}                                   from '@simplewebauthn/types';
import { toast }                    from 'sonner';
import { Fingerprint, Trash2, Plus, ShieldCheck, Monitor, Smartphone } from 'lucide-react';
import { api }                      from '../../lib/api';
import { useAuthStore }             from '../../stores/auth.store';
import { Button }                   from '../ui/button';
import { cn }                       from '../../lib/cn';

// ── Types ──────────────────────────────────────────────────────────────────

interface RegisteredPasskey {
  id:                   string;
  deviceName:           string;
  credentialDeviceType: 'singleDevice' | 'multiDevice';
  credentialBackedUp:   boolean;
  transports:           string[];
  lastUsedAt:           string | null;
  createdAt:            string;
}

interface ChallengeResponse {
  challengeId:  string;
  challenge:    string;
  options:      PublicKeyCredentialCreationOptionsJSON | PublicKeyCredentialRequestOptionsJSON;
}

// ── PasskeySetup ────────────────────────────────────────────────────────────
// Shown on the profile / security settings page for logged-in users.

export function PasskeySetup({ className }: { className?: string }) {
  const [deviceName, setDeviceName] = useState('');
  const { data: passkeys, refetch, isLoading } = useQuery({
    queryKey: ['passkeys'],
    queryFn:  () => api.get<RegisteredPasskey[]>('/auth/passkey/list'),
    staleTime: 30_000,
  });

  const supportsPasskeys = browserSupportsWebAuthn();

  const registerMutation = useMutation({
    mutationFn: async () => {
      // Step 1: Get challenge from server
      const { challengeId, options } = await api.get<ChallengeResponse>(
        '/auth/passkey/register/options',
      );

      // Step 2: Browser performs biometric / PIN ceremony
      const credential = await startRegistration(options as PublicKeyCredentialCreationOptionsJSON);

      // Step 3: Send attestation to server for verification + storage
      return api.post<{ verified: boolean; credentialId: string }>(
        '/auth/passkey/register/verify',
        { challengeId, response: credential, deviceName: deviceName || getDefaultDeviceName() },
      );
    },
    onSuccess: () => {
      toast.success('Passkey registered successfully', {
        description: 'You can now sign in with biometrics or a security key.',
      });
      setDeviceName('');
      refetch();
    },
    onError: (err: any) => {
      if (err?.name === 'NotAllowedError') {
        toast.error('Passkey registration cancelled');
      } else {
        toast.error('Passkey registration failed', { description: err?.message });
      }
    },
  });

  const revokeMutation = useMutation({
    mutationFn: (id: string) => api.delete(`/auth/passkey/${id}`),
    onSuccess:  () => { toast.success('Passkey removed'); refetch(); },
    onError:    () => toast.error('Failed to remove passkey'),
  });

  if (!supportsPasskeys) {
    return (
      <div className={cn('bg-[#FEF3C7] rounded-xl border border-[#FDE68A] p-4', className)}>
        <p className="text-[13px] text-[#92400E] font-medium">Passkeys not supported</p>
        <p className="text-[12px] text-[#92400E]/80 mt-1">
          Your browser or device does not support passkeys. Use Chrome 108+, Safari 16+, or Edge 108+.
        </p>
      </div>
    );
  }

  return (
    <div className={cn('bg-white rounded-xl border border-[#E5E7EB] overflow-hidden', className)}>
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-[#E5E7EB]">
        <div className="h-9 w-9 rounded-lg bg-[#EAF3DE] flex items-center justify-center flex-shrink-0">
          <Fingerprint className="h-4.5 w-4.5 text-[#1A4D2E]" aria-hidden="true" />
        </div>
        <div>
          <h3 className="text-[14px] font-semibold text-[#1A1A1A]">Passkeys</h3>
          <p className="text-[11px] text-[#9CA3AF] mt-0.5">
            Sign in with your fingerprint, face, or security key — no password needed
          </p>
        </div>
      </div>

      {/* Registered passkeys list */}
      <div className="divide-y divide-[#F3F4F6]">
        {isLoading ? (
          <div className="px-5 py-4">
            {[1, 2].map(i => (
              <div key={i} className="h-14 bg-[#F3F4F6] rounded-lg animate-pulse mb-2" />
            ))}
          </div>
        ) : passkeys && passkeys.length > 0 ? (
          passkeys.map(pk => (
            <div key={pk.id} className="flex items-center gap-3 px-5 py-3.5">
              <div className="h-8 w-8 rounded-lg bg-[#F7F4EF] flex items-center justify-center flex-shrink-0">
                {pk.credentialDeviceType === 'multiDevice'
                  ? <Smartphone className="h-4 w-4 text-[#6B7280]" aria-hidden="true" />
                  : <Monitor className="h-4 w-4 text-[#6B7280]"    aria-hidden="true" />
                }
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-medium text-[#1A1A1A] truncate">{pk.deviceName}</p>
                <p className="text-[11px] text-[#9CA3AF]">
                  {pk.credentialBackedUp ? '☁ Synced passkey · ' : '📱 Device-bound · '}
                  {pk.lastUsedAt
                    ? `Last used: ${new Date(pk.lastUsedAt).toLocaleDateString('en-NG')}`
                    : `Added: ${new Date(pk.createdAt).toLocaleDateString('en-NG')}`
                  }
                </p>
              </div>
              <button
                onClick={() => revokeMutation.mutate(pk.id)}
                disabled={revokeMutation.isPending}
                className="text-[#9CA3AF] hover:text-[#DC2626] transition-colors p-1.5 rounded-lg hover:bg-[#FEF2F2]"
                aria-label={`Remove ${pk.deviceName}`}>
                <Trash2 className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>
          ))
        ) : (
          <div className="px-5 py-6 text-center">
            <p className="text-[13px] text-[#9CA3AF]">No passkeys registered yet</p>
            <p className="text-[11px] text-[#D1D5DB] mt-0.5">Add one below to enable passwordless sign-in</p>
          </div>
        )}
      </div>

      {/* Register new passkey */}
      <div className="px-5 py-4 border-t border-[#E5E7EB] bg-[#FAFAFA]">
        <div className="flex gap-2">
          <input
            value={deviceName}
            onChange={e => setDeviceName(e.target.value)}
            placeholder={getDefaultDeviceName()}
            className="flex-1 h-8 px-3 text-[13px] rounded-md border border-[#E5E7EB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
            aria-label="Device name for this passkey"
          />
          <Button
            size="sm"
            onClick={() => registerMutation.mutate()}
            loading={registerMutation.isPending}>
            <Plus className="h-3.5 w-3.5 mr-1" aria-hidden="true" />
            Add passkey
          </Button>
        </div>
        <p className="text-[10px] text-[#D1D5DB] mt-2">
          Your browser will prompt for biometrics or a security key.
        </p>
      </div>
    </div>
  );
}

// ── PasskeyLoginButton ────────────────────────────────────────────────────
// Shown on the login page alongside the email/password form.

interface PasskeyLoginButtonProps {
  email?:     string;
  onSuccess?: (accessToken: string, user: { id: string; email: string; role: string }) => void;
  className?: string;
}

export function PasskeyLoginButton({ email, onSuccess, className }: PasskeyLoginButtonProps) {
  const supportsPasskeys = browserSupportsWebAuthn();
  const { setUser }      = useAuthStore();

  const loginMutation = useMutation({
    mutationFn: async () => {
      // Step 1: Get authentication challenge
      const { challengeId, options } = await api.post<ChallengeResponse>(
        '/auth/passkey/authenticate/options',
        { email },
      );

      // Step 2: Browser performs biometric / PIN ceremony
      const assertion = await startAuthentication(options as PublicKeyCredentialRequestOptionsJSON);

      // Step 3: Verify assertion on server
      return api.post<{ accessToken: string; user: { id: string; email: string; role: string } }>(
        '/auth/passkey/authenticate/verify',
        { challengeId, response: assertion },
      );
    },
    onSuccess: (data) => {
      toast.success('Signed in with passkey');
      setUser(
        { id: data.user.id, email: data.user.email, role: data.user.role } as any,
        data.accessToken,
      );
      onSuccess?.(data.accessToken, data.user);
    },
    onError: (err: any) => {
      if (err?.name === 'NotAllowedError') {
        // User cancelled — no toast needed
      } else {
        toast.error('Passkey sign-in failed', { description: err?.message ?? 'Please try your password instead.' });
      }
    },
  });

  if (!supportsPasskeys) return null;

  return (
    <button
      type="button"
      onClick={() => loginMutation.mutate()}
      disabled={loginMutation.isPending}
      className={cn(
        'w-full flex items-center justify-center gap-2.5 h-10 rounded-lg border border-[#E5E7EB]',
        'text-[13px] font-medium text-[#374151] bg-white hover:bg-[#F7F4EF] transition-colors',
        'focus:outline-none focus:ring-2 focus:ring-[#1A4D2E] focus:ring-offset-2',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        className,
      )}
      aria-label="Sign in with a passkey (biometrics or security key)">
      {loginMutation.isPending ? (
        <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E]/30 border-t-[#1A4D2E] animate-spin" />
      ) : (
        <Fingerprint className="h-4 w-4 text-[#1A4D2E]" aria-hidden="true" />
      )}
      {loginMutation.isPending ? 'Waiting for biometric…' : 'Sign in with a passkey'}
    </button>
  );
}

// ── Passkey availability indicator ────────────────────────────────────────

export function PasskeyBadge() {
  if (!browserSupportsWebAuthn()) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[11px] text-[#27500A] bg-[#EAF3DE] px-2 py-0.5 rounded-full font-medium">
      <ShieldCheck className="h-3 w-3" aria-hidden="true" />
      Passkey ready
    </span>
  );
}

// ── Helpers ────────────────────────────────────────────────────────────────

function getDefaultDeviceName(): string {
  if (typeof navigator === 'undefined') return 'My Device';
  const ua = navigator.userAgent;
  if (/iPhone/.test(ua))   return 'iPhone';
  if (/iPad/.test(ua))     return 'iPad';
  if (/Mac/.test(ua))      return 'MacBook';
  if (/Android/.test(ua))  return 'Android Phone';
  if (/Windows/.test(ua))  return 'Windows PC';
  return 'My Device';
}
