import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../lib/cn';

const badgeVariants = cva(
  'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors',
  {
    variants: {
      variant: {
        default:     'border-transparent bg-[#1A4D2E] text-white',
        secondary:   'border-transparent bg-[#F7F4EF] text-[#1A1A1A]',
        destructive: 'border-transparent bg-[#DC2626] text-white',
        outline:     'border-[#E5E7EB] text-[#1A1A1A]',
        success:     'border-transparent bg-[#DCFCE7] text-[#15803D]',
        warning:     'border-transparent bg-[#FEF3C7] text-[#92400E]',
        info:        'border-transparent bg-[#E6F1FB] text-[#0C447C]',
      },
    },
    defaultVariants: { variant: 'default' },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
