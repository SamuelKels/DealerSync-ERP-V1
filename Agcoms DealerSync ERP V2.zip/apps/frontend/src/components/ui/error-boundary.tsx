'use client';
/**
 * AGCOMS DealerSync ERP — ErrorBoundary
 * Sprint 2 Fix S2-07: No error boundary existed. Unhandled component errors
 * propagated to the root and rendered a blank Next.js error page with no recovery.
 *
 * Usage:
 *   <ErrorBoundary>
 *     <SomeModule />
 *   </ErrorBoundary>
 *
 * Or wrap a route group in the layout.tsx.
 */
import { Component, type ReactNode, type ErrorInfo } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Button } from './button';

interface ErrorBoundaryProps {
  children:   ReactNode;
  /** Optional custom fallback — overrides default error UI */
  fallback?:  ReactNode;
  /** Module name for error context in the UI */
  moduleName?: string;
}

interface ErrorBoundaryState {
  hasError:  boolean;
  error:     Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({ errorInfo });

    // Log to console in development
    if (process.env.NODE_ENV !== 'production') {
      console.error('[ErrorBoundary]', error, errorInfo);
    }

    // In production, send to Sentry (§9 observability)
    if (process.env.NODE_ENV === 'production' && typeof window !== 'undefined') {
      try {
        (window as any).Sentry?.captureException(error, { extra: errorInfo });
      } catch {
        // Sentry not loaded — silently ignore
      }
    }
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;

      const isDev = process.env.NODE_ENV !== 'production';
      const { moduleName } = this.props;

      return (
        <div
          role="alert"
          className="flex flex-col items-center justify-center min-h-[400px] p-8 text-center">
          <div className="h-14 w-14 rounded-xl bg-[#FEF2F2] flex items-center justify-center mb-4">
            <AlertTriangle className="h-7 w-7 text-[#DC2626]" aria-hidden="true" />
          </div>

          <h2 className="font-heading text-[18px] text-[#1A1A1A] mb-1">
            Something went wrong
          </h2>
          <p className="text-[13px] text-[#6B7280] max-w-[320px] mb-6">
            {moduleName
              ? `The ${moduleName} module encountered an unexpected error.`
              : 'An unexpected error occurred in this section.'}
            {' '}Your data is safe — please try refreshing.
          </p>

          {/* Development: show error details */}
          {isDev && this.state.error && (
            <details className="mb-6 text-left max-w-[480px] w-full">
              <summary className="text-[11px] text-[#9CA3AF] cursor-pointer mb-2">
                Error details (development only)
              </summary>
              <pre className="text-[10px] bg-[#F7F4EF] rounded-lg p-3 overflow-auto text-[#DC2626] leading-relaxed">
                {this.state.error.message}
                {'\n\n'}
                {this.state.error.stack?.slice(0, 500)}
              </pre>
            </details>
          )}

          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={this.handleReset}>
              <RefreshCw className="h-3.5 w-3.5 mr-1.5" aria-hidden="true" />
              Try again
            </Button>
            <Button variant="ghost" size="sm" onClick={() => window.location.href = '/erp/dashboard'}>
              <Home className="h-3.5 w-3.5 mr-1.5" aria-hidden="true" />
              Go to dashboard
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
