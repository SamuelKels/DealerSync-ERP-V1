'use client';
/**
 * AGCOMS DealerSync ERP — DataTable
 * Sprint 2 Fix S2-05: No shared table wrapper — TanStack Table was listed in
 * package.json but never instantiated. Every page used raw <table> elements
 * with duplicated pagination, sorting, and loading state logic.
 *
 * §3 Tables: TanStack Table
 * §8 UX: skeleton loading, dense data tables for desktop
 */
import {
  useReactTable, getCoreRowModel, getSortedRowModel,
  type ColumnDef, type SortingState, type OnChangeFn,
  flexRender,
} from '@tanstack/react-table';
import { useState }         from 'react';
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';
import { cn }               from '../../lib/cn';
import { Button }           from './button';
import { EmptyState }       from './page-header';
import { type LucideIcon }  from 'lucide-react';

interface DataTableProps<TData> {
  data:        TData[];
  columns:     ColumnDef<TData, any>[];
  isLoading?:  boolean;
  /** Total number of records (for server-side pagination display) */
  total?:      number;
  page?:       number;
  hasMore?:    boolean;
  onNextPage?: () => void;
  onPrevPage?: () => void;
  /** Empty state configuration */
  emptyTitle?:       string;
  emptyDescription?: string;
  emptyIcon?:        LucideIcon;
  emptyAction?:      React.ReactNode;
  /** Skeleton row count while loading */
  skeletonRows?: number;
  className?:    string;
}

export function DataTable<TData>({
  data, columns, isLoading = false,
  total, page = 1, hasMore = false,
  onNextPage, onPrevPage,
  emptyTitle = 'No records found',
  emptyDescription,
  emptyIcon,
  emptyAction,
  skeletonRows = 8,
  className,
}: DataTableProps<TData>) {
  const [sorting, setSorting] = useState<SortingState>([]);

  const table = useReactTable({
    data:            data ?? [],
    columns,
    state:           { sorting },
    onSortingChange: setSorting as OnChangeFn<SortingState>,
    getCoreRowModel:    getCoreRowModel(),
    getSortedRowModel:  getSortedRowModel(),
    manualPagination:   true, // Server-side pagination
  });

  return (
    <div className={cn('bg-white rounded-lg border border-[#E5E7EB] overflow-hidden', className)}>
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-[13px]" role="grid">
          <thead>
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id} className="border-b-2 border-[#E5E7EB]">
                {headerGroup.headers.map(header => {
                  const canSort = header.column.getCanSort();
                  const sorted  = header.column.getIsSorted();
                  return (
                    <th
                      key={header.id}
                      className={cn(
                        'px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap',
                        canSort && 'cursor-pointer select-none hover:text-[#1A1A1A]',
                      )}
                      onClick={header.column.getToggleSortingHandler()}
                      aria-sort={sorted === 'asc' ? 'ascending' : sorted === 'desc' ? 'descending' : undefined}>
                      <span className="inline-flex items-center gap-1">
                        {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                        {canSort && (
                          <span className="text-[#D1D5DB]" aria-hidden="true">
                            {sorted === 'asc'  ? <ChevronUp className="h-3 w-3" />    :
                             sorted === 'desc' ? <ChevronDown className="h-3 w-3" />  :
                             <ChevronsUpDown className="h-3 w-3" />}
                          </span>
                        )}
                      </span>
                    </th>
                  );
                })}
              </tr>
            ))}
          </thead>

          <tbody>
            {/* Skeleton loading rows — §8 UX: skeleton loading */}
            {isLoading ? (
              Array.from({ length: skeletonRows }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {columns.map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div
                        className="h-4 rounded animate-pulse bg-[#F3F4F6]"
                        style={{ width: `${Math.floor(Math.random() * 40 + 50)}%` }}
                        aria-hidden="true"
                      />
                    </td>
                  ))}
                </tr>
              ))
            ) : table.getRowModel().rows.length === 0 ? (
              <tr>
                <td colSpan={columns.length}>
                  <EmptyState
                    icon={emptyIcon}
                    title={emptyTitle}
                    description={emptyDescription}
                    action={emptyAction}
                  />
                </td>
              </tr>
            ) : (
              table.getRowModel().rows.map(row => (
                <tr
                  key={row.id}
                  className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
                  {row.getVisibleCells().map(cell => (
                    <td key={cell.id} className="px-3 py-2.5">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination footer */}
      {(onNextPage || onPrevPage) && (
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">
            {total !== undefined ? `${total.toLocaleString()} records` : ''}
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="xs"
              onClick={onPrevPage}
              disabled={!onPrevPage || page <= 1}
              aria-label="Previous page">
              ← Prev
            </Button>
            <span className="text-[11px] text-[#6B7280] w-12 text-center">
              Page {page}
            </span>
            <Button
              variant="outline"
              size="xs"
              onClick={onNextPage}
              disabled={!onNextPage || !hasMore}
              aria-label="Next page">
              Next →
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
