/**
 * AGCOMS DealerSync ERP — PageHeader
 * Sprint 2 Fix S2-05: No shared page header — every page had ad-hoc title markup.
 * Provides: title, subtitle, right-side action slot, breadcrumb slot.
 */
import { type ReactNode } from 'react';
import { cn }             from '../../lib/cn';

interface PageHeaderProps {
  title:      string;
  subtitle?:  string;
  actions?:   ReactNode;
  breadcrumb?: ReactNode;
  className?: string;
  /** data-tour attribute for onboarding tour targeting */
  dataTour?:  string;
}

export function PageHeader({
  title, subtitle, actions, breadcrumb, className, dataTour,
}: PageHeaderProps) {
  return (
    <div
      className={cn('flex items-start justify-between gap-4 flex-wrap mb-1', className)}
      {...(dataTour ? { 'data-tour': dataTour } : {})}>
      <div>
        {breadcrumb && (
          <nav className="text-[11px] text-[#9CA3AF] mb-0.5" aria-label="Breadcrumb">
            {breadcrumb}
          </nav>
        )}
        <h1 className="font-heading text-[20px] text-[#1A1A1A] leading-tight">{title}</h1>
        {subtitle && (
          <p className="text-[12px] text-[#6B7280] mt-0.5">{subtitle}</p>
        )}
      </div>
      {actions && (
        <div className="flex items-center gap-2 flex-wrap flex-shrink-0">
          {actions}
        </div>
      )}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────

/**
 * AGCOMS DealerSync ERP — EmptyState
 * Sprint 2 Fix S2-05: §8 UX "empty states" — missing from shared components.
 */
import { type LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon?:        LucideIcon;
  title:        string;
  description?: string;
  action?:      ReactNode;
  className?:   string;
}

export function EmptyState({ icon: Icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center py-16 px-8 text-center',
        className,
      )}>
      {Icon && (
        <div className="h-14 w-14 rounded-xl bg-[#F7F4EF] flex items-center justify-center mb-4">
          <Icon className="h-7 w-7 text-[#D1D5DB]" aria-hidden="true" />
        </div>
      )}
      <p className="text-[14px] font-medium text-[#1A1A1A] mb-1">{title}</p>
      {description && (
        <p className="text-[12px] text-[#9CA3AF] max-w-[280px] leading-relaxed mb-4">
          {description}
        </p>
      )}
      {action && <div>{action}</div>}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────

/**
 * AGCOMS DealerSync ERP — LoadingSpinner
 * Sprint 2 Fix S2-05: §8 UX "skeleton loading" — reusable spinner for async states.
 */

interface LoadingSpinnerProps {
  size?:      'sm' | 'md' | 'lg';
  className?: string;
  label?:     string;
}

const SIZES = { sm: 'h-4 w-4', md: 'h-6 w-6', lg: 'h-8 w-8' };

export function LoadingSpinner({ size = 'md', className, label = 'Loading…' }: LoadingSpinnerProps) {
  return (
    <span
      role="status"
      aria-label={label}
      className={cn('inline-flex items-center gap-2', className)}>
      <span
        className={cn(
          'rounded-full border-2 border-[#E5E7EB] border-t-[#1A4D2E] animate-spin',
          SIZES[size],
        )}
        aria-hidden="true"
      />
    </span>
  );
}

/**
 * Full-page loading state — used while auth is being checked or data is first-loading
 */
export function PageLoading({ label = 'Loading…' }: { label?: string }) {
  return (
    <div className="flex-1 flex items-center justify-center min-h-[400px]">
      <div className="flex flex-col items-center gap-3">
        <LoadingSpinner size="lg" label={label} />
        <p className="text-[13px] text-[#9CA3AF]">{label}</p>
      </div>
    </div>
  );
}
