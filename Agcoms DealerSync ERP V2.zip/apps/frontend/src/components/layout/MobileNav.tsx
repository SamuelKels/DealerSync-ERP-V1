'use client';
/**
 * AGCOMS DealerSync ERP — Mobile Bottom Navigation
 * Sprint 2 Fix S2-03: §8 Mobile: "bottom navigation"
 * Shows the 5 most-used modules on mobile via a sticky bottom bar.
 */
import Link           from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, Users, ShoppingCart, Wrench, MoreHorizontal,
} from 'lucide-react';
import { cn }         from '../../lib/cn';

const NAV_ITEMS = [
  { href: '/erp/dashboard',        label: 'Dashboard',  icon: LayoutDashboard },
  { href: '/erp/crm/customers',    label: 'CRM',        icon: Users           },
  { href: '/erp/sales/quotations', label: 'Sales',      icon: ShoppingCart    },
  { href: '/erp/workshop/job-cards', label: 'Workshop', icon: Wrench          },
  { href: '/erp/reports/kpis',     label: 'Reports',    icon: MoreHorizontal  },
] as const;

export function MobileNav() {
  const pathname = usePathname();

  return (
    <nav
      className="lg:hidden flex-shrink-0 bg-white border-t border-[#E5E7EB] pb-safe"
      aria-label="Mobile bottom navigation">
      <div className="flex">
        {NAV_ITEMS.map(item => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          const Icon     = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex-1 flex flex-col items-center justify-center gap-0.5 py-2 px-1',
                'min-h-[52px] transition-colors text-[10px] font-medium',
                isActive
                  ? 'text-[#1A4D2E]'
                  : 'text-[#9CA3AF] hover:text-[#6B7280]',
              )}
              aria-current={isActive ? 'page' : undefined}
              aria-label={item.label}>
              <Icon
                className="h-5 w-5"
                aria-hidden="true"
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span>{item.label}</span>
              {isActive && (
                <span
                  className="absolute bottom-0 w-8 h-0.5 rounded-full bg-[#1A4D2E]"
                  aria-hidden="true"
                />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
