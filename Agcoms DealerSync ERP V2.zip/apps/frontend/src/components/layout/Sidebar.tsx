'use client';
/**
 * AGCOMS DealerSync ERP — Sidebar
 * Sprint 2 Fix: No sidebar component existed — there was no navigation at all.
 *
 * Desktop: collapsible 220px (expanded) ↔ 60px (collapsed)
 * Collapse state persisted to localStorage.
 * Active route highlighted with brand green.
 * Module groups with dividers matching the 14 ERP modules.
 * AGCOMS logo at top, user menu at bottom.
 */
'use client';
import { useState, useEffect } from 'react';
import Link                     from 'next/link';
import { usePathname }          from 'next/navigation';
import { cn }                   from '../../lib/cn';
import {
  LayoutDashboard, Users, Package, ShoppingCart, ClipboardList,
  Wrench, Truck, Calculator, UserSquare2, FileText, BarChart3,
  Globe, Bot, Navigation, ChevronLeft, ChevronRight, Settings,
  LogOut, Bell,
} from 'lucide-react';
import { useAuthStore }         from '../../stores/auth.store';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Separator }            from '../ui/separator';

interface NavItem {
  href:    string;
  label:   string;
  icon:    React.ElementType;
  module:  number;
  perms?:  string[];
}

const NAV: NavItem[] = [
  { href: '/erp/dashboard',               label: 'Dashboard',        icon: LayoutDashboard, module: 2 },
  { href: '/erp/crm/customers',           label: 'CRM',              icon: Users,           module: 3, perms: ['crm:read'] },
  { href: '/erp/inventory/products',      label: 'Inventory',        icon: Package,         module: 4, perms: ['inventory:read'] },
  { href: '/erp/sales/quotations',        label: 'Sales',            icon: ShoppingCart,    module: 5, perms: ['sales:read'] },
  { href: '/erp/procurement/vendors',     label: 'Procurement',      icon: ClipboardList,   module: 6, perms: ['procurement:read'] },
  { href: '/erp/workshop/service-requests', label: 'Workshop',       icon: Wrench,          module: 7, perms: ['workshop:read'] },
  { href: '/erp/fleet/assets',            label: 'Fleet',            icon: Truck,           module: 14, perms: ['fleet:read'] },
  { href: '/erp/finance/accounts',        label: 'Finance',          icon: Calculator,      module: 8, perms: ['finance:read'] },
  { href: '/erp/hr/employees',            label: 'HR & Payroll',     icon: UserSquare2,     module: 9, perms: ['hr:read'] },
  { href: '/erp/contracts',               label: 'Gov Contracts',    icon: FileText,        module: 10, perms: ['contracts:read'] },
  { href: '/erp/reports/kpis',            label: 'Reports & BI',     icon: BarChart3,       module: 11, perms: ['reports:read'] },
  { href: '/erp/ai',                      label: 'AI Intelligence',  icon: Bot,             module: 13 },
  { href: '/erp/admin/users',             label: 'Admin',            icon: Settings,        module: 1, perms: ['auth:admin'] },
];

const DIVIDERS_BEFORE = new Set([3, 8, 11, 13, 1]);

interface SidebarProps {
  collapsed: boolean;
  onCollapseToggle: () => void;
  isMobile?: boolean;
}

export function Sidebar(props: SidebarProps = { collapsed: false, onCollapseToggle: () => {} }) {
  const { collapsed: propCollapsed, onCollapseToggle, isMobile } = props;
  const pathname    = usePathname();
  const { user, clearAuth, hasPermission } = useAuthStore();
  const [collapsed, setCollapsed] = useState(propCollapsed ?? false);

  useEffect(() => {
    const stored = localStorage.getItem('sidebar_collapsed');
    if (stored !== null) setCollapsed(stored === 'true');
  }, []);

  const toggle = () => {
    const next = !collapsed;
    setCollapsed(next);
    localStorage.setItem('sidebar_collapsed', String(next));
  };

  const initials = user
    ? `${user.firstName[0] ?? ''}${user.lastName[0] ?? ''}`.toUpperCase()
    : '??';

  const visibleNav = NAV.filter(item =>
    !item.perms || item.perms.some(p => hasPermission(p))
  );

  return (
    <aside
      data-tour="sidebar-nav"
      className={cn(
        'relative flex flex-col h-screen bg-[#1C1C1E] text-white transition-all duration-200 ease-in-out flex-shrink-0',
        collapsed ? 'w-[60px]' : 'w-[220px]',
      )}>

      {/* Logo */}
      <div className={cn('flex items-center h-14 px-3 border-b border-white/10', collapsed ? 'justify-center' : 'gap-3')}>
        <div className='flex-shrink-0 h-7 w-7 rounded bg-[#1A4D2E] flex items-center justify-center'>
          <span className='text-[10px] font-bold text-[#F5C518]'>AG</span>
        </div>
        {!collapsed && (
          <div className='min-w-0'>
            <p className='text-[13px] font-semibold text-white truncate'>AGCOMS</p>
            <p className='text-[10px] text-white/50 truncate'>DealerSync ERP</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className='flex-1 overflow-y-auto py-2 scrollbar-hide'>
        {visibleNav.map((item, idx) => {
          const isActive  = pathname === item.href || pathname.startsWith(item.href + '/');
          const showDiv   = DIVIDERS_BEFORE.has(item.module) && idx > 0;
          const Icon      = item.icon;
          return (
            <div key={item.href}>
              {showDiv && <Separator className='my-1.5 bg-white/10' />}
              <Link
                href={item.href}
                title={collapsed ? item.label : undefined}
                className={cn(
                  'flex items-center gap-3 mx-2 px-2.5 py-2 rounded-lg text-[13px] transition-colors',
                  isActive
                    ? 'bg-[#1A4D2E] text-white'
                    : 'text-white/60 hover:bg-white/8 hover:text-white',
                  collapsed && 'justify-center px-0',
                )}>
                <Icon className='h-4 w-4 flex-shrink-0' />
                {!collapsed && <span className='truncate'>{item.label}</span>}
                {!collapsed && isActive && (
                  <span className='ml-auto h-1.5 w-1.5 rounded-full bg-[#F5C518]' />
                )}
              </Link>
            </div>
          );
        })}
      </nav>

      {/* Bottom: user + collapse */}
      <div className='border-t border-white/10 p-2 space-y-1'>
        {/* Notification */}
        <Link href='/erp/admin/users' className='flex items-center gap-3 mx-0.5 px-2.5 py-2 rounded-lg text-white/60 hover:bg-white/8 hover:text-white transition-colors'>
          <Bell className='h-4 w-4 flex-shrink-0' />
          {!collapsed && <span className='text-[13px]'>Notifications</span>}
        </Link>

        {/* User */}
        <div className={cn('flex items-center gap-3 px-2.5 py-2 rounded-lg', collapsed && 'justify-center px-0')}>
          <Avatar className='h-7 w-7 flex-shrink-0'>
            <AvatarFallback className='text-[10px]'>{initials}</AvatarFallback>
          </Avatar>
          {!collapsed && (
            <div className='flex-1 min-w-0'>
              <p className='text-[12px] font-medium text-white truncate'>{user?.firstName} {user?.lastName}</p>
              <p className='text-[10px] text-white/50 truncate'>{user?.role?.replace(/_/g, ' ')}</p>
            </div>
          )}
          {!collapsed && (
            <button onClick={() => clearAuth()} title='Log out' className='text-white/40 hover:text-white transition-colors'>
              <LogOut className='h-3.5 w-3.5' />
            </button>
          )}
        </div>

        {/* Collapse toggle */}
        <button
          onClick={toggle}
          className={cn(
            'w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/40 hover:bg-white/8 hover:text-white transition-colors text-[12px]',
            collapsed && 'justify-center px-0',
          )}>
          {collapsed
            ? <ChevronRight className='h-3.5 w-3.5' />
            : <><ChevronLeft className='h-3.5 w-3.5' /><span>Collapse</span></>}
        </button>
      </div>
    </aside>
  );
}
