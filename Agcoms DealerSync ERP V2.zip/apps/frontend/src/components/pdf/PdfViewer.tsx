'use client';
/**
 * AGCOMS DealerSync ERP — PdfViewer
 * §3 Tech Stack: PDF Viewer: PDF.js
 *
 * Renders PDFs from S3 signed URLs inline in the ERP.
 * Used for: invoices, purchase orders, payslips, contracts, compliance docs.
 *
 * Features:
 *   - Page navigation (prev/next/jump)
 *   - Zoom in/out (50%–200%)
 *   - Full-screen mode
 *   - Secure signed-URL download
 *   - Loading skeleton
 *   - Error state with retry
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import {
  ChevronLeft, ChevronRight, ZoomIn, ZoomOut,
  Download, Maximize2, Minimize2, RotateCw,
} from 'lucide-react';

interface PdfViewerProps {
  /** S3 signed URL or public URL of the PDF */
  url:        string;
  /** Optional title shown in the toolbar */
  title?:     string;
  /** Fixed height; defaults to 700px */
  height?:    number;
  /** Whether to show the download button */
  allowDownload?: boolean;
  /** Called when viewer encounters an error */
  onError?:   (err: Error) => void;
}

export function PdfViewer({
  url,
  title,
  height    = 700,
  allowDownload = true,
  onError,
}: PdfViewerProps) {
  const canvasRef        = useRef<HTMLCanvasElement>(null);
  const containerRef     = useRef<HTMLDivElement>(null);
  const pdfRef           = useRef<any>(null);
  const renderingRef     = useRef(false);

  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [scale, setScale]           = useState(1.2);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);

  // ── Load PDF.js from CDN (pdfjs-dist) ────────────────────────
  const loadPdfJs = useCallback(async () => {
    if (typeof window === 'undefined') return null;
    if ((window as any).__pdfjsLib) return (window as any).__pdfjsLib;

    return new Promise<any>((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.min.mjs';
      script.type = 'module';
      script.onload = () => {
        const lib = (window as any).pdfjsLib;
        if (lib) {
          lib.GlobalWorkerOptions.workerSrc =
            'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.worker.min.mjs';
          (window as any).__pdfjsLib = lib;
          resolve(lib);
        } else {
          reject(new Error('PDF.js failed to initialise'));
        }
      };
      script.onerror = () => reject(new Error('Failed to load PDF.js'));
      document.head.appendChild(script);
    });
  }, []);

  // ── Render a page onto the canvas ─────────────────────────────
  const renderPage = useCallback(async (pageNum: number, scaleVal: number) => {
    if (!pdfRef.current || !canvasRef.current) return;
    if (renderingRef.current) return;

    renderingRef.current = true;
    try {
      const page     = await pdfRef.current.getPage(pageNum);
      const viewport = page.getViewport({ scale: scaleVal });
      const canvas   = canvasRef.current;
      const ctx      = canvas.getContext('2d');
      if (!ctx) return;

      // High-DPI rendering
      const dpr         = window.devicePixelRatio || 1;
      canvas.width      = viewport.width  * dpr;
      canvas.height     = viewport.height * dpr;
      canvas.style.width  = `${viewport.width}px`;
      canvas.style.height = `${viewport.height}px`;
      ctx.scale(dpr, dpr);

      await page.render({ canvasContext: ctx, viewport }).promise;
    } finally {
      renderingRef.current = false;
    }
  }, []);

  // ── Load PDF document ─────────────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    (async () => {
      try {
        const pdfjsLib = await loadPdfJs();
        if (!pdfjsLib || cancelled) return;

        const pdf = await pdfjsLib.getDocument({
          url,
          cMapUrl:      'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/cmaps/',
          cMapPacked:   true,
          withCredentials: false,
        }).promise;

        if (cancelled) return;
        pdfRef.current = pdf;
        setTotalPages(pdf.numPages);
        setCurrentPage(1);
        setLoading(false);
        await renderPage(1, scale);
      } catch (err) {
        if (cancelled) return;
        const msg = err instanceof Error ? err.message : 'Failed to load PDF';
        setError(msg);
        setLoading(false);
        onError?.(err instanceof Error ? err : new Error(msg));
      }
    })();

    return () => { cancelled = true; };
  }, [url, loadPdfJs]);

  // Re-render when page or scale changes
  useEffect(() => {
    if (!loading && !error) renderPage(currentPage, scale);
  }, [currentPage, scale, loading, error, renderPage]);

  const goTo     = (n: number) => setCurrentPage(Math.max(1, Math.min(n, totalPages)));
  const zoomIn   = () => setScale(s => Math.min(3.0, parseFloat((s + 0.2).toFixed(1))));
  const zoomOut  = () => setScale(s => Math.max(0.5, parseFloat((s - 0.2).toFixed(1))));
  const resetZoom = () => setScale(1.2);

  return (
    <div
      ref={containerRef}
      className="flex flex-col border border-[#E5E7EB] rounded-xl overflow-hidden bg-[#1C1C1E]"
      style={fullscreen ? { position: 'fixed', inset: 0, zIndex: 50, height: '100vh', borderRadius: 0 } : {}}>
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-[#2C2C2E] border-b border-[#3C3C3E] flex-shrink-0">
        <div className="flex items-center gap-3">
          {/* Page navigation */}
          <button onClick={() => goTo(currentPage - 1)} disabled={currentPage <= 1}
            className="p-1.5 rounded hover:bg-[#3C3C3E] disabled:opacity-40 text-[#A1A1AA] hover:text-white">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-1 text-[12px] text-[#A1A1AA]">
            <input
              type="number" min={1} max={totalPages} value={currentPage}
              onChange={e => goTo(Number(e.target.value))}
              className="w-10 text-center bg-[#3C3C3E] border border-[#52525B] rounded text-white text-[12px] py-0.5 focus:outline-none focus:ring-1 focus:ring-[#1A4D2E]"
            />
            <span>/ {totalPages || '—'}</span>
          </div>
          <button onClick={() => goTo(currentPage + 1)} disabled={currentPage >= totalPages}
            className="p-1.5 rounded hover:bg-[#3C3C3E] disabled:opacity-40 text-[#A1A1AA] hover:text-white">
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* Title */}
        {title && (
          <span className="text-[12px] text-[#A1A1AA] truncate max-w-[200px]">{title}</span>
        )}

        <div className="flex items-center gap-1">
          {/* Zoom */}
          <button onClick={zoomOut} className="p-1.5 rounded hover:bg-[#3C3C3E] text-[#A1A1AA] hover:text-white">
            <ZoomOut className="h-4 w-4" />
          </button>
          <button onClick={resetZoom} className="px-2 py-1 text-[11px] text-[#A1A1AA] hover:text-white hover:bg-[#3C3C3E] rounded font-mono">
            {Math.round(scale * 100)}%
          </button>
          <button onClick={zoomIn} className="p-1.5 rounded hover:bg-[#3C3C3E] text-[#A1A1AA] hover:text-white">
            <ZoomIn className="h-4 w-4" />
          </button>

          <div className="w-px h-5 bg-[#3C3C3E] mx-1" />

          {/* Download */}
          {allowDownload && (
            <a href={url} download
              className="p-1.5 rounded hover:bg-[#3C3C3E] text-[#A1A1AA] hover:text-white">
              <Download className="h-4 w-4" />
            </a>
          )}

          {/* Fullscreen */}
          <button onClick={() => setFullscreen(f => !f)}
            className="p-1.5 rounded hover:bg-[#3C3C3E] text-[#A1A1AA] hover:text-white">
            {fullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Canvas area */}
      <div className="flex-1 overflow-auto flex items-start justify-center p-4"
        style={{ height: fullscreen ? 'calc(100vh - 48px)' : `${height}px`, background: '#1C1C1E' }}>
        {loading ? (
          <div className="flex flex-col items-center gap-3 mt-20">
            <div className="h-8 w-8 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
            <p className="text-[12px] text-[#71717A]">Loading PDF…</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center gap-3 mt-20 text-center max-w-[280px]">
            <div className="h-12 w-12 rounded-full bg-[#3F3F46] flex items-center justify-center">
              <RotateCw className="h-6 w-6 text-[#71717A]" />
            </div>
            <p className="text-[13px] text-[#F87171] font-medium">Failed to load PDF</p>
            <p className="text-[11px] text-[#71717A]">{error}</p>
            <button onClick={() => { setError(null); setLoading(true); }}
              className="mt-2 px-4 py-2 rounded-lg text-[12px] font-medium text-white"
              style={{ background: '#1A4D2E' }}>
              Retry
            </button>
          </div>
        ) : (
          <canvas ref={canvasRef}
            className="shadow-2xl max-w-full"
            style={{ borderRadius: '4px' }} />
        )}
      </div>
    </div>
  );
}

export default PdfViewer;
