'use client';
/**
 * AGCOMS DealerSync ERP — Tremor KPI Components
 * §3 Tech Stack: "Charts: Tremor"
 *
 * Reusable Tremor-based KPI components for dashboard and reports pages.
 * These wrap @tremor/react primitives with AGCOMS brand colours and
 * production-grade patterns (skeleton, delta badge, drill-down nav).
 */

import {
  Card, Metric, Text, BadgeDelta, Flex, ProgressBar,
  AreaChart, BarChart, SparkAreaChart, DeltaBar,
} from '@tremor/react';
import type { DeltaType } from '@tremor/react';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

// ── Types ──────────────────────────────────────────────────────

export type KpiTrend = 'up' | 'down' | 'flat';

export interface KpiCardProps {
  title:      string;
  value:      string;
  subtitle?:  string;
  trend?:     KpiTrend;
  trendValue?: string;  // e.g. "+12%" or "₦2.4M vs prior month"
  progress?:  number;   // 0–100 to show a progress bar
  progressColor?: 'green' | 'yellow' | 'red' | 'blue' | 'teal';
  href?:      string;   // optional drill-down link
  sparkData?: Array<{ date: string; value: number }>;
  isLoading?: boolean;
}

function trendToDeltaType(trend: KpiTrend): DeltaType {
  return trend === 'up' ? 'moderateIncrease' : trend === 'down' ? 'moderateDecrease' : 'unchanged';
}

// ── KPI Card ───────────────────────────────────────────────────

export function KpiCard({
  title, value, subtitle, trend, trendValue,
  progress, progressColor = 'green', href, sparkData, isLoading = false,
}: KpiCardProps) {
  const content = (
    <Card className="border border-[#E5E7EB] relative" decoration={href ? 'top' : undefined} decorationColor="green">
      {isLoading ? (
        <div className="space-y-2">
          <div className="h-3 w-24 bg-[#F3F4F6] rounded animate-pulse" />
          <div className="h-8 w-32 bg-[#F3F4F6] rounded animate-pulse" />
          <div className="h-3 w-20 bg-[#F3F4F6] rounded animate-pulse" />
        </div>
      ) : (
        <>
          <Text>{title}</Text>
          <Flex alignItems="end" className="space-x-2 mt-1">
            <Metric className="text-[#1A1A1A]">{value}</Metric>
            {trend && trendValue && (
              <BadgeDelta deltaType={trendToDeltaType(trend)} size="xs">
                {trendValue}
              </BadgeDelta>
            )}
          </Flex>
          {subtitle && <Text className="mt-1 text-[11px] text-[#9CA3AF]">{subtitle}</Text>}
          {progress !== undefined && (
            <ProgressBar value={progress} color={progressColor} className="mt-3" />
          )}
          {sparkData && sparkData.length > 0 && (
            <SparkAreaChart
              data={sparkData}
              index="date"
              categories={['value']}
              colors={['green']}
              className="h-8 mt-3"
            />
          )}
          {href && (
            <div className="mt-3 flex items-center gap-1 text-[11px] text-[#1A4D2E] font-medium">
              View details <ArrowRight className="h-3 w-3" />
            </div>
          )}
        </>
      )}
    </Card>
  );

  if (href && !isLoading) {
    return <Link href={href} className="block hover:opacity-90 transition-opacity">{content}</Link>;
  }
  return content;
}

// ── KPI Grid — pre-laid-out grid of KPI cards ─────────────────

export function KpiGrid({ kpis }: { kpis: KpiCardProps[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {kpis.map((kpi, i) => <KpiCard key={i} {...kpi} />)}
    </div>
  );
}

// ── Revenue Area Chart ─────────────────────────────────────────

export interface RevenueChartProps {
  data:       Array<{ period: string; revenue: number; target?: number }>;
  title?:     string;
  isLoading?: boolean;
}

export function RevenueChart({ data, title = 'Revenue trend', isLoading = false }: RevenueChartProps) {
  const categories = data.some(d => d.target !== undefined) ? ['revenue', 'target'] : ['revenue'];
  return (
    <Card className="border border-[#E5E7EB]">
      <Text className="font-medium text-[13px] mb-3">{title}</Text>
      {isLoading ? (
        <div className="h-48 bg-[#F3F4F6] rounded animate-pulse" />
      ) : (
        <AreaChart
          data={data}
          index="period"
          categories={categories}
          colors={['green', 'gray']}
          className="h-48"
          valueFormatter={v => `₦${(v / 1_000_000).toFixed(1)}M`}
          showAnimation
          showLegend={categories.length > 1}
          curveType="monotone"
        />
      )}
    </Card>
  );
}

// ── Branch Bar Chart ───────────────────────────────────────────

export interface BranchBarChartProps {
  data:       Array<{ branch: string; [key: string]: string | number }>;
  category:   string;
  title?:     string;
  isLoading?: boolean;
}

export function BranchBarChart({ data, category, title = 'By branch', isLoading = false }: BranchBarChartProps) {
  return (
    <Card className="border border-[#E5E7EB]">
      <Text className="font-medium text-[13px] mb-3">{title}</Text>
      {isLoading ? (
        <div className="h-40 bg-[#F3F4F6] rounded animate-pulse" />
      ) : (
        <BarChart
          data={data}
          index="branch"
          categories={[category]}
          colors={['green']}
          className="h-40"
          valueFormatter={v => `₦${(v / 1_000_000).toFixed(1)}M`}
          showAnimation
          layout="vertical"
        />
      )}
    </Card>
  );
}

// ── Delta indicator ─────────────────────────────────────────────

export function TrendDelta({ trend, value }: { trend: KpiTrend; value: string }) {
  return (
    <BadgeDelta deltaType={trendToDeltaType(trend)} size="sm">{value}</BadgeDelta>
  );
}

export { DeltaBar };
