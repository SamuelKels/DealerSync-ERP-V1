'use client';
/**
 * AGCOMS DealerSync ERP — SyncStatusIndicator
 * Sprint 4 / S4-C: Visual indicator of offline sync state.
 *
 * Shown in the Header when the user has technician-level permissions.
 * Displays: online/offline pill + pending count badge + manual sync button.
 * On mobile, floats as a bottom notification when offline.
 */
import { useOfflineSync }                       from '../../lib/offline/use-offline-sync';
import { Wifi, WifiOff, RefreshCw, CloudOff }  from 'lucide-react';
import { Button }                               from '../ui/button';
import { cn }                                   from '../../lib/cn';

interface SyncStatusIndicatorProps {
  compact?: boolean;   // compact = icon only (for header); full = banner
  className?: string;
}

export function SyncStatusIndicator({ compact = false, className }: SyncStatusIndicatorProps) {
  const { isOnline, pendingCount, isSyncing, lastSyncAt, syncNow } = useOfflineSync();

  // ── Online with no pending — just a subtle green dot ─────────────────
  if (isOnline && pendingCount === 0) {
    if (compact) return (
      <span
        className="h-2 w-2 rounded-full bg-[#16A34A] flex-shrink-0"
        title="Online — all synced"
        aria-label="Online"
      />
    );
    return null;  // Full mode: nothing to show when all synced
  }

  // ── Compact mode (header) ─────────────────────────────────────────────
  if (compact) {
    return (
      <button
        onClick={isOnline && pendingCount > 0 ? syncNow : undefined}
        disabled={isSyncing}
        className={cn(
          'relative flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] font-medium transition-colors',
          isOnline
            ? 'text-[#D97706] bg-[#FEF3C7] hover:bg-[#FDE68A]'
            : 'text-[#6B7280] bg-[#F3F4F6]',
          className,
        )}
        aria-label={isOnline ? `${pendingCount} pending sync` : 'Offline'}>
        {isOnline
          ? <RefreshCw className={cn('h-3 w-3', isSyncing && 'animate-spin')} aria-hidden="true" />
          : <CloudOff className="h-3 w-3" aria-hidden="true" />
        }
        {pendingCount > 0 && (
          <span className="font-semibold">{pendingCount}</span>
        )}
        <span className="sr-only">
          {isOnline ? `${pendingCount} actions pending sync` : 'Offline mode'}
        </span>
      </button>
    );
  }

  // ── Full banner mode (mobile bottom / offline page) ───────────────────
  return (
    <div
      role="status"
      aria-live="polite"
      className={cn(
        'flex items-center gap-3 px-4 py-3 rounded-xl border',
        isOnline
          ? 'bg-[#FFFBEB] border-[#FDE68A]'
          : 'bg-[#F7F4EF] border-[#E5E7EB]',
        className,
      )}>
      <div className={cn(
        'h-9 w-9 rounded-lg flex items-center justify-center flex-shrink-0',
        isOnline ? 'bg-[#FEF3C7]' : 'bg-[#E5E7EB]',
      )}>
        {isOnline
          ? <Wifi className="h-4.5 w-4.5 text-[#D97706]" aria-hidden="true" />
          : <WifiOff className="h-4.5 w-4.5 text-[#9CA3AF]" aria-hidden="true" />
        }
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-medium text-[#1A1A1A]">
          {isOnline ? 'Back online' : 'Working offline'}
        </p>
        <p className="text-[11px] text-[#6B7280] leading-tight">
          {isOnline
            ? pendingCount > 0
              ? `${pendingCount} action${pendingCount > 1 ? 's' : ''} pending sync`
              : lastSyncAt
                ? `Last synced: ${lastSyncAt.toLocaleTimeString('en-NG')}`
                : 'All synced'
            : 'Your actions will sync when connectivity is restored'
          }
        </p>
      </div>

      {isOnline && pendingCount > 0 && (
        <Button
          size="sm"
          variant="outline"
          onClick={syncNow}
          loading={isSyncing}
          className="flex-shrink-0 text-[#D97706] border-[#FDE68A] hover:bg-[#FEF3C7]">
          {isSyncing ? 'Syncing…' : 'Sync now'}
        </Button>
      )}
    </div>
  );
}

/**
 * OfflineBanner — sticky bottom banner shown on mobile when offline.
 * Mounts itself; renders nothing when online and all synced.
 */
export function OfflineBanner() {
  const { isOnline, pendingCount } = useOfflineSync();

  if (isOnline && pendingCount === 0) return null;

  return (
    <div
      className="fixed bottom-16 left-4 right-4 z-40 lg:hidden"
      role="alert"
      aria-live="assertive">
      <SyncStatusIndicator compact={false} />
    </div>
  );
}
