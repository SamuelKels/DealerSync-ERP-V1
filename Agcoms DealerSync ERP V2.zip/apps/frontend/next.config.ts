/**
 * AGCOMS DealerSync ERP — Next.js Config (Sprint 4: PWA added)
 */
import type { NextConfig } from 'next';

// next-pwa wrapper — disabled in development, Workbox in production
let withPWA: (config: NextConfig) => NextConfig;
try {
  withPWA = require('next-pwa')({
    dest:        'public',
    disable:     process.env['NODE_ENV'] === 'development',
    register:    true,
    skipWaiting: true,
    runtimeCaching: [
      { urlPattern: /^https?.*/, handler: 'NetworkFirst',
        options: { cacheName: 'agcoms-pages', networkTimeoutSeconds: 10,
          expiration: { maxEntries: 64, maxAgeSeconds: 86400 },
          cacheableResponse: { statuses: [0, 200] } } },
      { urlPattern: /\.(png|jpg|jpeg|svg|gif|webp|ico|woff2?|ttf)$/,
        handler: 'CacheFirst',
        options: { cacheName: 'agcoms-assets',
          expiration: { maxEntries: 128, maxAgeSeconds: 31536000 },
          cacheableResponse: { statuses: [0, 200] } } },
      { urlPattern: /\/api\//, handler: 'NetworkOnly' },
    ],
  });
} catch {
  withPWA = (c: NextConfig) => c;
}

const baseConfig: NextConfig = {
  typedRoutes: false,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'agcomsinternational.com' },
      { protocol: 'https', hostname: '*.s3.amazonaws.com' },
      { protocol: 'https', hostname: '*.s3.eu-west-1.amazonaws.com' },
      { protocol: 'http',  hostname: 'localhost', port: '9000' },
    ],
  },
  transpilePackages: ['@tremor/react'],
  async rewrites() {
    return [{ source: '/api/:path*',
      destination: `${process.env['NEXT_PUBLIC_API_URL'] ?? 'http://localhost:3001'}/api/:path*` }];
  },
  async headers() {
    return [{ source: '/:path*', headers: [
      { key: 'X-Frame-Options',        value: 'DENY' },
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy',        value: 'strict-origin-when-cross-origin' },
      { key: 'Permissions-Policy',     value: 'camera=(), microphone=(), geolocation=(self)' },
    ]}];
  },
  webpack(config) {
    config.resolve = config.resolve ?? {};
    config.resolve.alias = { ...(config.resolve.alias ?? {}), canvas: false };
    return config;
  },
};

export default withPWA(baseConfig);
