import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    '../../packages/ui/src/**/*.{js,ts,jsx,tsx}',
    // Include Tremor components
    './node_modules/@tremor/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      // §1 Brand: AGCOMS color palette
      colors: {
        brand: {
          green:  '#1A4D2E',
          yellow: '#F5C518',
          gold:   '#E8A020',
        },
        surface:    '#F7F4EF',
        danger:     '#DC2626',
        success:    '#16A34A',
        warning:    '#D97706',
        dark:       '#1C1C1E',
      },
      // §1 Typography
      fontFamily: {
        heading:  ['DM Serif Display', 'Georgia', 'serif'],
        display:  ['Playfair Display', 'Georgia', 'serif'],
        ui:       ['Outfit', 'system-ui', 'sans-serif'],
        mono:     ['JetBrains Mono', 'Menlo', 'monospace'],
        sans:     ['Outfit', 'system-ui', 'sans-serif'],
      },
      // §8: responsive grid breakpoints
      screens: {
        'xs': '480px',
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
      },
      borderRadius: {
        'xl':  '12px',
        '2xl': '16px',
        '3xl': '24px',
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease-in-out',
        'slide-in': 'slideIn 0.25s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%':   { transform: 'translateY(-8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)',    opacity: '1' },
        },
      },
      // Safe area for mobile bottom nav
      spacing: {
        'safe-bottom': 'env(safe-area-inset-bottom)',
        'safe-top':    'env(safe-area-inset-top)',
      },
    },
  },
  plugins: [],
  // Ensure Tremor classes are not purged
  safelist: [
    { pattern: /^(bg|text|border|ring)-(slate|gray|zinc|neutral|stone|red|orange|amber|yellow|lime|green|emerald|teal|cyan|sky|blue|indigo|violet|purple|fuchsia|pink|rose)/ },
    { pattern: /^(tremor-)/ },
  ],
};

export default config;
