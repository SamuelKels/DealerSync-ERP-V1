// jest.integration.config.js
/** @type {import('@jest/types').Config.InitialOptions} */
module.exports = {
  displayName:     'integration',
  preset:          'ts-jest',
  testEnvironment: 'node',
  rootDir:         '.',
  testMatch:       ['<rootDir>/test/integration/**/*.spec.ts', '<rootDir>/test/integration/**/*.integration.spec.ts'],
  globalSetup:     '<rootDir>/test/integration/global-setup.ts',
  globalTeardown:  '<rootDir>/test/integration/global-teardown.ts',
  moduleNameMapper: {
    '^@agcoms/(.*)$': '<rootDir>/../../packages/$1/src/index',
  },
  transform: {
    '^.+\\.ts$': ['ts-jest', {
      tsconfig: '<rootDir>/tsconfig.json',
      diagnostics: { warnOnly: true },
    }],
  },
  // Integration tests run serially — share one DB connection
  maxWorkers:    1,
  testTimeout:   30_000,
  verbose:       true,
  forceExit:     true,
  clearMocks:    true,
};
