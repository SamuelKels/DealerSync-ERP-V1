# Prisma Schema — AGCOMS DealerSync ERP

## Production usage

Before first build, generate the typed Prisma client:

```bash
pnpm --filter backend exec prisma generate
```

Before first deploy, run migrations:

```bash
pnpm --filter backend exec prisma migrate deploy
```

For local dev:

```bash
pnpm --filter backend exec prisma migrate dev --name <change_description>
```

## V2 sandbox typecheck note

The V2 remediation sprint was run in an environment where the Prisma engine
binaries (`binaries.prisma.sh`) were blocked by network policy. To allow
`tsc --noEmit` to validate the rest of the backend, a **permissive synthetic
client** was written to `node_modules/.prisma/client/` and overlaid into
the pnpm-resolved `@prisma/client` location.

The synthetic client:

- Exports all 73 models as TypeScript interfaces with an `[index: string]: any`
  signature — meaning **field-access drift between code and schema will NOT
  be caught at typecheck time in V2**.
- Exports all 39 enums as both runtime constants and string-literal union types
- Exports stub `Prisma.PrismaClientKnownRequestError`, `Prisma.WhereInput`, etc.
- Exports a `PrismaClient` class with `findMany`, `create`, `update`, etc.,
  all returning `any`.

**Critical action before production:**

1. Delete `node_modules/.prisma/client/` (or wipe `node_modules` entirely)
2. Run `pnpm install`
3. Run `pnpm --filter backend exec prisma generate` against the real engines
4. Run `pnpm --filter backend exec tsc --noEmit` and resolve ANY field-access
   errors that surface. These will be real schema-vs-code mismatches accumulated
   across the V1 sprints that the synthetic stub could not detect.

## Migration history

Generated migrations live in `prisma/migrations/`. Each is a directory named
`YYYYMMDDHHMMSS_description/migration.sql`. Apply with `prisma migrate deploy`.

## Schema integrity

- 73 models, 39 enums (last verified V2 remediation)
- All models have `@id` primary keys
- All `@relation` references resolve to existing models
- Zero duplicate model/enum names
