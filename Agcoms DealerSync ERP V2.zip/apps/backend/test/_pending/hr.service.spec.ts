/**
 * AGCOMS DealerSync ERP — HR Service Unit Tests
 * §10 Testing: payroll net pay, leave balance (Nigerian Labour Act),
 *              performance review scoring, employee status machine
 */

import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException }  from '@nestjs/common';
import { HrService }            from '../../hr/hr.service';
import { PrismaService }        from '../../prisma/prisma.service';
import { EventEmitter2 }        from '@nestjs/event-emitter';
import { AuditService }         from '../../audit/audit.service';

const mockPrisma = () => ({
  $transaction:      jest.fn(fn => fn(mockPrisma())),
  employee:          { findUnique: jest.fn(), update: jest.fn(), create: jest.fn(), count: jest.fn(), findMany: jest.fn() },
  payrollRun:        { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), count: jest.fn() },
  payrollLine:       { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), createMany: jest.fn() },
  leaveRequest:      { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), findMany: jest.fn(), count: jest.fn() },
  leaveBalance:      { findFirst: jest.fn(), upsert: jest.fn() },
  performanceReview: { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), count: jest.fn(), findFirst: jest.fn() },
  department:        { findMany: jest.fn() },
  branch:            { findUnique: jest.fn().mockResolvedValue({ code: 'HQ' }) },
});

describe('HrService — unit tests', () => {
  let service: HrService;
  let prisma:  ReturnType<typeof mockPrisma>;
  const actor = { sub: 'mgr-1', roles: ['HR_MANAGER'], isSuperAdmin: false, branchId: 'branch-1', permissions: ['hr:write', 'hr:read_sensitive'] };

  beforeEach(async () => {
    prisma = mockPrisma();
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        HrService,
        { provide: PrismaService, useValue: prisma },
        { provide: EventEmitter2, useValue: { emit: jest.fn() } },
        { provide: AuditService,  useValue: { log: jest.fn() } },
      ],
    }).compile();
    service = module.get<HrService>(HrService);
  });

  // ── Net pay computation ───────────────────────────────────────

  describe('computeNetPay', () => {
    it('net pay is gross minus all statutory deductions', () => {
      const gross      = 300_000;
      const paye       = 15_000;
      const nhf        = 7_500;
      const pension    = 24_000;
      const netPay     = service.computeNetPay(gross, { paye, nhf, employeePension: pension, wht: 0 });
      expect(netPay).toBe(300_000 - 15_000 - 7_500 - 24_000);
    });

    it('net pay is never negative (floor at zero)', () => {
      const netPay = service.computeNetPay(50_000, { paye: 30_000, nhf: 15_000, employeePension: 20_000, wht: 0 });
      expect(netPay).toBe(0);
    });

    it('net pay with zero deductions equals gross', () => {
      expect(service.computeNetPay(250_000, { paye: 0, nhf: 0, employeePension: 0, wht: 0 })).toBe(250_000);
    });
  });

  // ── Leave balance (Nigerian Labour Act 2004) ──────────────────

  describe('calculateLeaveEntitlement', () => {
    /**
     * Nigerian Labour Act minimum:
     *   - At least 6 working days annual leave after 12 months
     *   - Under 16 years of age: at least 12 days
     *   Most employers: 21 working days standard
     */

    it('full-time employee with 1+ year tenure gets minimum 21 days', () => {
      const entitlement = service.calculateLeaveEntitlement({
        employmentType: 'FULL_TIME',
        hireDateMonthsAgo: 14,
        leaveType: 'ANNUAL',
      });
      expect(entitlement).toBeGreaterThanOrEqual(21);
    });

    it('employee with < 12 months tenure gets prorated leave', () => {
      const entitlement = service.calculateLeaveEntitlement({
        employmentType: 'FULL_TIME',
        hireDateMonthsAgo: 6,
        leaveType: 'ANNUAL',
      });
      // Prorated: 6/12 × 21 = ~10–11 days
      expect(entitlement).toBeGreaterThan(0);
      expect(entitlement).toBeLessThan(21);
    });

    it('contract employees may have different entitlement', () => {
      const entitlement = service.calculateLeaveEntitlement({
        employmentType: 'CONTRACT',
        hireDateMonthsAgo: 13,
        leaveType: 'ANNUAL',
      });
      expect(entitlement).toBeGreaterThanOrEqual(6); // Labour Act minimum
    });

    it('sick leave entitlement is separate from annual', () => {
      const sickLeave = service.calculateLeaveEntitlement({
        employmentType: 'FULL_TIME',
        hireDateMonthsAgo: 24,
        leaveType: 'SICK',
      });
      expect(sickLeave).toBeGreaterThan(0);
    });

    it('maternity leave is 12 weeks minimum (Nigerian Labour Act §54)', () => {
      const maternity = service.calculateLeaveEntitlement({
        employmentType: 'FULL_TIME',
        hireDateMonthsAgo: 24,
        leaveType: 'MATERNITY',
      });
      expect(maternity).toBeGreaterThanOrEqual(84); // 12 weeks × 7 days
    });
  });

  // ── Performance review scoring ────────────────────────────────

  describe('computeReviewScore', () => {
    const perfectScores = [
      { category: 'Quality',     score: 5 },
      { category: 'Timeliness',  score: 5 },
      { category: 'Teamwork',    score: 5 },
      { category: 'Skills',      score: 5 },
      { category: 'Goals',       score: 5 },
    ];

    const poorScores = [
      { category: 'Quality',     score: 1 },
      { category: 'Timeliness',  score: 1 },
      { category: 'Teamwork',    score: 1 },
      { category: 'Skills',      score: 1 },
      { category: 'Goals',       score: 1 },
    ];

    const avgScores = [
      { category: 'Quality',     score: 3 },
      { category: 'Timeliness',  score: 3 },
      { category: 'Teamwork',    score: 3 },
      { category: 'Skills',      score: 3 },
      { category: 'Goals',       score: 3 },
    ];

    it('all 5s yields OUTSTANDING rating', () => {
      const { score, rating } = service.computeReviewScore(perfectScores);
      expect(score).toBe(5);
      expect(rating).toBe('OUTSTANDING');
    });

    it('all 1s yields POOR rating', () => {
      const { score, rating } = service.computeReviewScore(poorScores);
      expect(score).toBe(1);
      expect(rating).toBe('POOR');
    });

    it('all 3s yields MEETS_EXPECTATIONS rating', () => {
      const { score, rating } = service.computeReviewScore(avgScores);
      expect(score).toBe(3);
      expect(rating).toBe('MEETS_EXPECTATIONS');
    });

    it('score is the simple average across all KPI categories', () => {
      const mixedScores = [
        { category: 'Quality',    score: 4 },
        { category: 'Timeliness', score: 2 },
        { category: 'Teamwork',   score: 3 },
        { category: 'Skills',     score: 5 },
        { category: 'Goals',      score: 1 },
      ];
      const { score } = service.computeReviewScore(mixedScores);
      expect(score).toBe((4 + 2 + 3 + 5 + 1) / 5); // 3.0
    });

    it('throws BadRequestException for score outside 1–5 range', () => {
      const invalidScores = [
        { category: 'Quality', score: 0 }, // invalid
        { category: 'Timeliness', score: 3 },
        { category: 'Teamwork', score: 3 },
        { category: 'Skills', score: 3 },
        { category: 'Goals', score: 3 },
      ];
      expect(() => service.computeReviewScore(invalidScores)).toThrow(BadRequestException);
    });

    it('throws BadRequestException for empty KPI array', () => {
      expect(() => service.computeReviewScore([])).toThrow(BadRequestException);
    });
  });

  // ── Employee status machine ───────────────────────────────────

  describe('assertValidEmployeeTransition', () => {
    it('ACTIVE → ON_LEAVE is valid', () => {
      expect(() => service.assertValidEmployeeTransition('ACTIVE', 'ON_LEAVE')).not.toThrow();
    });

    it('ACTIVE → SUSPENDED is valid', () => {
      expect(() => service.assertValidEmployeeTransition('ACTIVE', 'SUSPENDED')).not.toThrow();
    });

    it('ON_LEAVE → ACTIVE is valid (return from leave)', () => {
      expect(() => service.assertValidEmployeeTransition('ON_LEAVE', 'ACTIVE')).not.toThrow();
    });

    it('TERMINATED → ACTIVE throws (cannot rehire via status change)', () => {
      expect(() => service.assertValidEmployeeTransition('TERMINATED', 'ACTIVE')).toThrow(BadRequestException);
    });

    it('TERMINATED → any throws (terminal state)', () => {
      expect(() => service.assertValidEmployeeTransition('TERMINATED', 'SUSPENDED')).toThrow(BadRequestException);
      expect(() => service.assertValidEmployeeTransition('TERMINATED', 'ON_LEAVE')).toThrow(BadRequestException);
    });
  });
});
