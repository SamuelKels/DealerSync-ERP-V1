/**
 * AGCOMS DealerSync ERP — Supertest Integration Test Global Setup
 * §10 Testing: "integration tests" + "Supertest" tool
 *
 * Lifecycle:
 *   1. Bootstrap NestJS application against test database
 *   2. Run Prisma migrations to ensure fresh schema
 *   3. Seed minimal test data (branches, accounts, users)
 *   4. Authenticate test users and cache JWTs
 *   5. Expose app, HTTP server, and auth tokens via globalThis
 *
 * All integration tests share this single bootstrap (jest.config integration)
 * to avoid the overhead of spawning NestJS per-file.
 */

import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import supertest from 'supertest';
import { AppModule }     from '../../src/app.module';
import { PrismaService } from '../../src/prisma/prisma.service';
import { execSync }      from 'child_process';

declare global {
  var testApp:      INestApplication;
  var testRequest:  ReturnType<typeof supertest>;
  var adminToken:   string;
  var managerToken: string;
  var salesToken:   string;
  var testBranchId: string;
  var testCustomerId: string;
}

export default async function globalSetup() {
  // Ensure test DB URL is set
  if (!process.env['DATABASE_URL']?.includes('_test')) {
    throw new Error('DATABASE_URL must point to a test database (must contain "_test")');
  }

  // Run migrations fresh
  execSync('npx prisma migrate deploy', {
    env: { ...process.env },
    stdio: 'pipe',
  });

  // Bootstrap NestJS
  const moduleRef: TestingModule = await Test.createTestingModule({
    imports: [AppModule],
  }).compile();

  const app = moduleRef.createNestApplication();
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  app.setGlobalPrefix('api/v1');
  await app.init();

  const prisma = app.get<PrismaService>(PrismaService);

  // ── Seed test data ─────────────────────────────────────────────

  // Branch
  const branch = await prisma.branch.upsert({
    where:  { code: 'TEST' },
    update: {},
    create: { name: 'Test Branch', code: 'TEST', address: 'Test St, Abuja', isActive: true },
  });
  global.testBranchId = branch.id;

  // Accounts (needed for journal tests)
  const accountTypes = [
    { code: '1100', name: 'Accounts Receivable',   accountType: 'ASSET',     normalBalance: 'DEBIT' },
    { code: '2100', name: 'Accounts Payable',       accountType: 'LIABILITY', normalBalance: 'CREDIT' },
    { code: '2300', name: 'VAT Liability',          accountType: 'LIABILITY', normalBalance: 'CREDIT' },
    { code: '3000', name: 'Share Capital',          accountType: 'EQUITY',    normalBalance: 'CREDIT' },
    { code: '4000', name: 'Revenue',                accountType: 'REVENUE',   normalBalance: 'CREDIT' },
    { code: '5000', name: 'Cost of Sales',          accountType: 'COST_OF_SALES', normalBalance: 'DEBIT' },
    { code: '6000', name: 'Operating Expenses',     accountType: 'OPERATING_EXPENSE', normalBalance: 'DEBIT' },
    { code: '1000', name: 'Cash & Bank',            accountType: 'ASSET',     normalBalance: 'DEBIT' },
  ];
  for (const acct of accountTypes) {
    await prisma.account.upsert({
      where:  { code_branchId: { code: acct.code, branchId: branch.id } },
      update: {},
      create: { ...acct, branchId: branch.id, isActive: true },
    });
  }

  // Accounting period
  const now = new Date();
  await prisma.accountingPeriod.upsert({
    where:  { branchId_year_month: { branchId: branch.id, year: now.getFullYear(), month: now.getMonth() + 1 } },
    update: {},
    create: {
      branchId:  branch.id,
      year:      now.getFullYear(),
      month:     now.getMonth() + 1,
      name:      `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`,
      status:    'OPEN',
      startDate: new Date(now.getFullYear(), now.getMonth(), 1),
      endDate:   new Date(now.getFullYear(), now.getMonth() + 1, 0),
    },
  });

  // Test customer
  const customer = await prisma.customer.upsert({
    where:  { email_branchId: { email: 'testcustomer@example.ng', branchId: branch.id } },
    update: {},
    create: {
      name:         'Test Customer Ltd',
      email:        'testcustomer@example.ng',
      phone:        '+2348012345678',
      branchId:     branch.id,
      customerType: 'COMPANY',
      status:       'ACTIVE',
      creditLimit:  5_000_000,
    },
  });
  global.testCustomerId = customer.id;

  // ── Authenticate test users ─────────────────────────────────────

  const http = supertest(app.getHttpServer());

  const loginAndGetToken = async (email: string, password: string): Promise<string> => {
    const res = await http.post('/api/v1/auth/login').send({ email, password });
    if (res.status !== 200 && res.status !== 201) {
      throw new Error(`Login failed for ${email}: ${res.status} ${JSON.stringify(res.body)}`);
    }
    return (res.body as { data?: { accessToken?: string }; accessToken?: string }).data?.accessToken
        ?? (res.body as { accessToken?: string }).accessToken
        ?? '';
  };

  global.adminToken   = await loginAndGetToken('admin@agcoms.ng',   process.env['TEST_ADMIN_PASS']   ?? 'SecureP@ssword123');
  global.managerToken = await loginAndGetToken('manager@agcoms.ng', process.env['TEST_MANAGER_PASS'] ?? 'SecureP@ssword123');
  global.salesToken   = await loginAndGetToken('sales@agcoms.ng',   process.env['TEST_SALES_PASS']   ?? 'SecureP@ssword123');

  global.testApp     = app;
  global.testRequest = http;
}
