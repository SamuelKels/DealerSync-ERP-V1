// ────────────────────────────────────────────────────────────────
// AGCOMS DealerSync ERP — Sales Integration Tests
// ────────────────────────────────────────────────────────────────
// test/integration/sales/sales.integration.spec.ts

const authHeader = () => ({ Authorization: `Bearer ${global.adminToken}` });

describe('/api/v1/sales — integration tests', () => {
  let quotationId: string;
  let invoiceId:   string;

  describe('GET /api/v1/sales/quotations', () => {
    it('returns 200 with pagination envelope', async () => {
      const res = await global.testRequest
        .get(`/api/v1/sales/quotations?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      const body = res.body.data ?? res.body;
      expect(body.items ?? body).toBeInstanceOf(Array);
    });

    it('filters by status', async () => {
      const res = await global.testRequest
        .get(`/api/v1/sales/quotations?branchId=${global.testBranchId}&status=DRAFT&limit=5`)
        .set(authHeader())
        .expect(200);
      const items: Array<{ status: string }> = res.body.data?.items ?? res.body.items ?? [];
      items.forEach(q => expect(q.status).toBe('DRAFT'));
    });
  });

  describe('POST /api/v1/sales/quotations', () => {
    it('creates a quotation and returns 201 with quotationNo', async () => {
      const res = await global.testRequest
        .post('/api/v1/sales/quotations')
        .set(authHeader())
        .send({
          branchId:   global.testBranchId,
          customerId: global.testCustomerId,
          currency:   'NGN',
          lines: [
            { description: 'John Deere 6120M', quantity: 1, unitPrice: 14_000_000, vatRate: 7.5, discountPct: 0 },
          ],
        })
        .expect(201);

      const q = res.body.data ?? res.body;
      expect(q.quotationNo).toMatch(/^QUO-/);
      quotationId = q.id;
    });
  });

  describe('GET /api/v1/sales/invoices', () => {
    it('returns 200 with invoice list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/sales/invoices?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      expect(res.body.data?.items ?? res.body.items ?? res.body).toBeInstanceOf(Array);
    });

    it('invoice items have required fields', async () => {
      const res = await global.testRequest
        .get(`/api/v1/sales/invoices?branchId=${global.testBranchId}&limit=3`)
        .set(authHeader())
        .expect(200);
      const items: Array<{ invoiceNo: string; status: string; totalAmount: number }> =
        res.body.data?.items ?? res.body.items ?? [];
      items.forEach(inv => {
        expect(inv).toHaveProperty('invoiceNo');
        expect(inv).toHaveProperty('status');
        expect(inv).toHaveProperty('totalAmount');
      });
    });
  });

  describe('GET /api/v1/sales/credit-notes', () => {
    it('returns 200 credit notes list', async () => {
      await global.testRequest
        .get(`/api/v1/sales/credit-notes?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
    });
  });
});

// ────────────────────────────────────────────────────────────────
// CRM Integration Tests
// ────────────────────────────────────────────────────────────────
// test/integration/crm/crm.integration.spec.ts

describe('/api/v1/crm — integration tests', () => {
  let customerId: string;

  describe('GET /api/v1/crm/customers', () => {
    it('returns paginated customer list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/crm/customers?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toBeInstanceOf(Array);
    });
  });

  describe('POST /api/v1/crm/customers', () => {
    it('creates a customer and returns 201', async () => {
      const res = await global.testRequest
        .post('/api/v1/crm/customers')
        .set(authHeader())
        .send({
          name:         `Integration Test Customer ${Date.now()}`,
          email:        `inttest${Date.now()}@example.ng`,
          phone:        '+2348098765432',
          branchId:     global.testBranchId,
          customerType: 'COMPANY',
          creditLimit:  1_000_000,
        })
        .expect(201);

      const c = res.body.data ?? res.body;
      expect(c.customerNo).toBeDefined();
      customerId = c.id;
    });
  });

  describe('GET /api/v1/crm/customers/:id/credit-check', () => {
    it('returns credit utilisation for a customer', async () => {
      if (!global.testCustomerId) return;
      const res = await global.testRequest
        .get(`/api/v1/crm/customers/${global.testCustomerId}/credit-check`)
        .set(authHeader())
        .expect(200);
      const credit = res.body.data ?? res.body;
      expect(credit).toHaveProperty('status');
      expect(credit).toHaveProperty('utilisationPct');
      expect(['CLEAR', 'WARNING', 'BLOCKED']).toContain(credit.status);
    });
  });

  describe('Branch isolation', () => {
    it('customers from another branch are not returned', async () => {
      const res = await global.testRequest
        .get('/api/v1/crm/customers?branchId=non-existent-branch-id&limit=20')
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toHaveLength(0);
    });
  });
});

// ────────────────────────────────────────────────────────────────
// HR Integration Tests
// ────────────────────────────────────────────────────────────────

describe('/api/v1/hr — integration tests', () => {
  describe('GET /api/v1/hr/employees', () => {
    it('returns paginated employee list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/hr/employees?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toBeInstanceOf(Array);
    });

    it('grossSalary is masked (0) for non-HR-sensitive users', async () => {
      const res = await global.testRequest
        .get(`/api/v1/hr/employees?branchId=${global.testBranchId}&limit=5`)
        .set({ Authorization: `Bearer ${global.salesToken}` }) // sales user — no hr:read_sensitive
        .expect(200);
      const items: Array<{ grossSalary?: number }> = res.body.data?.items ?? res.body.items ?? [];
      if (items.length > 0 && 'grossSalary' in (items[0] ?? {})) {
        expect(items[0]!.grossSalary).toBe(0); // Masked
      }
    });

    it('grossSalary is visible to HR admin', async () => {
      const res = await global.testRequest
        .get(`/api/v1/hr/employees?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader()) // admin — has hr:read_sensitive
        .expect(200);
      const items: Array<{ grossSalary?: number }> = res.body.data?.items ?? res.body.items ?? [];
      if (items.length > 0 && 'grossSalary' in (items[0] ?? {})) {
        expect(typeof items[0]!.grossSalary).toBe('number');
        expect(items[0]!.grossSalary).toBeGreaterThan(0);
      }
    });
  });

  describe('GET /api/v1/hr/departments', () => {
    it('returns department list', async () => {
      await global.testRequest
        .get(`/api/v1/hr/departments?branchId=${global.testBranchId}`)
        .set(authHeader())
        .expect(200);
    });
  });
});

// ────────────────────────────────────────────────────────────────
// Inventory Integration Tests
// ────────────────────────────────────────────────────────────────

describe('/api/v1/inventory — integration tests', () => {
  describe('GET /api/v1/inventory/products', () => {
    it('returns product list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/inventory/products?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toBeInstanceOf(Array);
    });
  });

  describe('GET /api/v1/inventory/warehouses', () => {
    it('returns warehouse list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/inventory/warehouses?branchId=${global.testBranchId}`)
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toBeInstanceOf(Array);
    });
  });

  describe('GET /api/v1/inventory/stock-counts', () => {
    it('returns stock count list', async () => {
      await global.testRequest
        .get(`/api/v1/inventory/stock-counts?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
    });
  });
});

// ────────────────────────────────────────────────────────────────
// Procurement Integration Tests
// ────────────────────────────────────────────────────────────────

describe('/api/v1/procurement — integration tests', () => {
  describe('GET /api/v1/procurement/vendors', () => {
    it('returns vendor list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/procurement/vendors?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
      const items = res.body.data?.items ?? res.body.items ?? [];
      expect(items).toBeInstanceOf(Array);
    });
  });

  describe('GET /api/v1/procurement/purchase-orders', () => {
    it('returns PO list', async () => {
      await global.testRequest
        .get(`/api/v1/procurement/purchase-orders?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
    });
  });
});

// ────────────────────────────────────────────────────────────────
// Workshop Integration Tests
// ────────────────────────────────────────────────────────────────

describe('/api/v1/workshop — integration tests', () => {
  describe('GET /api/v1/workshop/service-requests', () => {
    it('returns service requests list', async () => {
      await global.testRequest
        .get(`/api/v1/workshop/service-requests?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
    });
  });

  describe('GET /api/v1/workshop/job-cards', () => {
    it('returns job cards list', async () => {
      await global.testRequest
        .get(`/api/v1/workshop/job-cards?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);
    });
  });
});
