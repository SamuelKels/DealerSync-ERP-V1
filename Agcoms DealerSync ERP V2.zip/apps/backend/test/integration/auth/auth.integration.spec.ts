/**
 * AGCOMS DealerSync ERP — Auth Integration Tests (Supertest)
 * §10 Testing: "integration tests" + "Supertest"
 *
 * Tests the full HTTP request/response cycle against a live
 * NestJS instance with real PostgreSQL.
 */

import * as supertest from 'supertest';

const request = () => global.testRequest;

describe('/api/v1/auth — integration tests', () => {

  // ── Login endpoint ────────────────────────────────────────────

  describe('POST /api/v1/auth/login', () => {
    it('returns 200 and accessToken for valid credentials', async () => {
      const res = await request()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: process.env['TEST_ADMIN_PASS'] ?? 'SecureP@ssword123' })
        .expect(200);

      expect(res.body.data ?? res.body).toMatchObject(
        expect.objectContaining({ accessToken: expect.any(String) })
      );
    });

    it('returns 401 for wrong password', async () => {
      await request()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: 'WrongPassword!' })
        .expect(401);
    });

    it('returns 401 for non-existent user', async () => {
      await request()
        .post('/api/v1/auth/login')
        .send({ email: 'nobody@nowhere.ng', password: 'SomePassword1!' })
        .expect(401);
    });

    it('returns 400 for invalid email format', async () => {
      await request()
        .post('/api/v1/auth/login')
        .send({ email: 'not-an-email', password: 'SomePassword1!' })
        .expect(400);
    });

    it('returns 400 for missing password', async () => {
      await request()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng' })
        .expect(400);
    });

    it('response sets HttpOnly refresh token cookie', async () => {
      const res = await request()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: process.env['TEST_ADMIN_PASS'] ?? 'SecureP@ssword123' })
        .expect(200);

      const cookies = res.headers['set-cookie'] as string[] | undefined;
      expect(cookies).toBeDefined();
      const refreshCookie = (Array.isArray(cookies) ? cookies : [cookies]).join(';');
      expect(refreshCookie).toMatch(/refresh_token/i);
      expect(refreshCookie).toMatch(/HttpOnly/i);
    });
  });

  // ── Security headers ──────────────────────────────────────────

  describe('Security headers', () => {
    it('all responses include X-Content-Type-Options: nosniff', async () => {
      const res = await request().get('/api/v1/health');
      expect(res.headers['x-content-type-options']).toBe('nosniff');
    });

    it('all responses include X-Frame-Options', async () => {
      const res = await request().get('/api/v1/health');
      expect(res.headers['x-frame-options']).toBeDefined();
    });

    it('API does not expose X-Powered-By header', async () => {
      const res = await request().get('/api/v1/health');
      expect(res.headers['x-powered-by']).toBeUndefined();
    });
  });

  // ── Protected endpoints require auth ──────────────────────────

  describe('RBAC enforcement on protected endpoints', () => {
    it('returns 401 for unauthenticated request to /customers', async () => {
      await request().get('/api/v1/crm/customers').expect(401);
    });

    it('returns 401 for unauthenticated request to /finance/journals', async () => {
      await request().get('/api/v1/finance/journals').expect(401);
    });

    it('returns 200 for authenticated request to /customers', async () => {
      await request()
        .get('/api/v1/crm/customers?limit=1')
        .set('Authorization', `Bearer ${global.adminToken}`)
        .expect(200);
    });

    it('returns 403 when user lacks required permission', async () => {
      // Sales token should not access admin routes
      await request()
        .get('/api/v1/users')
        .set('Authorization', `Bearer ${global.salesToken}`)
        .expect(403);
    });
  });

  // ── Token refresh ─────────────────────────────────────────────

  describe('POST /api/v1/auth/refresh', () => {
    it('returns a new accessToken using valid refresh cookie', async () => {
      // First login to get cookie
      const loginRes = await request()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: process.env['TEST_ADMIN_PASS'] ?? 'SecureP@ssword123' })
        .expect(200);

      const cookies = loginRes.headers['set-cookie'];
      if (!cookies) return; // Skip if cookies not implemented

      const refreshRes = await request()
        .post('/api/v1/auth/refresh')
        .set('Cookie', Array.isArray(cookies) ? cookies.join('; ') : cookies)
        .expect(200);

      const body = refreshRes.body.data ?? refreshRes.body;
      expect(body).toMatchObject(expect.objectContaining({ accessToken: expect.any(String) }));
    });

    it('returns 401 for missing refresh cookie', async () => {
      await request().post('/api/v1/auth/refresh').expect(401);
    });
  });

  // ── Logout ────────────────────────────────────────────────────

  describe('POST /api/v1/auth/logout', () => {
    it('returns 200 and clears the refresh token cookie', async () => {
      const res = await request()
        .post('/api/v1/auth/logout')
        .set('Authorization', `Bearer ${global.adminToken}`)
        .expect(200);

      const cookies = res.headers['set-cookie'] as string[] | undefined;
      if (cookies) {
        const joined = Array.isArray(cookies) ? cookies.join(';') : cookies;
        // Refresh token should be cleared (Max-Age=0 or expires in past)
        expect(joined).toMatch(/refresh_token/i);
      }
    });
  });

  // ── Health check ──────────────────────────────────────────────

  describe('GET /api/v1/health', () => {
    it('returns 200 with database and redis status', async () => {
      const res = await request().get('/api/v1/health').expect(200);
      expect(res.body).toMatchObject(
        expect.objectContaining({ status: 'ok' })
      );
    });
  });
});
