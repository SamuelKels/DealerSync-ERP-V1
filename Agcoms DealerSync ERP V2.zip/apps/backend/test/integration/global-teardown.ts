// test/integration/global-teardown.ts
export default async function globalTeardown() {
  try {
    await global.testApp?.close();
  } catch {
    // Ignore teardown errors — DB cleanup handled by test DB reset
  }
}
