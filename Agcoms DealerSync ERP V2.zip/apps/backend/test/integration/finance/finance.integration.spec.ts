/**
 * AGCOMS DealerSync ERP — Finance Integration Tests (Supertest)
 * §10 Testing: "finance workflow validation"
 * Critical: double-entry balance must be enforced at the HTTP layer
 */

import * as supertest from 'supertest';

const authHeader = () => ({ Authorization: `Bearer ${global.adminToken}` });

describe('/api/v1/finance — integration tests', () => {
  let arAccountId:  string;
  let revAccountId: string;
  let vatAccountId: string;

  // Fetch account IDs needed for journal tests
  beforeAll(async () => {
    const res = await global.testRequest
      .get(`/api/v1/finance/accounts?limit=20&branchId=${global.testBranchId}`)
      .set(authHeader());

    const accounts: Array<{ id: string; code: string }> =
      (res.body.data?.items ?? res.body.items ?? []);

    arAccountId  = accounts.find(a => a.code === '1100')?.id ?? '';
    revAccountId = accounts.find(a => a.code === '4000')?.id ?? '';
    vatAccountId = accounts.find(a => a.code === '2300')?.id ?? '';
  });

  // ── Journal entries ───────────────────────────────────────────

  describe('POST /api/v1/finance/journals', () => {
    it('accepts a balanced journal entry and returns 201', async () => {
      if (!arAccountId || !revAccountId) return;

      const amount = 500_000;
      const res = await global.testRequest
        .post('/api/v1/finance/journals')
        .set(authHeader())
        .send({
          branchId:    global.testBranchId,
          entryDate:   new Date().toISOString().split('T')[0],
          description: 'Integration test — balanced entry',
          entryType:   'MANUAL',
          lines: [
            { accountId: arAccountId,  debitAmount: amount, creditAmount: 0,      description: 'Dr AR' },
            { accountId: revAccountId, debitAmount: 0,      creditAmount: amount,  description: 'Cr Revenue' },
          ],
        })
        .expect(201);

      const entry = res.body.data ?? res.body;
      expect(entry).toMatchObject({ entryNo: expect.stringMatching(/^JNL-/) });
      expect(Math.abs(Number(entry.totalDebits) - Number(entry.totalCredits))).toBeLessThan(0.01);
    });

    it('rejects an unbalanced entry with 400', async () => {
      if (!arAccountId || !revAccountId) return;

      await global.testRequest
        .post('/api/v1/finance/journals')
        .set(authHeader())
        .send({
          branchId:    global.testBranchId,
          entryDate:   new Date().toISOString().split('T')[0],
          description: 'Unbalanced test',
          entryType:   'MANUAL',
          lines: [
            { accountId: arAccountId,  debitAmount: 100_000, creditAmount: 0,      description: 'Dr AR' },
            { accountId: revAccountId, debitAmount: 0,       creditAmount: 99_999, description: 'Cr Revenue — short' },
          ],
        })
        .expect(400);
    });

    it('rejects entry with zero total debits and credits with 400', async () => {
      if (!arAccountId || !revAccountId) return;

      await global.testRequest
        .post('/api/v1/finance/journals')
        .set(authHeader())
        .send({
          branchId:    global.testBranchId,
          entryDate:   new Date().toISOString().split('T')[0],
          description: 'Zero entry',
          entryType:   'MANUAL',
          lines: [
            { accountId: arAccountId,  debitAmount: 0, creditAmount: 0, description: 'Zero' },
            { accountId: revAccountId, debitAmount: 0, creditAmount: 0, description: 'Zero' },
          ],
        })
        .expect(400);
    });

    it('rejects posting to a locked accounting period with 400', async () => {
      if (!arAccountId || !revAccountId) return;

      await global.testRequest
        .post('/api/v1/finance/journals')
        .set(authHeader())
        .send({
          branchId:    global.testBranchId,
          entryDate:   '2020-01-15', // Far past — should be locked
          description: 'Locked period test',
          entryType:   'MANUAL',
          lines: [
            { accountId: arAccountId,  debitAmount: 50_000, creditAmount: 0,      description: 'Dr AR' },
            { accountId: revAccountId, debitAmount: 0,       creditAmount: 50_000, description: 'Cr Revenue' },
          ],
        })
        .expect(400);
    });
  });

  // ── Chart of accounts ─────────────────────────────────────────

  describe('GET /api/v1/finance/accounts', () => {
    it('returns paginated accounts list', async () => {
      const res = await global.testRequest
        .get(`/api/v1/finance/accounts?branchId=${global.testBranchId}&limit=10`)
        .set(authHeader())
        .expect(200);

      const body = res.body.data ?? res.body;
      expect(body.items ?? body).toBeInstanceOf(Array);
    });

    it('returned accounts have required fields', async () => {
      const res = await global.testRequest
        .get(`/api/v1/finance/accounts?branchId=${global.testBranchId}&limit=5`)
        .set(authHeader())
        .expect(200);

      const items: Array<{ id: string; code: string; name: string; accountType: string }> =
        res.body.data?.items ?? res.body.items ?? [];

      if (items.length > 0) {
        expect(items[0]).toMatchObject({
          id:          expect.any(String),
          code:        expect.any(String),
          name:        expect.any(String),
          accountType: expect.any(String),
        });
      }
    });
  });

  // ── Trial balance integrity ───────────────────────────────────

  describe('GET /api/v1/finance/reports/trial-balance', () => {
    it('trial balance is balanced (total debits = total credits)', async () => {
      // Get current period
      const periodsRes = await global.testRequest
        .get(`/api/v1/finance/periods?branchId=${global.testBranchId}`)
        .set(authHeader());

      const periods: Array<{ id: string; status: string }> =
        periodsRes.body.data?.items ?? periodsRes.body.items ?? [];

      const openPeriod = periods.find(p => p.status === 'OPEN');
      if (!openPeriod) return; // Skip if no open period

      const res = await global.testRequest
        .get(`/api/v1/finance/reports/trial-balance?branchId=${global.testBranchId}&periodId=${openPeriod.id}`)
        .set(authHeader())
        .expect(200);

      const tb = res.body.data ?? res.body;
      if (tb.totals) {
        expect(Math.abs(Number(tb.totals.closingDebit) - Number(tb.totals.closingCredit))).toBeLessThan(0.01);
        expect(tb.isBalanced).toBe(true);
      }
    });
  });
});
