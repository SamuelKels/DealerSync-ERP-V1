/**
 * AGCOMS DealerSync ERP — PdfService
 * Sprint 5: Section 7 — "PDF generation service"
 *           (invoices, purchase orders, job cards, payslips)
 *
 * Strategy:
 *   1. Compile an HTML template string with data interpolated
 *   2. Launch Puppeteer (headless Chrome) to render and print PDF
 *   3. Upload the PDF buffer to S3 under the correct context path
 *   4. Return the S3 key — callers save this to pdfS3Key on the entity
 *
 * Called by:
 *   - InvoiceService.generatePdf(invoiceId)
 *   - PurchaseOrderService.generatePdf(poId)
 *   - WorkshopService.generateJobCardPdf(jobCardId)
 *   - HrService.generatePayslipPdf(payrollLineId)
 */
import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import * as puppeteer from 'puppeteer';
import { format } from 'date-fns';
import { invoiceTemplate }     from './templates/invoice.template';
import { purchaseOrderTemplate } from './templates/purchase-order.template';
import { jobCardTemplate }      from './templates/job-card.template';
import { payslipTemplate }      from './templates/payslip.template';

export type PdfDocumentType = 'invoice' | 'purchase-order' | 'job-card' | 'payslip';

@Injectable()
export class PdfService {
  private readonly logger = new Logger(PdfService.name);
  private readonly s3: S3Client;
  private readonly bucket: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.bucket = this.config.get<string>('S3_ASSETS_BUCKET', '');
    this.s3 = new S3Client({
      region: this.config.get<string>('AWS_REGION', 'eu-west-1'),
      ...(this.config.get('NODE_ENV') !== 'production' && {
        endpoint:      this.config.get<string>('S3_ENDPOINT'),
        forcePathStyle: true,
      }),
    });
  }

  // ── Invoice PDF ────────────────────────────────────────────────

  async generateInvoicePdf(invoiceId: string): Promise<string> {
    const invoice = await this.prisma.invoice.findUnique({
      where: { id: invoiceId },
      include: {
        customer:      true,
        branch:        true,
        lines:         { include: { product: true } },
        salesOrder:    true,
        createdBy:     { select: { firstName: true, lastName: true } },
      },
    });
    if (!invoice) throw new NotFoundException(`Invoice ${invoiceId} not found`);

    const html = invoiceTemplate({
      invoiceNo:    invoice.invoiceNo,
      invoiceDate:  format(invoice.invoiceDate, 'dd MMMM yyyy'),
      dueDate:      invoice.dueDate ? format(invoice.dueDate, 'dd MMMM yyyy') : 'On receipt',
      customer: {
        name:        invoice.customer.name,
        address:     [invoice.customer.address, invoice.customer.city, invoice.customer.state].filter(Boolean).join(', '),
        email:       invoice.customer.email ?? '',
        phone:       invoice.customer.phone,
      },
      branch: {
        name:        invoice.branch.name,
        address:     invoice.branch.address ?? 'Abuja, Nigeria',
      },
      currency:     invoice.currency,
      lines:        invoice.lines.map(l => ({
        description: l.description,
        quantity:    Number(l.quantity),
        unitPrice:   Number(l.unitPrice),
        vatRate:     Number(l.vatRate),
        discount:    Number(l.discount),
        lineTotal:   Number(l.lineTotal),
      })),
      subtotal:     Number(invoice.subtotalAmount),
      vatAmount:    Number(invoice.vatAmount),
      totalAmount:  Number(invoice.totalAmount),
      amountPaid:   Number(invoice.amountPaid),
      balanceDue:   Number(invoice.totalAmount) - Number(invoice.amountPaid),
      status:       invoice.status,
      notes:        invoice.notes ?? '',
    });

    const fileKey = `invoices/${invoiceId}/invoice-${invoice.invoiceNo}.pdf`;
    await this.renderAndUpload(html, fileKey);

    // Update pdfS3Key on the invoice record
    await this.prisma.invoice.update({
      where: { id: invoiceId },
      data:  { pdfS3Key: fileKey },
    });

    this.logger.log(`Invoice PDF generated: ${fileKey}`);
    return fileKey;
  }

  // ── Purchase Order PDF ─────────────────────────────────────────

  async generatePurchaseOrderPdf(poId: string): Promise<string> {
    const po = await this.prisma.purchaseOrder.findUnique({
      where: { id: poId },
      include: {
        vendor:    true,
        branch:    true,
        lines:     { include: { product: { select: { name: true, sku: true } } } },
        createdBy: { select: { firstName: true, lastName: true } },
      },
    });
    if (!po) throw new NotFoundException(`Purchase order ${poId} not found`);

    const html = purchaseOrderTemplate({
      poNo:           po.poNo,
      poDate:         format(po.createdAt, 'dd MMMM yyyy'),
      expectedDelivery: po.expectedDelivery ? format(po.expectedDelivery, 'dd MMMM yyyy') : 'TBD',
      vendor: {
        name:    po.vendor.name,
        address: [po.vendor.address, po.vendor.city, po.vendor.state].filter(Boolean).join(', '),
        email:   po.vendor.email ?? '',
        phone:   po.vendor.phone,
      },
      branch:         { name: po.branch.name, address: po.branch.address ?? 'Abuja, Nigeria' },
      currency:       po.currency,
      lines:          po.lines.map(l => ({
        description: l.description,
        quantity:    Number(l.quantity),
        unitCost:    Number(l.unitCost),
        vatRate:     Number(l.vatRate),
        lineTotal:   Number(l.lineTotal),
      })),
      subtotal:       Number(po.subtotalAmount),
      vatAmount:      Number(po.vatAmount),
      totalAmount:    Number(po.totalAmount),
      paymentTerms:   `Net ${po.paymentTerms} days`,
      deliveryAddress: po.deliveryAddress ?? po.branch.address ?? '',
      createdBy:      `${po.createdBy.firstName} ${po.createdBy.lastName}`,
    });

    const fileKey = `purchase-orders/${poId}/po-${po.poNo}.pdf`;
    await this.renderAndUpload(html, fileKey);
    await this.prisma.purchaseOrder.update({ where: { id: poId }, data: { pdfS3Key: fileKey } });

    this.logger.log(`PO PDF generated: ${fileKey}`);
    return fileKey;
  }

  // ── Job Card PDF ───────────────────────────────────────────────

  async generateJobCardPdf(jobCardId: string): Promise<string> {
    const jc = await this.prisma.jobCard.findUnique({
      where: { id: jobCardId },
      include: {
        serviceRequest: { include: { customer: true } },
        assignedTechnician: { select: { firstName: true, lastName: true } },
        branch:          true,
        parts:           { include: { product: { select: { name: true, sku: true } } } },
        checklists:      true,
      },
    });
    if (!jc) throw new NotFoundException(`Job card ${jobCardId} not found`);

    const html = jobCardTemplate({
      jobCardNo:    jc.jobCardNo,
      openedDate:   format(jc.createdAt, 'dd MMMM yyyy'),
      closedDate:   jc.completedAt ? format(jc.completedAt, 'dd MMMM yyyy') : null,
      status:       jc.status,
      customer:     jc.serviceRequest.customer
        ? { name: jc.serviceRequest.customer.name, phone: jc.serviceRequest.customer.phone }
        : null,
      technician:   jc.assignedTechnician
        ? `${jc.assignedTechnician.firstName} ${jc.assignedTechnician.lastName}`
        : 'Unassigned',
      equipment: {
        description: jc.serviceRequest.equipmentDesc ?? '',
        make:        jc.serviceRequest.make ?? '',
        model:       jc.serviceRequest.model ?? '',
        serialNo:    jc.serviceRequest.serialNumber ?? '',
      },
      faultDescription: jc.serviceRequest.faultDescription,
      workPerformed:    jc.workPerformed ?? '',
      parts: jc.parts.map(p => ({
        sku:         p.product.sku,
        description: p.product.name,
        quantity:    Number(p.quantity),
        unitCost:    Number(p.unitCost),
        lineTotal:   Number(p.quantity) * Number(p.unitCost),
      })),
      labourHours:  Number(jc.labourHours ?? 0),
      labourRate:   Number(jc.labourRate ?? 0),
      partsTotal:   jc.parts.reduce((s, p) => s + Number(p.quantity) * Number(p.unitCost), 0),
      totalAmount:  Number(jc.totalAmount ?? 0),
      checklists:   jc.checklists.map(c => ({ item: c.item, completed: c.isCompleted })),
    });

    const fileKey = `job-cards/${jobCardId}/job-card-${jc.jobCardNo}.pdf`;
    await this.renderAndUpload(html, fileKey);
    await this.prisma.jobCard.update({ where: { id: jobCardId }, data: { pdfS3Key: fileKey } });

    this.logger.log(`Job card PDF generated: ${fileKey}`);
    return fileKey;
  }

  // ── Payslip PDF ────────────────────────────────────────────────

  async generatePayslipPdf(payrollLineId: string): Promise<string> {
    const line = await this.prisma.payrollLine.findUnique({
      where: { id: payrollLineId },
      include: {
        employee: { include: { department: true, branch: true } },
        payrollRun: true,
      },
    });
    if (!line) throw new NotFoundException(`Payroll line ${payrollLineId} not found`);

    const html = payslipTemplate({
      employeeNo:       line.employee.employeeNo,
      employeeName:     `${line.employee.firstName} ${line.employee.lastName}`,
      jobTitle:         line.employee.jobTitle ?? '',
      department:       line.employee.department?.name ?? '',
      branch:           line.employee.branch.name,
      payPeriod:        line.payrollRun.periodName,
      payDate:          format(line.payrollRun.payDate, 'dd MMMM yyyy'),
      grossSalary:      Number(line.grossSalary),
      basicSalary:      Number(line.basicSalary),
      housingAllowance: Number(line.housingAllowance),
      transportAllowance: Number(line.transportAllowance),
      otherAllowances:  Number(line.otherAllowances),
      cra:              Number(line.cra),
      taxableIncome:    Number(line.taxableIncome),
      paye:             Number(line.paye),
      employeePension:  Number(line.employeePension),
      employerPension:  Number(line.employerPension),
      nhf:              Number(line.nhf),
      wht:              Number(line.wht),
      totalDeductions:  Number(line.totalDeductions),
      netPay:           Number(line.netPay),
      bankName:         line.employee.bankName ?? '',
      bankAccountNo:    line.employee.bankAccountNo ?? '',
    });

    const fileKey = `payslips/${line.payrollRun.id}/${line.employee.employeeNo}-payslip.pdf`;
    await this.renderAndUpload(html, fileKey);
    await this.prisma.payrollLine.update({ where: { id: payrollLineId }, data: { pdfS3Key: fileKey } });

    this.logger.log(`Payslip PDF generated: ${fileKey}`);
    return fileKey;
  }

  // ── Core render engine ─────────────────────────────────────────

  private async renderAndUpload(html: string, fileKey: string): Promise<void> {
    let browser: puppeteer.Browser | null = null;
    try {
      browser = await puppeteer.launch({
        headless:       true,
        args: [
          '--no-sandbox',
          '--disable-setuid-sandbox',
          '--disable-dev-shm-usage',
          '--disable-gpu',
          '--single-process',
        ],
      });

      const page = await browser.newPage();
      await page.setContent(html, { waitUntil: 'networkidle0' });

      const pdfBuffer = await page.pdf({
        format:          'A4',
        printBackground: true,
        margin:          { top: '20mm', right: '15mm', bottom: '20mm', left: '15mm' },
      });

      await this.s3.send(new PutObjectCommand({
        Bucket:               this.bucket,
        Key:                  fileKey,
        Body:                 Buffer.from(pdfBuffer),
        ContentType:          'application/pdf',
        ServerSideEncryption: 'aws:kms',
        Metadata: {
          'generated-at': new Date().toISOString(),
          'generated-by': 'dealersync-pdf-service',
        },
      }));
    } finally {
      await browser?.close();
    }
  }
}
