/**
 * AGCOMS DealerSync ERP — Payslip PDF Template
 * Nigerian payroll: PAYE, Pension (PenCom), NHF, NSITF
 */
export function payslipTemplate(data: any): string {
  const totalDeductions = data.payeDeduction + data.pensionEmployee + data.nhfDeduction + data.nsitfDeduction + data.otherDeductions;
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<style>body{font-family:Arial,sans-serif;font-size:11px;margin:40px;color:#1A1A1A}
h1{color:#1A4D2E;font-size:18px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.section{margin:12px 0}.net{background:#1A4D2E;color:white;padding:12px;text-align:center;font-size:16px;font-weight:bold}
table{width:100%;border-collapse:collapse}td{padding:5px;border-bottom:1px solid #E5E7EB}
.right{text-align:right}</style></head>
<body>
<h1>AGCOMS International Trading Limited — PAYSLIP</h1>
<p><strong>${data.employeeName}</strong> | ${data.employeeNo} | ${data.department} | ${data.month} ${data.year}</p>
<div class="grid">
<div class="section"><strong>EARNINGS</strong>
<table>
<tr><td>Basic Salary</td><td class="right">₦${data.basicSalary.toLocaleString()}</td></tr>
<tr><td>Housing Allowance</td><td class="right">₦${data.housing.toLocaleString()}</td></tr>
<tr><td>Transport Allowance</td><td class="right">₦${data.transport.toLocaleString()}</td></tr>
<tr><td><strong>Gross Salary</strong></td><td class="right"><strong>₦${data.grossSalary.toLocaleString()}</strong></td></tr>
</table></div>
<div class="section"><strong>DEDUCTIONS</strong>
<table>
<tr><td>PAYE Tax</td><td class="right">₦${data.payeDeduction.toLocaleString()}</td></tr>
<tr><td>Pension (8%)</td><td class="right">₦${data.pensionEmployee.toLocaleString()}</td></tr>
<tr><td>NHF (2.5%)</td><td class="right">₦${data.nhfDeduction.toLocaleString()}</td></tr>
<tr><td>NSITF (1%)</td><td class="right">₦${data.nsitfDeduction.toLocaleString()}</td></tr>
<tr><td><strong>Total Deductions</strong></td><td class="right"><strong>₦${totalDeductions.toLocaleString()}</strong></td></tr>
</table></div>
</div>
<div class="net">NET PAY: ₦${data.netSalary.toLocaleString("en-NG",{minimumFractionDigits:2})}</div>
<p style="margin-top:12px;font-size:10px">Paid to: ${data.bankName} — ${data.accountNo}</p>
<p style="font-size:10px;color:#6B7280">This is a computer-generated payslip and requires no signature.</p>
</body></html>`;
}
