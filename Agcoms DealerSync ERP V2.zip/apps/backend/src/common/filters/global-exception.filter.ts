/**
 * AGCOMS DealerSync ERP — Global Exception Filter
 * Sprint 1 Fix: main.ts imports this but it was missing, crashing startup.
 *
 * Catches all unhandled exceptions, logs them with structured context,
 * and returns a consistent RFC-7807 Problem Details JSON response.
 * Never leaks stack traces to clients in production.
 */
import {
  ExceptionFilter, Catch, ArgumentsHost,
  HttpException, HttpStatus, Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { Prisma }            from '@prisma/client';

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx      = host.switchToHttp();
    const req      = ctx.getRequest<Request>();
    const res      = ctx.getResponse<Response>();
    const isProd   = process.env['NODE_ENV'] === 'production';

    let status  = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'An unexpected error occurred';
    let code    = 'INTERNAL_ERROR';

    if (exception instanceof HttpException) {
      status  = exception.getStatus();
      const body = exception.getResponse();
      message = typeof body === 'string' ? body : (body as any).message ?? message;
      code    = (body as any).error ?? `HTTP_${status}`;
    } else if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      switch (exception.code) {
        case 'P2002':
          status  = HttpStatus.CONFLICT;
          message = 'A record with this value already exists';
          code    = 'DUPLICATE_ENTRY';
          break;
        case 'P2025':
          status  = HttpStatus.NOT_FOUND;
          message = 'Record not found';
          code    = 'NOT_FOUND';
          break;
        case 'P2003':
          status  = HttpStatus.UNPROCESSABLE_ENTITY;
          message = 'Foreign key constraint violated';
          code    = 'FK_VIOLATION';
          break;
        default:
          status  = HttpStatus.UNPROCESSABLE_ENTITY;
          message = 'Database constraint violation';
          code    = `DB_${exception.code}`;
      }
    } else if (exception instanceof Prisma.PrismaClientValidationError) {
      status  = HttpStatus.BAD_REQUEST;
      message = 'Invalid data provided';
      code    = 'VALIDATION_ERROR';
    }

    const requestId = (req.headers['x-request-id'] as string) ?? crypto.randomUUID();

    this.logger.error({
      message:    `${req.method} ${req.url} → ${status}`,
      code,
      statusCode: status,
      requestId,
      userId:     (req as any).user?.sub,
      ip:         req.ip,
      userAgent:  req.headers['user-agent'],
      stack:      isProd ? undefined : (exception instanceof Error ? exception.stack : String(exception)),
    });

    res.status(status).json({
      error:     code,
      message,
      statusCode: status,
      path:      req.url,
      requestId,
      timestamp: new Date().toISOString(),
      ...(isProd ? {} : {
        detail: exception instanceof Error ? exception.message : String(exception),
      }),
    });
  }
}
