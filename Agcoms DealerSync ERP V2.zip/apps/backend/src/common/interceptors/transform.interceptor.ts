/**
 * AGCOMS DealerSync ERP — TransformInterceptor
 * Sprint 1 Fix: No response transformation — raw Prisma objects returned directly.
 *
 * Wraps every successful response in the standard envelope:
 *   { data: T, meta: { timestamp, requestId } }
 *
 * Skips wrapping if the response is already in envelope format (has .data property
 * at root with meta sibling), to avoid double-wrapping.
 */
import {
  Injectable, NestInterceptor, ExecutionContext,
  CallHandler, Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map, tap }  from 'rxjs/operators';
import { Request }   from 'express';

export interface ResponseEnvelope<T> {
  data:      T;
  meta: {
    timestamp:  string;
    requestId:  string;
    durationMs: number;
  };
}

@Injectable()
export class TransformInterceptor<T>
  implements NestInterceptor<T, ResponseEnvelope<T>> {

  intercept(
    context: ExecutionContext,
    next:    CallHandler<T>,
  ): Observable<ResponseEnvelope<T>> {
    const req       = context.switchToHttp().getRequest<Request>();
    const startedAt = Date.now();
    const requestId = (req.headers['x-request-id'] as string) ?? crypto.randomUUID();

    return next.handle().pipe(
      map(data => ({
        data,
        meta: {
          timestamp:  new Date().toISOString(),
          requestId,
          durationMs: Date.now() - startedAt,
        },
      })),
    );
  }
}

// ── LoggingInterceptor ─────────────────────────────────────────────────────
/**
 * Logs every HTTP request with method, path, status, duration, and user.
 * Output feeds into Winston → Loki for centralized structured logging (§9).
 */
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(ctx: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req     = ctx.switchToHttp().getRequest<Request>();
    const startAt = Date.now();

    return next.handle().pipe(
      tap(() => {
        const res      = ctx.switchToHttp().getResponse<{ statusCode: number }>();
        const duration = Date.now() - startAt;
        const userId   = (req as any).user?.sub ?? 'anon';

        this.logger.log({
          method:  req.method,
          path:    req.url,
          status:  res.statusCode,
          duration,
          userId,
          ip:      req.ip,
        });
      }),
    );
  }
}
