/**
 * AGCOMS DealerSync ERP — PiiMaskInterceptor
 * §5 Security Architecture: "field-level masking"
 *
 * Applied globally in main.ts as:
 *   app.useGlobalInterceptors(app.get(PiiMaskInterceptor));
 *
 * Algorithm (O(n) per response depth):
 *   1. Extract JWT payload from request context
 *   2. Build Set<string> of user's granted permissions
 *   3. Recursively traverse response body (object/array)
 *   4. For each key found in PII_FIELD_MAP:
 *      - If user holds requiredPermission → pass through unmasked
 *      - Else → replace value with maskWith sentinel
 *   5. SuperAdmin flag bypasses all masking
 *
 * Design decisions:
 *   - Masking happens on the response body AFTER the controller/service
 *     returns — business logic always sees real values
 *   - Arrays are traversed element-by-element so list endpoints mask
 *     correctly (e.g. payroll run lines)
 *   - Null / undefined values are passed through unmasked (nothing to hide)
 *   - Non-plain objects (Date, Buffer) are passed through unmasked
 *   - Depth limit of 10 prevents infinite recursion on circular references
 */

import {
  Injectable, NestInterceptor, ExecutionContext,
  CallHandler, Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PII_FIELD_MAP } from './pii-field.registry';
import type { JwtPayload } from '@agcoms/types';

const MAX_DEPTH = 10;

@Injectable()
export class PiiMaskInterceptor implements NestInterceptor {
  private readonly logger = new Logger(PiiMaskInterceptor.name);

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<{ user?: JwtPayload }>();
    const user    = request.user;

    // No authenticated user → mask everything (defensive)
    if (!user) {
      return next.handle().pipe(map(body => this.mask(body, new Set(), false, 0)));
    }

    // SuperAdmin sees all fields unmasked
    if (user.isSuperAdmin) {
      return next.handle();
    }

    const userPermissions = new Set<string>(user.permissions ?? []);
    return next.handle().pipe(
      map(body => this.mask(body, userPermissions, false, 0)),
    );
  }

  // ── Recursive masking engine ───────────────────────────────────

  private mask(
    value:           unknown,
    permissions:     Set<string>,
    isSuperAdmin:    boolean,
    depth:           number,
  ): unknown {
    if (depth > MAX_DEPTH) return value;
    if (value === null || value === undefined) return value;
    if (typeof value !== 'object') return value;
    if (value instanceof Date) return value;
    if (Buffer.isBuffer(value)) return value;

    // Array — recurse into each element
    if (Array.isArray(value)) {
      return value.map(item => this.mask(item, permissions, isSuperAdmin, depth + 1));
    }

    // Plain object — check each key against registry
    const masked: Record<string, unknown> = {};
    for (const [key, fieldValue] of Object.entries(value as Record<string, unknown>)) {
      const config = PII_FIELD_MAP.get(key);

      if (config && !permissions.has(config.requiredPermission)) {
        // User lacks the required permission — apply mask
        masked[key] = config.maskWith;
        this.logger.debug(
          `PII masked: field="${key}" permission="${config.requiredPermission}"`,
        );
      } else if (typeof fieldValue === 'object' && fieldValue !== null) {
        // Recurse into nested objects
        masked[key] = this.mask(fieldValue, permissions, isSuperAdmin, depth + 1);
      } else {
        masked[key] = fieldValue;
      }
    }

    return masked;
  }
}
