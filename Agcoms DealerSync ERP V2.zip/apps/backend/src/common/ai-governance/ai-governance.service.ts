/**
 * AGCOMS DealerSync ERP — AI Governance Enforcement Layer
 *
 * Master prompt AI Governance Rules (strictly enforced here):
 *
 * AI MAY:     summarize | recommend | draft | forecast | classify
 * AI MAY NOT: approve financial transactions | modify inventory autonomously
 *             alter accounting records | override approvals | bypass RBAC
 *
 * "All AI-generated operational actions require human approval."
 *
 * This module is the single enforcement point.  Every AI response is
 * wrapped through AiGovernanceService before being returned to callers.
 * No AI output ever directly mutates data — it always produces a
 * read-only advisory payload that a human must explicitly confirm.
 */

import { Injectable, ForbiddenException } from '@nestjs/common';
import { InjectPinoLogger, PinoLogger } from 'nestjs-pino';

// ── AI Action Types ────────────────────────────────────────────────────────

export type AllowedAiAction =
  | 'summarize'
  | 'recommend'
  | 'draft'
  | 'forecast'
  | 'classify'
  | 'analyze'
  | 'search'
  | 'predict';

export type ForbiddenAiAction =
  | 'approve_transaction'
  | 'modify_inventory'
  | 'alter_accounting'
  | 'override_approval'
  | 'bypass_rbac'
  | 'post_journal'
  | 'approve_po'
  | 'approve_payroll'
  | 'close_period'
  | 'lock_period'
  | 'settle_invoice'
  | 'close_job_card';

// ── Advisory payload wrapper ───────────────────────────────────────────────
// AI outputs are always advisory — never operational.
// The human_action_required flag is ALWAYS true for recommendations
// that would affect data if acted upon.

export interface AiAdvisory<T = unknown> {
  /** The AI-generated content */
  advisory: T;
  /** Always true for operational contexts — human must confirm before action */
  human_action_required: boolean;
  /** What the human should do with this output */
  suggested_human_action: string;
  /** Governance metadata */
  governance: {
    ai_action: AllowedAiAction;
    model: string;
    generated_at: string;
    disclaimer: string;
  };
}

// ── Governance Service ─────────────────────────────────────────────────────

@Injectable()
export class AiGovernanceService {
  private readonly DISCLAIMER =
    'This is an AI-generated advisory. All operational actions based on this output ' +
    'require explicit human review and approval before execution. ' +
    'AGCOMS DealerSync AI may not approve transactions, alter records, or override approvals.';

  constructor(
    @InjectPinoLogger(AiGovernanceService.name) private readonly logger: PinoLogger,
  ) {}

  /**
   * Wraps any AI output in a governance-compliant advisory envelope.
   * Use this for every AI response before returning to controller.
   */
  wrap<T>(
    action: AllowedAiAction,
    data: T,
    suggestedHumanAction: string,
    model = 'claude-sonnet-4-5',
  ): AiAdvisory<T> {
    this.logger.debug({ action }, 'AI advisory generated');
    return {
      advisory: data,
      human_action_required: true,
      suggested_human_action: suggestedHumanAction,
      governance: {
        ai_action: action,
        model,
        generated_at: new Date().toISOString(),
        disclaimer: this.DISCLAIMER,
      },
    };
  }

  /**
   * Hard block on forbidden AI actions.
   * Called defensively in every service method that could be AI-triggered.
   */
  assertNotForbidden(attemptedAction: ForbiddenAiAction | string, callerContext: string): void {
    const forbidden: ForbiddenAiAction[] = [
      'approve_transaction', 'modify_inventory', 'alter_accounting',
      'override_approval', 'bypass_rbac', 'post_journal', 'approve_po',
      'approve_payroll', 'close_period', 'lock_period', 'settle_invoice', 'close_job_card',
    ];
    if (forbidden.includes(attemptedAction as ForbiddenAiAction)) {
      this.logger.warn({ attemptedAction, callerContext }, 'AI governance violation blocked');
      throw new ForbiddenException(
        `AI governance violation: action "${attemptedAction}" requires human authorisation. ` +
        `Context: ${callerContext}. This action has been blocked and logged.`,
      );
    }
  }

  /** Log every AI interaction for audit trail */
  auditAiCall(params: {
    action: AllowedAiAction;
    userId: string;
    module: string;
    prompt?: string;
    tokensUsed?: number;
  }): void {
    this.logger.info(
      { ...params, prompt: params.prompt ? '[LOGGED]' : undefined },
      'AI interaction audit',
    );
  }
}
