/**
 * AGCOMS DealerSync ERP — @CurrentUser Decorator
 * Sprint 1 Fix: No @CurrentUser decorator — controllers couldn't access auth user.
 *
 * Usage:
 *   @Get('profile')
 *   @UseGuards(JwtAuthGuard)
 *   getProfile(@CurrentUser() user: JwtPayload) { ... }
 */
import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import type { JwtPayload } from '@agcoms/types';

export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): JwtPayload => {
    const request = ctx.switchToHttp().getRequest<{ user: JwtPayload }>();
    return request.user;
  },
);
