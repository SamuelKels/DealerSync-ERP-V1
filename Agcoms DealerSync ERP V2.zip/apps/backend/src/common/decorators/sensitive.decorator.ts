/**
 * AGCOMS DealerSync ERP — @Sensitive field decorator
 * Marks DTO/entity fields as sensitive for PII masking.
 * Sprint 1 / R1: PII masking interceptor.
 *
 * Usage:
 *   class Employee {
 *     @Sensitive('salary')    grossSalary: number;
 *     @Sensitive('nin')       nin: string;
 *   }
 */
import 'reflect-metadata';

export const SENSITIVE_META_KEY = 'agcoms:sensitive';

export type SensitiveFieldType =
  | 'salary' | 'bank_account' | 'nin' | 'bvn' | 'phone'
  | 'email' | 'address' | 'password' | 'token' | 'secret' | 'default';

/** Registry mapping class name → sensitive field names */
const sensitiveRegistry = new Map<string, Set<string>>();

export function Sensitive(fieldType: SensitiveFieldType = 'default'): PropertyDecorator {
  return (target: object, propertyKey: string | symbol): void => {
    const className = target.constructor.name;
    if (!sensitiveRegistry.has(className)) {
      sensitiveRegistry.set(className, new Set());
    }
    sensitiveRegistry.get(className)!.add(String(propertyKey));
    Reflect.defineMetadata(SENSITIVE_META_KEY, fieldType, target, propertyKey);
  };
}

export function getSensitiveFields(className: string): Set<string> {
  return sensitiveRegistry.get(className) ?? new Set();
}

export function isSensitive(target: object, propertyKey: string): boolean {
  return Reflect.hasMetadata(SENSITIVE_META_KEY, target, propertyKey);
}

export function getSensitiveType(target: object, propertyKey: string): SensitiveFieldType {
  return Reflect.getMetadata(SENSITIVE_META_KEY, target, propertyKey) ?? 'default';
}

/** Pre-registered sensitive field names for the HR domain (no decorator needed) */
export const HR_SENSITIVE_FIELDS = new Set([
  'grossSalary', 'basicSalary', 'netSalary', 'allowances', 'deductions',
  'bankAccountNo', 'bankName', 'bvn', 'nin', 'pensionPin', 'payeNumber',
  'nextOfKinPhone', 'emergencyContact',
]);
