import { Injectable, type OnModuleDestroy, type OnModuleInit, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Singleton Prisma client. Exposes lifecycle hooks aligned with NestJS so the
 * connection pool is closed cleanly during graceful shutdown.
 *
 * Slow-query logging satisfies Section 6: PERFORMANCE OPTIMIZATION
 * ("slow query monitoring").
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);
  private static readonly SLOW_QUERY_MS = 250;

  constructor() {
    super({
      log: [
        { emit: 'event', level: 'query' },
        { emit: 'event', level: 'warn' },
        { emit: 'event', level: 'error' },
      ],
      errorFormat: 'minimal',
    });

    this.$on('warn' as never, (e: { message: string }) => {
      this.logger.warn(e.message);
    });
    this.$on('error' as never, (e: { message: string }) => {
      this.logger.error(e.message);
    });
    this.$on('query' as never, (e: { duration: number; query: string; params: string }) => {
      if (e.duration >= PrismaService.SLOW_QUERY_MS) {
        this.logger.warn(`slow_query duration=${e.duration}ms query=${e.query}`);
      }
    });
  }

  async onModuleInit(): Promise<void> {
    await this.$connect();
    this.logger.log('Prisma connected');
  }

  async onModuleDestroy(): Promise<void> {
    await this.$disconnect();
  }
}
