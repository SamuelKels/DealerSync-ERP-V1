// Type shim for 'bull' — actual types come from @types/bull
// This file resolves the TS2688 "Cannot find type definition file for 'bull'" error
// in pnpm monorepo environments where @types/bull is hoisted to root node_modules.
export * from '@nestjs/bull';
