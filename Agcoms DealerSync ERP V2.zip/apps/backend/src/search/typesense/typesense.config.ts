/**
 * AGCOMS DealerSync ERP — Typesense Configuration
 * Collection names and config used by TypesenseService.
 */
import { ConfigService } from '@nestjs/config';

// Collection names — used as constants throughout the search module
export const COLLECTION_PRODUCTS  = 'products';
export const COLLECTION_CUSTOMERS = 'customers';
export const COLLECTION_VENDORS   = 'vendors';
export const COLLECTION_EMPLOYEES = 'employees';

export const TYPESENSE_CLIENT = 'TYPESENSE_CLIENT';

export interface TypesenseConfig {
  host:     string;
  port:     number;
  protocol: 'http' | 'https';
  apiKey:   string;
}

export function getTypesenseConfig(config: ConfigService): TypesenseConfig {
  return {
    host:     config.get<string>('TYPESENSE_HOST', 'localhost'),
    port:     config.get<number>('TYPESENSE_PORT', 8108),
    protocol: config.get<string>('TYPESENSE_PROTOCOL', 'http') as 'http' | 'https',
    apiKey:   config.get<string>('TYPESENSE_API_KEY', 'dealersync_typesense_dev_key'),
  };
}
