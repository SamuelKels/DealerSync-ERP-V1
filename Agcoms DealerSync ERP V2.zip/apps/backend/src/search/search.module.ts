import { Module }            from '@nestjs/common';
import { ConfigService }     from '@nestjs/config';
import * as Typesense        from 'typesense';
import { TypesenseService }  from './typesense/typesense.service';
import { SearchSyncService } from './sync/search-sync.service';
import { TYPESENSE_CLIENT, getTypesenseConfig } from './typesense/typesense.config';

@Module({
  providers: [
    {
      provide: TYPESENSE_CLIENT,
      inject:  [ConfigService],
      useFactory: (config: ConfigService) => {
        const cfg = getTypesenseConfig(config);
        return new Typesense.Client({
          nodes: [{ host: cfg.host, port: cfg.port, protocol: cfg.protocol }],
          apiKey: cfg.apiKey,
          connectionTimeoutSeconds: 5,
        });
      },
    },
    TypesenseService,
    SearchSyncService,
  ],
  exports: [TypesenseService],
})
export class SearchModule {}
