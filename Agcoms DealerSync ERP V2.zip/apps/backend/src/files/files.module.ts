import { Module }       from '@nestjs/common';
import { BullModule }   from '@nestjs/bull';
import { FileService }  from './file.service';

@Module({
  imports:   [BullModule.registerQueue({ name: 'malware-scan' })],
  providers: [FileService],
  exports:   [FileService],
})
export class FilesModule {}
