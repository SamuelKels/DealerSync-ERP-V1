/**
 * AGCOMS DealerSync ERP — ReadModelService
 * Sprint 4 / S4-B: CQRS read model — separates expensive OLAP reporting queries
 * from transactional OLTP writes.
 *
 * Problem solved:
 *   ERP reporting queries (AR aging, trial balance, KPI aggregations, NADF compliance)
 *   are expensive multi-table scans competing with invoice creation and journal posting
 *   on the same PgBouncer connection pool. Under load, reports slow down writes and
 *   vice versa — a classic OLTP/OLAP contention problem.
 *
 * Solution:
 *   A second PrismaClient pointed at DATABASE_URL_READ_REPLICA (or the primary if no
 *   replica is configured). All /reports/* and analytics endpoints inject this service
 *   instead of PrismaService. In production (Stage 2+), DATABASE_URL_READ_REPLICA
 *   points to the RDS read replica with its own PgBouncer pool.
 *
 * Connection pool configuration (§6 Performance):
 *   Write pool (PrismaService):     max 10 connections, transaction mode
 *   Read pool  (ReadModelService):  max 25 connections, session mode for long scans
 *
 * In development/staging without a replica, both pools point to primary —
 * this is still beneficial because it separates pool exhaustion domains.
 */
import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { PrismaClient }  from '@prisma/client';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ReadModelService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(ReadModelService.name);
  private readonly client: PrismaClient;

  constructor(private readonly config: ConfigService) {
    // Use read replica URL if configured, fall back to primary
    const readUrl = this.config.get<string>('DATABASE_URL_READ_REPLICA')
                 ?? this.config.getOrThrow<string>('DATABASE_URL');

    this.client = new PrismaClient({
      datasources: { db: { url: readUrl } },
      log: [
        { level: 'warn',  emit: 'event' },
        { level: 'error', emit: 'event' },
      ],
    });

    // Log slow read queries (> 2s) for observability (§9)
    (this.client as any).$on('query', (e: any) => {
      if (e.duration > 2000) {
        this.logger.warn(`Slow read query: ${e.duration}ms — ${e.query.slice(0, 120)}`);
      }
    });
  }

  async onModuleInit() {
    await this.client.$connect();
    this.logger.log('Read model Prisma client connected');
  }

  async onModuleDestroy() {
    await this.client.$disconnect();
  }

  // ── Expose the read-only Prisma client ─────────────────────────────────

  get db(): PrismaClient {
    return this.client;
  }

  // ── Pre-built read queries for the 4 core reports ─────────────────────

  /**
   * AR Aging report — groups outstanding invoices into buckets.
   * This is the most common heavy read in any ERP — runs on read replica.
   */
  async getArAging(branchId: string): Promise<{
    current:    { count: number; amount: number };
    days1_30:   { count: number; amount: number };
    days31_60:  { count: number; amount: number };
    days61_90:  { count: number; amount: number };
    over90:     { count: number; amount: number };
    total:      { count: number; amount: number };
    lines:      Array<{
      customerId: string; customerName: string; invoiceNo: string;
      dueDate: Date | null; outstanding: number; agingBucket: string;
    }>;
  }> {
    const now = new Date();
    const invoices = await this.client.invoice.findMany({
      where: {
        branchId,
        status: { in: ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'] },
      },
      include: { customer: { select: { id: true, name: true } } },
      orderBy: { dueDate: 'asc' },
    });

    const buckets = {
      current:   { count: 0, amount: 0 },
      days1_30:  { count: 0, amount: 0 },
      days31_60: { count: 0, amount: 0 },
      days61_90: { count: 0, amount: 0 },
      over90:    { count: 0, amount: 0 },
      total:     { count: 0, amount: 0 },
    };

    const lines = invoices.map(inv => {
      const outstanding = Number(inv.totalAmount) - Number(inv.amountPaid);
      const daysOverdue = inv.dueDate
        ? Math.max(0, Math.floor((now.getTime() - inv.dueDate.getTime()) / 86400_000))
        : 0;

      let bucket: keyof typeof buckets;
      let bucketLabel: string;
      if (daysOverdue === 0)       { bucket = 'current';   bucketLabel = 'Current'; }
      else if (daysOverdue <= 30)  { bucket = 'days1_30';  bucketLabel = '1–30 days'; }
      else if (daysOverdue <= 60)  { bucket = 'days31_60'; bucketLabel = '31–60 days'; }
      else if (daysOverdue <= 90)  { bucket = 'days61_90'; bucketLabel = '61–90 days'; }
      else                         { bucket = 'over90';    bucketLabel = 'Over 90 days'; }

      buckets[bucket].count++;
      buckets[bucket].amount += outstanding;
      buckets.total.count++;
      buckets.total.amount += outstanding;

      return {
        customerId:  inv.customer.id,
        customerName: inv.customer.name,
        invoiceNo:   inv.invoiceNo,
        dueDate:     inv.dueDate,
        outstanding,
        agingBucket: bucketLabel,
        daysOverdue,
      };
    });

    return { ...buckets, lines };
  }

  /**
   * KPI summary for dashboard — aggregated across the branch.
   * Replaces multiple individual queries with one pass.
   */
  async getBranchKpis(branchId: string, periodStart: Date, periodEnd: Date) {
    const [revenue, outstanding, quotations, customers, inventory] = await Promise.all([
      // Revenue in period
      this.client.invoice.aggregate({
        where:  { branchId, status: 'PAID', createdAt: { gte: periodStart, lte: periodEnd } },
        _sum:   { amountPaid: true },
        _count: { id: true },
      }),
      // Outstanding invoices
      this.client.invoice.aggregate({
        where: { branchId, status: { in: ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'] } },
        _sum:  { totalAmount: true, amountPaid: true },
        _count: { id: true },
      }),
      // Quotation conversion rate
      this.client.quotation.groupBy({
        by:    ['status'],
        where: { branchId, createdAt: { gte: periodStart, lte: periodEnd } },
        _count: { id: true },
      }),
      // Active customers (had at least 1 transaction in period)
      this.client.customer.count({
        where: { branchId, status: 'ACTIVE', invoices: { some: { createdAt: { gte: periodStart, lte: periodEnd } } } },
      }),
      // Low stock alerts
      this.client.stockItem.count({
        where: { product: { branchId }, status: 'AVAILABLE', quantity: { lte: 2 } },
      }),
    ]);

    const totalQuotes  = quotations.reduce((s, q) => s + q._count.id, 0);
    const wonQuotes    = quotations.find(q => ['ACCEPTED', 'CONVERTED'].includes(q.status))?._count.id ?? 0;

    return {
      revenue: {
        total:     Number(revenue._sum.amountPaid ?? 0),
        invoices:  revenue._count.id,
      },
      outstanding: {
        total:     Number(outstanding._sum.totalAmount ?? 0) - Number(outstanding._sum.amountPaid ?? 0),
        invoices:  outstanding._count.id,
      },
      sales: {
        quotations:      totalQuotes,
        conversionRate:  totalQuotes > 0 ? Math.round((wonQuotes / totalQuotes) * 1000) / 10 : 0,
        activeCustomers: customers,
      },
      inventory: { lowStockAlerts: inventory },
      period: { start: periodStart, end: periodEnd },
    };
  }

  /**
   * Trial balance — reads all posted journal lines grouped by account.
   * This is the heaviest single query in the Finance module.
   */
  async getTrialBalance(branchId: string, periodId: string) {
    const lines = await this.client.journalLine.groupBy({
      by:    ['accountId'],
      where: { journalEntry: { branchId, periodId, status: 'POSTED' } },
      _sum:  { debitAmount: true, creditAmount: true },
    });

    const accountIds = lines.map(l => l.accountId);
    const accounts   = await this.client.account.findMany({
      where:  { id: { in: accountIds } },
      select: { id: true, code: true, name: true, accountType: true, normalBalance: true },
    });
    const accountMap = new Map<string, { id: string; code: string; name: string; accountType: string; normalBalance: string }>(accounts.map(a => [a.id, a as any]));

    const entries = lines.map(l => {
      const acct = accountMap.get(l.accountId)!;
      const dr   = Number(l._sum.debitAmount  ?? 0);
      const cr   = Number(l._sum.creditAmount ?? 0);
      return {
        accountId:    l.accountId,
        accountCode:  acct.code,
        accountName:  acct.name,
        accountType:  acct.accountType,
        closingDebit: dr,
        closingCredit: cr,
        netBalance:   dr - cr,
      };
    }).sort((a, b) => a.accountCode.localeCompare(b.accountCode));

    const totalDebit  = entries.reduce((s, e) => s + e.closingDebit,  0);
    const totalCredit = entries.reduce((s, e) => s + e.closingCredit, 0);
    const isBalanced  = Math.abs(totalDebit - totalCredit) < 0.01;

    return { entries, totals: { closingDebit: totalDebit, closingCredit: totalCredit }, isBalanced };
  }
}
