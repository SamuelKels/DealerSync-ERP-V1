import { Module }          from '@nestjs/common';
import { JwtModule }       from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { RealtimeGateway } from './realtime.gateway';
import { SecretsModule }   from '../secrets/secrets.module';

@Module({
  imports: [
    JwtModule.registerAsync({
      imports:    [ConfigModule],
      inject:     [ConfigService],
      useFactory: (cfg: ConfigService) => ({
        secret: cfg.get<string>('JWT_PUBLIC_KEY') ?? cfg.get<string>('JWT_SECRET') ?? 'fallback',
      }),
    }),
    SecretsModule,
  ],
  providers: [RealtimeGateway],
  exports:   [RealtimeGateway],
})
export class GatewayModule {}
