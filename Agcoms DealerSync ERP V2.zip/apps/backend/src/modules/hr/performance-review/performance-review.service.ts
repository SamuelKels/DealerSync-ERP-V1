/**
 * AGCOMS DealerSync ERP — PerformanceReviewService
 * Sprint 5: Section 7 Module 9 — "performance reviews"
 *
 * Workflow:
 *   DRAFT → SELF_ASSESSMENT → MANAGER_REVIEW → APPROVED → ACKNOWLEDGED
 *
 * Scoring:
 *   - 5 KPI categories (Quality, Timeliness, Teamwork, Skills, Goals)
 *   - Each scored 1–5 (1=Poor, 3=Meets, 5=Exceeds)
 *   - Weighted overall score computed
 *   - Rating mapped: <2=POOR, <3=NEEDS_IMPROVEMENT, <4=MEETS, <5=EXCEEDS, 5=OUTSTANDING
 */
import {
  Injectable, Logger, NotFoundException, BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { AuditService } from '../../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { JwtPayload } from '@agcoms/types';

export interface KpiScore {
  category:   string;
  score:      number;  // 1–5
  comment?:   string;
}

export interface CreateReviewDto {
  employeeId:   string;
  branchId:     string;
  reviewPeriod: string;  // e.g. 'Q1 2025' or '2025'
  reviewType:   'QUARTERLY' | 'ANNUAL' | 'PROBATION' | 'SPECIAL';
  dueDate:      Date;
}

export interface SubmitSelfAssessmentDto {
  kpiScores:       KpiScore[];
  achievements:    string;
  challenges:      string;
  developmentGoals: string;
}

export interface SubmitManagerReviewDto {
  kpiScores:          KpiScore[];
  managerComment:     string;
  overallRating:      string;
  promotionRecommended: boolean;
  salaryIncrement?:   number;
  developmentPlan?:   string;
}

const RATING_SCALE: { min: number; label: string }[] = [
  { min: 4.5, label: 'OUTSTANDING'       },
  { min: 3.5, label: 'EXCEEDS_EXPECTATIONS' },
  { min: 2.5, label: 'MEETS_EXPECTATIONS'  },
  { min: 1.5, label: 'NEEDS_IMPROVEMENT'   },
  { min: 0,   label: 'POOR'               },
];

function computeOverallScore(kpiScores: KpiScore[]): { score: number; rating: string } {
  if (kpiScores.length === 0) return { score: 0, rating: 'POOR' };
  const avg   = kpiScores.reduce((s, k) => s + k.score, 0) / kpiScores.length;
  const score = Math.round(avg * 10) / 10;
  const rating = (RATING_SCALE.find(r => score >= r.min) ?? RATING_SCALE.at(-1)!).label;
  return { score, rating };
}

@Injectable()
export class PerformanceReviewService {
  private readonly logger = new Logger(PerformanceReviewService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ── 1. Create review cycle ─────────────────────────────────────

  async createReview(dto: CreateReviewDto, actor: JwtPayload) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: dto.employeeId, branchId: dto.branchId, isDeleted: false },
      include: { reportsTo: { select: { id: true, firstName: true, lastName: true } } },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    // Check no active review for this period
    const existing = await this.prisma.performanceReview.findFirst({
      where: {
        employeeId:   dto.employeeId,
        reviewPeriod: dto.reviewPeriod,
        status:       { notIn: ['CANCELLED', 'ACKNOWLEDGED'] },
      },
    });
    if (existing) {
      throw new BadRequestException(
        `A ${dto.reviewType} review for ${dto.reviewPeriod} already exists for this employee`
      );
    }

    const reviewNo = await this.generateReviewNo(dto.branchId);
    const review   = await this.prisma.performanceReview.create({
      data: {
        reviewNo,
        employeeId:   dto.employeeId,
        reviewerId:   employee.reportsToId ?? actor.sub,
        branchId:     dto.branchId,
        reviewPeriod: dto.reviewPeriod,
        reviewType:   dto.reviewType,
        status:       'DRAFT',
        dueDate:      dto.dueDate,
        createdById:  actor.sub,
      },
      include: { employee: { select: { firstName: true, lastName: true, employeeNo: true } } },
    });

    // Notify employee
    this.events.emit('performance_review.created', {
      reviewId:   review.id,
      employeeId: dto.employeeId,
      period:     dto.reviewPeriod,
    });

    this.logger.log(`Performance review ${reviewNo} created for ${employee.firstName} ${employee.lastName}`);
    return review;
  }

  // ── 2. Employee self-assessment ────────────────────────────────

  async submitSelfAssessment(reviewId: string, dto: SubmitSelfAssessmentDto, actor: JwtPayload) {
    const review = await this.getReview(reviewId);
    if (review.status !== 'DRAFT' && review.status !== 'SELF_ASSESSMENT') {
      throw new BadRequestException('Self-assessment can only be submitted for DRAFT or SELF_ASSESSMENT reviews');
    }
    if (review.employeeId !== actor.sub && !actor.isSuperAdmin) {
      throw new BadRequestException('Only the reviewed employee can submit the self-assessment');
    }

    const { score: selfScore, rating: selfRating } = computeOverallScore(dto.kpiScores);

    await this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: {
        status:          'SELF_ASSESSMENT',
        selfKpiScores:   JSON.stringify(dto.kpiScores),
        selfScore,
        selfRating,
        achievements:    dto.achievements,
        challenges:      dto.challenges,
        developmentGoals: dto.developmentGoals,
        selfSubmittedAt: new Date(),
      },
    });

    // Notify reviewer
    this.events.emit('performance_review.self_submitted', { reviewId, reviewerId: review.reviewerId });

    this.logger.log(`Self-assessment submitted for review ${review.reviewNo}`);
    return { reviewId, selfScore, selfRating };
  }

  // ── 3. Manager review ─────────────────────────────────────────

  async submitManagerReview(reviewId: string, dto: SubmitManagerReviewDto, actor: JwtPayload) {
    const review = await this.getReview(reviewId);
    if (!['SELF_ASSESSMENT', 'MANAGER_REVIEW'].includes(review.status)) {
      throw new BadRequestException('Manager review can only be submitted after self-assessment');
    }

    const { score: managerScore } = computeOverallScore(dto.kpiScores);

    await this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: {
        status:               'MANAGER_REVIEW',
        managerKpiScores:     JSON.stringify(dto.kpiScores),
        managerScore,
        overallRating:        dto.overallRating,
        managerComment:       dto.managerComment,
        promotionRecommended: dto.promotionRecommended,
        salaryIncrement:      dto.salaryIncrement,
        developmentPlan:      dto.developmentPlan,
        managerReviewedAt:    new Date(),
        reviewedById:         actor.sub,
      },
    });

    this.logger.log(`Manager review submitted for ${review.reviewNo}`);
    return { reviewId, managerScore, overallRating: dto.overallRating };
  }

  // ── 4. Approve review (HR / super_admin) ──────────────────────

  async approveReview(reviewId: string, actor: JwtPayload) {
    const review = await this.getReview(reviewId);
    if (review.status !== 'MANAGER_REVIEW') {
      throw new BadRequestException('Only MANAGER_REVIEW status reviews can be approved');
    }

    await this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: { status: 'APPROVED', approvedAt: new Date(), approvedById: actor.sub },
    });

    // Notify employee to acknowledge
    this.events.emit('performance_review.approved', {
      reviewId,
      employeeId:    review.employeeId,
      overallRating: review.overallRating,
    });

    this.logger.log(`Performance review ${review.reviewNo} approved`);
    return { reviewId, status: 'APPROVED' };
  }

  // ── 5. Employee acknowledges the final review ─────────────────

  async acknowledgeReview(reviewId: string, actor: JwtPayload) {
    const review = await this.getReview(reviewId);
    if (review.status !== 'APPROVED') throw new BadRequestException('Only APPROVED reviews can be acknowledged');
    if (review.employeeId !== actor.sub) throw new BadRequestException('Only the reviewed employee can acknowledge');

    await this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: { status: 'ACKNOWLEDGED', acknowledgedAt: new Date() },
    });

    this.logger.log(`Review ${review.reviewNo} acknowledged by employee`);
    return { reviewId, status: 'ACKNOWLEDGED' };
  }

  // ── List and get ──────────────────────────────────────────────

  async listReviews(params: {
    branchId: string; employeeId?: string; reviewerId?: string;
    status?: string; period?: string; page?: number; limit?: number;
  }) {
    const { branchId, employeeId, reviewerId, status, period, page = 1, limit = 20 } = params;
    const where: any = { branchId, isDeleted: false };
    if (employeeId) where.employeeId = employeeId;
    if (reviewerId) where.reviewerId = reviewerId;
    if (status)     where.status     = status;
    if (period)     where.reviewPeriod = { contains: period };

    const [items, total] = await Promise.all([
      this.prisma.performanceReview.findMany({
        where, skip: (page - 1) * limit, take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          employee: { select: { firstName: true, lastName: true, employeeNo: true, jobTitle: true } },
          reviewer: { select: { firstName: true, lastName: true } },
        },
      }),
      this.prisma.performanceReview.count({ where }),
    ]);

    return { items, total, hasMore: page * limit < total };
  }

  private async getReview(id: string) {
    const r = await this.prisma.performanceReview.findUnique({ where: { id } });
    if (!r) throw new NotFoundException('Performance review not found');
    return r;
  }

  private async generateReviewNo(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const count  = await this.prisma.performanceReview.count({ where: { branchId } });
    return `PRA-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  }
}
