/**
 * AGCOMS DealerSync ERP — HR DTOs
 * Sprint 2 Fix S2-06: No DTOs for employee management, payroll, or leave.
 * Nigerian payroll requires validated PAYE, NHF, and pension inputs.
 */
import {
  IsString, IsOptional, IsEnum, IsNumber, IsDate,
  IsEmail, IsUUID, Min, MaxLength, IsDateString, IsBoolean,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export enum EmploymentType { FULL_TIME = 'FULL_TIME', PART_TIME = 'PART_TIME', CONTRACT = 'CONTRACT', INTERN = 'INTERN' }
export enum LeaveType { ANNUAL = 'ANNUAL', SICK = 'SICK', MATERNITY = 'MATERNITY', PATERNITY = 'PATERNITY', STUDY = 'STUDY', UNPAID = 'UNPAID' }

export class CreateEmployeeDto {
  @ApiProperty()
  @IsString()
  firstName: string;

  @ApiProperty()
  @IsString()
  lastName: string;

  @ApiProperty()
  @IsEmail()
  email: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  phone?: string;

  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty()
  @IsString()
  jobTitle: string;

  @ApiProperty()
  @IsString()
  department: string;

  @ApiProperty({ enum: EmploymentType })
  @IsEnum(EmploymentType)
  employmentType: EmploymentType;

  @ApiProperty({ example: '2025-01-15' })
  @IsDateString()
  hireDate: string;

  @ApiProperty({ description: 'Gross monthly salary in NGN', minimum: 0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  grossSalary: number;

  @ApiPropertyOptional({ description: 'Basic salary component (typically 60% of gross)' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  basicSalary?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  bankAccountNo?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  bankName?: string;

  @ApiPropertyOptional({ description: 'National Identity Number' })
  @IsOptional()
  @IsString()
  nin?: string;

  @ApiPropertyOptional({ description: 'PenCom Pension Fund Administrator PIN' })
  @IsOptional()
  @IsString()
  pensionPin?: string;
}

export class UpdateEmployeeDto extends PartialType(CreateEmployeeDto) {}

export class CreateLeaveRequestDto {
  @ApiProperty()
  @IsUUID()
  employeeId: string;

  @ApiProperty({ enum: LeaveType })
  @IsEnum(LeaveType)
  leaveType: LeaveType;

  @ApiProperty({ example: '2025-02-01' })
  @IsDateString()
  startDate: string;

  @ApiProperty({ example: '2025-02-10' })
  @IsDateString()
  endDate: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  reason?: string;
}
