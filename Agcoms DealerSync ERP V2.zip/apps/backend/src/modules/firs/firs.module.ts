import { Module }         from '@nestjs/common';
import { BullModule }     from '@nestjs/bull';
import { FirsVatService } from './firs-vat.service';
import { FirsController } from './firs.controller';
import { FIRS_FILING_QUEUE } from './firs-vat.service';

@Module({
  imports:   [BullModule.registerQueue({ name: FIRS_FILING_QUEUE })],
  controllers: [FirsController],
  providers: [FirsVatService],
  exports:   [FirsVatService],
})
export class FirsModule {}
