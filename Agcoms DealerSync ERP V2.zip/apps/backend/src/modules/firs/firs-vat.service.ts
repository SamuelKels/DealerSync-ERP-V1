/**
 * AGCOMS DealerSync ERP — FirsVatService
 * Sprint 5 / S5-A: FIRS (Federal Inland Revenue Service) tax filing automation.
 *
 * Nigerian tax compliance:
 *   VAT: 7.5% per Finance Act 2020 (effective Feb 2020)
 *        Filing due: 21st of the month following the tax period
 *        FIRS portal: https://taxpromax.firs.gov.ng
 *
 *   WHT: Withholding Tax deducted at source
 *        Contracts (supply of goods/services): 5%
 *        Consultancy/management/technical: 10%
 *        Rent: 10%
 *        Certificate issued to recipient as credit evidence
 *
 * Output formats:
 *   - JSON (API response, in-app review)
 *   - Excel (FIRS TaxPro-Max upload format)
 *   - PDF (signed print copy for physical submission)
 *
 * Financial integrity: all figures computed directly from POSTED journal entries.
 * AI cannot trigger filings — all submissions require human approval.
 */
import { Injectable, Logger, BadRequestException, NotFoundException } from '@nestjs/common';
import { InjectQueue }   from '@nestjs/bull';
import { Queue }         from 'bull';
import { EventEmitter2 } from '@nestjs/event-emitter';
import * as ExcelJS      from 'exceljs';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService }  from '../../audit/audit.service';
import type { JwtPayload } from '@agcoms/types';

// Nigerian tax constants
const VAT_RATE       = 0.075;  // Finance Act 2020 — 7.5%
const WHT_CONTRACT   = 0.05;   // 5% — contracts & supply
const WHT_CONSULT    = 0.10;   // 10% — consultancy, management, technical, rent

// VAT account codes in chart of accounts
const VAT_OUTPUT_CODE = '2100';   // VAT Payable (Output)
const VAT_INPUT_CODE  = '2110';   // VAT Recoverable (Input)

export const FIRS_FILING_QUEUE = 'firs-filings';

@Injectable()
export class FirsVatService {
  private readonly logger = new Logger(FirsVatService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly audit:   AuditService,
    private readonly events:  EventEmitter2,
    @InjectQueue(FIRS_FILING_QUEUE) private readonly queue: Queue,
  ) {}

  // ── Compute VAT return ──────────────────────────────────────────────────

  async computeVatReturn(
    branchId: string,
    year:     number,
    month:    number,
    actor:    JwtPayload,
  ) {
    // Validate period
    if (month < 1 || month > 12) throw new BadRequestException('Month must be 1–12');
    const now = new Date();
    if (year > now.getFullYear() || (year === now.getFullYear() && month > now.getMonth() + 1)) {
      throw new BadRequestException('Cannot compute VAT return for a future period');
    }

    // Check not already submitted
    const existing = await this.prisma.firsVatReturn.findUnique({
      where: { branchId_periodYear_periodMonth: { branchId, periodYear: year, periodMonth: month } },
    });
    if (existing?.status === 'SUBMITTED' || existing?.status === 'ACCEPTED') {
      throw new BadRequestException(`VAT return for ${year}-${month} is already ${existing.status}`);
    }

    const periodStart = new Date(year, month - 1, 1);
    const periodEnd   = new Date(year, month, 0, 23, 59, 59, 999);

    // Fetch all POSTED journal lines for the period
    const [outputVatLines, inputVatLines] = await Promise.all([
      this.getAccountLines(branchId, VAT_OUTPUT_CODE, periodStart, periodEnd),
      this.getAccountLines(branchId, VAT_INPUT_CODE,  periodStart, periodEnd),
    ]);

    // Compute VAT figures
    const outputVat = outputVatLines.reduce((s, l) => s + Number(l._sum.creditAmount ?? 0), 0);
    const inputVat  = inputVatLines.reduce((s, l)  => s + Number(l._sum.debitAmount  ?? 0), 0);
    const netVatPayable = outputVat - inputVat;

    // Taxable supplies: derive from revenue accounts
    const revenueLines = await this.prisma.journalLine.groupBy({
      by:    ['accountId'],
      where: {
        journalEntry: { branchId, status: 'POSTED', entryDate: { gte: periodStart, lte: periodEnd } },
        account: { accountType: 'REVENUE' },
      },
      _sum: { creditAmount: true, debitAmount: true },
    });
    const taxableSupplies = revenueLines.reduce((s, l) =>
      s + Number(l._sum.creditAmount ?? 0) - Number(l._sum.debitAmount ?? 0), 0
    );

    // VAT due date: 21st of following month
    const dueDate = new Date(year, month, 21);

    // Line-by-line breakdown for the return
    const invoiceLines = await this.prisma.invoice.findMany({
      where: { branchId, status: { in: ['ISSUED', 'PAID', 'PARTIALLY_PAID'] }, invoiceDate: { gte: periodStart, lte: periodEnd } },
      select: { invoiceNo: true, invoiceDate: true, customer: { select: { name: true } }, totalAmount: true, vatAmount: true },
      orderBy: { invoiceDate: 'asc' },
    });

    const returnRef = `VAT-${await this.getBranchCode(branchId)}-${year}-${String(month).padStart(2, '0')}`;

    const computedData = {
      period:        `${year}-${String(month).padStart(2, '0')}`,
      invoiceLines:  invoiceLines.map(inv => ({
        invoiceNo:   inv.invoiceNo,
        date:        inv.invoiceDate?.toISOString().split('T')[0],
        customer:    inv.customer.name,
        gross:       Number(inv.totalAmount),
        vat:         Number(inv.vatAmount ?? 0),
      })),
      totals: { outputVat, inputVat, netVatPayable, taxableSupplies },
    };

    // Upsert the return
    const vatReturn = await this.prisma.firsVatReturn.upsert({
      where:  { branchId_periodYear_periodMonth: { branchId, periodYear: year, periodMonth: month } },
      update: { status: 'COMPUTED', outputVat, inputVat, netVatPayable, taxableSupplies, exemptSupplies: 0, exportSales: 0, computedData, returnRef, dueDate },
      create: { returnRef, branchId, periodYear: year, periodMonth: month, dueDate, status: 'COMPUTED', outputVat, inputVat, netVatPayable, taxableSupplies, exemptSupplies: 0, exportSales: 0, computedData, createdById: actor.sub },
    });

    await this.audit.log({
      action: 'firs.vat_return.computed', resource: 'FirsVatReturn', entityId: vatReturn.id,
      actorId: actor.sub, actorRole: actor.roles[0] ?? 'UNKNOWN',
      afterState: { returnRef, period: `${year}-${month}`, netVatPayable },
    });

    this.logger.log(`VAT return computed: ${returnRef} — Net payable: ₦${netVatPayable.toLocaleString('en-NG')}`);
    return vatReturn;
  }

  // ── Submit VAT return (human-approved action) ───────────────────────────

  async submitVatReturn(returnId: string, firsReference: string, actor: JwtPayload) {
    const vatReturn = await this.prisma.firsVatReturn.findUnique({ where: { id: returnId } });
    if (!vatReturn) throw new NotFoundException('VAT return not found');
    if (!['COMPUTED', 'REVIEWED'].includes(vatReturn.status)) {
      throw new BadRequestException(`VAT return must be COMPUTED or REVIEWED to submit — current status: ${vatReturn.status}`);
    }

    const updated = await this.prisma.firsVatReturn.update({
      where: { id: returnId },
      data: { status: 'SUBMITTED', submittedAt: new Date(), submittedById: actor.sub, firsReference },
    });

    await this.audit.log({
      action: 'firs.vat_return.submitted', resource: 'FirsVatReturn', entityId: returnId,
      actorId: actor.sub, actorRole: actor.roles[0] ?? 'UNKNOWN',
      afterState: { returnRef: vatReturn.returnRef, firsReference, status: 'SUBMITTED' },
    });

    this.events.emit('firs.vat_return.submitted', { returnId, returnRef: vatReturn.returnRef, firsReference });
    this.logger.log(`VAT return submitted: ${vatReturn.returnRef} (FIRS ref: ${firsReference})`);
    return updated;
  }

  // ── Generate FIRS-format Excel export ───────────────────────────────────

  async generateVatExcel(returnId: string): Promise<Buffer> {
    const vatReturn = await this.prisma.firsVatReturn.findUnique({
      where:   { id: returnId },
      include: { branch: { select: { name: true, code: true } } },
    });
    if (!vatReturn) throw new NotFoundException('VAT return not found');

    const wb  = new ExcelJS.Workbook();
    wb.creator = 'AGCOMS DealerSync ERP';
    wb.created = new Date();

    const ws  = wb.addWorksheet('VAT Return', {
      pageSetup: { paperSize: 9, orientation: 'landscape' },
    });

    // FIRS-style header block
    const headerRows = [
      ['FEDERAL INLAND REVENUE SERVICE'],
      ['VALUE ADDED TAX RETURN'],
      [`Company: AGCOMS International Trading Limited`],
      [`Branch: ${vatReturn.branch.name} (${vatReturn.branch.code})`],
      [`Period: ${vatReturn.periodYear}-${String(vatReturn.periodMonth).padStart(2, '0')}`],
      [`Return Reference: ${vatReturn.returnRef}`],
      [`Due Date: ${vatReturn.dueDate.toLocaleDateString('en-NG')}`],
      [],
    ];
    headerRows.forEach(row => ws.addRow(row));

    // Style headers
    ['A1', 'A2'].forEach(cell => {
      ws.getCell(cell).font = { bold: true, size: 14, color: { argb: 'FF1A4D2E' } };
    });

    // Column definitions
    ws.columns = [
      { header: 'Invoice No',     key: 'invoiceNo',  width: 20 },
      { header: 'Date',           key: 'date',       width: 14 },
      { header: 'Customer Name',  key: 'customer',   width: 35 },
      { header: 'Gross Amount (₦)', key: 'gross',    width: 18, style: { numFmt: '#,##0.00' } },
      { header: 'VAT Amount (₦)', key: 'vat',        width: 16, style: { numFmt: '#,##0.00' } },
    ];

    // Header row styling
    const headerRow = ws.getRow(9);
    headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1A4D2E' } };

    // Invoice lines
    const data = (vatReturn.computedData as any)?.invoiceLines ?? [];
    data.forEach((line: any) => ws.addRow(line));

    // Totals row
    ws.addRow({});
    const totals = ws.addRow({
      invoiceNo: 'TOTALS',
      gross:     Number(vatReturn.taxableSupplies),
      vat:       Number(vatReturn.outputVat),
    });
    totals.font = { bold: true };
    totals.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEAF3DE' } };

    // Summary section
    ws.addRow({});
    ws.addRow({ invoiceNo: 'SUMMARY' }).font = { bold: true };
    [
      ['Output VAT (Sales)',       Number(vatReturn.outputVat)],
      ['Input VAT (Purchases)',    Number(vatReturn.inputVat)],
      ['Net VAT Payable',          Number(vatReturn.netVatPayable)],
    ].forEach(([label, value]) => {
      const row = ws.addRow({ invoiceNo: label, gross: value as number });
      if (label === 'Net VAT Payable') row.font = { bold: true, color: { argb: 'FFB91C1C' } };
    });

    ws.autoFilter = { from: 'A9', to: 'E9' };

    const buffer = await wb.xlsx.writeBuffer();
    this.logger.log(`VAT Excel generated: ${vatReturn.returnRef} (${data.length} lines)`);
    return Buffer.from(buffer);
  }

  // ── WHT certificate generation ─────────────────────────────────────────

  async generateWhtCertificate(
    branchId:        string,
    recipientName:   string,
    recipientTin:    string | undefined,
    grossAmount:     number,
    transactionType: 'CONTRACT' | 'CONSULTANCY' | 'RENT' | 'TECHNICAL',
    referenceType:   string,
    referenceId:     string,
    year:            number,
    month:           number,
    actor:           JwtPayload,
  ) {
    const rate      = ['CONSULTANCY', 'RENT', 'TECHNICAL'].includes(transactionType) ? WHT_CONSULT : WHT_CONTRACT;
    const whtAmount = Math.round(grossAmount * rate * 100) / 100;
    const netAmount = grossAmount - whtAmount;

    const branch = await this.prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const count  = await this.prisma.firsWhtCertificate.count({ where: { branchId } });
    const certNo = `WHT-${branch?.code ?? 'HQ'}-${year}-${String(month).padStart(2,'0')}-${String(count+1).padStart(4,'0')}`;

    const cert = await this.prisma.firsWhtCertificate.create({
      data: {
        certificateNo: certNo, branchId, recipientName, recipientTin,
        transactionType, grossAmount, whtRate: rate * 100, whtAmount, netAmount,
        periodYear: year, periodMonth: month,
        referenceType, referenceId: referenceId as any,
        issuedById: actor.sub,
      },
    });

    await this.audit.log({
      action: 'firs.wht_certificate.issued', resource: 'FirsWhtCertificate', entityId: cert.id,
      actorId: actor.sub, actorRole: actor.roles[0] ?? 'UNKNOWN',
      afterState: { certNo, recipient: recipientName, whtAmount, rate: `${rate*100}%` },
    });

    this.logger.log(`WHT certificate issued: ${certNo} — ${recipientName} — ₦${whtAmount.toLocaleString('en-NG')} (${rate*100}%)`);
    return cert;
  }

  // ── Filing schedule & alerts ────────────────────────────────────────────

  async getFilingSchedule(branchId: string) {
    const now     = new Date();
    const months: Array<{ year: number; month: number; dueDate: Date; status: string; daysUntilDue: number }> = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const yr = d.getFullYear();
      const mo = d.getMonth() + 1;
      const dueDate = new Date(yr, mo, 21);     // 21st of following month
      const existing = await this.prisma.firsVatReturn.findUnique({
        where: { branchId_periodYear_periodMonth: { branchId, periodYear: yr, periodMonth: mo } },
        select: { status: true },
      });
      months.push({
        year: yr, month: mo, dueDate,
        status:       existing?.status ?? 'PENDING',
        daysUntilDue: Math.ceil((dueDate.getTime() - now.getTime()) / 86400_000),
      });
    }

    const overdue  = months.filter(m => m.daysUntilDue < 0  && !['SUBMITTED','ACCEPTED'].includes(m.status));
    const duesSoon = months.filter(m => m.daysUntilDue >= 0 && m.daysUntilDue <= 7 && !['SUBMITTED','ACCEPTED'].includes(m.status));

    return { schedule: months, overdue, duesSoon, alertCount: overdue.length + duesSoon.length };
  }

  async listVatReturns(branchId: string) {
    return this.prisma.firsVatReturn.findMany({
      where:   { branchId },
      orderBy: [{ periodYear: 'desc' }, { periodMonth: 'desc' }],
    });
  }

  // ── Private helpers ────────────────────────────────────────────────────

  private async getAccountLines(branchId: string, accountCode: string, from: Date, to: Date) {
    return this.prisma.journalLine.groupBy({
      by:    ['accountId'],
      where: {
        journalEntry: { branchId, status: 'POSTED', entryDate: { gte: from, lte: to } },
        account: { code: accountCode, branchId },
      },
      _sum: { debitAmount: true, creditAmount: true },
    });
  }

  private async getBranchCode(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    return branch?.code ?? 'HQ';
  }
}
