/**
 * AGCOMS DealerSync ERP — BudgetService
 * §7 Module 8 Finance: "budgets"
 *
 * Workflow:  DRAFT → SUBMITTED → APPROVED → LOCKED
 * Features:  Budget creation, line management, variance reporting,
 *            reforecast, period locking, approval workflow.
 */
import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService }  from '../../../prisma/prisma.service';
import { AuditService }   from '../../../audit/audit.service';
import { EventEmitter2 }  from '@nestjs/event-emitter';
import type { JwtPayload } from '@agcoms/types';

export type BudgetStatus = 'DRAFT' | 'SUBMITTED' | 'APPROVED' | 'LOCKED';
export type VarianceStatus = 'ON_TRACK' | 'OVER_BUDGET' | 'UNDER_BUDGET' | 'NO_ACTIVITY';

const OVER_BUDGET_TOLERANCE_PCT  = 10; // 10% over = warning
const UNDER_BUDGET_TOLERANCE_PCT = 10; // 10% under = warning

export interface BudgetLineDto {
  accountId:    string;
  description?: string;
  amount:       number;   // Budgeted amount
  notes?:       string;
}

export interface CreateBudgetDto {
  branchId:   string;
  periodId:   string;       // Accounting period
  name:       string;
  notes?:     string;
  lines:      BudgetLineDto[];
}

export interface ReforecastLineDto {
  budgetLineId:  string;
  newAmount:     number;
  reforecastNote: string;
}

export interface VarianceLine {
  accountId:     string;
  accountCode:   string;
  accountName:   string;
  budgeted:      number;
  actual:        number;
  variance:      number;         // actual - budgeted (positive = over budget for expenses)
  variancePct:   number;
  status:        VarianceStatus;
}

@Injectable()
export class BudgetService {
  private readonly logger = new Logger(BudgetService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly audit:   AuditService,
    private readonly events:  EventEmitter2,
  ) {}

  // ── Create budget ─────────────────────────────────────────────

  async createBudget(dto: CreateBudgetDto, actor: JwtPayload) {
    // Prevent duplicate budgets for same branch+period
    const existing = await this.prisma.budget.findFirst({
      where: { branchId: dto.branchId, periodId: dto.periodId, isDeleted: false },
    });
    if (existing) {
      throw new BadRequestException(
        `A budget already exists for this branch and period (${existing.budgetNo}). Use reforecast to update amounts.`
      );
    }

    // Validate all account IDs exist and are active
    const accountIds = [...new Set(dto.lines.map(l => l.accountId))];
    const accounts   = await this.prisma.account.findMany({
      where: { id: { in: accountIds }, branchId: dto.branchId, isActive: true },
    });
    if (accounts.length !== accountIds.length) {
      throw new BadRequestException('One or more account IDs are invalid or inactive');
    }

    if (dto.lines.some(l => l.amount < 0)) {
      throw new BadRequestException('Budget line amounts cannot be negative');
    }

    const budgetNo = await this.generateBudgetNo(dto.branchId);
    const period   = await this.prisma.accountingPeriod.findUnique({ where: { id: dto.periodId } });
    if (!period) throw new NotFoundException('Accounting period not found');

    const budget = await this.prisma.budget.create({
      data: {
        budgetNo,
        branchId:    dto.branchId,
        periodId:    dto.periodId,
        name:        dto.name,
        notes:       dto.notes,
        status:      'DRAFT',
        totalAmount: dto.lines.reduce((s, l) => s + l.amount, 0),
        createdById: actor.sub,
        lines: {
          create: dto.lines.map(l => ({
            accountId:    l.accountId,
            description:  l.description,
            originalAmount: l.amount,
            currentAmount:  l.amount,
            notes:          l.notes,
          })),
        },
      },
      include: { lines: { include: { account: { select: { code: true, name: true } } } } },
    });

    await this.audit.log({
      action:     'budget.created',
      resource:   'Budget',
      entityId:   budget.id,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: { budgetNo, periodId: dto.periodId, totalAmount: budget.totalAmount },
    });

    this.logger.log(`Budget ${budgetNo} created for period ${period.name}`);
    return budget;
  }

  // ── Submit for approval ───────────────────────────────────────

  async submitBudget(id: string, actor: JwtPayload) {
    const budget = await this.findBudget(id);
    if (budget.status !== 'DRAFT') throw new BadRequestException('Only DRAFT budgets can be submitted');

    await this.prisma.budget.update({
      where: { id },
      data:  { status: 'SUBMITTED', submittedAt: new Date(), submittedById: actor.sub },
    });

    this.events.emit('budget.submitted', { budgetId: id, budgetNo: budget.budgetNo });
    return { id, status: 'SUBMITTED' };
  }

  // ── Approve ───────────────────────────────────────────────────

  async approveBudget(id: string, actor: JwtPayload) {
    const budget = await this.findBudget(id);
    if (budget.status !== 'SUBMITTED') throw new BadRequestException('Only SUBMITTED budgets can be approved');

    await this.prisma.budget.update({
      where: { id },
      data:  { status: 'APPROVED', approvedAt: new Date(), approvedById: actor.sub },
    });

    await this.audit.log({
      action: 'budget.approved', resource: 'Budget', entityId: id,
      actorId: actor.sub, actorRole: actor.roles[0],
      afterState: { budgetNo: budget.budgetNo, status: 'APPROVED' },
    });

    this.events.emit('budget.approved', { budgetId: id });
    this.logger.log(`Budget ${budget.budgetNo} approved`);
    return { id, status: 'APPROVED' };
  }

  // ── Lock (end of period — no further changes) ─────────────────

  async lockBudget(id: string, actor: JwtPayload) {
    const budget = await this.findBudget(id);
    if (budget.status !== 'APPROVED') throw new BadRequestException('Only APPROVED budgets can be locked');

    await this.prisma.budget.update({
      where: { id },
      data:  { status: 'LOCKED', lockedAt: new Date(), lockedById: actor.sub },
    });

    return { id, status: 'LOCKED' };
  }

  // ── Reforecast individual lines ───────────────────────────────

  async reforecastLines(id: string, lines: ReforecastLineDto[], actor: JwtPayload) {
    const budget = await this.findBudget(id);
    if (budget.status === 'LOCKED') throw new BadRequestException('Cannot reforecast a LOCKED budget');

    for (const reforecast of lines) {
      if (reforecast.newAmount < 0) throw new BadRequestException('Reforecast amounts cannot be negative');

      const line = await this.prisma.budgetLine.findFirst({
        where: { id: reforecast.budgetLineId, budgetId: id },
      });
      if (!line) throw new NotFoundException(`Budget line ${reforecast.budgetLineId} not found`);

      await this.prisma.budgetLine.update({
        where: { id: reforecast.budgetLineId },
        data: {
          previousAmount:  Number(line.currentAmount),
          currentAmount:   reforecast.newAmount,
          reforecastNote:  reforecast.reforecastNote,
          reforecastAt:    new Date(),
          reforecastById:  actor.sub,
          reforecastCount: { increment: 1 },
        },
      });
    }

    // Recompute total
    const allLines = await this.prisma.budgetLine.findMany({ where: { budgetId: id } });
    const newTotal = allLines.reduce((s, l) => s + Number(l.currentAmount), 0);
    await this.prisma.budget.update({ where: { id }, data: { totalAmount: newTotal } });

    this.logger.log(`Budget ${budget.budgetNo} reforecast: ${lines.length} lines updated`);
    return { id, reforecastedLines: lines.length, newTotal };
  }

  // ── Variance report ───────────────────────────────────────────

  async getVarianceReport(id: string): Promise<{
    budget: { budgetNo: string; name: string; period: string; status: string };
    lines:  VarianceLine[];
    summary: { totalBudgeted: number; totalActual: number; totalVariance: number; variancePct: number };
  }> {
    const budget = await this.prisma.budget.findUnique({
      where:   { id },
      include: {
        period: true,
        lines:  { include: { account: { select: { code: true, name: true } } } },
      },
    });
    if (!budget) throw new NotFoundException(`Budget ${id} not found`);

    // Fetch actual amounts from posted journal entries within the period
    const actuals = await this.prisma.journalLine.groupBy({
      by:    ['accountId'],
      where: {
        journalEntry: {
          branchId:  budget.branchId,
          status:    'POSTED',
          entryDate: {
            gte: budget.period.startDate,
            lte: budget.period.endDate,
          },
        },
      },
      _sum: { debitAmount: true, creditAmount: true },
    });

    const actualMap = new Map<string, number>();
    actuals.forEach(a => {
      // Net actual = debits - credits (for expense accounts, debits are positive)
      actualMap.set(a.accountId, Number(a._sum.debitAmount ?? 0) - Number(a._sum.creditAmount ?? 0));
    });

    const lines: VarianceLine[] = budget.lines.map(line => {
      const budgeted    = Number(line.currentAmount);
      const actual      = actualMap.get(line.accountId) ?? 0;
      const variance    = actual - budgeted;
      const variancePct = budgeted > 0 ? (variance / budgeted) * 100 : actual !== 0 ? 100 : 0;
      const absPct      = Math.abs(variancePct);

      let status: VarianceStatus;
      if (actual === 0 && budgeted === 0)       status = 'NO_ACTIVITY';
      else if (variance > budgeted * (OVER_BUDGET_TOLERANCE_PCT / 100)) status = 'OVER_BUDGET';
      else if (variance < -(budgeted * (UNDER_BUDGET_TOLERANCE_PCT / 100))) status = 'UNDER_BUDGET';
      else                                       status = 'ON_TRACK';

      return {
        accountId:   line.accountId,
        accountCode: line.account.code,
        accountName: line.account.name,
        budgeted,
        actual,
        variance,
        variancePct: Math.round(variancePct * 10) / 10,
        status,
      };
    });

    const totalBudgeted = lines.reduce((s, l) => s + l.budgeted, 0);
    const totalActual   = lines.reduce((s, l) => s + l.actual,   0);
    const totalVariance = totalActual - totalBudgeted;

    return {
      budget: {
        budgetNo: budget.budgetNo,
        name:     budget.name,
        period:   budget.period.name,
        status:   budget.status,
      },
      lines,
      summary: {
        totalBudgeted,
        totalActual,
        totalVariance,
        variancePct: totalBudgeted > 0 ? Math.round((totalVariance / totalBudgeted) * 1000) / 10 : 0,
      },
    };
  }

  // ── List + find ───────────────────────────────────────────────

  async listBudgets(params: { branchId: string; periodId?: string; status?: BudgetStatus }) {
    return this.prisma.budget.findMany({
      where:   { ...params, isDeleted: false },
      include: { period: { select: { name: true } }, _count: { select: { lines: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  private async findBudget(id: string) {
    const b = await this.prisma.budget.findUnique({ where: { id } });
    if (!b) throw new NotFoundException(`Budget ${id} not found`);
    return b;
  }

  private async generateBudgetNo(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const count  = await this.prisma.budget.count({ where: { branchId } });
    return `BUD-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  }
}
