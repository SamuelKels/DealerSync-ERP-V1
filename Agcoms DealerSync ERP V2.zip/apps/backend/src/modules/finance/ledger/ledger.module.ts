/**
 * AGCOMS DealerSync ERP — LedgerModule
 * Sprint 5 / S5-B: Immutable ledger event log.
 * Global — any domain module emitting financial events can inject LedgerEventService.
 */
import { Global, Module }       from '@nestjs/common';
import { LedgerEventService }   from './ledger-event.service';
import { LedgerController }     from './ledger.controller';

@Global()
@Module({
  controllers: [LedgerController],
  providers:   [LedgerEventService],
  exports:     [LedgerEventService],
})
export class LedgerModule {}
