/**
 * AGCOMS DealerSync ERP — Ledger Controller
 * Sprint 5 / S5-B: Immutable ledger event log endpoints.
 *
 * GET  /api/v1/finance/ledger/verify                 — full chain integrity check
 * GET  /api/v1/finance/ledger/entity/:type/:id       — event history for an entity
 * GET  /api/v1/finance/ledger/balance/:accountId     — point-in-time balance
 */
import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam, ApiQuery } from '@nestjs/swagger';
import { LedgerEventService }               from './ledger-event.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../../common/guards/auth.guards';
import { CurrentUser }                      from '../../../common/decorators/current-user.decorator';
import type { JwtPayload }                  from '@agcoms/types';

@ApiTags('finance-ledger')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('finance/ledger')
export class LedgerController {
  constructor(private readonly svc: LedgerEventService) {}

  @Get('verify')
  @RequirePermission('finance:read')
  @ApiOperation({
    summary: 'Verify ledger chain integrity — recomputes all SHA-256 hashes. Expensive: run on-demand only.',
  })
  verifyChain(@CurrentUser() actor: JwtPayload) {
    return this.svc.verifyChainIntegrity(actor.branchId);
  }

  @Get('entity/:entityType/:entityId')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Get full immutable event history for a financial entity' })
  @ApiParam({ name: 'entityType', examples: { invoice: { value: 'Invoice' }, journal: { value: 'JournalEntry' } } })
  @ApiParam({ name: 'entityId',   description: 'Entity UUID' })
  getEntityHistory(
    @Param('entityType') entityType: string,
    @Param('entityId')   entityId:   string,
  ) {
    return this.svc.getEntityHistory(entityType, entityId);
  }

  @Get('balance/:accountId')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Reconstruct account balance at any point in time from ledger events' })
  @ApiParam({ name: 'accountId', description: 'Account UUID' })
  @ApiQuery({ name: 'asOf', required: false, description: 'ISO date — defaults to now', example: '2025-03-31' })
  reconstructBalance(
    @Param('accountId') accountId: string,
    @CurrentUser() actor: JwtPayload,
    @Query('asOf') asOf?: string,
  ) {
    const asOfDate = asOf ? new Date(asOf) : new Date();
    return this.svc.reconstructBalanceAt(accountId, actor.branchId, asOfDate);
  }
}
