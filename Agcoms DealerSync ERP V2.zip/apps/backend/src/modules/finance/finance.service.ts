// AGCOMS DealerSync — Finance & Accounting Service (Module 8)
// Double-entry bookkeeping · IFRS-ready CoA · Nigerian VAT/WHT · Period locks
// CRITICAL: Financial integrity enforced at every layer — debits MUST equal credits
// AI CANNOT: post journals, approve payroll, alter accounting records, override period locks

import { Injectable, NotFoundException, BadRequestException, ForbiddenException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prisma } from '@prisma/client';

@Injectable()
export class FinanceService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextCode(prefix: string, model: string): Promise<string> {
    const year = new Date().getFullYear();
    const count = await (this.prisma as any)[model].count({ where: { createdAt: { gte: new Date(`${year}-01-01`) } } });
    return `${prefix}-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Chart of Accounts ─────────────────────────────────────────────────────

  async getChartOfAccounts(branchId?: string) {
    return this.prisma.chartOfAccount.findMany({
      where: { isDeleted: false, status: { not: 'ARCHIVED' }, ...(branchId && { OR: [{ branchId }, { branchId: null }] }) },
      include: { parent: { select: { id: true, code: true, name: true } }, _count: { select: { children: true, journalLines: true } } },
      orderBy: { code: 'asc' },
    });
  }

  async createAccount(dto: any, actorId: string) {
    const existing = await this.prisma.chartOfAccount.findUnique({ where: { code: dto.code } });
    if (existing) throw new ConflictException(`Account code ${dto.code} already exists`);
    const account = await this.prisma.chartOfAccount.create({ data: { ...dto, createdById: actorId } });
    await this.audit.log({ action: 'create', resource: 'chart_of_account', entityId: account.id, afterState: account, actorId });
    return account;
  }

  async getAccountLedger(accountId: string, from: Date, to: Date) {
    const account = await this.prisma.chartOfAccount.findUnique({ where: { id: accountId } });
    if (!account) throw new NotFoundException('Account not found');
    const lines = await this.prisma.journalEntryLine.findMany({
      where: {
        accountId,
        journalEntry: { status: 'POSTED', entryDate: { gte: from, lte: to } },
      },
      include: { journalEntry: { select: { id: true, code: true, entryDate: true, description: true, reference: true, entryType: true } } },
      orderBy: { journalEntry: { entryDate: 'asc' } },
    });
    // Build running balance
    let balance = 0;
    const enriched = lines.map((l) => {
      const movement = account.normalBalance === 'DEBIT'
        ? Number(l.debitAmount) - Number(l.creditAmount)
        : Number(l.creditAmount) - Number(l.debitAmount);
      balance += movement;
      return { ...l, runningBalance: balance };
    });
    return { account, entries: enriched, closingBalance: balance };
  }

  // ── Accounting Periods ────────────────────────────────────────────────────

  async listPeriods(branchId?: string) {
    return this.prisma.accountingPeriod.findMany({
      where: { ...(branchId && { OR: [{ branchId }, { branchId: null }] }) },
      orderBy: [{ periodYear: 'desc' }, { periodMonth: 'desc' }],
    });
  }

  async getOrCreatePeriod(year: number, month: number, branchId: string | null, actorId: string) {
    const existing = await this.prisma.accountingPeriod.findFirst({ where: { periodYear: year, periodMonth: month, branchId: branchId ?? null } });
    if (existing) return existing;
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 0); // last day of month
    const name = `${new Date(year, month - 1).toLocaleString('en', { month: 'long' })} ${year}`;
    return this.prisma.accountingPeriod.create({
      data: { name, periodYear: year, periodMonth: month, startDate: start, endDate: end, status: 'OPEN', branchId: branchId ?? undefined, createdById: actorId },
    });
  }

  async closePeriod(id: string, actorId: string) {
    const period = await this.prisma.accountingPeriod.findUnique({ where: { id } });
    if (!period) throw new NotFoundException('Period not found');
    if (period.status !== 'OPEN') throw new BadRequestException('Only OPEN periods can be closed');
    const updated = await this.prisma.accountingPeriod.update({ where: { id }, data: { status: 'CLOSED', closedAt: new Date(), closedById: actorId } });
    await this.audit.log({ action: 'close_period', resource: 'accounting_period', entityId: id, beforeState: { status: 'OPEN' }, afterState: { status: 'CLOSED' }, actorId });
    return updated;
  }

  async lockPeriod(id: string, actorId: string) {
    const period = await this.prisma.accountingPeriod.findUnique({ where: { id } });
    if (!period) throw new NotFoundException('Period not found');
    if (period.status === 'LOCKED') throw new BadRequestException('Period already locked');
    // AI GOVERNANCE: period locking requires a human super-admin action
    const updated = await this.prisma.accountingPeriod.update({ where: { id }, data: { status: 'LOCKED', lockedAt: new Date(), lockedById: actorId } });
    await this.audit.log({ action: 'lock_period', resource: 'accounting_period', entityId: id, beforeState: { status: period.status }, afterState: { status: 'LOCKED' }, actorId });
    return updated;
  }

  // ── Journal Entries (Core Double-Entry Engine) ────────────────────────────

  async createJournalEntry(dto: {
    entryDate: Date; description: string; reference?: string; referenceType?: string;
    entryType?: string; branchId: string; currency?: string; exchangeRate?: number;
    notes?: string; lines: { accountId: string; description?: string; debitAmount: number; creditAmount: number; costCentre?: string; entityRef?: string; entityType?: string }[];
  }, actorId: string) {
    // FINANCIAL INTEGRITY CHECK: debits must equal credits
    const totalDebits = dto.lines.reduce((s, l) => s + (l.debitAmount || 0), 0);
    const totalCredits = dto.lines.reduce((s, l) => s + (l.creditAmount || 0), 0);
    if (Math.abs(totalDebits - totalCredits) > 0.001) {
      throw new BadRequestException(
        `Journal entry is not balanced. Debits: ${totalDebits.toFixed(2)}, Credits: ${totalCredits.toFixed(2)}, Difference: ${(totalDebits - totalCredits).toFixed(2)}`
      );
    }
    if (totalDebits === 0) throw new BadRequestException('Journal entry cannot have zero values');
    if (dto.lines.length < 2) throw new BadRequestException('Journal entry must have at least 2 lines');

    // Get the accounting period for this date
    const date = new Date(dto.entryDate);
    const period = await this.getOrCreatePeriod(date.getFullYear(), date.getMonth() + 1, dto.branchId, actorId);
    if (period.status === 'LOCKED') {
      throw new BadRequestException(`Accounting period "${period.name}" is LOCKED. Cannot post entries. Contact your Financial Controller.`);
    }

    const code = await this.nextCode('JNL', 'journalEntry');
    const je = await this.prisma.journalEntry.create({
      data: {
        code, status: 'DRAFT', entryType: (dto.entryType ?? 'MANUAL') as any,
        periodId: period.id, branchId: dto.branchId,
        entryDate: dto.entryDate, description: dto.description,
        reference: dto.reference, referenceType: dto.referenceType,
        totalDebits, totalCredits,
        currency: (dto.currency ?? 'NGN') as any, exchangeRate: dto.exchangeRate ?? 1,
        notes: dto.notes, createdById: actorId,
        lines: {
          create: dto.lines.map((l, i) => ({
            lineNumber: i + 1, accountId: l.accountId, description: l.description,
            debitAmount: l.debitAmount || 0, creditAmount: l.creditAmount || 0,
            costCentre: l.costCentre, entityRef: l.entityRef, entityType: l.entityType,
          })),
        },
      },
      include: { lines: { include: { account: { select: { id: true, code: true, name: true } } } } },
    });

    await this.audit.log({ action: 'create', resource: 'journal_entry', entityId: je.id, afterState: { code: je.code, totalDebits, totalCredits }, actorId });
    return je;
  }

  async postJournalEntry(id: string, actorId: string) {
    const je = await this.prisma.journalEntry.findFirst({
      where: { id }, include: { period: true, lines: { include: { account: true } } },
    });
    if (!je) throw new NotFoundException('Journal entry not found');
    if (je.status === 'POSTED') throw new BadRequestException('Journal entry already posted');
    if (je.status === 'VOID') throw new BadRequestException('Cannot post a void journal entry');
    if (je.period.status === 'LOCKED') throw new BadRequestException(`Period "${je.period.name}" is locked`);

    // Re-validate balance before posting (immutability guarantee)
    if (Math.abs(Number(je.totalDebits) - Number(je.totalCredits)) > 0.001) {
      throw new BadRequestException('Journal entry is not balanced — cannot post');
    }

    // ACID transaction: post entry and update account balances
    await this.prisma.$transaction(async (tx) => {
      await tx.journalEntry.update({ where: { id }, data: { status: 'POSTED', postedAt: new Date(), postedById: actorId } });

      for (const line of je.lines) {
        const movement = line.account.normalBalance === 'DEBIT'
          ? Number(line.debitAmount) - Number(line.creditAmount)
          : Number(line.creditAmount) - Number(line.debitAmount);

        await tx.chartOfAccount.update({
          where: { id: line.accountId },
          data: { balance: { increment: movement }, balanceAsOf: new Date() },
        });
      }
    });

    await this.audit.log({ action: 'post', resource: 'journal_entry', entityId: id, beforeState: { status: je.status }, afterState: { status: 'POSTED', postedAt: new Date() }, actorId });
    this.events.emit('finance.journal.posted', { journalId: id, totalDebits: je.totalDebits });
    return { success: true, message: 'Journal entry posted and account balances updated' };
  }

  async reverseJournalEntry(id: string, reversalDate: Date, reason: string, actorId: string) {
    const je = await this.prisma.journalEntry.findFirst({
      where: { id }, include: { lines: true, period: true, branch: true },
    });
    if (!je) throw new NotFoundException('Journal entry not found');
    if (je.status !== 'POSTED') throw new BadRequestException('Only POSTED entries can be reversed');
    if (je.isReversal) throw new BadRequestException('Cannot reverse a reversal entry');

    // Create mirror entry with swapped debits/credits
    const reversalLines = je.lines.map((l) => ({
      accountId: l.accountId, description: `Reversal: ${l.description || ''}`,
      debitAmount: Number(l.creditAmount), creditAmount: Number(l.debitAmount),
    }));

    const reversal = await this.createJournalEntry({
      entryDate: reversalDate, description: `REVERSAL: ${je.description}`,
      reference: je.code, referenceType: 'REVERSAL', entryType: 'REVERSAL',
      branchId: je.branchId, notes: reason, lines: reversalLines,
    }, actorId);

    // Mark original as reversed and link to reversal
    await this.prisma.journalEntry.update({ where: { id }, data: { status: 'REVERSED' } });
    await this.prisma.journalEntry.update({ where: { id: reversal.id }, data: { isReversal: true, reversedEntryId: id } });
    await this.postJournalEntry(reversal.id, actorId);

    await this.audit.log({ action: 'reverse', resource: 'journal_entry', entityId: id, beforeState: { status: je.status }, afterState: { status: 'REVERSED', reversalId: reversal.id, reason }, actorId });
    return reversal;
  }

  async listJournalEntries(query: any, actorBranchId: string, isSuperAdmin: boolean) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where: any = {
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.entryType && { entryType: query.entryType }),
      ...(query.from && { entryDate: { gte: new Date(query.from) } }),
      ...(query.to && { entryDate: { lte: new Date(query.to) } }),
      ...(query.reference && { reference: { contains: query.reference, mode: 'insensitive' } }),
    };
    const [items, total] = await Promise.all([
      this.prisma.journalEntry.findMany({ where, include: { period: { select: { name: true } }, createdBy: { select: { firstName: true, lastName: true } } }, orderBy: { entryDate: 'desc' }, take: query.limit ?? 20 }),
      this.prisma.journalEntry.count({ where }),
    ]);
    return { items, total };
  }

  // ── Trial Balance ─────────────────────────────────────────────────────────

  async getTrialBalance(branchId: string | null, asOfDate: Date) {
    const accounts = await this.prisma.chartOfAccount.findMany({
      where: { isDeleted: false, status: 'ACTIVE', ...(branchId && { OR: [{ branchId }, { branchId: null }] }) },
      include: { journalLines: {
        where: { journalEntry: { status: 'POSTED', entryDate: { lte: asOfDate }, ...(branchId && { branchId }) } },
        select: { debitAmount: true, creditAmount: true },
      }},
      orderBy: { code: 'asc' },
    });

    let totalDebits = 0, totalCredits = 0;
    const rows = accounts.map((acc) => {
      const debitTotal = acc.journalLines.reduce((s, l) => s + Number(l.debitAmount), 0);
      const creditTotal = acc.journalLines.reduce((s, l) => s + Number(l.creditAmount), 0);
      const balance = acc.normalBalance === 'DEBIT' ? debitTotal - creditTotal : creditTotal - debitTotal;
      const debitBalance = balance > 0 && acc.normalBalance === 'DEBIT' ? balance : 0;
      const creditBalance = balance > 0 && acc.normalBalance === 'CREDIT' ? balance : 0;
      totalDebits += debitBalance;
      totalCredits += creditBalance;
      return { code: acc.code, name: acc.name, accountType: acc.accountType, debitBalance, creditBalance };
    }).filter((r) => r.debitBalance !== 0 || r.creditBalance !== 0);

    return { rows, totalDebits, totalCredits, isBalanced: Math.abs(totalDebits - totalCredits) < 0.01, asOfDate };
  }

  // ── VAT Management ────────────────────────────────────────────────────────

  async createVatReturn(dto: any, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) throw new ForbiddenException('Access denied');
    const year = new Date().getFullYear();
    const month = dto.periodMonth;
    const code = `VAT-${year}-${String(month).padStart(2, '0')}`;
    const existing = await this.prisma.vatReturn.findFirst({ where: { code, branchId: dto.branchId } });
    if (existing) throw new ConflictException('VAT return already exists for this period');
    const netVatPayable = Number(dto.outputVatAmount) - Number(dto.inputVatAmount);
    const vr = await this.prisma.vatReturn.create({
      data: { code, periodId: dto.periodId, branchId: dto.branchId, outputVatAmount: dto.outputVatAmount, taxableSales: dto.taxableSales, exemptSales: dto.exemptSales ?? 0, inputVatAmount: dto.inputVatAmount, taxablePurchases: dto.taxablePurchases, netVatPayable, createdById: actorId },
    });
    await this.audit.log({ action: 'create', resource: 'vat_return', entityId: vr.id, afterState: vr, actorId });
    return vr;
  }

  // ── Bank Reconciliation ───────────────────────────────────────────────────

  async reconcileTransaction(transactionId: string, journalEntryId: string, actorId: string) {
    const txn = await this.prisma.bankTransaction.findUnique({ where: { id: transactionId } });
    if (!txn) throw new NotFoundException('Bank transaction not found');
    if (txn.reconciliationStatus === 'RECONCILED') throw new BadRequestException('Transaction already reconciled');
    const updated = await this.prisma.bankTransaction.update({
      where: { id: transactionId },
      data: { reconciliationStatus: 'RECONCILED', matchedJournalId: journalEntryId, matchedAt: new Date(), matchedById: actorId },
    });
    await this.audit.log({ action: 'reconcile', resource: 'bank_transaction', entityId: transactionId, beforeState: { status: 'UNRECONCILED' }, afterState: { status: 'RECONCILED', journalEntryId }, actorId });
    return updated;
  }

  // ── Financial Reports ─────────────────────────────────────────────────────

  async getIncomeStatement(branchId: string | null, from: Date, to: Date) {
    const revenueTypes = ['REVENUE', 'OTHER_INCOME'];
    const expenseTypes = ['COST_OF_SALES', 'OPERATING_EXPENSE', 'OTHER_EXPENSE', 'TAX'];

    const accounts = await this.prisma.chartOfAccount.findMany({
      where: { isDeleted: false, accountType: { in: [...revenueTypes, ...expenseTypes] as any }, ...(branchId && { OR: [{ branchId }, { branchId: null }] }) },
      include: { journalLines: { where: { journalEntry: { status: 'POSTED', entryDate: { gte: from, lte: to }, ...(branchId && { branchId }) } }, select: { debitAmount: true, creditAmount: true } } },
      orderBy: { code: 'asc' },
    });

    const revenue: any[] = [], costOfSales: any[] = [], opex: any[] = [], otherIncome: any[] = [], otherExpense: any[] = [], tax: any[] = [];
    accounts.forEach((acc) => {
      const net = acc.normalBalance === 'CREDIT'
        ? acc.journalLines.reduce((s, l) => s + Number(l.creditAmount) - Number(l.debitAmount), 0)
        : acc.journalLines.reduce((s, l) => s + Number(l.debitAmount) - Number(l.creditAmount), 0);
      if (net === 0) return;
      const row = { code: acc.code, name: acc.name, amount: net };
      if (acc.accountType === 'REVENUE') revenue.push(row);
      else if (acc.accountType === 'COST_OF_SALES') costOfSales.push(row);
      else if (acc.accountType === 'OPERATING_EXPENSE') opex.push(row);
      else if (acc.accountType === 'OTHER_INCOME') otherIncome.push(row);
      else if (acc.accountType === 'OTHER_EXPENSE') otherExpense.push(row);
      else if (acc.accountType === 'TAX') tax.push(row);
    });

    const totalRevenue = revenue.reduce((s, r) => s + r.amount, 0);
    const totalCOS = costOfSales.reduce((s, r) => s + r.amount, 0);
    const grossProfit = totalRevenue - totalCOS;
    const totalOpex = opex.reduce((s, r) => s + r.amount, 0);
    const ebit = grossProfit - totalOpex;
    const netOther = otherIncome.reduce((s, r) => s + r.amount, 0) - otherExpense.reduce((s, r) => s + r.amount, 0);
    const totalTax = tax.reduce((s, r) => s + r.amount, 0);
    const netProfit = ebit + netOther - totalTax;

    return { revenue, costOfSales, grossProfit, opex, ebit, otherIncome, otherExpense, tax, netProfit, period: { from, to } };
  }

  async getFinanceStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };
    const now = new Date();
    const yearStart = new Date(now.getFullYear(), 0, 1);

    const [journalCount, pendingJournals, openPeriods, lockedPeriods, vatDrafts] = await Promise.all([
      this.prisma.journalEntry.count({ where: { ...branchFilter, status: 'POSTED', createdAt: { gte: yearStart } } }),
      this.prisma.journalEntry.count({ where: { ...branchFilter, status: 'DRAFT' } }),
      this.prisma.accountingPeriod.count({ where: { status: 'OPEN' } }),
      this.prisma.accountingPeriod.count({ where: { status: 'LOCKED' } }),
      this.prisma.vatReturn.count({ where: { ...branchFilter, status: 'DRAFT' } }),
    ]);

    return { journalCount, pendingJournals, openPeriods, lockedPeriods, vatDrafts };
  }
}
