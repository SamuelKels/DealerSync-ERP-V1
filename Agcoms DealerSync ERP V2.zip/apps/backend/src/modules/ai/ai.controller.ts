/**
 * AGCOMS DealerSync ERP — AI Controller (Sprint 4)
 * Exposes the four Anthropic-powered AI capabilities.
 *
 * POST /api/v1/ai/forecast/inventory          — demand forecasting
 * POST /api/v1/ai/risk/invoices               — collection risk scoring
 * POST /api/v1/ai/summarise/job-card/:id      — service report summary
 * POST /api/v1/ai/search                      — NLP catalogue search
 * GET  /api/v1/ai/governance/check            — governance self-test
 */
import { Controller, Get, Post, Param, Body, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiBody, ApiParam } from '@nestjs/swagger';
import { IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { AiService } from './ai.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { JwtPayload } from '@agcoms/types';

class NlpSearchDto {
  @ApiProperty({ example: 'John Deere tractors under ₦15 million available in Abuja' })
  @IsString() @MinLength(3)
  query: string;
}

@ApiTags('ai')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('ai')
export class AiController {
  constructor(private readonly svc: AiService) {}

  @Post('forecast/inventory')
  @RequirePermission('ai:use')
  @ApiOperation({ summary: 'AI inventory demand forecast — 90-day velocity + Nigerian seasonal analysis' })
  forecastInventory(@CurrentUser() actor: JwtPayload) {
    return this.svc.forecastInventoryDemand(actor.branchId, actor);
  }

  @Post('risk/invoices')
  @RequirePermission('ai:use')
  @ApiOperation({ summary: 'AI invoice collection risk scoring with recommended actions' })
  scoreInvoiceRisk(@CurrentUser() actor: JwtPayload) {
    return this.svc.scoreInvoiceRisk(actor.branchId, actor);
  }

  @Post('summarise/job-card/:id')
  @RequirePermission('ai:use')
  @ApiOperation({ summary: 'AI service report summarisation — customer-ready plain English' })
  @ApiParam({ name: 'id', description: 'Job card UUID' })
  summariseJobCard(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return this.svc.summariseServiceReport(id, actor);
  }

  @Post('search')
  @RequirePermission('ai:use')
  @ApiOperation({ summary: 'NLP equipment catalogue search — natural language to structured filters' })
  @ApiBody({ type: NlpSearchDto })
  nlpSearch(@Body() dto: NlpSearchDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.nlpSearch(dto.query, actor.branchId, actor);
  }

  @Get('governance/check')
  @RequirePermission('ai:use')
  @ApiOperation({ summary: 'Governance self-test — verify blocked actions throw 403' })
  governanceCheck() {
    try {
      this.svc.assertAiActionPermitted('approve_financial_transaction');
      return { passed: false, error: 'GOVERNANCE FAILURE: blocked action was permitted' };
    } catch (e) {
      return {
        passed:          true,
        blockedActionsEnforced: true,
        permittedActions: ['summarize','recommend','draft','forecast','classify','search','analyse'],
        model:           'claude-sonnet-4-20250514',
      };
    }
  }
}
