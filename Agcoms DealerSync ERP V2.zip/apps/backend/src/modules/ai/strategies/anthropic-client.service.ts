/**
 * AGCOMS DealerSync ERP — AnthropicClient
 * Sprint 4 / S4-A: Singleton Anthropic SDK wrapper.
 *
 * Enforces §7 Module 13 AI Governance Rules at the infrastructure level:
 *   AI MAY:    summarize, recommend, draft, forecast, classify
 *   AI MAY NOT: approve, modify_inventory, alter_accounting, override_approval, bypass_rbac
 *
 * Every response is wrapped in the AiAdvisory envelope:
 *   { result, human_action_required: true, governance: { model, generated_at, disclaimer } }
 *
 * Design decisions:
 *   - Uses claude-sonnet-4-20250514 (cost/capability balance for ERP workloads)
 *   - Structured output via JSON mode for forecasting and classification
 *   - Temperature 0 for deterministic financial/inventory outputs
 *   - Temperature 0.3 for natural language summarisation
 *   - All prompts include the ERP system context (Nigerian agricultural equipment)
 *   - Max tokens 1024 for structured outputs, 2048 for summaries
 */
import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { ConfigService }  from '@nestjs/config';
import Anthropic          from '@anthropic-ai/sdk';

// §7 Governance — actions the AI is permanently blocked from performing
const BLOCKED_ACTIONS = new Set([
  'approve_financial_transaction',
  'modify_inventory',
  'alter_accounting_records',
  'override_approval',
  'bypass_rbac',
]);

// §7 Governance — actions the AI is permitted to perform
const PERMITTED_ACTIONS = new Set([
  'summarize', 'recommend', 'draft', 'forecast', 'classify',
  'search', 'analyse', 'explain', 'score',
]);

export interface AiAdvisory<T = unknown> {
  result:                T;
  human_action_required: true;
  governance: {
    model:        string;
    generated_at: string;
    action:       string;
    disclaimer:   string;
    input_tokens:  number;
    output_tokens: number;
  };
}

export interface AnthropicCallOptions {
  action:      string;          // Must be in PERMITTED_ACTIONS
  systemPrompt: string;
  userPrompt:   string;
  temperature?: number;         // Default: 0 for structured, 0.3 for text
  maxTokens?:   number;         // Default: 1024
  jsonMode?:    boolean;        // Wrap response in JSON parse
}

@Injectable()
export class AnthropicClientService {
  private readonly logger = new Logger(AnthropicClientService.name);
  private readonly client: Anthropic;
  private readonly model  = 'claude-sonnet-4-20250514';

  // ERP system context injected into every prompt
  private readonly systemContext = `You are an AI assistant embedded in AGCOMS DealerSync ERP,
the enterprise resource planning system for AGCOMS International Trading Limited,
an agricultural and industrial equipment dealership headquartered in Abuja, Nigeria.

AGCOMS sells John Deere, Massey Ferguson, New Holland, and Caterpillar equipment.
Key programme: NADF (National Agricultural Development Fund) tractor supply to Nigerian farmers.

CRITICAL GOVERNANCE RULES (you must never violate these):
- You are an ADVISORY system only. You NEVER take operational actions.
- You NEVER approve financial transactions, modify inventory, alter accounting records,
  override approvals, or bypass access controls.
- All your outputs are recommendations that require human review before any action is taken.
- You always acknowledge that your outputs are advisory and not authoritative.
- Financial figures in Nigeria are in Nigerian Naira (NGN) unless stated otherwise.
- Tax rates: VAT 7.5%, PAYE per PITA 2011 bands, Pension 8%/10%, NHF 2.5%.`;

  constructor(private readonly config: ConfigService) {
    this.client = new Anthropic({
      apiKey: this.config.getOrThrow<string>('ANTHROPIC_API_KEY'),
    });
  }

  // ── Core call method ─────────────────────────────────────────────────────

  async call<T = string>(opts: AnthropicCallOptions): Promise<AiAdvisory<T>> {
    // Governance check — hard block
    this.assertActionPermitted(opts.action);

    const startedAt = Date.now();

    try {
      const message = await this.client.messages.create({
        model:      this.model,
        max_tokens: opts.maxTokens ?? 1024,
        temperature: opts.temperature ?? 0,
        system:     `${this.systemContext}\n\n${opts.systemPrompt}`,
        messages:   [{ role: 'user', content: opts.userPrompt }],
      });

      const rawText = message.content
        .filter(b => b.type === 'text')
        .map(b => (b as Anthropic.TextBlock).text)
        .join('');

      let result: T;
      if (opts.jsonMode) {
        // Strip markdown code fences if present
        const cleaned = rawText.replace(/^```json\s*/i, '').replace(/\s*```$/i, '').trim();
        result = JSON.parse(cleaned) as T;
      } else {
        result = rawText as T;
      }

      const durationMs = Date.now() - startedAt;
      this.logger.log(
        `AI call [${opts.action}]: ${message.usage.input_tokens}in / ${message.usage.output_tokens}out tokens — ${durationMs}ms`,
      );

      return this.wrapAdvisory(result, opts.action, message.usage);
    } catch (err) {
      if (err instanceof SyntaxError && opts.jsonMode) {
        this.logger.error(`JSON parse failed for action ${opts.action}`);
        throw new Error(`AI returned invalid JSON for action: ${opts.action}`);
      }
      throw err;
    }
  }

  // ── Governance enforcement ─────────────────────────────────────────────

  assertActionPermitted(action: string): void {
    if (BLOCKED_ACTIONS.has(action)) {
      throw new ForbiddenException(
        `AI governance violation: action '${action}' is permanently blocked. ` +
        `AI may only: ${[...PERMITTED_ACTIONS].join(', ')}.`,
      );
    }
  }

  // ── Advisory envelope ──────────────────────────────────────────────────

  private wrapAdvisory<T>(
    result:  T,
    action:  string,
    usage:   { input_tokens: number; output_tokens: number },
  ): AiAdvisory<T> {
    return {
      result,
      human_action_required: true,
      governance: {
        model:        this.model,
        generated_at: new Date().toISOString(),
        action,
        disclaimer:
          'This output is AI-generated advisory only. ' +
          'It requires human review and approval before any operational action is taken. ' +
          'AGCOMS DealerSync ERP AI cannot approve transactions, modify records, or bypass controls.',
        input_tokens:  usage.input_tokens,
        output_tokens: usage.output_tokens,
      },
    };
  }
}
