/**
 * Auth module — Sprint 1 Fix.
 * Wires JWT strategy, Passport, and provides auth guards globally.
 */
import { Module }          from '@nestjs/common';
import { PassportModule }  from '@nestjs/passport';
import { JwtModule }       from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { AuthController }  from './auth.controller';
import { AuthService }     from './auth.service';
import { JwtStrategy }     from '../../common/guards/jwt.strategy';
import { PasskeyService }   from './passkey/passkey.service';
import { PasskeyController } from './passkey/passkey.controller';

@Module({
  imports: [
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.registerAsync({
      imports:    [ConfigModule],
      inject:     [ConfigService],
      useFactory: (config: ConfigService) => {
        const privateKeyB64 = config.getOrThrow<string>('JWT_PRIVATE_KEY');
        const privateKey    = Buffer.from(privateKeyB64, 'base64').toString('utf8');
        return {
          privateKey,
          signOptions: { algorithm: 'RS256', expiresIn: config.get('JWT_ACCESS_EXPIRY', '15m') },
        };
      },
    }),
  ],
  controllers: [AuthController, PasskeyController],
  providers:   [AuthService, JwtStrategy, PasskeyService],
  exports:     [AuthService, JwtModule],
})
export class AuthModule {}
