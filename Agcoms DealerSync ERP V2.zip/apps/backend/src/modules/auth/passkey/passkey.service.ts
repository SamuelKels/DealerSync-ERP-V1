/**
 * AGCOMS DealerSync ERP — PasskeyService
 * Sprint 5 / S5-C: FIDO2 WebAuthn passkey authentication.
 *
 * Passkeys provide phishing-resistant, password-free authentication.
 * They are bound to the device and the origin (domain) — a phishing site
 * cannot intercept passkey assertions.
 *
 * Supported authenticators:
 *   - Touch ID / Face ID (macOS, iOS)
 *   - Windows Hello (Windows 10+)
 *   - Android biometric (Pixel, Samsung)
 *   - Hardware security keys (YubiKey, FIDO2 USB)
 *
 * Flow:
 *   REGISTRATION:
 *     1. Client calls GET /auth/passkey/register/options
 *     2. Browser prompts biometric / PIN
 *     3. Client calls POST /auth/passkey/register/verify
 *     4. Server stores PasskeyAuthenticator record
 *
 *   AUTHENTICATION:
 *     1. Client calls POST /auth/passkey/authenticate/options (with email)
 *     2. Browser prompts biometric
 *     3. Client calls POST /auth/passkey/authenticate/verify
 *     4. Server returns JWT access token + sets refresh cookie
 *
 * Nigerian market note: Passkeys work without SMS (no SIM-swap risk) and
 * without an authenticator app (no app install required). They work on
 * offline devices — assertion is computed locally using the stored private key.
 *
 * §5 Security: "MFA/TOTP" — passkeys provide stronger MFA than TOTP.
 */
import { Injectable, Logger, UnauthorizedException, NotFoundException, ConflictException } from '@nestjs/common';
import { ConfigService }   from '@nestjs/config';
import {
  generateRegistrationOptions,
  verifyRegistrationResponse,
  generateAuthenticationOptions,
  verifyAuthenticationResponse,
  type GenerateRegistrationOptionsOpts,
  type VerifyRegistrationResponseOpts,
  type GenerateAuthenticationOptionsOpts,
  type VerifyAuthenticationResponseOpts,
} from '@simplewebauthn/server';
import type { AuthenticatorTransportFuture, CredentialDeviceType } from '@simplewebauthn/types';
import { PrismaService }  from '../../../prisma/prisma.service';
import { AuditService }   from '../../../audit/audit.service';
import { JwtService }     from '@nestjs/jwt';
import type { JwtPayload } from '@agcoms/types';

export interface PasskeyRegistrationOptions {
  challenge:      string;
  challengeId:    string;
  options:        object;
}

export interface PasskeyAuthOptions {
  challenge:      string;
  challengeId:    string;
  options:        object;
}

@Injectable()
export class PasskeyService {
  private readonly logger      = new Logger(PasskeyService.name);
  private readonly rpId:         string;
  private readonly rpName:       string;
  private readonly origin:       string;

  constructor(
    private readonly prisma:   PrismaService,
    private readonly audit:    AuditService,
    private readonly jwt:      JwtService,
    private readonly config:   ConfigService,
  ) {
    this.rpId   = this.config.get<string>('WEBAUTHN_RP_ID',   'localhost');
    this.rpName = this.config.get<string>('WEBAUTHN_RP_NAME', 'AGCOMS DealerSync ERP');
    this.origin = this.config.get<string>('WEBAUTHN_ORIGIN',  'http://localhost:3000');
  }

  // ── Registration ──────────────────────────────────────────────────────────

  /** Step 1: Generate registration options for a logged-in user */
  async generateRegistrationOptions(userId: string): Promise<PasskeyRegistrationOptions> {
    const user = await this.prisma.user.findUnique({
      where:   { id: userId },
      include: { passkeys: { where: { isActive: true }, select: { credentialId: true, transports: true } } },
    });
    if (!user) throw new NotFoundException('User not found');

    const opts: GenerateRegistrationOptionsOpts = {
      rpName:              this.rpName,
      rpID:                this.rpId,
      userID:              Buffer.from(userId),
      userName:            user.email,
      userDisplayName:     `${user.firstName} ${user.lastName}`,
      timeout:             60_000,    // 60 seconds to complete biometric
      attestationType:     'none',    // 'none' = don't require hardware attestation (simpler)
      excludeCredentials:  user.passkeys.map(pk => ({
        id:         pk.credentialId,
        transports: pk.transports as AuthenticatorTransportFuture[],
      })),
      authenticatorSelection: {
        residentKey:        'preferred',    // Allow passkeys stored on device
        userVerification:   'preferred',    // Prefer biometric/PIN verification
        authenticatorAttachment: 'platform', // Prefer on-device (Touch ID, Face ID, Windows Hello)
      },
      supportedAlgorithmIDs: [-7, -257],    // ES256 + RS256
    };

    const options   = await generateRegistrationOptions(opts);
    const challenge = await this.prisma.passkeyChallenge.create({
      data: {
        userId,
        challenge:   options.challenge,
        type:        'registration',
        expiresAt:   new Date(Date.now() + 5 * 60_000),   // 5 minutes
      },
    });

    return { challenge: options.challenge, challengeId: challenge.id, options };
  }

  /** Step 2: Verify registration and store the authenticator */
  async verifyRegistration(
    userId:        string,
    challengeId:   string,
    response:      any,
    deviceName?:   string,
  ): Promise<{ verified: boolean; credentialId: string }> {
    const challengeRecord = await this.prisma.passkeyChallenge.findUnique({
      where: { id: challengeId },
    });

    if (!challengeRecord || challengeRecord.userId !== userId) {
      throw new UnauthorizedException('Invalid or expired registration challenge');
    }
    if (challengeRecord.usedAt) {
      throw new UnauthorizedException('Challenge already used');
    }
    if (challengeRecord.expiresAt < new Date()) {
      throw new UnauthorizedException('Registration challenge expired — please restart');
    }

    const opts: VerifyRegistrationResponseOpts = {
      response,
      expectedChallenge: challengeRecord.challenge,
      expectedOrigin:    this.origin,
      expectedRPID:      this.rpId,
      requireUserVerification: false,
    };

    const verification = await verifyRegistrationResponse(opts);

    if (!verification.verified || !verification.registrationInfo) {
      throw new UnauthorizedException('WebAuthn registration verification failed');
    }

    const { credentialID, credentialPublicKey, counter, credentialDeviceType, credentialBackedUp } =
      verification.registrationInfo;

    const credentialIdBase64 = Buffer.from(credentialID).toString('base64url');

    // Check for duplicate credential
    const existing = await this.prisma.passkeyAuthenticator.findUnique({
      where: { credentialId: credentialIdBase64 },
    });
    if (existing) throw new ConflictException('This passkey is already registered to an account');

    await this.prisma.$transaction([
      this.prisma.passkeyAuthenticator.create({
        data: {
          userId,
          credentialId:         credentialIdBase64,
          credentialPublicKey:  Buffer.from(credentialPublicKey),
          counter:              BigInt(counter),
          credentialDeviceType: credentialDeviceType as CredentialDeviceType,
          credentialBackedUp,
          transports:           response.response?.transports ?? [],
          deviceName:           deviceName ?? 'My Passkey',
          lastUsedAt:           new Date(),
        },
      }),
      this.prisma.passkeyChallenge.update({
        where: { id: challengeId },
        data:  { usedAt: new Date() },
      }),
    ]);

    await this.audit.log({
      action:    'auth.passkey.registered',
      resource:  'PasskeyAuthenticator',
      entityId:  userId,
      actorId:   userId,
      actorRole: 'USER',
      afterState: { credentialId: credentialIdBase64.slice(0, 12) + '…', deviceName },
    });

    this.logger.log(`Passkey registered for user ${userId}: ${deviceName ?? 'unnamed'}`);
    return { verified: true, credentialId: credentialIdBase64 };
  }

  // ── Authentication ─────────────────────────────────────────────────────────

  /** Step 1: Generate authentication challenge (provide email to limit credentials) */
  async generateAuthenticationOptions(email?: string): Promise<PasskeyAuthOptions> {
    let allowCredentials: Array<{ id: string; transports?: AuthenticatorTransportFuture[] }> = [];

    if (email) {
      const user = await this.prisma.user.findUnique({
        where:   { email },
        include: { passkeys: { where: { isActive: true }, select: { credentialId: true, transports: true } } },
      });
      if (user?.passkeys.length) {
        allowCredentials = user.passkeys.map(pk => ({
          id:         pk.credentialId,
          transports: pk.transports as AuthenticatorTransportFuture[],
        }));
      }
    }

    const opts: GenerateAuthenticationOptionsOpts = {
      rpID:               this.rpId,
      timeout:            60_000,
      allowCredentials,
      userVerification:   'preferred',
    };

    const options   = await generateAuthenticationOptions(opts);
    const challenge = await this.prisma.passkeyChallenge.create({
      data: {
        challenge:  options.challenge,
        type:       'authentication',
        expiresAt:  new Date(Date.now() + 5 * 60_000),
      },
    });

    return { challenge: options.challenge, challengeId: challenge.id, options };
  }

  /** Step 2: Verify assertion and return JWT tokens */
  async verifyAuthentication(
    challengeId: string,
    response:    any,
    ip:          string,
  ): Promise<{ accessToken: string; user: { id: string; email: string; role: string } }> {
    const challengeRecord = await this.prisma.passkeyChallenge.findUnique({
      where: { id: challengeId },
    });

    if (!challengeRecord || challengeRecord.type !== 'authentication') {
      throw new UnauthorizedException('Invalid authentication challenge');
    }
    if (challengeRecord.usedAt || challengeRecord.expiresAt < new Date()) {
      throw new UnauthorizedException('Challenge expired or already used');
    }

    // Look up the authenticator by credential ID
    const credentialId = response.id as string;
    const authenticator = await this.prisma.passkeyAuthenticator.findUnique({
      where:   { credentialId },
      include: { user: { include: { role: true, branch: { select: { id: true, code: true } } } } },
    });

    if (!authenticator || !authenticator.isActive) {
      throw new UnauthorizedException('Passkey not found or revoked');
    }
    if (!authenticator.user.isActive) {
      throw new UnauthorizedException('User account is inactive');
    }

    const opts: VerifyAuthenticationResponseOpts = {
      response,
      expectedChallenge:      challengeRecord.challenge,
      expectedOrigin:         this.origin,
      expectedRPID:           this.rpId,
      authenticator: {
        credentialID:         credentialId,
        credentialPublicKey:  authenticator.credentialPublicKey,
        counter:              Number(authenticator.counter),
        transports:           authenticator.transports as AuthenticatorTransportFuture[],
      },
      requireUserVerification: false,
    };

    const verification = await verifyAuthenticationResponse(opts);

    if (!verification.verified) {
      throw new UnauthorizedException('Passkey authentication failed — invalid assertion');
    }

    // Update counter (replay attack prevention)
    await this.prisma.$transaction([
      this.prisma.passkeyAuthenticator.update({
        where: { credentialId },
        data:  { counter: BigInt(verification.authenticationInfo.newCounter), lastUsedAt: new Date() },
      }),
      this.prisma.passkeyChallenge.update({
        where: { id: challengeId },
        data:  { usedAt: new Date() },
      }),
    ]);

    // Issue JWT
    const user = authenticator.user;
    const payload: Partial<JwtPayload> = {
      sub:        user.id,
      email:      user.email,
      roles:      [user.role.name],
      branchId:   user.branch.id,
      branchCode: user.branch.code,
      isSuperAdmin: user.isSuperAdmin,
    };

    const accessToken = this.jwt.sign(payload);

    await this.audit.log({
      action:    'auth.passkey.login',
      resource:  'User',
      entityId:  user.id,
      actorId:   user.id,
      actorRole: user.role.name,
      afterState: { method: 'passkey', ip, deviceName: authenticator.deviceName },
    });

    this.logger.log(`Passkey login: ${user.email} (${authenticator.deviceName ?? 'unknown device'})`);
    return {
      accessToken,
      user: { id: user.id, email: user.email, role: user.role.name },
    };
  }

  // ── Passkey management ─────────────────────────────────────────────────────

  async listPasskeys(userId: string) {
    return this.prisma.passkeyAuthenticator.findMany({
      where:   { userId, isActive: true },
      select: {
        id: true, credentialId: true, deviceName: true,
        credentialDeviceType: true, credentialBackedUp: true,
        transports: true, lastUsedAt: true, createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  async revokePasskey(passkeyId: string, userId: string) {
    const pk = await this.prisma.passkeyAuthenticator.findFirst({
      where: { id: passkeyId, userId },
    });
    if (!pk) throw new NotFoundException('Passkey not found');

    await this.prisma.passkeyAuthenticator.update({
      where: { id: passkeyId },
      data:  { isActive: false },
    });

    await this.audit.log({
      action:    'auth.passkey.revoked',
      resource:  'PasskeyAuthenticator',
      entityId:  passkeyId,
      actorId:   userId,
      actorRole: 'USER',
      afterState: { deviceName: pk.deviceName, revoked: true },
    });

    this.logger.log(`Passkey revoked: ${passkeyId} for user ${userId}`);
  }
}
