/**
 * AGCOMS DealerSync ERP — Procurement Service
 * Module 6: Vendors, requisitions, purchase orders, GRNs, invoice matching,
 *           vendor scoring, landed cost calculation, approval matrix.
 *
 * V2 NOTE: This is a scaffold service. Domain logic for vendor/PO/GRN flows
 * is split across separate files (vendor.service.ts, purchase-order.service.ts,
 * grn.service.ts) which are wired into the same module. This file provides the
 * generic findAll/findOne/create/update/remove operations the base controller
 * calls.
 */
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService }  from '../../audit/audit.service';
import type { JwtPayload } from '@agcoms/types';

@Injectable()
export class ProcurementService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit:  AuditService,
  ) {}

  async findAll(query: Record<string, string> & { branchId?: string }, actor: JwtPayload) {
    const where: any = { isDeleted: false };
    if (query.branchId) where.branchId = query.branchId;

    const [items, total] = await Promise.all([
      this.prisma.vendor.findMany({
        where,
        take: parseInt(query.limit ?? '20', 10),
        orderBy: { createdAt: 'desc' },
      }),
      this.prisma.vendor.count({ where }),
    ]);

    return { items, total };
  }

  async findOne(id: string, actor: JwtPayload) {
    const vendor = await this.prisma.vendor.findUnique({ where: { id } });
    if (!vendor) throw new NotFoundException(`Vendor ${id} not found`);
    return vendor;
  }

  async create(dto: Record<string, unknown>, actor: JwtPayload) {
    const vendor = await this.prisma.vendor.create({ data: dto as any });
    await this.audit.log({
      action:    'procurement.vendor.created',
      resource:  'Vendor',
      entityId:  vendor.id,
      actorId:   actor.sub,
      actorRole: actor.roles?.[0] ?? 'UNKNOWN',
      afterState: vendor,
    });
    return vendor;
  }

  async update(id: string, dto: Record<string, unknown>, actor: JwtPayload) {
    const before = await this.findOne(id, actor);
    const after  = await this.prisma.vendor.update({ where: { id }, data: dto as any });
    await this.audit.log({
      action:    'procurement.vendor.updated',
      resource:  'Vendor',
      entityId:  id,
      actorId:   actor.sub,
      actorRole: actor.roles?.[0] ?? 'UNKNOWN',
      beforeState: before,
      afterState:  after,
    });
    return after;
  }

  async remove(id: string, actor: JwtPayload) {
    await this.findOne(id, actor);
    await this.prisma.vendor.update({ where: { id }, data: { isDeleted: true } as any });
    await this.audit.log({
      action:    'procurement.vendor.deleted',
      resource:  'Vendor',
      entityId:  id,
      actorId:   actor.sub,
      actorRole: actor.roles?.[0] ?? 'UNKNOWN',
    });
    return { deleted: true };
  }
}
