import { Module }                     from '@nestjs/common';
import { AiModule }    from '../ai/ai.module';
import { BullModule }                  from '@nestjs/bull';
import { FleetController }             from './fleet.controller';
import { FleetService }                from './fleet.service';
import { FleetMaintenanceService }     from './maintenance/fleet-maintenance.service';
import { FleetMaintenanceController }  from './maintenance/fleet-maintenance.controller';
import { FleetMaintenanceProcessor }   from './maintenance/fleet-maintenance.processor';
import { FLEET_MAINTENANCE_QUEUE }     from './maintenance/fleet-maintenance.service';

@Module({
  imports: [
    BullModule.registerQueue({ name: FLEET_MAINTENANCE_QUEUE }),
    AiModule,
  ],
  controllers: [FleetController, FleetMaintenanceController],
  providers:   [FleetService, FleetMaintenanceService, FleetMaintenanceProcessor],
  exports:     [FleetService, FleetMaintenanceService],
})
export class FleetModule {}
