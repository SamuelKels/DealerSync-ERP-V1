// AGCOMS DealerSync — Fleet & Telematics Module (Module 14)
// GPS tracking, fuel monitoring, maintenance alerts, route analytics, telemetry readiness
import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prisma, FleetAssetStatus, MaintenanceRiskLevel } from '@prisma/client';
import { paginate, PaginationDto } from '../../common/pagination';

@Injectable()
export class FleetService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextCode() {
    const count = await this.prisma.fleetAsset.count();
    return `FLT-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Fleet Assets ──────────────────────────────────────────────────────────

  async listFleetAssets(query, actorBranchId, isSuperAdmin) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.assetType && { assetType: query.assetType }),
      ...(query.driverId && { driverId: query.driverId }),
    };
    return paginate(this.prisma.fleetAsset, { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.fleetAsset.findFirst({ where: { id }, select: { createdAt: true } }));
  }

  async getFleetAsset(id, actorBranchId, isSuperAdmin) {
    const asset = await this.prisma.fleetAsset.findFirst({
      where: { id, isDeleted: false },
      include: {
        branch: { select: { id: true, code: true, name: true } },
        driver: { select: { id: true, firstName: true, lastName: true, email: true } },
        stockItem: { include: { product: { select: { id: true, sku: true, name: true } } } },
        maintenanceAlerts: { where: { isActive: true }, orderBy: { level: 'asc' } },
        _count: { select: { fuelLogs: true, trips: true, maintenanceLogs: true } },
      },
    });
    if (!asset) throw new NotFoundException('Fleet asset not found');
    if (!isSuperAdmin && asset.branchId !== actorBranchId) throw new ForbiddenException('Access denied');
    return asset;
  }

  async createFleetAsset(dto, actorId, actorBranchId, isSuperAdmin) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) throw new ForbiddenException('Cannot create fleet asset for another branch');
    const code = await this.nextCode();
    const asset = await this.prisma.fleetAsset.create({
      data: { ...dto, code, status: 'AVAILABLE', createdById: actorId },
    });
    await this.audit.log({ action: 'create', resource: 'fleet_asset', entityId: asset.id, afterState: asset, actorId });
    this.events.emit('fleet.asset.created', { assetId: asset.id });
    // Auto-create compliance alerts if expiry dates provided
    await this.checkAndCreateComplianceAlerts(asset.id, asset);
    return asset;
  }

  async updateFleetAsset(id, dto, actorId, actorBranchId, isSuperAdmin) {
    const existing = await this.getFleetAsset(id, actorBranchId, isSuperAdmin);
    const updated = await this.prisma.fleetAsset.update({ where: { id }, data: { ...dto, updatedAt: new Date() } });
    await this.audit.log({ action: 'update', resource: 'fleet_asset', entityId: id, beforeState: existing, afterState: updated, actorId });
    await this.checkAndCreateComplianceAlerts(id, updated);
    return updated;
  }

  async updateAssetStatus(id, status, actorId, actorBranchId, isSuperAdmin) {
    const asset = await this.getFleetAsset(id, actorBranchId, isSuperAdmin);
    const updated = await this.prisma.fleetAsset.update({
      where: { id }, data: { status, updatedAt: new Date() },
    });
    await this.audit.log({ action: `fleet_status_${status.toLowerCase()}`, resource: 'fleet_asset', entityId: id, beforeState: { status: asset.status }, afterState: { status }, actorId });
    this.events.emit('fleet.asset.status_changed', { assetId: id, status });
    return updated;
  }

  private async checkAndCreateComplianceAlerts(assetId, asset) {
    const now = new Date();
    const warningDays = 30;
    const warningDate = new Date(now.getTime() + warningDays * 24 * 60 * 60 * 1000);
    const alerts: Array<{ type: string; level: string; title: string; dueDate: any }> = [];
    if (asset.insuranceExpiry && new Date(asset.insuranceExpiry) <= warningDate) {
      alerts.push({ type: 'INSURANCE_EXPIRY', level: new Date(asset.insuranceExpiry) <= now ? 'CRITICAL' : 'WARNING', title: 'Insurance expiring', dueDate: asset.insuranceExpiry });
    }
    if (asset.roadworthyExpiry && new Date(asset.roadworthyExpiry) <= warningDate) {
      alerts.push({ type: 'ROADWORTHY_EXPIRY', level: new Date(asset.roadworthyExpiry) <= now ? 'CRITICAL' : 'WARNING', title: 'Roadworthy certificate expiring', dueDate: asset.roadworthyExpiry });
    }
    for (const a of alerts) {
      const exists = await this.prisma.fleetMaintenanceAlert.findFirst({
        where: { fleetAssetId: assetId, alertType: a.type, isActive: true },
      });
      if (!exists) {
        await this.prisma.fleetMaintenanceAlert.create({
          data: { fleetAssetId: assetId, level: a.level, alertType: a.type, title: a.title, description: `${a.title} soon or already expired`, dueDate: a.dueDate },
        });
      }
    }
  }

  // ── GPS Readings ──────────────────────────────────────────────────────────

  async recordGpsReading(dto, actorId) {
    // Telemetry append-only — no updates allowed
    const reading = await this.prisma.gpsReading.create({ data: { ...dto, recordedAt: dto.recordedAt ?? new Date() } });
    // Update asset odometer / engine hours
    if (dto.odometerKm || dto.engineHours) {
      await this.prisma.fleetAsset.update({
        where: { id: dto.fleetAssetId },
        data: {
          ...(dto.odometerKm && { odometerKm: dto.odometerKm }),
          ...(dto.engineHours && { engineHours: dto.engineHours }),
          updatedAt: new Date(),
        },
      });
    }
    this.events.emit('fleet.gps.reading', { assetId: dto.fleetAssetId, readingId: reading.id });
    return reading;
  }

  async getLatestGpsReadings(branchId, isSuperAdmin, actorBranchId) {
    const allowedBranch = isSuperAdmin ? branchId : actorBranchId;
    const assets = await this.prisma.fleetAsset.findMany({
      where: { isDeleted: false, ...(allowedBranch && { branchId: allowedBranch }) },
      select: { id: true, code: true, name: true, registrationNo: true, status: true, driverId: true },
    });
    const readingsWithAssets = await Promise.all(
      assets.map(async (asset) => {
        const latest = await this.prisma.gpsReading.findFirst({
          where: { fleetAssetId: asset.id },
          orderBy: { recordedAt: 'desc' },
        });
        return { ...asset, latestPosition: latest };
      }),
    );
    return readingsWithAssets;
  }

  // ── Fuel Logs ─────────────────────────────────────────────────────────────

  async logFuel(dto, actorId, actorBranchId, isSuperAdmin) {
    const asset = await this.getFleetAsset(dto.fleetAssetId, actorBranchId, isSuperAdmin);
    const totalCost = dto.litres * dto.pricePerLitre;
    const log = await this.prisma.fuelLog.create({
      data: { ...dto, totalCost, filledById: actorId, filledAt: dto.filledAt ?? new Date() },
    });
    if (dto.odometerKm) {
      await this.prisma.fleetAsset.update({ where: { id: dto.fleetAssetId }, data: { odometerKm: dto.odometerKm } });
    }
    await this.audit.log({ action: 'fuel_log', resource: 'fleet_asset', entityId: dto.fleetAssetId, afterState: { litres: dto.litres, cost: totalCost }, actorId });
    this.events.emit('fleet.fuel.logged', { assetId: dto.fleetAssetId, logId: log.id });
    return log;
  }

  async getFuelLogs(assetId, query) {
    return paginate(
      this.prisma.fuelLog,
      { where: { fleetAssetId: assetId }, cursor: query.cursor, limit: query.limit ?? 20 },
      (id) => this.prisma.fuelLog.findFirst({ where: { id }, select: { filledAt: true } }),
    );
  }

  // ── Trips ─────────────────────────────────────────────────────────────────

  async startTrip(dto, actorId, actorBranchId, isSuperAdmin) {
    const asset = await this.getFleetAsset(dto.fleetAssetId, actorBranchId, isSuperAdmin);
    if (asset.status !== 'AVAILABLE') throw new BadRequestException('Asset is not available for a trip');
    const trip = await this.prisma.$transaction(async (tx) => {
      const t = await tx.fleetTrip.create({
        data: {
          fleetAssetId: dto.fleetAssetId, driverId: dto.driverId ?? actorId,
          purpose: dto.purpose, originAddr: dto.originAddr, destAddr: dto.destAddr,
          startOdoKm: dto.startOdoKm, startedAt: new Date(), branchId: dto.branchId ?? asset.branchId,
        },
      });
      await tx.fleetAsset.update({ where: { id: dto.fleetAssetId }, data: { status: 'IN_USE', driverId: dto.driverId ?? actorId } });
      return t;
    });
    await this.audit.log({ action: 'trip_start', resource: 'fleet_asset', entityId: dto.fleetAssetId, afterState: { tripId: trip.id }, actorId });
    this.events.emit('fleet.trip.started', { assetId: dto.fleetAssetId, tripId: trip.id });
    return trip;
  }

  async endTrip(tripId, endOdoKm, notes, actorId) {
    const trip = await this.prisma.fleetTrip.findUnique({ where: { id: tripId } });
    if (!trip) throw new NotFoundException('Trip not found');
    if (trip.endedAt) throw new BadRequestException('Trip already ended');
    const distanceKm = endOdoKm - Number(trip.startOdoKm);
    const updated = await this.prisma.$transaction(async (tx) => {
      const t = await tx.fleetTrip.update({
        where: { id: tripId }, data: { endOdoKm, distanceKm, endedAt: new Date(), notes },
      });
      await tx.fleetAsset.update({
        where: { id: trip.fleetAssetId }, data: { status: 'AVAILABLE', odometerKm: endOdoKm, driverId: null },
      });
      return t;
    });
    await this.audit.log({ action: 'trip_end', resource: 'fleet_asset', entityId: trip.fleetAssetId, afterState: { tripId, distanceKm }, actorId });
    this.events.emit('fleet.trip.ended', { assetId: trip.fleetAssetId, tripId, distanceKm });
    return updated;
  }

  // ── Maintenance Alerts ────────────────────────────────────────────────────

  async getActiveAlerts(actorBranchId, isSuperAdmin) {
    const allowedBranch = isSuperAdmin ? undefined : actorBranchId;
    return this.prisma.fleetMaintenanceAlert.findMany({
      where: {
        isActive: true,
        ...(allowedBranch && { fleetAsset: { branchId: allowedBranch } }),
      },
      include: { fleetAsset: { select: { id: true, code: true, name: true, registrationNo: true, branchId: true } } },
      orderBy: [{ level: 'asc' }, { dueDate: 'asc' }],
    });
  }

  async acknowledgeAlert(id, actorId) {
    const alert = await this.prisma.fleetMaintenanceAlert.findUnique({ where: { id } });
    if (!alert) throw new NotFoundException('Alert not found');
    const updated = await this.prisma.fleetMaintenanceAlert.update({
      where: { id }, data: { acknowledgedAt: new Date(), acknowledgedById: actorId },
    });
    await this.audit.log({ action: 'alert_acknowledged', resource: 'fleet_alert', entityId: id, beforeState: { acknowledgedAt: null }, afterState: { acknowledgedAt: new Date() }, actorId });
    return updated;
  }

  // ── Maintenance Logs ──────────────────────────────────────────────────────

  async logMaintenance(dto, actorId, actorBranchId, isSuperAdmin) {
    const asset = await this.getFleetAsset(dto.fleetAssetId, actorBranchId, isSuperAdmin);
    const log = await this.prisma.fleetMaintenanceLog.create({
      data: { ...dto, performedById: actorId },
    });
    // Update odometer if provided
    if (dto.odometerKm) {
      await this.prisma.fleetAsset.update({ where: { id: dto.fleetAssetId }, data: { odometerKm: dto.odometerKm } });
    }
    // Resolve related alert if any
    if (dto.resolveAlertType) {
      await this.prisma.fleetMaintenanceAlert.updateMany({
        where: { fleetAssetId: dto.fleetAssetId, alertType: dto.resolveAlertType, isActive: true },
        data: { isActive: false, resolvedAt: new Date() },
      });
    }
    await this.audit.log({ action: 'maintenance_logged', resource: 'fleet_asset', entityId: dto.fleetAssetId, afterState: log, actorId });
    this.events.emit('fleet.maintenance.logged', { assetId: dto.fleetAssetId, logId: log.id });
    return log;
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getFleetStats(actorBranchId, isSuperAdmin) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };
    const [total, available, inUse, maintenance, criticalAlerts, fuelThisMonth] = await Promise.all([
      this.prisma.fleetAsset.count({ where: { ...branchFilter, isDeleted: false } }),
      this.prisma.fleetAsset.count({ where: { ...branchFilter, isDeleted: false, status: 'AVAILABLE' } }),
      this.prisma.fleetAsset.count({ where: { ...branchFilter, isDeleted: false, status: 'IN_USE' } }),
      this.prisma.fleetAsset.count({ where: { ...branchFilter, isDeleted: false, status: 'UNDER_MAINTENANCE' } }),
      this.prisma.fleetMaintenanceAlert.count({ where: { isActive: true, level: 'CRITICAL', ...(branchFilter.branchId && { fleetAsset: branchFilter }) } }),
      this.prisma.fuelLog.aggregate({
        where: { fleetAsset: branchFilter, filledAt: { gte: new Date(new Date().setDate(1)) } },
        _sum: { totalCost: true, litres: true },
      }),
    ]);
    return {
      total, available, inUse, maintenance,
      utilisation: total > 0 ? Math.round((inUse / total) * 100) : 0,
      criticalAlerts,
      fuelCostMonth: Number(fuelThisMonth._sum.totalCost ?? 0),
      fuelLitresMonth: Number(fuelThisMonth._sum.litres ?? 0),
    };
  }
}
