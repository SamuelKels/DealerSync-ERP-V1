/**
 * AGCOMS DealerSync ERP — Predictive Maintenance Controller
 * Sprint 6 / S6-A
 *
 * POST /api/v1/fleet/maintenance/score         — score all assets now
 * GET  /api/v1/fleet/maintenance/scores        — latest scores (read from DB)
 * GET  /api/v1/fleet/maintenance/summary       — risk level count summary
 */
import { Controller, Get, Post, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { PredictiveMaintenanceService }  from './predictive-maintenance.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../../common/guards/auth.guards';
import { CurrentUser }                   from '../../../common/decorators/current-user.decorator';
import type { JwtPayload }               from '@agcoms/types';

@ApiTags('fleet-maintenance')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('fleet/maintenance')
export class PredictiveMaintenanceController {
  constructor(private readonly svc: PredictiveMaintenanceService) {}

  @Post('score')
  @RequirePermission('fleet:write')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Score all fleet assets — generates predictive maintenance risk scores' })
  scoreAll(@CurrentUser() actor: JwtPayload) {
    return this.svc.scoreAllAssets(actor.branchId, actor);
  }

  @Get('scores')
  @RequirePermission('fleet:read')
  @ApiOperation({ summary: 'Get latest predictive maintenance scores for all fleet assets' })
  getScores(@CurrentUser() actor: JwtPayload) {
    return this.svc.getLatestScores(actor.branchId);
  }

  @Get('summary')
  @RequirePermission('fleet:read')
  @ApiOperation({ summary: 'Fleet maintenance risk level summary (count by level)' })
  async getSummary(@CurrentUser() actor: JwtPayload) {
    const scores = await this.svc.getLatestScores(actor.branchId);
    const summary = { CRITICAL: 0, HIGH: 0, MODERATE: 0, LOW: 0, total: scores.length };
    scores.forEach(s => { summary[s.riskLevel as keyof typeof summary] = (summary[s.riskLevel as keyof typeof summary] as number) + 1; });
    return summary;
  }
}
