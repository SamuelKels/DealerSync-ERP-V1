import { Controller, Get, Post, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam } from '@nestjs/swagger';
import { FleetMaintenanceService } from './fleet-maintenance.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../../common/guards/auth.guards';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import type { JwtPayload } from '@agcoms/types';

@ApiTags('fleet-maintenance')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('fleet/maintenance')
export class FleetMaintenanceController {
  constructor(private readonly svc: FleetMaintenanceService) {}

  @Get('risk-summary')
  @RequirePermission('fleet:read')
  @ApiOperation({ summary: 'Get latest predictive maintenance risk scores for all fleet assets' })
  getRiskSummary(@CurrentUser() actor: JwtPayload) {
    return this.svc.getFleetRiskSummary(actor.branchId);
  }

  @Post('score/:assetId')
  @RequirePermission('fleet:write')
  @ApiOperation({ summary: 'Trigger immediate scoring for a single asset' })
  @ApiParam({ name: 'assetId', description: 'Fleet asset UUID' })
  scoreAsset(@Param('assetId') assetId: string) {
    return this.svc.scoreAsset(assetId);
  }

  @Post('trigger')
  @RequirePermission('fleet:write')
  @ApiOperation({ summary: 'Manually trigger scoring for all branch assets (queued)' })
  triggerScoring(@CurrentUser() actor: JwtPayload) {
    return this.svc.triggerManualScoring(actor.branchId);
  }
}
