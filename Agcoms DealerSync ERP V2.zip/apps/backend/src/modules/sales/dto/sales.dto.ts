/**
 * AGCOMS DealerSync ERP — Sales DTOs
 * Sprint 2 Fix S2-06: No DTOs for quotations, sales orders, or invoices.
 */
import {
  IsString, IsOptional, IsUUID, IsEnum, IsNumber, Min, Max,
  IsArray, ValidateNested, IsDateString, IsPositive, MaxLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export enum Currency { NGN = 'NGN', USD = 'USD', EUR = 'EUR' }

export class QuotationLineDto {
  @ApiProperty()
  @IsUUID()
  productId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ minimum: 1 })
  @IsNumber()
  @Min(0.001)
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ minimum: 0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice: number;

  @ApiPropertyOptional({ minimum: 0, maximum: 100 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  @Type(() => Number)
  discountPct?: number;

  @ApiPropertyOptional({ description: 'VAT rate in percent (default 7.5)', default: 7.5 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Max(100)
  @Type(() => Number)
  vatRate?: number;
}

export class CreateQuotationDto {
  @ApiProperty()
  @IsUUID()
  customerId: string;

  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty({ enum: Currency, default: Currency.NGN })
  @IsEnum(Currency)
  currency: Currency;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  validUntil?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;

  @ApiProperty({ type: [QuotationLineDto], minItems: 1 })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => QuotationLineDto)
  lines: QuotationLineDto[];
}

export class UpdateQuotationDto extends PartialType(CreateQuotationDto) {}

export class CreateCreditNoteDto {
  @ApiProperty({ description: 'Invoice ID to credit against' })
  @IsUUID()
  invoiceId: string;

  @ApiProperty({ minimum: 0.01 })
  @IsNumber()
  @IsPositive()
  @Type(() => Number)
  amount: number;

  @ApiProperty()
  @IsString()
  @MaxLength(500)
  reason: string;
}

export class RecordPaymentDto {
  @ApiProperty()
  @IsUUID()
  invoiceId: string;

  @ApiProperty({ minimum: 0.01 })
  @IsNumber()
  @IsPositive()
  @Type(() => Number)
  amount: number;

  @ApiProperty({ example: '2025-01-15' })
  @IsDateString()
  paymentDate: string;

  @ApiProperty({ enum: ['BANK_TRANSFER', 'CASH', 'CHEQUE', 'CARD', 'PAYSTACK', 'FLUTTERWAVE'] })
  @IsString()
  paymentMethod: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reference?: string;
}
