/**
 * AGCOMS DealerSync ERP — CreditControlService
 * Sprint 5: Section 7 Module 3 — "credit control"
 *
 * Enforces credit limits when:
 *   - Creating quotations (warning at 80%, block at 100%)
 *   - Confirming sales orders (hard block at 100%)
 *   - Issuing invoices
 *
 * Credit utilisation = sum of all ISSUED/PARTIALLY_PAID invoices + pending orders
 */
import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

export interface CreditCheckResult {
  customerId:        string;
  customerName:      string;
  creditLimit:       number;
  currentUtilisation: number;
  availableCredit:   number;
  utilisationPct:    number;
  status:            'CLEAR' | 'WARNING' | 'BLOCKED';
  message?:          string;
}

@Injectable()
export class CreditControlService {
  private readonly logger = new Logger(CreditControlService.name);
  private readonly WARN_PCT  = 80;
  private readonly BLOCK_PCT = 100;

  constructor(private readonly prisma: PrismaService) {}

  // ── Check credit before order/invoice creation ────────────────

  async checkCredit(
    customerId:      string,
    transactionValue: number,
    context:          'quotation' | 'sales_order' | 'invoice',
  ): Promise<CreditCheckResult> {
    const customer = await this.prisma.customer.findUnique({
      where: { id: customerId },
      select: { id: true, name: true, creditLimit: true, status: true },
    });

    if (!customer) throw new BadRequestException('Customer not found');
    if (customer.status === 'BLACKLISTED') {
      throw new BadRequestException(
        `Customer ${customer.name} is BLACKLISTED and cannot place orders`
      );
    }

    const creditLimit = Number(customer.creditLimit);

    // Credit limit of 0 means no credit facility — cash only
    if (creditLimit === 0) {
      return {
        customerId, customerName: customer.name,
        creditLimit: 0, currentUtilisation: 0, availableCredit: 0,
        utilisationPct: 0, status: 'CLEAR',
      };
    }

    // Sum all outstanding balances (issued/unpaid invoices)
    const outstandingAgg = await this.prisma.invoice.aggregate({
      where: {
        customerId,
        status:    { in: ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'] },
        isDeleted: false,
      },
      _sum: { totalAmount: true, amountPaid: true },
    });

    const totalInvoiced = Number(outstandingAgg._sum.totalAmount ?? 0);
    const totalPaid     = Number(outstandingAgg._sum.amountPaid ?? 0);
    const outstanding   = totalInvoiced - totalPaid;

    const currentUtilisation = outstanding + transactionValue;
    const availableCredit    = creditLimit - outstanding;
    const utilisationPct     = creditLimit > 0
      ? (currentUtilisation / creditLimit) * 100
      : 0;

    let status: 'CLEAR' | 'WARNING' | 'BLOCKED' = 'CLEAR';
    let message: string | undefined;

    if (utilisationPct >= this.BLOCK_PCT) {
      status  = 'BLOCKED';
      message = `Credit limit exceeded. Outstanding: ₦${outstanding.toLocaleString()} / Limit: ₦${creditLimit.toLocaleString()}. This ${context} will cause the limit to be exceeded by ₦${(currentUtilisation - creditLimit).toLocaleString()}.`;
    } else if (utilisationPct >= this.WARN_PCT) {
      status  = 'WARNING';
      message = `Credit utilisation is ${utilisationPct.toFixed(0)}% of limit. Available credit: ₦${availableCredit.toLocaleString()}`;
    }

    return {
      customerId,
      customerName:      customer.name,
      creditLimit,
      currentUtilisation,
      availableCredit:   Math.max(0, availableCredit),
      utilisationPct:    Math.round(utilisationPct * 10) / 10,
      status,
      message,
    };
  }

  // ── Enforce credit (throw if BLOCKED) ─────────────────────────

  async enforceCredit(
    customerId:       string,
    transactionValue: number,
    context:          'quotation' | 'sales_order' | 'invoice',
  ): Promise<CreditCheckResult> {
    const result = await this.checkCredit(customerId, transactionValue, context);

    if (result.status === 'BLOCKED') {
      this.logger.warn(
        `Credit blocked for ${result.customerName}: ${result.utilisationPct}% utilised`
      );
      throw new BadRequestException(result.message ?? 'Customer credit limit exceeded');
    }

    if (result.status === 'WARNING') {
      this.logger.warn(`Credit warning for ${result.customerName}: ${result.utilisationPct}% utilised`);
    }

    return result;
  }

  // ── Customers approaching/over limit ─────────────────────────

  async getCustomersOnCreditWatch(branchId: string): Promise<CreditCheckResult[]> {
    const customers = await this.prisma.customer.findMany({
      where:  { branchId, isDeleted: false, creditLimit: { gt: 0 } },
      select: { id: true, name: true, creditLimit: true, status: true },
    });

    const results = await Promise.all(
      customers.map(c => this.checkCredit(c.id, 0, 'invoice').catch(() => null))
    );

    return (results.filter(Boolean) as CreditCheckResult[])
      .filter(r => r.utilisationPct >= 70) // Only show those at 70%+
      .sort((a, b) => b.utilisationPct - a.utilisationPct);
  }
}


/**
 * AGCOMS DealerSync ERP — CustomerSegmentationService
 * Sprint 5: Section 7 Module 3 — "customer segmentation"
 *
 * Segments customers by:
 *   - Revenue tier (A/B/C/D from highest to lowest spenders)
 *   - Industry (AGRICULTURE, CONSTRUCTION, GOVERNMENT, etc.)
 *   - Purchase frequency (ACTIVE, OCCASIONAL, DORMANT)
 *   - Geography (by state)
 *
 * Used by: CRM list filters, marketing outreach, AI recommendations
 */
export interface CustomerSegment {
  id:       string;
  name:     string;
  description: string;
  filters:  Record<string, unknown>;
  count?:   number;
}

export const PREDEFINED_SEGMENTS: CustomerSegment[] = [
  {
    id:   'tier-a',
    name: 'Tier A — Top Revenue',
    description: 'Customers generating ₦10M+ in the last 12 months',
    filters: { revenueMin: 10_000_000, period: '12m' },
  },
  {
    id:   'tier-b',
    name: 'Tier B — High Revenue',
    description: 'Customers generating ₦2M–₦10M in the last 12 months',
    filters: { revenueMin: 2_000_000, revenueMax: 10_000_000, period: '12m' },
  },
  {
    id:   'tier-c',
    name: 'Tier C — Mid Revenue',
    description: 'Customers generating ₦500K–₦2M in the last 12 months',
    filters: { revenueMin: 500_000, revenueMax: 2_000_000, period: '12m' },
  },
  {
    id:   'government',
    name: 'Government Customers',
    description: 'All customers of type GOVERNMENT (NADF programme etc.)',
    filters: { customerType: 'GOVERNMENT' },
  },
  {
    id:   'active',
    name: 'Active Customers',
    description: 'Customers with at least one order in the last 90 days',
    filters: { lastOrderWithin: '90d' },
  },
  {
    id:   'dormant',
    name: 'Dormant Customers',
    description: 'Customers with no orders in the last 180 days',
    filters: { noOrderSince: '180d' },
  },
  {
    id:   'credit-risk',
    name: 'Credit Watch',
    description: 'Customers at 70%+ credit limit utilisation',
    filters: { creditUtilisationMin: 70 },
  },
];

@Injectable()
export class CustomerSegmentationService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly creditControl: CreditControlService,
  ) {}

  async getSegmentCustomers(
    segmentId:  string,
    branchId:   string,
    page = 1,
    limit = 20,
  ) {
    const segment = PREDEFINED_SEGMENTS.find(s => s.id === segmentId);
    if (!segment) throw new BadRequestException(`Segment '${segmentId}' not found`);

    const f = segment.filters;
    const where: any = { branchId, isDeleted: false, status: 'ACTIVE' };

    if (f['customerType'])    where.customerType = f['customerType'];

    // Time-based filters via invoice data
    if (f['lastOrderWithin']) {
      const days = parseInt(String(f['lastOrderWithin']));
      const since = new Date(Date.now() - days * 86400_000);
      where.invoices = { some: { createdAt: { gte: since }, isDeleted: false } };
    }

    if (f['noOrderSince']) {
      const days = parseInt(String(f['noOrderSince']));
      const since = new Date(Date.now() - days * 86400_000);
      where.invoices = { none: { createdAt: { gte: since }, isDeleted: false } };
    }

    const [customers, total] = await Promise.all([
      this.prisma.customer.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { name: 'asc' },
        include: {
          _count: { select: { invoices: true } },
        },
      }),
      this.prisma.customer.count({ where }),
    ]);

    return {
      segment,
      customers,
      total,
      hasMore: page * limit < total,
    };
  }

  async getSegmentsWithCounts(branchId: string): Promise<CustomerSegment[]> {
    return Promise.all(
      PREDEFINED_SEGMENTS.map(async (seg) => {
        try {
          const result = await this.getSegmentCustomers(seg.id, branchId, 1, 1);
          return { ...seg, count: result.total };
        } catch {
          return { ...seg, count: 0 };
        }
      })
    );
  }
}
