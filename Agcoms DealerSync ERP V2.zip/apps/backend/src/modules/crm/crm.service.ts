import {
  Injectable,
  NotFoundException,
  ConflictException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  CustomerType,
  CustomerStatus,
  LeadStatus,
  RfqStatus,
  CommunicationChannel,
  Prisma,
} from '@prisma/client';
import { paginate, PaginationDto } from '../../common/pagination';

// ── DTOs ────────────────────────────────────────────────────────────────────

export interface CreateCustomerDto {
  type: CustomerType;
  name: string;
  tradingName?: string;
  rcNumber?: string;
  taxId?: string;
  email?: string;
  phone: string;
  phone2?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  creditLimit?: number;
  paymentTerms?: number;
  segment?: string;
  tags?: string[];
  notes?: string;
  branchId: string;
  assignedToId?: string;
}

export interface UpdateCustomerDto extends Partial<CreateCustomerDto> {}

export interface CreateLeadDto {
  title: string;
  description?: string;
  source: string;
  estimatedValue?: number;
  probability?: number;
  expectedCloseAt?: Date;
  customerId?: string;
  branchId: string;
}

export interface CreateRfqDto {
  subject: string;
  notes?: string;
  dueDate?: Date;
  customerId: string;
  leadId?: string;
  branchId: string;
  items: {
    description: string;
    quantity: number;
    unit?: string;
    notes?: string;
    productId?: string;
  }[];
}

export interface LogCommunicationDto {
  customerId: string;
  channel: CommunicationChannel;
  direction: 'INBOUND' | 'OUTBOUND';
  subject?: string;
  body: string;
  outcome?: string;
  followUpDate?: Date;
  leadId?: string;
}

export interface CustomerListQuery extends PaginationDto {
  branchId?: string;
  status?: CustomerStatus;
  type?: CustomerType;
  search?: string;
  segment?: string;
}

export interface LeadListQuery extends PaginationDto {
  branchId?: string;
  status?: LeadStatus;
  ownerId?: string;
  search?: string;
}

// ── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class CrmService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ── Sequence generators ────────────────────────────────────────────────────

  private async nextCustomerCode(): Promise<string> {
    const count = await this.prisma.customer.count();
    return `AGC-CUST-${String(count + 1).padStart(4, '0')}`;
  }

  private async nextLeadCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await this.prisma.lead.count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `LEAD-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  private async nextRfqCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await this.prisma.rfq.count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `RFQ-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Customers ─────────────────────────────────────────────────────────────

  async listCustomers(query: CustomerListQuery, actorBranchId: string, isSuperAdmin: boolean) {
    const { branchId, status, type, search, segment, cursor, limit = 20 } = query;

    // Enforce branch isolation for non-super-admins
    const allowedBranchId = isSuperAdmin ? branchId : actorBranchId;

    const where: Prisma.CustomerWhereInput = {
      isDeleted: false,
      ...(allowedBranchId && { branchId: allowedBranchId }),
      ...(status && { status }),
      ...(type && { type }),
      ...(segment && { segment }),
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { phone: { contains: search } },
          { code: { contains: search, mode: 'insensitive' } },
          { rcNumber: { contains: search, mode: 'insensitive' } },
        ],
      }),
    };

    return paginate(this.prisma.customer, { where, cursor, limit }, (id) =>
      this.prisma.customer.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getCustomer(id: string, actorBranchId: string, isSuperAdmin: boolean) {
    const customer = await this.prisma.customer.findFirst({
      where: { id, isDeleted: false },
      include: {
        branch: { select: { id: true, code: true, name: true } },
        assignedTo: { select: { id: true, firstName: true, lastName: true, email: true } },
        createdBy: { select: { id: true, firstName: true, lastName: true } },
        _count: {
          select: {
            leads: true,
            rfqs: true,
            quotations: true,
            salesOrders: true,
            invoices: true,
          },
        },
      },
    });

    if (!customer) throw new NotFoundException('Customer not found');
    if (!isSuperAdmin && customer.branchId !== actorBranchId) {
      throw new ForbiddenException('Access denied to this customer');
    }

    return customer;
  }

  async createCustomer(
    dto: CreateCustomerDto,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    // Enforce branch isolation
    if (!isSuperAdmin && dto.branchId !== actorBranchId) {
      throw new ForbiddenException('Cannot create customer for another branch');
    }

    const code = await this.nextCustomerCode();

    const customer = await this.prisma.customer.create({
      data: {
        code,
        type: dto.type,
        name: dto.name,
        tradingName: dto.tradingName,
        rcNumber: dto.rcNumber,
        taxId: dto.taxId,
        email: dto.email,
        phone: dto.phone,
        phone2: dto.phone2,
        address: dto.address,
        city: dto.city,
        state: dto.state,
        country: dto.country ?? 'Nigeria',
        creditLimit: dto.creditLimit ?? 0,
        paymentTerms: dto.paymentTerms ?? 30,
        segment: dto.segment,
        tags: dto.tags ?? [],
        notes: dto.notes,
        branchId: dto.branchId,
        assignedToId: dto.assignedToId,
        createdById: actorId,
      },
    });

    await this.audit.log({
      action: 'create',
      resource: 'customer',
      entityId: customer.id,
      afterState: customer,
      actorId,
    });

    this.events.emit('crm.customer.created', { customerId: customer.id, actorId });
    return customer;
  }

  async updateCustomer(
    id: string,
    dto: UpdateCustomerDto,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const existing = await this.getCustomer(id, actorBranchId, isSuperAdmin);

    const updated = await this.prisma.customer.update({
      where: { id },
      data: {
        ...dto,
        updatedAt: new Date(),
      },
    });

    await this.audit.log({
      action: 'update',
      resource: 'customer',
      entityId: id,
      beforeState: existing,
      afterState: updated,
      actorId,
    });

    return updated;
  }

  async archiveCustomer(id: string, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    const customer = await this.getCustomer(id, actorBranchId, isSuperAdmin);

    // Check no open invoices
    const openInvoices = await this.prisma.invoice.count({
      where: {
        customerId: id,
        status: { in: ['DRAFT', 'ISSUED', 'PARTIALLY_PAID', 'OVERDUE'] },
        isDeleted: false,
      },
    });
    if (openInvoices > 0) {
      throw new BadRequestException('Cannot archive customer with open invoices');
    }

    await this.prisma.customer.update({
      where: { id },
      data: { status: 'ARCHIVED', isDeleted: true },
    });

    await this.audit.log({
      action: 'archive',
      resource: 'customer',
      entityId: id,
      beforeState: customer,
      afterState: { ...customer, status: 'ARCHIVED', isDeleted: true },
      actorId,
    });
  }

  async updateCreditLimit(
    id: string,
    newLimit: number,
    reason: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const customer = await this.getCustomer(id, actorBranchId, isSuperAdmin);

    const updated = await this.prisma.customer.update({
      where: { id },
      data: { creditLimit: newLimit },
    });

    await this.audit.log({
      action: 'credit_limit_change',
      resource: 'customer',
      entityId: id,
      beforeState: { creditLimit: customer.creditLimit },
      afterState: { creditLimit: newLimit, reason },
      actorId,
    });

    return updated;
  }

  async getCreditStatus(id: string, actorBranchId: string, isSuperAdmin: boolean) {
    const customer = await this.getCustomer(id, actorBranchId, isSuperAdmin);
    const availableCredit = Number(customer.creditLimit) - Number(customer.creditUsed);
    const utilizationPct =
      Number(customer.creditLimit) > 0
        ? Math.round((Number(customer.creditUsed) / Number(customer.creditLimit)) * 100)
        : 0;

    return {
      customerId: customer.id,
      creditLimit: customer.creditLimit,
      creditUsed: customer.creditUsed,
      availableCredit,
      utilizationPct,
      status:
        utilizationPct >= 100
          ? 'OVER_LIMIT'
          : utilizationPct >= 80
          ? 'NEAR_LIMIT'
          : 'OK',
    };
  }

  // ── Leads ─────────────────────────────────────────────────────────────────

  async listLeads(query: LeadListQuery, actorBranchId: string, isSuperAdmin: boolean) {
    const { branchId, status, ownerId, search, cursor, limit = 20 } = query;
    const allowedBranchId = isSuperAdmin ? branchId : actorBranchId;

    const where: Prisma.LeadWhereInput = {
      isDeleted: false,
      ...(allowedBranchId && { branchId: allowedBranchId }),
      ...(status && { status }),
      ...(ownerId && { ownerId }),
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' } },
          { code: { contains: search, mode: 'insensitive' } },
        ],
      }),
    };

    return paginate(this.prisma.lead, { where, cursor, limit }, (id) =>
      this.prisma.lead.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async createLead(dto: CreateLeadDto, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) {
      throw new ForbiddenException('Cannot create lead for another branch');
    }

    const code = await this.nextLeadCode();

    const lead = await this.prisma.lead.create({
      data: {
        code,
        title: dto.title,
        description: dto.description,
        source: dto.source as any,
        estimatedValue: dto.estimatedValue ?? 0,
        probability: dto.probability ?? 0,
        expectedCloseAt: dto.expectedCloseAt,
        customerId: dto.customerId,
        branchId: dto.branchId,
        ownerId: actorId,
      },
    });

    await this.audit.log({
      action: 'create',
      resource: 'lead',
      entityId: lead.id,
      afterState: lead,
      actorId,
    });

    this.events.emit('crm.lead.created', { leadId: lead.id, actorId });
    return lead;
  }

  async updateLeadStatus(
    id: string,
    newStatus: LeadStatus,
    data: { lostReason?: string; actualCloseAt?: Date },
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const lead = await this.prisma.lead.findFirst({
      where: { id, isDeleted: false },
    });
    if (!lead) throw new NotFoundException('Lead not found');
    if (!isSuperAdmin && lead.branchId !== actorBranchId) {
      throw new ForbiddenException('Access denied');
    }

    const updated = await this.prisma.lead.update({
      where: { id },
      data: {
        status: newStatus,
        ...(newStatus === 'WON' || newStatus === 'LOST'
          ? { actualCloseAt: data.actualCloseAt ?? new Date() }
          : {}),
        ...(newStatus === 'LOST' ? { lostReason: data.lostReason } : {}),
      },
    });

    await this.audit.log({
      action: `lead_status_${newStatus.toLowerCase()}`,
      resource: 'lead',
      entityId: id,
      beforeState: { status: lead.status },
      afterState: { status: newStatus },
      actorId,
    });

    if (newStatus === 'WON') {
      this.events.emit('crm.lead.won', { leadId: id, actorId });
    }

    return updated;
  }

  // ── RFQs ─────────────────────────────────────────────────────────────────

  async createRfq(dto: CreateRfqDto, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) {
      throw new ForbiddenException('Cannot create RFQ for another branch');
    }

    const code = await this.nextRfqCode();

    const rfq = await this.prisma.rfq.create({
      data: {
        code,
        subject: dto.subject,
        notes: dto.notes,
        dueDate: dto.dueDate,
        customerId: dto.customerId,
        leadId: dto.leadId,
        branchId: dto.branchId,
        handledById: actorId,
        items: {
          create: dto.items.map((item) => ({
            description: item.description,
            quantity: item.quantity,
            unit: item.unit ?? 'unit',
            notes: item.notes,
            productId: item.productId,
          })),
        },
      },
      include: { items: true },
    });

    await this.audit.log({
      action: 'create',
      resource: 'rfq',
      entityId: rfq.id,
      afterState: rfq,
      actorId,
    });

    return rfq;
  }

  async listRfqs(
    query: PaginationDto & { branchId?: string; status?: RfqStatus; customerId?: string },
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const allowedBranchId = isSuperAdmin ? query.branchId : actorBranchId;
    const where: Prisma.RfqWhereInput = {
      isDeleted: false,
      ...(allowedBranchId && { branchId: allowedBranchId }),
      ...(query.status && { status: query.status }),
      ...(query.customerId && { customerId: query.customerId }),
    };
    return paginate(this.prisma.rfq, { where, cursor: query.cursor, limit: query.limit }, (id) =>
      this.prisma.rfq.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  // ── Communication Log ─────────────────────────────────────────────────────

  async logCommunication(dto: LogCommunicationDto, actorId: string) {
    const log = await this.prisma.communicationLog.create({
      data: {
        customerId: dto.customerId,
        channel: dto.channel,
        direction: dto.direction,
        subject: dto.subject,
        body: dto.body,
        outcome: dto.outcome,
        followUpDate: dto.followUpDate,
        leadId: dto.leadId,
        createdById: actorId,
      },
    });

    await this.audit.log({
      action: 'create',
      resource: 'communication_log',
      entityId: log.id,
      afterState: log,
      actorId,
    });

    return log;
  }

  async getCommunicationHistory(
    customerId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
    pagination: PaginationDto,
  ) {
    await this.getCustomer(customerId, actorBranchId, isSuperAdmin);
    return paginate(
      this.prisma.communicationLog,
      { where: { customerId }, cursor: pagination.cursor, limit: pagination.limit ?? 50 },
      (id) =>
        this.prisma.communicationLog.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getCrmStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };

    const [
      totalCustomers,
      activeCustomers,
      totalLeads,
      pipelineValue,
      wonLeads,
      openRfqs,
      pendingFollowUps,
    ] = await Promise.all([
      this.prisma.customer.count({ where: { ...branchFilter, isDeleted: false } }),
      this.prisma.customer.count({ where: { ...branchFilter, isDeleted: false, status: 'ACTIVE' } }),
      this.prisma.lead.count({ where: { ...branchFilter, isDeleted: false, status: { notIn: ['WON', 'LOST', 'ARCHIVED'] } } }),
      this.prisma.lead.aggregate({
        where: { ...branchFilter, isDeleted: false, status: { notIn: ['WON', 'LOST', 'ARCHIVED'] } },
        _sum: { estimatedValue: true },
      }),
      this.prisma.lead.count({ where: { ...branchFilter, isDeleted: false, status: 'WON' } }),
      this.prisma.rfq.count({ where: { ...branchFilter, isDeleted: false, status: { in: ['SUBMITTED', 'IN_REVIEW'] } } }),
      this.prisma.communicationLog.count({
        where: {
          customer: { ...branchFilter, isDeleted: false },
          followUpDate: { lte: new Date() },
        },
      }),
    ]);

    const leadsByStatus = await this.prisma.lead.groupBy({
      by: ['status'],
      where: { ...branchFilter, isDeleted: false },
      _count: { id: true },
    });

    return {
      totalCustomers,
      activeCustomers,
      totalLeads,
      pipelineValue: Number(pipelineValue._sum.estimatedValue ?? 0),
      wonLeads,
      openRfqs,
      pendingFollowUps,
      pipeline: leadsByStatus.map((g) => ({ status: g.status, count: g._count.id })),
    };
  }
}
