/**
 * AGCOMS DealerSync ERP — Exchange Rate Controller
 * Sprint 3 / S3-B: CBN exchange rate endpoints
 *
 * GET  /api/v1/exchange-rates/current      — all tracked currencies (cache-first)
 * GET  /api/v1/exchange-rates/:currency    — single currency rate
 * GET  /api/v1/exchange-rates/:currency/history — 30-day history
 * POST /api/v1/exchange-rates/sync         — manual trigger (Finance Manager+)
 * POST /api/v1/exchange-rates/:currency/override — manual rate (Finance Manager+)
 * POST /api/v1/exchange-rates/convert      — currency conversion
 */
import {
  Controller, Get, Post, Param, Body, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery, ApiParam } from '@nestjs/swagger';
import { IsNumber, IsString, Min, IsPositive }  from 'class-validator';
import { Type }                                 from 'class-transformer';
import { ApiProperty }                          from '@nestjs/swagger';
import { ExchangeRateService }                  from './exchange-rate.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';
import { CurrentUser }                          from '../../common/decorators/current-user.decorator';
import type { JwtPayload }                      from '@agcoms/types';

class ConvertDto {
  @ApiProperty({ example: 50000, description: 'Amount to convert' })
  @IsNumber()
  @IsPositive()
  @Type(() => Number)
  amount: number;

  @ApiProperty({ example: 'USD', description: 'Source currency code' })
  @IsString()
  fromCurrency: string;
}

class OverrideRateDto {
  @ApiProperty({ example: 1580.5, description: '1 currency = X NGN' })
  @IsNumber()
  @Min(0.01)
  @Type(() => Number)
  rate: number;
}

@ApiTags('exchange-rates')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('exchange-rates')
export class ExchangeRateController {
  constructor(private readonly svc: ExchangeRateService) {}

  @Get('current')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Get all tracked CBN exchange rates (USD, EUR, GBP vs NGN)' })
  getAllRates() {
    return this.svc.getAllRates();
  }

  @Get(':currency')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Get rate for a single currency pair against NGN' })
  @ApiParam({ name: 'currency', example: 'USD' })
  getRate(@Param('currency') currency: string) {
    return this.svc.getRate(currency.toUpperCase());
  }

  @Get(':currency/history')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Get 30-day exchange rate history for charting' })
  @ApiParam({ name: 'currency', example: 'USD' })
  @ApiQuery({ name: 'days', required: false, type: Number, description: 'Days of history (default 30)' })
  getHistory(
    @Param('currency') currency: string,
    @Query('days') days?: string,
  ) {
    const daysBack  = parseInt(days ?? '30', 10);
    const fromDate  = new Date();
    fromDate.setDate(fromDate.getDate() - daysBack);
    return this.svc.getRateHistory(currency.toUpperCase(), fromDate, new Date());
  }

  @Post('sync')
  @RequirePermission('finance:write')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Manually trigger CBN rate sync (Finance Manager+)' })
  syncRates() {
    return this.svc.syncRates();
  }

  @Post('convert')
  @RequirePermission('finance:read')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Convert an amount from foreign currency to NGN' })
  convert(@Body() dto: ConvertDto) {
    return this.svc.convertToNgn(dto.amount, dto.fromCurrency.toUpperCase());
  }

  @Post(':currency/override')
  @RequirePermission('finance:write')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Manually override exchange rate (Finance Manager only) — creates audit trail' })
  @ApiParam({ name: 'currency', example: 'USD' })
  override(
    @Param('currency') currency: string,
    @Body() dto: OverrideRateDto,
    @CurrentUser() actor: JwtPayload,
  ) {
    return this.svc.overrideRate(currency.toUpperCase(), dto.rate, actor);
  }
}
