import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Prisma, StockMovementType, EquipmentCondition, Currency } from '@prisma/client';
import { paginate, PaginationDto } from '../../common/pagination';

// ── DTOs ────────────────────────────────────────────────────────────────────

export interface CreateWarehouseDto {
  code: string;
  name: string;
  address?: string;
  branchId: string;
  managerId?: string;
  isDefault?: boolean;
}

export interface CreateProductDto {
  sku: string;
  name: string;
  description?: string;
  categoryId: string;
  isSerialized?: boolean;
  basePrice: number;
  currency?: Currency;
  vatRate?: number;
  whtRate?: number;
  unit?: string;
  weightKg?: number;
  brand?: string;
  model?: string;
  year?: number;
  reorderPoint?: number;
  safetyStock?: number;
}

export interface CreateStockItemDto {
  productId: string;
  warehouseId: string;
  serialNumber?: string;
  engineNumber?: string;
  chassisNumber?: string;
  condition?: EquipmentCondition;
  quantityOnHand?: number;
  landedCost?: number;
  currency?: Currency;
  binLocation?: string;
}

export interface StockAdjustmentDto {
  stockItemId: string;
  type: StockMovementType;
  quantity: number;
  notes: string;
  reference?: string;
}

export interface CreateTransferDto {
  fromWarehouseId: string;
  toWarehouseId: string;
  notes?: string;
  items: {
    productId: string;
    quantity: number;
    serialNumber?: string;
  }[];
}

export interface StockListQuery extends PaginationDto {
  warehouseId?: string;
  productId?: string;
  branchId?: string;
  search?: string;
  lowStock?: boolean;
}

// ── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class InventoryService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextTransferCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await this.prisma.stockTransfer.count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `TRF-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Warehouses ────────────────────────────────────────────────────────────

  async listWarehouses(branchId?: string, isSuperAdmin = false, actorBranchId?: string) {
    const where: Prisma.WarehouseWhereInput = {
      isDeleted: false,
      isActive: true,
      ...(!isSuperAdmin && actorBranchId ? { branchId: actorBranchId } : {}),
      ...(branchId && isSuperAdmin ? { branchId } : {}),
    };
    return this.prisma.warehouse.findMany({
      where,
      include: {
        branch: { select: { id: true, code: true, name: true } },
        manager: { select: { id: true, firstName: true, lastName: true } },
        _count: { select: { stockItems: true } },
      },
      orderBy: { createdAt: 'asc' },
    });
  }

  async createWarehouse(dto: CreateWarehouseDto, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) {
      throw new ForbiddenException('Cannot create warehouse for another branch');
    }

    const existing = await this.prisma.warehouse.findUnique({ where: { code: dto.code } });
    if (existing) throw new ConflictException(`Warehouse code ${dto.code} already exists`);

    const warehouse = await this.prisma.warehouse.create({
      data: {
        code: dto.code,
        name: dto.name,
        address: dto.address,
        branchId: dto.branchId,
        managerId: dto.managerId,
        isDefault: dto.isDefault ?? false,
      },
    });

    await this.audit.log({ action: 'create', resource: 'warehouse', entityId: warehouse.id, afterState: warehouse, actorId });
    return warehouse;
  }

  // ── Product Categories ────────────────────────────────────────────────────

  async listCategories() {
    return this.prisma.productCategory.findMany({
      where: { isDeleted: false, parentId: null },
      include: {
        children: { where: { isDeleted: false }, include: { _count: { select: { products: true } } } },
        _count: { select: { products: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async createCategory(data: { name: string; code: string; description?: string; parentId?: string }, actorId: string) {
    const existing = await this.prisma.productCategory.findUnique({ where: { code: data.code } });
    if (existing) throw new ConflictException(`Category code ${data.code} already exists`);
    const cat = await this.prisma.productCategory.create({ data });
    await this.audit.log({ action: 'create', resource: 'product_category', entityId: cat.id, afterState: cat, actorId });
    return cat;
  }

  // ── Products ─────────────────────────────────────────────────────────────

  async listProducts(query: PaginationDto & { categoryId?: string; search?: string; isActive?: boolean }) {
    const where: Prisma.ProductWhereInput = {
      isDeleted: false,
      ...(query.isActive !== undefined && { isActive: query.isActive }),
      ...(query.categoryId && { categoryId: query.categoryId }),
      ...(query.search && {
        OR: [
          { name: { contains: query.search, mode: 'insensitive' } },
          { sku: { contains: query.search, mode: 'insensitive' } },
          { brand: { contains: query.search, mode: 'insensitive' } },
          { model: { contains: query.search, mode: 'insensitive' } },
        ],
      }),
    };
    return paginate(this.prisma.product, { where, cursor: query.cursor, limit: query.limit }, (id) =>
      this.prisma.product.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getProduct(id: string) {
    const product = await this.prisma.product.findFirst({
      where: { id, isDeleted: false },
      include: {
        category: true,
        _count: { select: { stockItems: true } },
      },
    });
    if (!product) throw new NotFoundException('Product not found');
    return product;
  }

  async createProduct(dto: CreateProductDto, actorId: string) {
    const existing = await this.prisma.product.findUnique({ where: { sku: dto.sku } });
    if (existing) throw new ConflictException(`SKU ${dto.sku} already exists`);

    const product = await this.prisma.product.create({
      data: {
        sku: dto.sku,
        name: dto.name,
        description: dto.description,
        categoryId: dto.categoryId,
        isSerialized: dto.isSerialized ?? false,
        basePrice: dto.basePrice,
        currency: dto.currency ?? 'NGN',
        vatRate: dto.vatRate ?? 7.5,
        whtRate: dto.whtRate ?? 0,
        unit: dto.unit ?? 'unit',
        weightKg: dto.weightKg,
        brand: dto.brand,
        model: dto.model,
        year: dto.year,
        reorderPoint: dto.reorderPoint ?? 0,
        safetyStock: dto.safetyStock ?? 0,
        createdById: actorId,
      },
    });

    await this.audit.log({ action: 'create', resource: 'product', entityId: product.id, afterState: product, actorId });
    this.events.emit('inventory.product.created', { productId: product.id });
    return product;
  }

  async updateProduct(id: string, dto: Partial<CreateProductDto>, actorId: string) {
    const existing = await this.getProduct(id);
    const updated = await this.prisma.product.update({ where: { id }, data: { ...dto, updatedAt: new Date() } });
    await this.audit.log({ action: 'update', resource: 'product', entityId: id, beforeState: existing, afterState: updated, actorId });
    return updated;
  }

  // ── Stock Items ───────────────────────────────────────────────────────────

  async listStockItems(query: StockListQuery, actorBranchId: string, isSuperAdmin: boolean) {
    const allowedBranchId = isSuperAdmin ? query.branchId : actorBranchId;

    const where: Prisma.StockItemWhereInput = {
      isDeleted: false,
      ...(allowedBranchId && { warehouse: { branchId: allowedBranchId } }),
      ...(query.warehouseId && { warehouseId: query.warehouseId }),
      ...(query.productId && { productId: query.productId }),
      ...(query.search && {
        OR: [
          { serialNumber: { contains: query.search, mode: 'insensitive' } },
          { product: { name: { contains: query.search, mode: 'insensitive' } } },
          { product: { sku: { contains: query.search, mode: 'insensitive' } } },
        ],
      }),
      ...(query.lowStock && {
        quantityAvailable: { lte: (this.prisma.stockItem as any).fields?.quantityAvailable },
        product: { reorderPoint: { gt: 0 } },
      }),
    };

    return paginate(this.prisma.stockItem, { where, cursor: query.cursor, limit: query.limit }, (id) =>
      this.prisma.stockItem.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async createStockItem(dto: CreateStockItemDto, actorId: string) {
    // For serialized items, check uniqueness
    const product = await this.prisma.product.findUnique({ where: { id: dto.productId } });
    if (!product) throw new NotFoundException('Product not found');

    if (product.isSerialized && dto.serialNumber) {
      const existing = await this.prisma.stockItem.findFirst({
        where: { serialNumber: dto.serialNumber, isDeleted: false },
      });
      if (existing) throw new ConflictException(`Serial number ${dto.serialNumber} already in system`);
    }

    const stockItem = await this.prisma.$transaction(async (tx) => {
      const item = await tx.stockItem.create({
        data: {
          productId: dto.productId,
          warehouseId: dto.warehouseId,
          serialNumber: dto.serialNumber,
          engineNumber: dto.engineNumber,
          chassisNumber: dto.chassisNumber,
          condition: dto.condition ?? 'NEW',
          quantityOnHand: product.isSerialized ? 1 : (dto.quantityOnHand ?? 0),
          quantityReserved: 0,
          quantityAvailable: product.isSerialized ? 1 : (dto.quantityOnHand ?? 0),
          landedCost: dto.landedCost ?? 0,
          currency: dto.currency ?? 'NGN',
          binLocation: dto.binLocation,
        },
      });

      // Record opening stock movement
      await tx.stockMovement.create({
        data: {
          stockItemId: item.id,
          type: 'OPENING_STOCK',
          quantity: product.isSerialized ? 1 : (dto.quantityOnHand ?? 0),
          quantityBefore: 0,
          quantityAfter: product.isSerialized ? 1 : (dto.quantityOnHand ?? 0),
          notes: 'Opening stock entry',
          createdById: actorId,
        },
      });

      return item;
    });

    await this.audit.log({ action: 'create', resource: 'stock_item', entityId: stockItem.id, afterState: stockItem, actorId });
    this.events.emit('inventory.stock.created', { stockItemId: stockItem.id });
    return stockItem;
  }

  // ── Stock Adjustments ─────────────────────────────────────────────────────

  async adjustStock(dto: StockAdjustmentDto, actorId: string) {
    const stockItem = await this.prisma.stockItem.findFirst({
      where: { id: dto.stockItemId, isDeleted: false },
    });
    if (!stockItem) throw new NotFoundException('Stock item not found');

    const isAddition = ['ADJUSTMENT_ADD', 'PURCHASE_RECEIPT', 'TRANSFER_IN', 'RETURNED', 'LOAN_IN'].includes(dto.type);
    const isReduction = ['ADJUSTMENT_REMOVE', 'SALES_DISPATCH', 'TRANSFER_OUT', 'DAMAGED', 'LOAN_OUT'].includes(dto.type);

    const newQty = isAddition
      ? Number(stockItem.quantityOnHand) + dto.quantity
      : isReduction
      ? Number(stockItem.quantityOnHand) - dto.quantity
      : Number(stockItem.quantityOnHand);

    if (newQty < 0) {
      throw new BadRequestException(
        `Insufficient stock. Available: ${stockItem.quantityAvailable}, Requested: ${dto.quantity}`,
      );
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.stockItem.update({
        where: { id: dto.stockItemId },
        data: {
          quantityOnHand: newQty,
          quantityAvailable: newQty - Number(stockItem.quantityReserved),
          updatedAt: new Date(),
        },
      });

      await tx.stockMovement.create({
        data: {
          stockItemId: dto.stockItemId,
          type: dto.type,
          quantity: dto.quantity,
          quantityBefore: stockItem.quantityOnHand,
          quantityAfter: newQty,
          notes: dto.notes,
          reference: dto.reference,
          createdById: actorId,
        },
      });
    });

    await this.audit.log({
      action: 'stock_adjustment',
      resource: 'stock_item',
      entityId: dto.stockItemId,
      beforeState: { quantityOnHand: stockItem.quantityOnHand },
      afterState: { quantityOnHand: newQty, type: dto.type },
      actorId,
    });

    // Check for low stock alert
    const product = await this.prisma.product.findUnique({ where: { id: stockItem.productId } });
    if (product && newQty <= product.reorderPoint) {
      this.events.emit('inventory.stock.low', { stockItemId: dto.stockItemId, productId: stockItem.productId, qty: newQty });
    }
  }

  // ── Stock Transfers ───────────────────────────────────────────────────────

  async createTransfer(dto: CreateTransferDto, actorId: string) {
    if (dto.fromWarehouseId === dto.toWarehouseId) {
      throw new BadRequestException('Source and destination warehouses must differ');
    }

    const code = await this.nextTransferCode();

    const transfer = await this.prisma.stockTransfer.create({
      data: {
        code,
        fromWarehouseId: dto.fromWarehouseId,
        toWarehouseId: dto.toWarehouseId,
        notes: dto.notes,
        requestedById: actorId,
        items: {
          create: dto.items.map((item) => ({
            productId: item.productId,
            quantity: item.quantity,
            serialNumber: item.serialNumber,
          })),
        },
      },
      include: { items: true },
    });

    await this.audit.log({ action: 'create', resource: 'stock_transfer', entityId: transfer.id, afterState: transfer, actorId });
    return transfer;
  }

  async approveTransfer(id: string, actorId: string) {
    const transfer = await this.prisma.stockTransfer.findFirst({
      where: { id, isDeleted: false },
      include: { items: true },
    });
    if (!transfer) throw new NotFoundException('Transfer not found');
    if (transfer.status !== 'DRAFT') throw new BadRequestException('Only DRAFT transfers can be approved');

    await this.prisma.stockTransfer.update({
      where: { id },
      data: { status: 'IN_TRANSIT', approvedById: actorId, dispatchedAt: new Date() },
    });

    await this.audit.log({
      action: 'approve',
      resource: 'stock_transfer',
      entityId: id,
      beforeState: { status: 'DRAFT' },
      afterState: { status: 'IN_TRANSIT' },
      actorId,
    });

    this.events.emit('inventory.transfer.approved', { transferId: id });
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getInventoryStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { warehouse: { branchId: actorBranchId } };

    const [totalProducts, totalStockItems, totalWarehouses, lowStockCount] = await Promise.all([
      this.prisma.product.count({ where: { isDeleted: false, isActive: true } }),
      this.prisma.stockItem.count({ where: { isDeleted: false, ...branchFilter } }),
      this.prisma.warehouse.count({ where: { isDeleted: false, isActive: true, ...(!isSuperAdmin && { branchId: actorBranchId }) } }),
      this.prisma.stockItem.count({
        where: {
          isDeleted: false,
          ...branchFilter,
          AND: [{ quantityAvailable: { lte: 2 } }, { product: { reorderPoint: { gt: 0 } } }],
        },
      }),
    ]);

    const stockValue = await this.prisma.stockItem.aggregate({
      where: { isDeleted: false, ...branchFilter },
      _sum: { landedCost: true },
    });

    const categoryBreakdown = await this.prisma.product.groupBy({
      by: ['categoryId'],
      where: { isDeleted: false },
      _count: { id: true },
    });

    return {
      totalProducts,
      totalStockItems,
      totalWarehouses,
      lowStockCount,
      totalStockValue: Number(stockValue._sum.landedCost ?? 0),
      categoryBreakdown,
    };
  }
}
