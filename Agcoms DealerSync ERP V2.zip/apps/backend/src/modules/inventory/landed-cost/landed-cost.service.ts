/**
 * AGCOMS DealerSync ERP — LandedCostService
 * §7 Module 4: "landed cost allocation"
 *
 * Allocates freight, insurance, customs duties, and other import costs
 * across GRN lines using one of 4 methods. Updates inventory average cost
 * and posts ACID journal entry.
 *
 * Allocation methods:
 *   WEIGHT   → allocate by product weight (kg)
 *   VALUE    → allocate by line value (quantity × unit cost)
 *   QUANTITY → allocate by line quantity
 *   EQUAL    → equal split across all lines
 *
 * Journal (on approve):
 *   Dr  Inventory / Stock Account       [total landed cost]
 *   Cr  Freight Payable / Customs Acct  [per component]
 */
import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService }  from '../../../prisma/prisma.service';
import { AuditService }   from '../../../audit/audit.service';
import { EventEmitter2 }  from '@nestjs/event-emitter';
import type { JwtPayload } from '@agcoms/types';

export type AllocationMethod = 'WEIGHT' | 'VALUE' | 'QUANTITY' | 'EQUAL';

export interface LandedCostComponent {
  description:   string;           // e.g. 'Ocean freight', 'Customs duty'
  amount:        number;           // Total amount of this cost component
  currency:      string;
  creditAccountId: string;         // Account to credit (Freight Payable, etc.)
}

export interface CreateLandedCostDto {
  grnId:              string;
  branchId:           string;
  allocationMethod:   AllocationMethod;
  components:         LandedCostComponent[];
  inventoryAccountId: string;      // Debit: Inventory account
  notes?:             string;
}

interface AllocationLine {
  grnLineId:        string;
  productId:        string;
  productName:      string;
  quantity:         number;
  currentUnitCost:  number;
  weightKg?:        number;
  lineValue:        number;
  allocatedCost:    number;        // Computed by allocate()
  newUnitCost:      number;        // currentUnitCost + allocatedCost / quantity
}

@Injectable()
export class LandedCostService {
  private readonly logger = new Logger(LandedCostService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit:  AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ── Create and post landed cost allocation ────────────────────

  async createLandedCostAllocation(dto: CreateLandedCostDto, actor: JwtPayload) {
    // 1. Fetch GRN with all lines and products
    const grn = await this.prisma.goodsReceivedNote.findFirst({
      where: { id: dto.grnId, branchId: dto.branchId, isDeleted: false },
      include: {
        lines: {
          include: {
            product: { select: { id: true, name: true, sku: true, weightKg: true } },
          },
        },
      },
    });
    if (!grn) throw new NotFoundException(`GRN ${dto.grnId} not found`);
    if (grn.status !== 'POSTED') {
      throw new BadRequestException('Landed costs can only be allocated against POSTED GRNs');
    }

    const totalLandedCost = dto.components.reduce((s, c) => s + c.amount, 0);
    if (totalLandedCost <= 0) throw new BadRequestException('Total landed cost must be greater than zero');

    // 2. Build allocation lines
    const lines: AllocationLine[] = grn.lines.map(line => ({
      grnLineId:       line.id,
      productId:       line.productId,
      productName:     line.product.name,
      quantity:        Number(line.quantity),
      currentUnitCost: Number(line.unitCost),
      weightKg:        line.product.weightKg ? Number(line.product.weightKg) : undefined,
      lineValue:       Number(line.quantity) * Number(line.unitCost),
      allocatedCost:   0,
      newUnitCost:     0,
    }));

    // 3. Compute allocation amounts
    const allocated = this.allocate(lines, totalLandedCost, dto.allocationMethod);

    // 4. ACID transaction: create allocation record, update GRN lines, update stock, post journal
    const allocation = await this.prisma.$transaction(async (tx) => {
      // 4a. Create allocation header
      const alloc = await tx.landedCostAllocation.create({
        data: {
          grnId:            dto.grnId,
          branchId:         dto.branchId,
          allocationMethod: dto.allocationMethod,
          totalCost:        totalLandedCost,
          notes:            dto.notes,
          createdById:      actor.sub,
          components: {
            create: dto.components.map(c => ({
              description:     c.description,
              amount:          c.amount,
              currency:        c.currency,
              creditAccountId: c.creditAccountId,
            })),
          },
          lines: {
            create: allocated.map(l => ({
              grnLineId:        l.grnLineId,
              allocatedCost:    l.allocatedCost,
              previousUnitCost: l.currentUnitCost,
              newUnitCost:      l.newUnitCost,
            })),
          },
        },
      });

      // 4b. Update GRN line costs
      for (const line of allocated) {
        await tx.grnLine.update({
          where: { id: line.grnLineId },
          data: {
            landedCostPerUnit: line.allocatedCost / line.quantity,
            actualUnitCost:    line.newUnitCost,
          },
        });
      }

      // 4c. Update stock item weighted average cost
      for (const line of allocated) {
        await tx.stockItem.updateMany({
          where: { grnLineId: line.grnLineId },
          data:  { averageCost: line.newUnitCost },
        });
      }

      // 4d. Post journal entry
      const entryNo    = await this.generateJournalNo(dto.branchId, tx);
      const journalLines = [
        // Dr Inventory for total landed cost
        {
          accountId:    dto.inventoryAccountId,
          debitAmount:  totalLandedCost,
          creditAmount: 0,
          description:  `Landed cost — GRN ${grn.grnNo}`,
        },
        // Cr each cost component's payable account
        ...dto.components.map(c => ({
          accountId:    c.creditAccountId,
          debitAmount:  0,
          creditAmount: c.amount,
          description:  `${c.description} — GRN ${grn.grnNo}`,
        })),
      ];

      // Validate balanced
      const totalDebits  = journalLines.reduce((s, l) => s + l.debitAmount, 0);
      const totalCredits = journalLines.reduce((s, l) => s + l.creditAmount, 0);
      if (Math.abs(totalDebits - totalCredits) > 0.01) {
        throw new BadRequestException('Landed cost journal is unbalanced — check component amounts');
      }

      await tx.journalEntry.create({
        data: {
          entryNo,
          branchId:      dto.branchId,
          entryDate:     new Date(),
          description:   `Landed cost allocation — GRN ${grn.grnNo}`,
          entryType:     'LANDED_COST',
          status:        'POSTED',
          referenceType: 'LandedCostAllocation',
          referenceId:   alloc.id,
          currency:      dto.components[0]?.currency ?? 'NGN',
          totalDebits,
          totalCredits,
          createdById:   actor.sub,
          lines: { create: journalLines },
        },
      });

      return alloc;
    });

    await this.audit.log({
      action:     'landed_cost.allocated',
      resource:   'LandedCostAllocation',
      entityId:   allocation.id,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: { grnId: dto.grnId, totalLandedCost, method: dto.allocationMethod },
    });

    this.events.emit('landed_cost.allocated', {
      allocationId: allocation.id,
      grnId:        dto.grnId,
      totalCost:    totalLandedCost,
      lineCount:    allocated.length,
    });

    this.logger.log(`Landed cost allocated: ₦${totalLandedCost.toLocaleString()} across ${allocated.length} lines (${dto.allocationMethod})`);
    return { allocationId: allocation.id, lines: allocated };
  }

  // ── Allocation engine ─────────────────────────────────────────

  private allocate(
    lines:    AllocationLine[],
    total:    number,
    method:   AllocationMethod,
  ): AllocationLine[] {
    if (lines.length === 0) throw new BadRequestException('GRN has no lines to allocate costs to');

    // Compute basis per line
    const bases = lines.map(line => {
      switch (method) {
        case 'WEIGHT':
          if (!line.weightKg || line.weightKg <= 0) {
            throw new BadRequestException(
              `Product "${line.productName}" has no weight — cannot use WEIGHT allocation method`
            );
          }
          return line.weightKg * line.quantity;
        case 'VALUE':    return line.lineValue;
        case 'QUANTITY': return line.quantity;
        case 'EQUAL':    return 1;
        default:         throw new BadRequestException(`Unknown allocation method: ${method as string}`);
      }
    });

    const totalBasis = bases.reduce((s, b) => s + b, 0);
    if (totalBasis <= 0) throw new BadRequestException('Total allocation basis is zero — check product weights/values');

    // Compute allocated amounts using proportional split
    const allocated = lines.map((line, i) => {
      const proportion   = (bases[i] ?? 0) / totalBasis;
      const allocatedCost = Math.round(total * proportion * 100) / 100; // Round to 2dp
      return {
        ...line,
        allocatedCost,
        newUnitCost: line.currentUnitCost + allocatedCost / line.quantity,
      };
    });

    // Assign remainder to last line (prevent floating-point drift)
    const sumAllocated = allocated.reduce((s, l) => s + l.allocatedCost, 0);
    const remainder    = Math.round((total - sumAllocated) * 100) / 100;
    if (remainder !== 0 && allocated.length > 0) {
      const last = allocated[allocated.length - 1]!;
      last.allocatedCost += remainder;
      last.newUnitCost    = last.currentUnitCost + last.allocatedCost / last.quantity;
    }

    return allocated;
  }

  // ── List allocations for a GRN ────────────────────────────────

  async listAllocationsForGrn(grnId: string) {
    return this.prisma.landedCostAllocation.findMany({
      where:   { grnId, isDeleted: false },
      include: { components: true, lines: { include: { grnLine: { include: { product: { select: { name: true, sku: true } } } } } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  private async generateJournalNo(branchId: string, tx: any): Promise<string> {
    const count  = await tx.journalEntry.count({ where: { branchId } });
    const branch = await tx.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    return `JNL-${branch?.code ?? 'HQ'}-${String(count + 1).padStart(6, '0')}`;
  }
}
