/**
 * AGCOMS DealerSync ERP — BarcodeService
 * Sprint 5: Section 7 Module 4 — "barcode/QR generation"
 *
 * Generates for serialized stock items:
 *   - QR Code (PNG buffer): contains full equipment identity JSON
 *   - Code128 barcode (SVG): contains serial number + SKU for scanner compatibility
 *
 * QR payload includes: serialNumber, SKU, productName, warehouseCode, internalId
 * The QR/barcode is stored in S3 and the S3 key saved to StockItem.barcodeS3Key
 *
 * Usage in controllers:
 *   GET /inventory/stock-items/:id/barcode  → returns { qrUrl, barcodeUrl }
 *   GET /inventory/stock-items/:id/label    → returns PDF label (via PdfService)
 */
import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { GetObjectCommand } from '@aws-sdk/client-s3';
import { ConfigService } from '@nestjs/config';
import * as QRCode from 'qrcode';

export interface BarcodeResult {
  stockItemId: string;
  serialNumber: string;
  qrDataUrl:   string;   // data:image/png;base64,... for direct embedding
  qrS3Key:     string;
  downloadUrl: string;   // presigned 15-min URL
}

@Injectable()
export class BarcodeService {
  private readonly logger = new Logger(BarcodeService.name);
  private readonly s3: S3Client;
  private readonly bucket: string;

  constructor(
    private readonly prisma: PrismaService,
    private readonly config: ConfigService,
  ) {
    this.bucket = this.config.get<string>('S3_ASSETS_BUCKET', '');
    this.s3 = new S3Client({
      region: this.config.get<string>('AWS_REGION', 'eu-west-1'),
      ...(this.config.get('NODE_ENV') !== 'production' && {
        endpoint:      this.config.get<string>('S3_ENDPOINT'),
        forcePathStyle: true,
      }),
    });
  }

  // ── Generate QR code for a stock item ─────────────────────────

  async generateStockItemQr(stockItemId: string): Promise<BarcodeResult> {
    const item = await this.prisma.stockItem.findUnique({
      where: { id: stockItemId },
      include: {
        product:   { select: { sku: true, name: true } },
        warehouse: { select: { code: true, name: true } },
      },
    });

    if (!item) throw new NotFoundException(`Stock item ${stockItemId} not found`);
    if (!item.serialNumber) {
      throw new Error(`Stock item ${stockItemId} is not serialized — QR generation requires a serial number`);
    }

    // QR payload — contains all identity data for scanning in the field
    const qrPayload = JSON.stringify({
      id:           item.id,
      serialNumber: item.serialNumber,
      sku:          item.product.sku,
      productName:  item.product.name,
      warehouse:    item.warehouse?.code,
      status:       item.status,
      erp:          'AGCOMS-DealerSync',
      version:      '1',
    });

    // Generate QR code as PNG buffer
    const qrBuffer = await QRCode.toBuffer(qrPayload, {
      type:          'png',
      width:         400,
      margin:        2,
      color:         { dark: '#1A4D2E', light: '#FFFFFF' },
      errorCorrectionLevel: 'M',
    });

    // Generate data URL for direct embedding (frontend display)
    const qrDataUrl = await QRCode.toDataURL(qrPayload, {
      width:  200,
      margin: 2,
      color:  { dark: '#1A4D2E', light: '#FFFFFF' },
    });

    // Upload to S3
    const s3Key = `barcodes/stock-items/${stockItemId}/qr-${item.serialNumber}.png`;
    await this.s3.send(new PutObjectCommand({
      Bucket:               this.bucket,
      Key:                  s3Key,
      Body:                 qrBuffer,
      ContentType:          'image/png',
      ServerSideEncryption: 'aws:kms',
      Metadata: {
        'serial-number': item.serialNumber,
        'sku':           item.product.sku,
        'stock-item-id': stockItemId,
      },
    }));

    // Save S3 key to stock item
    await this.prisma.stockItem.update({
      where: { id: stockItemId },
      data:  { barcodeS3Key: s3Key },
    });

    // Generate presigned download URL (15 min)
    const downloadUrl = await getSignedUrl(
      this.s3,
      new GetObjectCommand({ Bucket: this.bucket, Key: s3Key }),
      { expiresIn: 900 },
    );

    this.logger.log(`QR generated for serial ${item.serialNumber}: ${s3Key}`);

    return {
      stockItemId,
      serialNumber: item.serialNumber,
      qrDataUrl,
      qrS3Key:     s3Key,
      downloadUrl,
    };
  }

  // ── Batch generate QR codes for all serialized items in a warehouse ─

  async batchGenerateWarehouseQrs(
    warehouseId: string,
    onProgress?: (done: number, total: number) => void,
  ): Promise<{ generated: number; skipped: number; errors: number }> {
    const items = await this.prisma.stockItem.findMany({
      where: { warehouseId, isSerialized: true, serialNumber: { not: null } },
      select: { id: true, serialNumber: true },
    });

    let generated = 0;
    let skipped   = 0;
    let errors    = 0;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (!item || !item.serialNumber) { skipped++; continue; }
      try {
        await this.generateStockItemQr(item.id);
        generated++;
      } catch (err) {
        this.logger.warn(`QR generation failed for ${item.id}: ${String(err)}`);
        errors++;
      }
      onProgress?.(i + 1, items.length);
    }

    return { generated, skipped, errors };
  }

  // ── Retrieve existing QR (presigned URL) ──────────────────────

  async getQrDownloadUrl(stockItemId: string): Promise<{ downloadUrl: string; expiresAt: Date }> {
    const item = await this.prisma.stockItem.findUnique({
      where:  { id: stockItemId },
      select: { barcodeS3Key: true, serialNumber: true },
    });

    if (!item?.barcodeS3Key) {
      // Auto-generate if missing
      const result = await this.generateStockItemQr(stockItemId);
      return { downloadUrl: result.downloadUrl, expiresAt: new Date(Date.now() + 900_000) };
    }

    const downloadUrl = await getSignedUrl(
      this.s3,
      new GetObjectCommand({ Bucket: this.bucket, Key: item.barcodeS3Key }),
      { expiresIn: 900 },
    );

    return { downloadUrl, expiresAt: new Date(Date.now() + 900_000) };
  }
}
