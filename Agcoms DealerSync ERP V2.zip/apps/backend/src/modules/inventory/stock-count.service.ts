/**
 * AGCOMS DealerSync ERP — StockCountService
 * Sprint 5: Section 7 Module 4 — "Stock counting workflow"
 *           PhysicalCount → Count Lines → Variance → Reconciliation Approval
 *
 * Workflow:
 *   1. CREATE   → new PhysicalCount (status=OPEN), system snapshots current book quantities
 *   2. COUNT    → technician scans items and enters counted quantities (line by line)
 *   3. SUBMIT   → status=SUBMITTED, variances auto-calculated (counted - book)
 *   4. REVIEW   → manager reviews variance report
 *   5. APPROVE  → creates StockAdjustment records for each variance, updates inventory
 *   6. CLOSE    → PhysicalCount status=CLOSED
 *
 * All adjustments are append-only StockMovement records (audit trail).
 */
import {
  Injectable, Logger, NotFoundException, BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { AuditService } from '../../audit/audit.service';
import type { JwtPayload } from '@agcoms/types';

export interface CreateStockCountDto {
  warehouseId:  string;
  branchId:     string;
  title:        string;
  notes?:       string;
  /** If true, creates a count line for every stock item in the warehouse */
  fullCount:    boolean;
  /** If fullCount=false, specific product IDs to include */
  productIds?:  string[];
}

export interface CountLineEntryDto {
  stockItemId:   string;
  countedQty:    number;
  notes?:        string;
}

export interface VarianceSummary {
  stockItemId:    string;
  sku:            string;
  productName:    string;
  bookQty:        number;
  countedQty:     number;
  variance:       number;  // positive = surplus, negative = shortage
  variancePct:    number;
  requiresApproval: boolean;
}

// Variance tolerance — differences < 1% are automatically accepted
const AUTO_ACCEPT_TOLERANCE_PCT = 1;

@Injectable()
export class StockCountService {
  private readonly logger = new Logger(StockCountService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly events: EventEmitter2,
    private readonly audit: AuditService,
  ) {}

  // ── 1. Create physical count ───────────────────────────────────

  async createStockCount(dto: CreateStockCountDto, actor: JwtPayload) {
    const warehouse = await this.prisma.warehouse.findFirst({
      where: { id: dto.warehouseId, branchId: dto.branchId },
    });
    if (!warehouse) throw new NotFoundException('Warehouse not found in this branch');

    // Check no open count already exists for this warehouse
    const existing = await this.prisma.physicalCount.findFirst({
      where: { warehouseId: dto.warehouseId, status: { in: ['OPEN', 'IN_PROGRESS', 'SUBMITTED'] } },
    });
    if (existing) {
      throw new BadRequestException(
        `A stock count (${existing.countNo}) is already in progress for this warehouse. Complete it before starting a new one.`
      );
    }

    // Generate count number
    const countNo = await this.generateCountNo(dto.branchId);

    // Get items to include in the count
    const itemsQuery = dto.fullCount
      ? { warehouseId: dto.warehouseId, isDeleted: false }
      : { warehouseId: dto.warehouseId, isDeleted: false, productId: { in: dto.productIds ?? [] } };

    const items = await this.prisma.stockItem.findMany({
      where: itemsQuery,
      include: { product: { select: { sku: true, name: true } } },
    });

    // Create the count with snapshot of book quantities
    const count = await this.prisma.$transaction(async (tx) => {
      const pc = await tx.physicalCount.create({
        data: {
          countNo,
          warehouseId:  dto.warehouseId,
          branchId:     dto.branchId,
          title:        dto.title,
          notes:        dto.notes,
          status:       'OPEN',
          fullCount:    dto.fullCount,
          createdById:  actor.sub,
          lines: {
            create: items.map(item => ({
              stockItemId: item.id,
              productId:   item.productId,
              bookQty:     item.quantity,   // Snapshot current quantity
              countedQty:  null,            // To be filled by counting team
              notes:       null,
            })),
          },
        },
        include: { lines: { include: { stockItem: { include: { product: true } } } } },
      });
      return pc;
    });

    await this.audit.log({
      action:     'stock_count.created',
      resource:   'PhysicalCount',
      entityId:   count.id,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: { countNo, warehouseId: dto.warehouseId, lineCount: items.length },
    });

    this.logger.log(`Stock count ${countNo} created with ${items.length} lines`);
    return count;
  }

  // ── 2. Enter counted quantity for a line ──────────────────────

  async enterCountLine(
    countId:    string,
    lineId:     string,
    dto:        CountLineEntryDto,
    actor:      JwtPayload,
  ) {
    const count = await this.findActiveCount(countId);
    if (!['OPEN', 'IN_PROGRESS'].includes(count.status)) {
      throw new BadRequestException('Can only enter counts for OPEN or IN_PROGRESS counts');
    }

    const line = await this.prisma.physicalCountLine.findFirst({
      where: { id: lineId, physicalCountId: countId },
    });
    if (!line) throw new NotFoundException('Count line not found');

    const updated = await this.prisma.physicalCountLine.update({
      where: { id: lineId },
      data: {
        countedQty:  dto.countedQty,
        notes:       dto.notes,
        countedById: actor.sub,
        countedAt:   new Date(),
      },
    });

    // Progress the count to IN_PROGRESS on first entry
    if (count.status === 'OPEN') {
      await this.prisma.physicalCount.update({
        where: { id: countId },
        data:  { status: 'IN_PROGRESS' },
      });
    }

    return updated;
  }

  // ── 3. Submit for variance review ─────────────────────────────

  async submitCount(countId: string, actor: JwtPayload) {
    const count = await this.findActiveCount(countId, true);

    const uncounted = count.lines.filter((l: any) => l.countedQty === null);
    if (uncounted.length > 0) {
      throw new BadRequestException(
        `${uncounted.length} lines have not been counted yet. Count all lines before submitting.`
      );
    }

    const variances = this.calculateVariances(count.lines as any[]);

    await this.prisma.physicalCount.update({
      where: { id: countId },
      data: {
        status:      'SUBMITTED',
        submittedAt: new Date(),
        submittedById: actor.sub,
        // Store variance summary as JSON
        varianceSummary: JSON.stringify(variances),
      },
    });

    this.logger.log(`Stock count ${count.countNo} submitted. ${variances.filter(v => v.variance !== 0).length} variances found.`);
    return { countId, variances, totalVariances: variances.filter(v => v.variance !== 0).length };
  }

  // ── 4. Get variance report ────────────────────────────────────

  async getVarianceReport(countId: string): Promise<VarianceSummary[]> {
    const count = await this.findActiveCount(countId, true);
    return this.calculateVariances(count.lines as any[]);
  }

  // ── 5. Approve and reconcile ──────────────────────────────────
  // AI MAY NOT call this. Only human with 'inventory:reconcile' permission.

  async approveAndReconcile(countId: string, actor: JwtPayload) {
    const count = await this.findActiveCount(countId, true);

    if (count.status !== 'SUBMITTED') {
      throw new BadRequestException('Only SUBMITTED counts can be approved and reconciled');
    }

    const variances = this.calculateVariances(count.lines as any[]);
    const nonZero   = variances.filter(v => v.variance !== 0);

    // Create stock adjustments for all variances in a single transaction
    await this.prisma.$transaction(async (tx) => {
      for (const v of nonZero) {
        const adjustmentType = v.variance > 0 ? 'INCREASE' : 'DECREASE';
        const qty            = Math.abs(v.variance);

        // Create stock movement (append-only)
        await tx.stockMovement.create({
          data: {
            stockItemId:     v.stockItemId,
            movementType:    adjustmentType === 'INCREASE' ? 'ADJUSTMENT_IN' : 'ADJUSTMENT_OUT',
            quantity:        qty,
            reason:          `Physical count reconciliation: ${count.countNo}`,
            referenceType:   'PhysicalCount',
            referenceId:     countId,
            performedById:   actor.sub,
            branchId:        count.branchId,
          },
        });

        // Update stock item quantity
        await tx.stockItem.update({
          where: { id: v.stockItemId },
          data:  {
            quantity: { increment: v.variance },
          },
        });
      }

      // Close the count
      await tx.physicalCount.update({
        where: { id: countId },
        data: {
          status:       'CLOSED',
          closedAt:     new Date(),
          closedById:   actor.sub,
          adjustmentsMade: nonZero.length,
        },
      });
    });

    await this.audit.log({
      action:     'stock_count.reconciled',
      resource:   'PhysicalCount',
      entityId:   countId,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: { countNo: count.countNo, adjustmentsMade: nonZero.length },
    });

    this.events.emit('inventory.reconciled', { countId, countNo: count.countNo, adjustments: nonZero.length });

    this.logger.log(`Stock count ${count.countNo} reconciled. ${nonZero.length} adjustments made.`);
    return { countNo: count.countNo, adjustmentsMade: nonZero.length, variances: nonZero };
  }

  // ── Internal helpers ──────────────────────────────────────────

  private async findActiveCount(countId: string, includeLines = false) {
    const count = await this.prisma.physicalCount.findUnique({
      where: { id: countId },
      include: includeLines ? {
        lines: {
          include: {
            stockItem: { include: { product: { select: { sku: true, name: true } } } },
          },
        },
      } : undefined,
    });
    if (!count) throw new NotFoundException(`Stock count ${countId} not found`);
    return count;
  }

  private calculateVariances(lines: any[]): VarianceSummary[] {
    return lines.map(line => {
      const bookQty    = Number(line.bookQty);
      const countedQty = Number(line.countedQty ?? bookQty);
      const variance   = countedQty - bookQty;
      const variancePct = bookQty > 0 ? Math.abs(variance / bookQty) * 100 : variance !== 0 ? 100 : 0;

      return {
        stockItemId:      line.stockItemId,
        sku:              line.stockItem?.product?.sku ?? '',
        productName:      line.stockItem?.product?.name ?? '',
        bookQty,
        countedQty,
        variance,
        variancePct:      Math.round(variancePct * 10) / 10,
        requiresApproval: Math.abs(variancePct) > AUTO_ACCEPT_TOLERANCE_PCT,
      };
    });
  }

  private async generateCountNo(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const count  = await this.prisma.physicalCount.count({ where: { branchId } });
    const seq    = String(count + 1).padStart(4, '0');
    return `COUNT-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${seq}`;
  }
}
