/**
 * AGCOMS DealerSync ERP — Government Contracts DTOs
 * Sprint 2 Fix S2-06: No DTOs for NADF contract or tender management.
 */
import {
  IsString, IsOptional, IsEnum, IsNumber, IsArray,
  ValidateNested, IsDateString, IsUUID, Min, Max, MaxLength, IsPositive,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateTenderDto {
  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty()
  @IsString()
  @MaxLength(300)
  title: string;

  @ApiProperty()
  @IsString()
  @MaxLength(2000)
  description: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  referenceNo?: string;

  @ApiProperty({ minimum: 0, description: 'Estimated contract value in NGN' })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  estimatedValue: number;

  @ApiProperty({ enum: ['NGN', 'USD', 'EUR'] })
  @IsString()
  currency: string;

  @ApiProperty()
  @IsDateString()
  closingDate: string;

  @ApiProperty({ minimum: 0, maximum: 100, description: 'Technical score weight (must sum to 100 with commercialWeightPct)' })
  @IsNumber()
  @Min(0)
  @Max(100)
  @Type(() => Number)
  technicalWeightPct: number;

  @ApiProperty({ minimum: 0, maximum: 100 })
  @IsNumber()
  @Min(0)
  @Max(100)
  @Type(() => Number)
  commercialWeightPct: number;
}

export class RegisterBeneficiaryDto {
  @ApiProperty()
  @IsUUID()
  contractId: string;

  @ApiProperty({ enum: ['INDIVIDUAL_FARMER', 'COOPERATIVE', 'AGRIBUSINESS', 'STATE_AGENCY'] })
  @IsString()
  beneficiaryType: string;

  @ApiProperty()
  @IsString()
  @MaxLength(200)
  name: string;

  @ApiProperty({ description: 'Nigerian phone number' })
  @IsString()
  phone: string;

  @ApiProperty({ description: 'Nigerian state' })
  @IsString()
  state: string;

  @ApiProperty({ description: 'Local Government Area' })
  @IsString()
  lga: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  farmSizeHectares?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  primaryCrop?: string;
}
