import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../../audit/audit.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ContractStatus, MilestoneStatus, Currency, Prisma } from '@prisma/client';
import { paginate, PaginationDto } from '../../common/pagination';

export interface CreateContractDto {
  title: string;
  description?: string;
  nadfRef?: string;
  counterparty: string;
  contactPerson?: string;
  contactEmail?: string;
  contactPhone?: string;
  contractValue: number;
  currency?: Currency;
  vatInclusive?: boolean;
  awardDate?: Date;
  startDate?: Date;
  endDate?: Date;
  branchId: string;
  notes?: string;
}

export interface CreateMilestoneDto {
  contractId: string;
  code: string;
  title: string;
  description?: string;
  value?: number;
  dueDate: Date;
  notes?: string;
}

export interface CreateBeneficiaryDto {
  contractId: string;
  name: string;
  bvn?: string;
  nin?: string;
  phone?: string;
  state?: string;
  lga?: string;
  farmSizeHa?: number;
  cropType?: string;
  equipment?: string;
  notes?: string;
}

export interface CreateDeliveryScheduleDto {
  contractId: string;
  scheduleDate: Date;
  quantity: number;
  equipmentType: string;
  state?: string;
  lga?: string;
  notes?: string;
}

@Injectable()
export class ContractsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextCode(): Promise<string> {
    const year = new Date().getFullYear();
    const count = await this.prisma.governmentContract.count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `GC-NADF-${year}-${String(count + 1).padStart(3, '0')}`;
  }

  // ── Contracts ─────────────────────────────────────────────────────────────

  async listContracts(
    query: PaginationDto & { status?: ContractStatus; branchId?: string },
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where: Prisma.GovernmentContractWhereInput = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
    };
    return paginate(
      this.prisma.governmentContract,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.governmentContract.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getContract(id: string, actorBranchId: string, isSuperAdmin: boolean) {
    const contract = await this.prisma.governmentContract.findFirst({
      where: { id, isDeleted: false },
      include: {
        branch: { select: { id: true, code: true, name: true } },
        manager: { select: { id: true, firstName: true, lastName: true } },
        milestones: { orderBy: { dueDate: 'asc' } },
        deliverySchedules: { orderBy: { scheduleDate: 'asc' } },
        _count: { select: { beneficiaries: true } },
      },
    });
    if (!contract) throw new NotFoundException('Contract not found');
    if (!isSuperAdmin && contract.branchId !== actorBranchId) throw new ForbiddenException('Access denied');
    return contract;
  }

  async createContract(dto: CreateContractDto, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) throw new ForbiddenException('Cannot create contract for another branch');

    const code = await this.nextCode();

    const contract = await this.prisma.governmentContract.create({
      data: {
        code,
        nadfRef: dto.nadfRef,
        title: dto.title,
        description: dto.description,
        counterparty: dto.counterparty,
        contactPerson: dto.contactPerson,
        contactEmail: dto.contactEmail,
        contactPhone: dto.contactPhone,
        contractValue: dto.contractValue,
        currency: dto.currency ?? 'NGN',
        vatInclusive: dto.vatInclusive ?? false,
        awardDate: dto.awardDate,
        startDate: dto.startDate,
        endDate: dto.endDate,
        branchId: dto.branchId,
        managerId: actorId,
        notes: dto.notes,
        createdById: actorId,
      },
    });

    await this.audit.log({ action: 'create', resource: 'government_contract', entityId: contract.id, afterState: contract, actorId });
    this.events.emit('contracts.contract.created', { contractId: contract.id });
    return contract;
  }

  async updateContractStatus(id: string, status: ContractStatus, notes: string, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    const contract = await this.getContract(id, actorBranchId, isSuperAdmin);
    const updated = await this.prisma.governmentContract.update({
      where: { id },
      data: { status, notes: notes ?? contract.notes, updatedAt: new Date() },
    });
    await this.audit.log({ action: `contract_${status.toLowerCase()}`, resource: 'government_contract', entityId: id, beforeState: { status: contract.status }, afterState: { status }, actorId });
    return updated;
  }

  // ── Milestones ────────────────────────────────────────────────────────────

  async createMilestone(dto: CreateMilestoneDto, actorId: string) {
    const milestone = await this.prisma.contractMilestone.create({
      data: {
        contractId: dto.contractId,
        code: dto.code,
        title: dto.title,
        description: dto.description,
        value: dto.value ?? 0,
        dueDate: dto.dueDate,
        notes: dto.notes,
      },
    });
    await this.audit.log({ action: 'create', resource: 'contract_milestone', entityId: milestone.id, afterState: milestone, actorId });
    return milestone;
  }

  async updateMilestoneStatus(id: string, status: MilestoneStatus, actorId: string) {
    const milestone = await this.prisma.contractMilestone.findUnique({ where: { id } });
    if (!milestone) throw new NotFoundException('Milestone not found');

    // AI GOVERNANCE: milestone completion must be a human action with evidence
    const updated = await this.prisma.contractMilestone.update({
      where: { id },
      data: {
        status,
        ...(status === 'COMPLETED' ? { completedAt: new Date() } : {}),
        updatedAt: new Date(),
      },
    });

    await this.audit.log({
      action: `milestone_${status.toLowerCase()}`,
      resource: 'contract_milestone',
      entityId: id,
      beforeState: { status: milestone.status },
      afterState: { status },
      actorId,
    });

    if (status === 'COMPLETED') {
      this.events.emit('contracts.milestone.completed', { milestoneId: id, contractId: milestone.contractId });
    }

    return updated;
  }

  // ── Beneficiaries ─────────────────────────────────────────────────────────

  async addBeneficiary(dto: CreateBeneficiaryDto, actorId: string) {
    const beneficiary = await this.prisma.contractBeneficiary.create({
      data: {
        contractId: dto.contractId,
        name: dto.name,
        bvn: dto.bvn,
        nin: dto.nin,
        phone: dto.phone,
        state: dto.state,
        lga: dto.lga,
        farmSizeHa: dto.farmSizeHa,
        cropType: dto.cropType,
        equipment: dto.equipment,
        notes: dto.notes,
      },
    });
    await this.audit.log({ action: 'create', resource: 'contract_beneficiary', entityId: beneficiary.id, afterState: beneficiary, actorId });
    return beneficiary;
  }

  async listBeneficiaries(contractId: string, query: PaginationDto & { state?: string; lga?: string }) {
    const where: Prisma.ContractBeneficiaryWhereInput = {
      contractId,
      ...(query.state && { state: query.state }),
      ...(query.lga && { lga: query.lga }),
    };
    return paginate(
      this.prisma.contractBeneficiary,
      { where, cursor: query.cursor, limit: query.limit ?? 50 },
      (id) => this.prisma.contractBeneficiary.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  // ── Delivery Schedules ────────────────────────────────────────────────────

  async addDeliverySchedule(dto: CreateDeliveryScheduleDto, actorId: string) {
    const schedule = await this.prisma.contractDeliverySchedule.create({
      data: {
        contractId: dto.contractId,
        scheduleDate: dto.scheduleDate,
        quantity: dto.quantity,
        equipmentType: dto.equipmentType,
        state: dto.state,
        lga: dto.lga,
        notes: dto.notes,
      },
    });
    await this.audit.log({ action: 'create', resource: 'delivery_schedule', entityId: schedule.id, afterState: schedule, actorId });
    return schedule;
  }

  async recordDelivery(id: string, deliveredQty: number, actorId: string) {
    const schedule = await this.prisma.contractDeliverySchedule.findUnique({ where: { id } });
    if (!schedule) throw new NotFoundException('Schedule not found');
    if (deliveredQty > schedule.quantity) throw new BadRequestException('Delivered quantity exceeds scheduled quantity');

    const updated = await this.prisma.contractDeliverySchedule.update({
      where: { id },
      data: {
        deliveredQty,
        deliveredAt: new Date(),
        status: deliveredQty >= schedule.quantity ? 'DELIVERED' : 'PARTIAL',
        updatedAt: new Date(),
      },
    });

    await this.audit.log({
      action: 'delivery_recorded',
      resource: 'delivery_schedule',
      entityId: id,
      beforeState: { deliveredQty: schedule.deliveredQty, status: schedule.status },
      afterState: { deliveredQty, status: updated.status },
      actorId,
    });

    this.events.emit('contracts.delivery.recorded', { scheduleId: id, contractId: schedule.contractId });
    return updated;
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getContractStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };

    const [totalContracts, activeContracts, contractValue, milestones, deliveries] = await Promise.all([
      this.prisma.governmentContract.count({ where: { ...branchFilter, isDeleted: false } }),
      this.prisma.governmentContract.count({ where: { ...branchFilter, isDeleted: false, status: 'ACTIVE' } }),
      this.prisma.governmentContract.aggregate({
        where: { ...branchFilter, isDeleted: false, status: { in: ['ACTIVE', 'AWARDED'] } },
        _sum: { contractValue: true },
      }),
      this.prisma.contractMilestone.groupBy({
        by: ['status'],
        where: { contract: { ...branchFilter, isDeleted: false } },
        _count: { id: true },
      }),
      this.prisma.contractDeliverySchedule.aggregate({
        where: { contract: { ...branchFilter, isDeleted: false } },
        _sum: { quantity: true, deliveredQty: true },
      }),
    ]);

    const totalScheduled = Number(deliveries._sum.quantity ?? 0);
    const totalDelivered = Number(deliveries._sum.deliveredQty ?? 0);

    return {
      totalContracts,
      activeContracts,
      totalContractValue: Number(contractValue._sum.contractValue ?? 0),
      milestones,
      deliveryProgress: {
        scheduled: totalScheduled,
        delivered: totalDelivered,
        pct: totalScheduled > 0 ? Math.round((totalDelivered / totalScheduled) * 100) : 0,
      },
    };
  }
}
