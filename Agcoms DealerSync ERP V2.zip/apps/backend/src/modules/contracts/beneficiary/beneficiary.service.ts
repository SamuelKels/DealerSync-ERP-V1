/**
 * AGCOMS DealerSync ERP — BeneficiaryService
 * §7 Module 10 Government Contracts: "beneficiary tracking"
 *
 * Manages the full NADF (National Agricultural Development Fund)
 * tractor delivery lifecycle:
 *   1. Register farmer / cooperative beneficiary
 *   2. Allocate tractor from inventory (serialised equipment)
 *   3. Record GPS-confirmed delivery
 *   4. Generate NADF compliance report
 *
 * All operations are fully audited and tied to a GovernmentContract.
 * Supports batch import for large NADF programmes (50–1000 beneficiaries).
 */

import {
  Injectable, Logger, NotFoundException,
  BadRequestException, ConflictException,
} from '@nestjs/common';
import { PrismaService }  from '../../../prisma/prisma.service';
import { AuditService }   from '../../../audit/audit.service';
import { EventEmitter2 }  from '@nestjs/event-emitter';
import type { JwtPayload } from '@agcoms/types';

export type BeneficiaryType = 'INDIVIDUAL_FARMER' | 'COOPERATIVE' | 'AGRIBUSINESS' | 'STATE_AGENCY';
export type DeliveryStatus  = 'PENDING' | 'ALLOCATED' | 'IN_TRANSIT' | 'DELIVERED' | 'REJECTED';

export interface RegisterBeneficiaryDto {
  contractId:       string;
  beneficiaryType:  BeneficiaryType;
  name:             string;
  registrationNo?:  string;  // NIN for individual, CAC for cooperative
  phone:            string;
  email?:           string;
  state:            string;
  lga:              string;   // Local Government Area
  ward?:            string;
  farmSizeHectares?: number;
  primaryCrop?:     string;
  bankAccountNo?:   string;
  bankName?:        string;
  notes?:           string;
}

export interface AllocateTractorDto {
  beneficiaryId: string;
  stockItemId:   string;  // Serialised tractor from inventory
  scheduledDate: Date;
  deliveryOfficer?: string;
  notes?:        string;
}

export interface ConfirmDeliveryDto {
  beneficiaryId: string;
  deliveredAt:   Date;
  gpsLat:        number;
  gpsLng:        number;
  deliveryPhotos?: string[];  // S3 URLs
  receiverName:  string;
  receiverSignatureUrl?: string;
  notes?:        string;
}

export interface NadfReportFilters {
  contractId: string;
  state?:     string;
  status?:    DeliveryStatus;
}

@Injectable()
export class BeneficiaryService {
  private readonly logger = new Logger(BeneficiaryService.name);

  constructor(
    private readonly prisma:  PrismaService,
    private readonly audit:   AuditService,
    private readonly events:  EventEmitter2,
  ) {}

  // ── Register beneficiary ──────────────────────────────────────

  async registerBeneficiary(dto: RegisterBeneficiaryDto, actor: JwtPayload) {
    const contract = await this.prisma.governmentContract.findUnique({
      where: { id: dto.contractId },
    });
    if (!contract) throw new NotFoundException(`Contract ${dto.contractId} not found`);
    if (!['ACTIVE', 'PENDING_SIGNATURE'].includes(contract.status)) {
      throw new BadRequestException('Beneficiaries can only be registered against active contracts');
    }

    // Prevent duplicate registration by phone + contractId
    const existing = await this.prisma.contractBeneficiary.findFirst({
      where: { contractId: dto.contractId, phone: dto.phone, isDeleted: false },
    });
    if (existing) {
      throw new ConflictException(`A beneficiary with phone ${dto.phone} is already registered on this contract`);
    }

    const beneficiaryNo = await this.generateBeneficiaryNo(dto.contractId);

    const beneficiary = await this.prisma.contractBeneficiary.create({
      data: {
        beneficiaryNo,
        contractId:       dto.contractId,
        beneficiaryType:  dto.beneficiaryType,
        name:             dto.name,
        registrationNo:   dto.registrationNo,
        phone:            dto.phone,
        email:            dto.email,
        state:            dto.state,
        lga:              dto.lga,
        ward:             dto.ward,
        farmSizeHectares: dto.farmSizeHectares,
        primaryCrop:      dto.primaryCrop,
        bankAccountNo:    dto.bankAccountNo,
        bankName:         dto.bankName,
        deliveryStatus:   'PENDING',
        notes:            dto.notes,
        registeredById:   actor.sub,
      },
    });

    await this.audit.log({
      action:     'beneficiary.registered',
      resource:   'ContractBeneficiary',
      entityId:   beneficiary.id,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: { beneficiaryNo, contractId: dto.contractId, name: dto.name, state: dto.state },
    });

    this.logger.log(`Beneficiary ${beneficiaryNo} registered — ${dto.name}, ${dto.lga} LGA, ${dto.state}`);
    return beneficiary;
  }

  // ── Batch import beneficiaries ────────────────────────────────

  async batchImport(
    contractId: string,
    beneficiaries: Omit<RegisterBeneficiaryDto, 'contractId'>[],
    actor: JwtPayload,
  ) {
    const results = { success: 0, skipped: 0, errors: [] as string[] };

    for (const b of beneficiaries) {
      try {
        await this.registerBeneficiary({ ...b, contractId }, actor);
        results.success++;
      } catch (err) {
        if (err instanceof ConflictException) {
          results.skipped++;
        } else {
          results.errors.push(`${b.name}: ${err instanceof Error ? err.message : 'Unknown error'}`);
        }
      }
    }

    this.logger.log(`Batch import complete: ${results.success} registered, ${results.skipped} skipped, ${results.errors.length} errors`);
    return results;
  }

  // ── Allocate tractor to beneficiary ──────────────────────────

  async allocateTractor(dto: AllocateTractorDto, actor: JwtPayload) {
    const [beneficiary, stockItem] = await Promise.all([
      this.prisma.contractBeneficiary.findUnique({ where: { id: dto.beneficiaryId } }),
      this.prisma.stockItem.findUnique({
        where:   { id: dto.stockItemId },
        include: { product: { select: { name: true, sku: true } } },
      }),
    ]);

    if (!beneficiary) throw new NotFoundException(`Beneficiary ${dto.beneficiaryId} not found`);
    if (!stockItem)   throw new NotFoundException(`Stock item ${dto.stockItemId} not found`);

    if (beneficiary.deliveryStatus !== 'PENDING') {
      throw new BadRequestException(`Beneficiary is already in status ${beneficiary.deliveryStatus} — cannot allocate`);
    }
    if (stockItem.status !== 'AVAILABLE') {
      throw new BadRequestException(`Stock item ${stockItem.serialNo ?? stockItem.id} is not available (status: ${stockItem.status})`);
    }
    if (!stockItem.serialNo) {
      throw new BadRequestException('Only serialised equipment can be allocated to NADF beneficiaries');
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.contractBeneficiary.update({
        where: { id: dto.beneficiaryId },
        data: {
          deliveryStatus:   'ALLOCATED',
          allocatedItemId:  dto.stockItemId,
          allocatedAt:      new Date(),
          scheduledDate:    dto.scheduledDate,
          deliveryOfficer:  dto.deliveryOfficer,
          allocatedById:    actor.sub,
        },
      });

      await tx.stockItem.update({
        where: { id: dto.stockItemId },
        data:  { status: 'RESERVED', reservedForId: dto.beneficiaryId },
      });
    });

    await this.audit.log({
      action:     'beneficiary.tractor_allocated',
      resource:   'ContractBeneficiary',
      entityId:   dto.beneficiaryId,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: {
        beneficiaryNo: beneficiary.beneficiaryNo,
        serialNo: stockItem.serialNo,
        product:  stockItem.product.name,
        scheduledDate: dto.scheduledDate,
      },
    });

    this.events.emit('nadf.tractor_allocated', {
      contractId:    beneficiary.contractId,
      beneficiaryId: dto.beneficiaryId,
      stockItemId:   dto.stockItemId,
      serialNo:      stockItem.serialNo,
    });

    this.logger.log(`Tractor ${stockItem.serialNo} allocated to beneficiary ${beneficiary.beneficiaryNo}`);
    return { allocated: true, serialNo: stockItem.serialNo, scheduledDate: dto.scheduledDate };
  }

  // ── Confirm GPS-verified delivery ─────────────────────────────

  async confirmDelivery(dto: ConfirmDeliveryDto, actor: JwtPayload) {
    const beneficiary = await this.prisma.contractBeneficiary.findUnique({
      where: { id: dto.beneficiaryId },
    });
    if (!beneficiary) throw new NotFoundException(`Beneficiary ${dto.beneficiaryId} not found`);
    if (!['ALLOCATED', 'IN_TRANSIT'].includes(beneficiary.deliveryStatus)) {
      throw new BadRequestException(`Cannot confirm delivery for beneficiary in status ${beneficiary.deliveryStatus}`);
    }

    // Validate GPS coordinates are within Nigeria (approx bounding box)
    if (dto.gpsLat < 4.0 || dto.gpsLat > 14.0 || dto.gpsLng < 2.5 || dto.gpsLng > 15.0) {
      throw new BadRequestException('GPS coordinates appear to be outside Nigeria — please verify location');
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.contractBeneficiary.update({
        where: { id: dto.beneficiaryId },
        data: {
          deliveryStatus:   'DELIVERED',
          deliveredAt:      dto.deliveredAt,
          deliveryLat:      dto.gpsLat,
          deliveryLng:      dto.gpsLng,
          deliveryPhotos:   dto.deliveryPhotos ?? [],
          receiverName:     dto.receiverName,
          receiverSignatureUrl: dto.receiverSignatureUrl,
          confirmedById:    actor.sub,
        },
      });

      // Release stock reservation and mark as delivered
      if (beneficiary.allocatedItemId) {
        await tx.stockItem.update({
          where: { id: beneficiary.allocatedItemId },
          data:  { status: 'DELIVERED', reservedForId: null },
        });
      }
    });

    // Update contract delivery counter
    const contractStats = await this.getContractStats(beneficiary.contractId);
    this.events.emit('nadf.delivery_confirmed', {
      contractId:      beneficiary.contractId,
      beneficiaryId:   dto.beneficiaryId,
      beneficiaryNo:   beneficiary.beneficiaryNo,
      deliveredAt:     dto.deliveredAt,
      gpsLat:          dto.gpsLat,
      gpsLng:          dto.gpsLng,
      totalDelivered:  contractStats.delivered,
    });

    await this.audit.log({
      action:     'beneficiary.delivery_confirmed',
      resource:   'ContractBeneficiary',
      entityId:   dto.beneficiaryId,
      actorId:    actor.sub,
      actorRole:  actor.roles[0],
      afterState: {
        beneficiaryNo: beneficiary.beneficiaryNo,
        deliveredAt:   dto.deliveredAt,
        gpsLat: dto.gpsLat,
        gpsLng: dto.gpsLng,
        receiverName: dto.receiverName,
      },
    });

    this.logger.log(`Delivery confirmed for ${beneficiary.beneficiaryNo} at ${dto.gpsLat},${dto.gpsLng}`);
    return { delivered: true, deliveredAt: dto.deliveredAt, contractStats };
  }

  // ── NADF compliance report ────────────────────────────────────

  async generateNadfReport(filters: NadfReportFilters) {
    const contract = await this.prisma.governmentContract.findUnique({
      where:   { id: filters.contractId },
      include: { branch: { select: { name: true, code: true } } },
    });
    if (!contract) throw new NotFoundException(`Contract ${filters.contractId} not found`);

    const beneficiaries = await this.prisma.contractBeneficiary.findMany({
      where: {
        contractId:     filters.contractId,
        isDeleted:      false,
        ...(filters.state  ? { state: filters.state }           : {}),
        ...(filters.status ? { deliveryStatus: filters.status } : {}),
      },
      orderBy: [{ state: 'asc' }, { lga: 'asc' }, { beneficiaryNo: 'asc' }],
    });

    // Aggregate by state and status
    const byState = beneficiaries.reduce((acc, b) => {
      const key = b.state;
      if (!acc[key]) acc[key] = { state: key, total: 0, delivered: 0, pending: 0, allocated: 0 };
      acc[key]!.total++;
      if (b.deliveryStatus === 'DELIVERED') acc[key]!.delivered++;
      if (b.deliveryStatus === 'PENDING')   acc[key]!.pending++;
      if (b.deliveryStatus === 'ALLOCATED') acc[key]!.allocated++;
      return acc;
    }, {} as Record<string, { state: string; total: number; delivered: number; pending: number; allocated: number }>);

    const stats = await this.getContractStats(filters.contractId);

    return {
      reportDate:    new Date().toISOString(),
      contract: {
        contractNo:    contract.contractNo,
        title:         contract.title,
        value:         Number(contract.contractValue),
        currency:      contract.currency,
        status:        contract.status,
        branch:        contract.branch.name,
      },
      summary: {
        totalBeneficiaries: stats.total,
        delivered:           stats.delivered,
        allocated:           stats.allocated,
        pending:             stats.pending,
        deliveryRate:        stats.total > 0
          ? Math.round((stats.delivered / stats.total) * 1000) / 10
          : 0,
      },
      byState:       Object.values(byState),
      beneficiaries: beneficiaries.map(b => ({
        beneficiaryNo:   b.beneficiaryNo,
        name:            b.name,
        type:            b.beneficiaryType,
        state:           b.state,
        lga:             b.lga,
        ward:            b.ward,
        phone:           b.phone,
        farmSize:        b.farmSizeHectares,
        primaryCrop:     b.primaryCrop,
        deliveryStatus:  b.deliveryStatus,
        allocatedAt:     b.allocatedAt,
        deliveredAt:     b.deliveredAt,
        deliveryLat:     b.deliveryLat,
        deliveryLng:     b.deliveryLng,
        receiverName:    b.receiverName,
      })),
    };
  }

  // ── List and find helpers ─────────────────────────────────────

  async listBeneficiaries(params: {
    contractId: string; state?: string;
    status?: DeliveryStatus; page?: number; limit?: number;
  }) {
    const { contractId, state, status, page = 1, limit = 50 } = params;
    const where = {
      contractId,
      isDeleted: false,
      ...(state  ? { state }           : {}),
      ...(status ? { deliveryStatus: status } : {}),
    };

    const [items, total] = await Promise.all([
      this.prisma.contractBeneficiary.findMany({
        where, skip: (page - 1) * limit, take: limit,
        orderBy: [{ state: 'asc' }, { beneficiaryNo: 'asc' }],
        include: { allocatedItem: { select: { serialNo: true, product: { select: { name: true } } } } },
      }),
      this.prisma.contractBeneficiary.count({ where }),
    ]);
    return { items, total, hasMore: page * limit < total };
  }

  private async getContractStats(contractId: string) {
    const [total, delivered, allocated, pending] = await Promise.all([
      this.prisma.contractBeneficiary.count({ where: { contractId, isDeleted: false } }),
      this.prisma.contractBeneficiary.count({ where: { contractId, deliveryStatus: 'DELIVERED', isDeleted: false } }),
      this.prisma.contractBeneficiary.count({ where: { contractId, deliveryStatus: 'ALLOCATED', isDeleted: false } }),
      this.prisma.contractBeneficiary.count({ where: { contractId, deliveryStatus: 'PENDING', isDeleted: false } }),
    ]);
    return { total, delivered, allocated, pending };
  }

  private async generateBeneficiaryNo(contractId: string): Promise<string> {
    const contract = await this.prisma.governmentContract.findUnique({
      where: { id: contractId }, select: { contractNo: true },
    });
    const prefix = contract?.contractNo.replace(/-/g, '').slice(0, 8) ?? 'BEN';
    const count  = await this.prisma.contractBeneficiary.count({ where: { contractId } });
    return `${prefix}-${String(count + 1).padStart(4, '0')}`;
  }
}
