/**
 * AGCOMS DealerSync ERP — Portal Controller
 * Sprint 1 Fix: Controller was missing — no HTTP endpoints existed for this module.
 *
 * Base CRUD scaffold. Domain-specific endpoints are in separate files
 * per feature (e.g. crm.customers.controller.ts, crm.leads.controller.ts).
 * Every route requires JWT auth via the global JwtAuthGuard registered in main.ts.
 */
import {
  Controller, Get, Post, Patch, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { PortalService }       from './portal.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';
import { CurrentUser }         from '../../common/decorators/current-user.decorator';
import type { JwtPayload }     from '@agcoms/types';

@ApiTags('portal')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('portal')
export class PortalController {
  constructor(private readonly svc: PortalService) {}

  @Get()
  @RequirePermission('portal:read')
  @ApiOperation({ summary: 'List portal records — paginated + branch-scoped' })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'page',  required: false, type: Number })
  findAll(
    @Query() query: Record<string, string>,
    @CurrentUser() actor: JwtPayload,
  ) {
    const branchId = actor.isSuperAdmin ? query['branchId'] : actor.branchId;
    return (this.svc as any).findAll?.({ ...query, branchId }, actor)
        ?? { items: [], total: 0 };
  }

  @Get(':id')
  @RequirePermission('portal:read')
  @ApiOperation({ summary: 'Get single portal by ID' })
  findOne(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).findOne?.(id, actor);
  }

  @Post()
  @RequirePermission('portal:write')
  @ApiOperation({ summary: 'Create portal record' })
  create(@Body() dto: Record<string, unknown>, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).create?.(dto, actor);
  }

  @Patch(':id')
  @RequirePermission('portal:write')
  @ApiOperation({ summary: 'Update portal record (partial)' })
  update(
    @Param('id') id: string,
    @Body() dto: Record<string, unknown>,
    @CurrentUser() actor: JwtPayload,
  ) {
    return (this.svc as any).update?.(id, dto, actor);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @RequirePermission('portal:delete')
  @ApiOperation({ summary: 'Soft-delete portal record' })
  remove(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).remove?.(id, actor);
  }
}
