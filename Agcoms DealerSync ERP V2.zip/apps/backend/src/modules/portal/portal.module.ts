import { Module }        from '@nestjs/common';
import { JwtModule }     from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PortalController } from './portal.controller';
import { PortalService }    from './portal.service';

@Module({
  imports: [
    JwtModule.registerAsync({
      imports:    [ConfigModule],
      inject:     [ConfigService],
      useFactory: (cfg: ConfigService) => ({
        secret: cfg.get<string>('JWT_PORTAL_SECRET') ?? cfg.get<string>('JWT_SECRET') ?? 'fallback',
      }),
    }),
  ],
  controllers: [PortalController],
  providers:   [PortalService],
  exports:     [PortalService],
})
export class PortalModule {}
