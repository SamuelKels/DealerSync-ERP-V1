/**
 * AGCOMS DealerSync ERP — WhatsApp Queue Processor
 * Sprint 3 / S3-A: BullMQ processor for reliable WhatsApp delivery.
 *
 * §3 Tech Stack: Queues: BullMQ
 *
 * Each job:
 *   1. Calls WhatsappService.dispatchToMeta()
 *   2. Updates WhatsappLog with messageId (SENT)
 *   3. On failure: marks log as FAILED, logs error
 *
 * BullMQ handles retries with exponential backoff (3 attempts, 5s base).
 * Failed jobs go to the dead-letter queue visible in Grafana queue dashboard.
 */
import { Process, Processor, OnQueueFailed, OnQueueCompleted } from '@nestjs/bull';
import { Logger }                          from '@nestjs/common';
import { Job }                             from 'bull';
import { WhatsappService, WHATSAPP_QUEUE, type WhatsappJobPayload } from '../whatsapp.service';

@Processor(WHATSAPP_QUEUE)
export class WhatsappQueueProcessor {
  private readonly logger = new Logger(WhatsappQueueProcessor.name);

  constructor(private readonly whatsapp: WhatsappService) {}

  @Process({ concurrency: 5 })   // Up to 5 concurrent sends (respects Meta rate limits)
  async processJob(job: Job<WhatsappJobPayload>): Promise<{ messageId: string }> {
    const { logId, recipientPhone, templateKey } = job.data;

    this.logger.debug(`Processing WhatsApp job ${job.id}: ${templateKey} → ${recipientPhone}`);

    try {
      const result = await this.whatsapp.dispatchToMeta(job.data);

      // Mark as SENT (not yet DELIVERED — that comes via webhook)
      await this.whatsapp.updateLogStatus(logId, 'SENT', result.messageId);

      return result;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : String(err);

      // On final failure (all retries exhausted), mark log as FAILED
      if (job.attemptsMade >= (job.opts.attempts ?? 3) - 1) {
        await this.whatsapp.updateLogStatus(logId, 'FAILED', undefined, errorMsg);
      }

      this.logger.error(`WhatsApp delivery failed (attempt ${job.attemptsMade + 1}): ${errorMsg}`);
      throw err;  // Re-throw so BullMQ schedules retry
    }
  }

  @OnQueueFailed()
  onFailed(job: Job<WhatsappJobPayload>, err: Error) {
    this.logger.error(
      `Job ${job.id} permanently failed after ${job.attemptsMade} attempts: ${err.message}`,
      { templateKey: job.data.templateKey, phone: job.data.recipientPhone },
    );
  }

  @OnQueueCompleted()
  onCompleted(job: Job<WhatsappJobPayload>, result: { messageId: string }) {
    this.logger.debug(`Job ${job.id} completed: messageId=${result.messageId}`);
  }
}
