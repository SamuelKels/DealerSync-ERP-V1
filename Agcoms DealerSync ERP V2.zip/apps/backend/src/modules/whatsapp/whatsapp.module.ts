/**
 * AGCOMS DealerSync ERP — WhatsAppModule
 * Sprint 3 / S3-A: Registers WhatsApp service globally.
 * Exported so SalesModule, WorkshopModule, ContractsModule can inject WhatsappService.
 */
import { Module }        from '@nestjs/common';
import { HttpModule }    from '@nestjs/axios';
import { BullModule }    from '@nestjs/bull';
import { WhatsappService }          from './whatsapp.service';
import { WhatsappController }       from './whatsapp.controller';
import { WhatsappQueueProcessor }   from './processors/whatsapp.processor';
import { WHATSAPP_QUEUE }           from './whatsapp.service';

@Module({
  imports: [
    HttpModule.register({ timeout: 15_000 }),
    // Register the BullMQ queue — backed by Redis (already in docker-compose.yml)
    BullModule.registerQueue({
      name:           WHATSAPP_QUEUE,
      defaultJobOptions: {
        attempts:     3,
        backoff:      { type: 'exponential', delay: 5_000 },
        removeOnComplete: 100,
        removeOnFail: 50,
      },
    }),
  ],
  controllers: [WhatsappController],
  providers:   [WhatsappService, WhatsappQueueProcessor],
  exports:     [WhatsappService],   // Injected by Sales, Workshop, Contracts
})
export class WhatsappModule {}
