import { Injectable, Logger, type OnModuleDestroy, type OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

/**
 * RedisService — wraps ioredis Redis client.
 * V2 NOTE: Uses composition (not inheritance) to avoid base-class method signature
 * conflicts with ioredis declarations.
 */
@Injectable()
export class RedisService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(RedisService.name);
  public readonly client: Redis;

  constructor(private readonly config: ConfigService) {
    this.client = new Redis(config.get<string>('REDIS_URL', 'redis://localhost:6379'), {
      maxRetriesPerRequest: 3,
      enableReadyCheck:     true,
      lazyConnect:          true,
      connectTimeout:       5000,
      commandTimeout:       3000,
      reconnectOnError: (err) => {
        this.logger.error(`Redis reconnect on error: ${err.message}`);
        return true;
      },
    });

    this.client.on('error',        (err) => this.logger.error(`Redis error: ${err.message}`));
    this.client.on('connect',      ()    => this.logger.log('Redis connected'));
    this.client.on('reconnecting', ()    => this.logger.warn('Redis reconnecting…'));
  }

  async onModuleInit(): Promise<void> {
    if (this.client.status !== 'ready') {
      await this.client.connect().catch(() => undefined);
    }
  }

  async onModuleDestroy(): Promise<void> {
    this.client.disconnect();
  }

  /** Used by HealthModule to probe Redis readiness. */
  async pingProbe(): Promise<string> {
    return await this.client.ping();
  }

  // ── Common Redis methods delegated to underlying client ───────────────────
  async get(key: string)                                    { return this.client.get(key); }
  async set(key: string, value: string, ...args: any[])     { return (this.client.set as any)(key, value, ...args); }
  async del(...keys: string[])                              { return this.client.del(...keys); }
  async setex(key: string, seconds: number, value: string)  { return this.client.setex(key, seconds, value); }
  async incr(key: string)                                   { return this.client.incr(key); }
  async expire(key: string, seconds: number)                { return this.client.expire(key, seconds); }
  async exists(...keys: string[])                           { return this.client.exists(...keys); }
  async keys(pattern: string)                               { return this.client.keys(pattern); }
  async hget(key: string, field: string)                    { return this.client.hget(key, field); }
  async hset(key: string, field: string, value: string)     { return this.client.hset(key, field, value); }
  async hgetall(key: string)                                { return this.client.hgetall(key); }
  async sadd(key: string, ...members: string[])             { return this.client.sadd(key, ...members); }
  async smembers(key: string)                               { return this.client.smembers(key); }
  async srem(key: string, ...members: string[])             { return this.client.srem(key, ...members); }
  async lpush(key: string, ...values: string[])             { return this.client.lpush(key, ...values); }
  async rpush(key: string, ...values: string[])             { return this.client.rpush(key, ...values); }
  async lrange(key: string, start: number, stop: number)    { return this.client.lrange(key, start, stop); }
  async lpop(key: string)                                   { return this.client.lpop(key); }
  multi()                                                   { return this.client.multi(); }
  pipeline()                                                { return this.client.pipeline(); }
  duplicate()                                               { return this.client.duplicate(); }
  on(event: string, listener: (...args: any[]) => void)     { return this.client.on(event, listener); }
}
