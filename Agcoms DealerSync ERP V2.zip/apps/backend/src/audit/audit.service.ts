import { Injectable, Logger } from '@nestjs/common';
// AuditAction is a string literal in this implementation

import { PrismaService } from '../prisma/prisma.service';

export interface AuditParams {
  action: string;
  resource: string;
  resourceId?: string;
  actorUserId?: string | null;
  actorRole?: string | null;
  beforeState?: Record<string, unknown>;
  afterState?: Record<string, unknown>;
  ipAddress?: string | null;
  userAgent?: string | null;
  traceId?: string | null;
}

/**
 * AuditService — append-only write path.
 *
 * NO update/delete operations are available on audit records. The repository
 * pattern enforces append-only semantics as required by Section 5.
 *
 * Schema-level protection: the DB user used by the application should only
 * have INSERT on the audit_entries table (apply via a migration-time GRANT).
 */
@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaService) {}

  async record(params: AuditParams): Promise<void> {
    try {
      await this.prisma.auditEntry.create({
        data: {
          actorUserId: params.actorUserId ?? null,
          actorRole: params.actorRole ?? null,
          action: params.action,
          resource: params.resource,
          resourceId: params.resourceId ?? null,
          beforeState: params.beforeState ?? undefined,
          afterState: params.afterState ?? undefined,
          ipAddress: params.ipAddress ?? null,
          userAgent: params.userAgent ?? null,
          traceId: params.traceId ?? null,
        },
      });
    } catch (err) {
      // Audit failure is logged but NEVER propagated — it must not break the
      // primary transaction. Use dead-letter queue for audit failures in Phase 2.
      this.logger.error(`Audit write failed: ${(err as Error).message}`, (err as Error).stack);
    }
  }

  /** Alias for record() — used throughout services for consistency */
  async log(params: {
    action:     string;
    resource:   string;
    entityId?:  string;
    actorId:    string;
    actorRole?: string;   // Optional — many services don't have role context
    beforeState?: Record<string, unknown>;
    afterState?:  Record<string, unknown>;
    ip?:          string;
  }): Promise<void> {
    return this.record({
      action:      params.action,
      resource:    params.resource,
      resourceId:  params.entityId,
      actorUserId: params.actorId,
      actorRole:   params.actorRole,
      beforeState: params.beforeState,
      afterState:  params.afterState,
      ipAddress:   params.ip,
    });
  }
}
