import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'AGCOMS Customer Portal',
  description: 'Customer portal for AGCOMS DealerSync ERP',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
