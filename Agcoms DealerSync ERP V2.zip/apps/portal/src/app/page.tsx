export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-agcoms-surface">
      <div className="text-center">
        <h1 className="text-3xl font-semibold text-agcoms-green">AGCOMS Customer Portal</h1>
        <p className="mt-2 text-gray-600">Sign in to view your quotations, invoices, and service history.</p>
        <a href="/login" className="mt-6 inline-block px-6 py-2 bg-agcoms-green text-white rounded-lg">Sign In</a>
      </div>
    </main>
  );
}
