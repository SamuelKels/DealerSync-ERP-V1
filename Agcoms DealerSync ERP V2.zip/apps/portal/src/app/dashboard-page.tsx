/**
 * AGCOMS Customer Portal — Dashboard (V2 stub)
 */
'use client';
import Link from 'next/link';

export default function PortalDashboard() {
  return (
    <main className="min-h-screen bg-agcoms-surface p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-semibold text-agcoms-green mb-6">Customer Portal</h1>
        <p className="text-gray-700 mb-8">Welcome to your AGCOMS account dashboard.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link href="/quotations" className="bg-white p-6 rounded-xl border hover:shadow-md">
            <h2 className="font-semibold">Quotations</h2>
            <p className="text-sm text-gray-600 mt-1">View open quotations</p>
          </Link>
          <Link href="/invoices" className="bg-white p-6 rounded-xl border hover:shadow-md">
            <h2 className="font-semibold">Invoices</h2>
            <p className="text-sm text-gray-600 mt-1">Pay and download</p>
          </Link>
          <Link href="/service" className="bg-white p-6 rounded-xl border hover:shadow-md">
            <h2 className="font-semibold">Service requests</h2>
            <p className="text-sm text-gray-600 mt-1">Track workshop progress</p>
          </Link>
        </div>
      </div>
    </main>
  );
}
