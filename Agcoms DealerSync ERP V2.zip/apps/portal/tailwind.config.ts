import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        agcoms: {
          green: '#1A4D2E',
          yellow: '#F5C518',
          gold: '#E8A020',
          surface: '#F7F4EF',
        },
      },
    },
  },
};

export default config;
