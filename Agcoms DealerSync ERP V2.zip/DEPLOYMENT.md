# AGCOMS DealerSync ERP — Production Deployment Runbook

**Version:** 1.0  
**Environment:** Production (AWS eu-west-1)  
**Stack:** ECS/Fargate · RDS PostgreSQL 16 · ElastiCache Redis · CloudFront · Route53

---

## Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| AWS CLI | 2.x | Infrastructure management |
| Terraform | 1.8+ | IaC provisioning |
| Docker | 24+ | Container builds |
| pnpm | 9.x | Package management |

Ensure `aws configure` is set up with a user that has `AdministratorAccess` or the custom DealerSync IAM policy.

---

## Step 1 — Bootstrap Terraform state (first deploy only)

```bash
bash infrastructure/terraform/bootstrap/create-tfstate-bucket.sh
```

This creates:
- S3 bucket `agcoms-tfstate-prod` (versioned, encrypted, public-access blocked)
- DynamoDB table `agcoms-tfstate-lock` (prevents concurrent applies)
- Empty Secrets Manager entries for all production secrets

---

## Step 2 — Populate production secrets

Using AWS Secrets Manager (not environment files — never commit secrets):

```bash
# Database
aws secretsmanager put-secret-value \
  --secret-id dealersync/prod/database-url \
  --secret-string 'postgresql://dealersync:STRONG_PASS@rds-endpoint:5432/dealersync'

# JWT RS256 keys (generate with: bash scripts/generate-keys.sh)
aws secretsmanager put-secret-value \
  --secret-id dealersync/prod/jwt-keys \
  --secret-string "{\"private\": \"$(cat .keys/jwt-private.b64)\", \"public\": \"$(cat .keys/jwt-public.b64)\"}"

# Anthropic API key
aws secretsmanager put-secret-value \
  --secret-id dealersync/prod/anthropic-api-key \
  --secret-string 'sk-ant-api03-...'

# WhatsApp
aws secretsmanager put-secret-value \
  --secret-id dealersync/prod/whatsapp-credentials \
  --secret-string "{\"phoneNumberId\": \"...\", \"accessToken\": \"...\", \"verifyToken\": \"...\"}"
```

---

## Step 3 — Provision infrastructure

```bash
cd infrastructure/terraform

# Review the plan
terraform plan -var-file=terraform.tfvars

# Apply (creates VPC, ECS, RDS, Redis, ALB, CloudFront, Route53)
terraform apply -var-file=terraform.tfvars
```

**Critical outputs** — save these after apply:
- `alb_dns_name` — the load balancer DNS
- `rds_endpoint` — PostgreSQL endpoint
- `redis_endpoint` — ElastiCache endpoint
- `ecr_backend_url`, `ecr_frontend_url`, `ecr_portal_url` — container registries

---

## Step 4 — Build and push Docker images

```bash
# Authenticate to ECR
aws ecr get-login-password --region eu-west-1 | \
  docker login --username AWS --password-stdin ${ECR_REGISTRY}

# Build and push (replace with actual ECR URLs from Terraform output)
IMAGE_TAG=$(git rev-parse --short HEAD)

docker build -t ${ECR_REGISTRY}/dealersync-backend:${IMAGE_TAG}  -f apps/backend/Dockerfile  .
docker build -t ${ECR_REGISTRY}/dealersync-frontend:${IMAGE_TAG} -f apps/frontend/Dockerfile .
docker build -t ${ECR_REGISTRY}/dealersync-portal:${IMAGE_TAG}   -f apps/portal/Dockerfile   .

docker push ${ECR_REGISTRY}/dealersync-backend:${IMAGE_TAG}
docker push ${ECR_REGISTRY}/dealersync-frontend:${IMAGE_TAG}
docker push ${ECR_REGISTRY}/dealersync-portal:${IMAGE_TAG}
```

---

## Step 5 — Database setup

```bash
# Run migrations against production RDS
DATABASE_URL="postgresql://dealersync:PASS@rds-endpoint:5432/dealersync" \
  pnpm --filter backend run db:migrate

# Create Super Admin
DATABASE_URL="postgresql://dealersync:PASS@rds-endpoint:5432/dealersync" \
  ADMIN_EMAIL=admin@agcoms.ng \
  ADMIN_FIRST=System \
  ADMIN_LAST=Administrator \
  pnpm --filter backend run create:admin --non-interactive
```

---

## Step 6 — Deploy ECS services

```bash
# Update ECS services with new image tag
aws ecs update-service \
  --cluster dealersync-production \
  --service dealersync-backend \
  --force-new-deployment

aws ecs update-service \
  --cluster dealersync-production \
  --service dealersync-frontend \
  --force-new-deployment
```

Wait for services to stabilise:
```bash
aws ecs wait services-stable \
  --cluster dealersync-production \
  --services dealersync-backend dealersync-frontend
```

---

## Step 7 — Health verification

```bash
API_URL=https://api.dealersync.agcoms.ng
FRONTEND_URL=https://dealersync.agcoms.ng

# Backend health
curl -f "${API_URL}/api/v1/health"
curl -f "${API_URL}/api/v1/health/ready"

# Swagger docs (should be disabled in production — verify)
curl -f "${API_URL}/api/docs" && echo "WARNING: Swagger exposed in production" || echo "OK: Swagger not exposed"

# Run full health check
bash scripts/health-check.sh --api-only
```

---

## Step 8 — Post-deployment validation

Run smoke tests:
```bash
pnpm --filter frontend run test:e2e -- --project=smoke
```

Verify monitoring:
- Grafana: https://dealersync.agcoms.ng/grafana
- All Prometheus targets UP: https://dealersync.agcoms.ng/prometheus/targets

---

## Rollback procedure

```bash
# Get the previous image tag from ECR
PREVIOUS_TAG=$(aws ecr describe-images \
  --repository-name dealersync-backend \
  --query 'sort_by(imageDetails,& imagePushedAt)[-2].imageTags[0]' \
  --output text)

# Update ECS to use previous tag
aws ecs update-service \
  --cluster dealersync-production \
  --service dealersync-backend \
  --task-definition dealersync-backend:${PREVIOUS_TASK_DEF_REVISION}
```

---

## Environment variables required in production

| Variable | Source | Notes |
|----------|--------|-------|
| `DATABASE_URL` | Secrets Manager | RDS connection string |
| `JWT_PRIVATE_KEY` | Secrets Manager | RS256 base64-encoded PEM |
| `JWT_PUBLIC_KEY` | Secrets Manager | RS256 base64-encoded PEM |
| `ANTHROPIC_API_KEY` | Secrets Manager | Claude API key |
| `WHATSAPP_PHONE_NUMBER_ID` | Secrets Manager | Meta Business |
| `WHATSAPP_ACCESS_TOKEN` | Secrets Manager | Meta permanent token |
| `REDIS_URL` | Terraform output | ElastiCache endpoint |
| `AWS_S3_BUCKET` | Terraform output | S3 bucket name |
| `WEBAUTHN_RP_ID` | tfvars | `dealersync.agcoms.ng` |
| `WEBAUTHN_ORIGIN` | tfvars | `https://dealersync.agcoms.ng` |
| `SENTRY_DSN` | Secrets Manager | Error tracking |
| `DOMAIN` | tfvars | `dealersync.agcoms.ng` |

---

## Nigerian-specific deployment notes

- **AWS Region:** `eu-west-1` (Ireland) is the closest AWS region to Nigeria with full service availability. `af-south-1` (Cape Town) is available but has fewer services.
- **Latency:** Typical RTT from Lagos to eu-west-1 is 80–120ms — acceptable for an ERP.
- **DNS TTL:** Set Route53 TTL to 60s during first deployment (allows quick cutover if issues arise).
- **WhatsApp:** Ensure the Meta webhook URL (`https://api.dealersync.agcoms.ng/api/v1/whatsapp/webhook`) is registered in Meta Business Suite before go-live.
- **FIRS TaxPro-Max:** Test Excel export format against the actual FIRS portal with a test filing in a sandbox environment before processing real returns.

---

*AGCOMS International Trading Limited — DealerSync ERP v1.0*  
*Production deployment runbook — keep updated with each release*
