import { z } from 'zod';
import { EmailSchema, PhoneSchema, UuidSchema, NigerianAmountSchema, CurrencyCodeSchema } from './auth';

// ── Procurement Schemas ───────────────────────────────────────

export const CreateVendorSchema = z.object({
  name:           z.string().min(2).max(200).trim(),
  tradingName:    z.string().max(200).optional(),
  rcNumber:       z.string().max(20).optional(),
  taxId:          z.string().max(20).optional(),
  email:          EmailSchema.optional(),
  phone:          PhoneSchema,
  phone2:         PhoneSchema.optional(),
  address:        z.string().max(500).optional(),
  city:           z.string().max(100).optional(),
  state:          z.string().max(100).optional(),
  country:        z.string().max(100).default('Nigeria'),
  website:        z.string().url().optional().or(z.literal('')),
  contactPerson:  z.string().max(200).optional(),
  category:       z.enum(['OEM_DEALER','SPARE_PARTS','CONSUMABLES','SERVICES','LOGISTICS','IT','GENERAL']),
  bankName:       z.string().max(100).optional(),
  bankAccount:    z.string().max(20).optional(),
  bankCode:       z.string().max(10).optional(),
  paymentTerms:   z.number().int().min(0).max(365).default(30),
  currency:       CurrencyCodeSchema.default('NGN'),
  creditLimit:    NigerianAmountSchema.default(0),
  branchId:       UuidSchema.optional(),
  notes:          z.string().max(2000).optional(),
}).strict();
export type CreateVendorDto = z.infer<typeof CreateVendorSchema>;

export const PurchaseOrderLineSchema = z.object({
  productId:   UuidSchema.optional(),
  description: z.string().min(1).max(500).trim(),
  quantity:    z.number().positive(),
  unit:        z.string().max(50).default('unit'),
  unitCost:    NigerianAmountSchema,
  vatRate:     z.number().min(0).max(100).default(7.5),
});

export const CreatePurchaseOrderSchema = z.object({
  vendorId:        UuidSchema,
  requisitionId:   UuidSchema.optional(),
  branchId:        UuidSchema,
  currency:        CurrencyCodeSchema.default('NGN'),
  exchangeRate:    z.number().positive().default(1),
  paymentTerms:    z.number().int().min(0).max(365).default(30),
  deliveryAddress: z.string().max(500).optional(),
  expectedDelivery: z.coerce.date().optional(),
  notes:           z.string().max(2000).optional(),
  internalNotes:   z.string().max(2000).optional(),
  lines:           z.array(PurchaseOrderLineSchema).min(1, 'At least one line item required'),
}).strict();
export type CreatePurchaseOrderDto = z.infer<typeof CreatePurchaseOrderSchema>;

export const VendorScoreSchema = z.object({
  qualityScore:  z.number().int().min(0).max(100),
  deliveryScore: z.number().int().min(0).max(100),
  priceScore:    z.number().int().min(0).max(100),
}).strict();
export type VendorScoreDto = z.infer<typeof VendorScoreSchema>;

// ── Finance Schemas ───────────────────────────────────────────

export const JournalLineSchema = z.object({
  accountId:    UuidSchema,
  description:  z.string().max(500).optional(),
  debitAmount:  z.number().nonnegative(),
  creditAmount: z.number().nonnegative(),
  costCentre:   z.string().max(50).optional(),
  entityRef:    z.string().max(100).optional(),
  entityType:   z.string().max(50).optional(),
}).strict().refine(
  (l) => (l.debitAmount > 0) !== (l.creditAmount > 0) || (l.debitAmount === 0 && l.creditAmount === 0),
  { message: 'Each line must have either a debit or credit amount, not both' }
);

export const CreateJournalEntrySchema = z.object({
  entryDate:     z.coerce.date(),
  description:   z.string().min(3).max(500).trim(),
  branchId:      UuidSchema,
  reference:     z.string().max(100).optional(),
  referenceType: z.string().max(50).optional(),
  entryType:     z.string().max(50).optional(),
  currency:      CurrencyCodeSchema.default('NGN'),
  exchangeRate:  z.number().positive().default(1),
  notes:         z.string().max(2000).optional(),
  lines:         z.array(JournalLineSchema).min(2, 'Journal entry must have at least 2 lines'),
}).strict().refine((d) => {
  const totalDebits  = d.lines.reduce((s, l) => s + l.debitAmount, 0);
  const totalCredits = d.lines.reduce((s, l) => s + l.creditAmount, 0);
  return Math.abs(totalDebits - totalCredits) < 0.01;
}, { message: 'Journal entry must be balanced: total debits must equal total credits', path: ['lines'] });
export type CreateJournalEntryDto = z.infer<typeof CreateJournalEntrySchema>;

export const CreateVatReturnSchema = z.object({
  periodId:        UuidSchema,
  branchId:        UuidSchema,
  periodMonth:     z.number().int().min(1).max(12),
  outputVatAmount: NigerianAmountSchema,
  taxableSales:    NigerianAmountSchema,
  exemptSales:     NigerianAmountSchema.default(0),
  inputVatAmount:  NigerianAmountSchema,
  taxablePurchases: NigerianAmountSchema,
  notes:           z.string().max(2000).optional(),
}).strict();
export type CreateVatReturnDto = z.infer<typeof CreateVatReturnSchema>;

// ── HR Schemas ────────────────────────────────────────────────

export const CreateEmployeeSchema = z.object({
  firstName:           z.string().min(1).max(100).trim(),
  lastName:            z.string().min(1).max(100).trim(),
  middleName:          z.string().max(100).optional(),
  email:               EmailSchema,
  phone:               PhoneSchema.optional(),
  gender:              z.enum(['MALE','FEMALE','OTHER','PREFER_NOT_TO_SAY']).optional(),
  dateOfBirth:         z.coerce.date().optional(),
  nationalId:          z.string().max(20).optional(),
  bvn:                 z.string().length(11).regex(/^\d{11}$/).optional(),
  jobTitle:            z.string().min(2).max(200).trim(),
  grade:               z.string().max(20).optional(),
  departmentId:        UuidSchema.optional(),
  branchId:            UuidSchema,
  reportsToId:         UuidSchema.optional(),
  employmentType:      z.enum(['FULL_TIME','PART_TIME','CONTRACT','INTERN','CONSULTANT']).default('FULL_TIME'),
  hireDate:            z.coerce.date(),
  grossSalary:         NigerianAmountSchema,
  basicSalary:         NigerianAmountSchema,
  housingAllowance:    NigerianAmountSchema.default(0),
  transportAllowance:  NigerianAmountSchema.default(0),
  otherAllowances:     NigerianAmountSchema.default(0),
  bankName:            z.string().max(100).optional(),
  bankAccountNo:       z.string().max(20).optional(),
  bankCode:            z.string().max(10).optional(),
  pencomPin:           z.string().max(30).optional(),
  nhfNo:               z.string().max(30).optional(),
  taxId:               z.string().max(30).optional(),
}).strict().refine(
  (d) => d.basicSalary <= d.grossSalary,
  { message: 'Basic salary cannot exceed gross salary', path: ['basicSalary'] }
);
export type CreateEmployeeDto = z.infer<typeof CreateEmployeeSchema>;

export const LeaveRequestSchema = z.object({
  employeeId:     UuidSchema,
  leaveTypeId:    UuidSchema,
  startDate:      z.coerce.date(),
  endDate:        z.coerce.date(),
  daysRequested:  z.number().positive(),
  reason:         z.string().max(1000).optional(),
  reliefOfficerId: UuidSchema.optional(),
}).strict().refine(
  (d) => d.endDate >= d.startDate,
  { message: 'End date must be on or after start date', path: ['endDate'] }
);
export type LeaveRequestDto = z.infer<typeof LeaveRequestSchema>;
