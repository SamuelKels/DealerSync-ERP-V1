import { z } from 'zod';
import { EmailSchema, PhoneSchema, UuidSchema, NigerianAmountSchema, CurrencyCodeSchema } from './auth';

// ── CRM Schemas ───────────────────────────────────────────────

export const CreateCustomerSchema = z.object({
  name:         z.string().min(2).max(200).trim(),
  tradingName:  z.string().max(200).trim().optional(),
  customerType: z.enum(['INDIVIDUAL','CORPORATE','GOVERNMENT','NGO']),
  status:       z.enum(['ACTIVE','INACTIVE','BLACKLISTED','PROSPECT']).default('ACTIVE'),
  email:        EmailSchema.optional(),
  phone:        PhoneSchema,
  phone2:       PhoneSchema.optional(),
  address:      z.string().max(500).optional(),
  city:         z.string().max(100).optional(),
  state:        z.string().max(100).optional(),
  country:      z.string().max(100).default('Nigeria'),
  branchId:     UuidSchema,
  creditLimit:  NigerianAmountSchema.default(0),
  notes:        z.string().max(2000).optional(),
}).strict();
export type CreateCustomerDto = z.infer<typeof CreateCustomerSchema>;

export const UpdateCustomerSchema = CreateCustomerSchema.partial().omit({ branchId: true });
export type UpdateCustomerDto = z.infer<typeof UpdateCustomerSchema>;

export const CreateLeadSchema = z.object({
  firstName:   z.string().min(1).max(100).trim(),
  lastName:    z.string().min(1).max(100).trim(),
  company:     z.string().max(200).optional(),
  email:       EmailSchema.optional(),
  phone:       PhoneSchema.optional(),
  source:      z.enum(['WEBSITE','REFERRAL','COLD_CALL','EXHIBITION','GOVERNMENT','OTHER']),
  status:      z.enum(['NEW','CONTACTED','QUALIFIED','PROPOSAL','NEGOTIATION','CLOSED_WON','CLOSED_LOST']).default('NEW'),
  branchId:    UuidSchema,
  assignedToId: UuidSchema.optional(),
  notes:       z.string().max(2000).optional(),
}).strict();
export type CreateLeadDto = z.infer<typeof CreateLeadSchema>;

export const RfqItemSchema = z.object({
  description: z.string().min(1).max(500).trim(),
  quantity:    z.number().positive().multipleOf(0.001),
  unit:        z.string().max(50).default('unit'),
  notes:       z.string().max(500).optional(),
});

export const CreateRfqSchema = z.object({
  customerId:   UuidSchema,
  subject:      z.string().min(3).max(300).trim(),
  description:  z.string().max(2000).optional(),
  requiredBy:   z.coerce.date().optional(),
  branchId:     UuidSchema,
  items:        z.array(RfqItemSchema).min(1, 'At least one RFQ item required'),
}).strict();
export type CreateRfqDto = z.infer<typeof CreateRfqSchema>;

// ── Inventory Schemas ─────────────────────────────────────────

export const CreateProductSchema = z.object({
  sku:          z.string().min(2).max(50).toUpperCase().trim(),
  name:         z.string().min(2).max(300).trim(),
  description:  z.string().max(2000).optional(),
  categoryId:   UuidSchema,
  vatRate:      z.number().min(0).max(100).default(7.5),
  whtRate:      z.number().min(0).max(100).default(0),
  reorderPoint: z.number().nonnegative().default(0),
  reorderQty:   z.number().nonnegative().default(0),
  unitOfMeasure: z.string().max(50).default('unit'),
  isSerialized: z.boolean().default(false),
  notes:        z.string().max(2000).optional(),
}).strict();
export type CreateProductDto = z.infer<typeof CreateProductSchema>;

export const StockAdjustmentSchema = z.object({
  stockItemId:     UuidSchema,
  adjustmentType:  z.enum(['INCREASE','DECREASE','WRITE_OFF','RECOUNT']),
  quantity:        z.number().positive(),
  reason:          z.string().min(5).max(500).trim(),
  branchId:        UuidSchema,
  referenceDoc:    z.string().max(100).optional(),
}).strict();
export type StockAdjustmentDto = z.infer<typeof StockAdjustmentSchema>;

export const InterWarehouseTransferSchema = z.object({
  fromWarehouseId: UuidSchema,
  toWarehouseId:   UuidSchema,
  branchId:        UuidSchema,
  notes:           z.string().max(500).optional(),
  items: z.array(z.object({
    stockItemId: UuidSchema,
    quantity:    z.number().positive(),
  })).min(1),
}).strict().refine(
  (d) => d.fromWarehouseId !== d.toWarehouseId,
  { message: 'Source and destination warehouse must be different', path: ['toWarehouseId'] }
);
export type InterWarehouseTransferDto = z.infer<typeof InterWarehouseTransferSchema>;

// ── Sales Schemas ─────────────────────────────────────────────

export const QuotationLineSchema = z.object({
  productId:   UuidSchema.optional(),
  description: z.string().min(1).max(500).trim(),
  quantity:    z.number().positive(),
  unitPrice:   NigerianAmountSchema,
  vatRate:     z.number().min(0).max(100).default(7.5),
  discount:    z.number().min(0).max(100).default(0),
  notes:       z.string().max(500).optional(),
});

export const CreateQuotationSchema = z.object({
  customerId:   UuidSchema,
  branchId:     UuidSchema,
  validUntil:   z.coerce.date().optional(),
  currency:     CurrencyCodeSchema.default('NGN'),
  exchangeRate: z.number().positive().default(1),
  notes:        z.string().max(2000).optional(),
  internalNotes: z.string().max(2000).optional(),
  lines:        z.array(QuotationLineSchema).min(1, 'At least one line item required'),
}).strict();
export type CreateQuotationDto = z.infer<typeof CreateQuotationSchema>;

export const RecordPaymentSchema = z.object({
  invoiceId:     UuidSchema,
  amount:        NigerianAmountSchema.refine((n) => n > 0, 'Payment amount must be greater than zero'),
  paymentMethod: z.enum(['BANK_TRANSFER','CASH','CHEQUE','ONLINE','POS']),
  reference:     z.string().max(100).optional(),
  paidAt:        z.coerce.date().optional(),
  notes:         z.string().max(500).optional(),
}).strict();
export type RecordPaymentDto = z.infer<typeof RecordPaymentSchema>;
