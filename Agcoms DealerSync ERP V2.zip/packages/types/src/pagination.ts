// ── Pagination ────────────────────────────────────────────────

/** Cursor-based pagination query parameters */
export interface PaginationQuery {
  cursor?: string;
  limit?: number;
  /** Sort field */
  sortBy?: string;
  /** 'asc' | 'desc' */
  sortOrder?: 'asc' | 'desc';
}

/** Paginated response envelope */
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  nextCursor: string | null;
  hasMore: boolean;
  limit: number;
}

// ── Standard API response wrappers ───────────────────────────

/** Success response envelope */
export interface ApiResponse<T = void> {
  success: true;
  data: T;
  meta?: Record<string, unknown>;
}

/** Error response envelope */
export interface ApiErrorResponse {
  success: false;
  statusCode: number;
  error: string;
  message: string | string[];
  timestamp: string;
  path: string;
  requestId?: string;
}

/** Validation error detail */
export interface ValidationError {
  field: string;
  message: string;
  value?: unknown;
}

// ── Audit types ───────────────────────────────────────────────

/** Audit entry record */
export interface AuditEntry {
  id: string;
  action: string;
  resource: string;
  entityId: string;
  actorId: string;
  actorRole?: string;
  ipAddress?: string;
  beforeState?: Record<string, unknown>;
  afterState?: Record<string, unknown>;
  createdAt: Date;
}

// ── Branch types ──────────────────────────────────────────────

export interface BranchSummary {
  id: string;
  code: string;
  name: string;
  city?: string;
  state?: string;
  isHeadquarters: boolean;
}

// ── User types ────────────────────────────────────────────────

export interface UserSummary {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  isActive: boolean;
  branchId: string;
}

// ── Domain event types ────────────────────────────────────────

export interface DomainEvent<T = Record<string, unknown>> {
  eventType: string;
  entityId: string;
  entityType: string;
  payload: T;
  actorId: string;
  occurredAt: Date;
}

// ── File upload types ─────────────────────────────────────────

export interface PresignedUploadUrl {
  uploadUrl: string;
  fileKey: string;
  expiresAt: Date;
  maxSizeBytes: number;
  allowedMimeTypes: string[];
}

export interface UploadedFile {
  fileKey: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  uploadedAt: Date;
}

// ── AI advisory types ─────────────────────────────────────────

export interface AiAdvisory<T = unknown> {
  advisory: T;
  human_action_required: true;
  suggested_human_action: string;
  governance: {
    ai_action: 'summarize' | 'recommend' | 'draft' | 'forecast' | 'classify' | 'analyze' | 'search' | 'predict';
    model: string;
    generated_at: string;
    disclaimer: string;
  };
}
