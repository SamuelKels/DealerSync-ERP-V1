// @agcoms/types — procurement types
// Detailed entity types for the procurement domain
export * from './api';
