// @agcoms/types — workshop types
// Detailed entity types for the workshop domain
export * from './api';
