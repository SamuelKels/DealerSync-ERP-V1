// @agcoms/types — hr types
// Detailed entity types for the hr domain
export * from './api';
