// @agcoms/types — inventory types
// Detailed entity types for the inventory domain
export * from './api';
