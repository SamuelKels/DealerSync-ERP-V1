// ── Authentication & RBAC types ───────────────────────────────

/** Internal staff JWT payload (RS256) */
export interface JwtPayload {
  /** User UUID */
  sub: string;
  /** User email */
  email: string;
  /** First name */
  firstName: string;
  /** Last name */
  lastName: string;
  /** Primary branch UUID */
  branchId: string;
  /** Primary branch code (e.g. 'ABJ', 'LGS') */
  branchCode: string;
  /** All branch UUIDs the user can access */
  branchIds: string[];
  /** Assigned role codes (e.g. ['super_admin', 'finance_manager']) */
  roles: string[];
  /** Flat permission set (e.g. 'invoices:read') */
  permissions: string[];
  /** Super-admin bypass flag */
  isSuperAdmin: boolean;
  /** Token type — distinguishes from portal tokens */
  type: 'internal';
  /** JWT issuer */
  iss?: string;
  /** JWT audience */
  aud?: string;
  /** Session UUID — used to revoke individual sessions */
  sessionId: string;
  /** JWT issued-at (epoch seconds) */
  iat?: number;
  /** JWT expiry (epoch seconds) */
  exp?: number;
}

/** Customer portal JWT payload (separate secret, scoped to one customer) */
export interface PortalJwtPayload {
  /** Customer UUID */
  sub: string;
  /** Customer email */
  email: string;
  /** Customer display name */
  name: string;
  /** Token type — hard barrier from internal tokens */
  type: 'portal';
  iat?: number;
  exp?: number;
}

/** Refresh token payload stored in Redis */
export interface RefreshTokenPayload {
  userId: string;
  sessionId: string;
  family: string;    // rotation family — entire family invalidated on reuse
  issuedAt: number;
}

/** MFA challenge context stored in Redis during 2FA flow */
export interface MfaChallengePayload {
  userId: string;
  sessionId: string;
  expiresAt: number;
}

/** Session record shape */
export interface SessionContext {
  sessionId: string;
  userId: string;
  ipAddress: string;
  userAgent: string;
  deviceFingerprint?: string;
  createdAt: Date;
  lastSeenAt: Date;
  expiresAt: Date;
}

/** RBAC permission string format: 'resource:action' */
export type Permission = string;

/** Role definition */
export interface RoleDefinition {
  id: string;
  code: string;
  name: string;
  permissions: Permission[];
  isSystemRole: boolean;
}

/** Auth response returned to client after successful login */
export interface AuthResponse {
  accessToken: string;
  expiresIn: number;
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    roles: string[];
    branchId: string;
    isSuperAdmin: boolean;
    mfaEnabled: boolean;
  };
}

/** MFA verification step response */
export interface MfaStepResponse {
  requiresMfa: true;
  challengeToken: string;
  expiresIn: number;
}

/** Token refresh response */
export interface TokenRefreshResponse {
  accessToken: string;
  expiresIn: number;
}
