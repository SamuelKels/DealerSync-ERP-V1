// @agcoms/types — ai types
// Detailed entity types for the ai domain
export * from './api';
