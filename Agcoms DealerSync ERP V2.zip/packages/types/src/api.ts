// ── API DTOs (request/response shapes for all modules) ────────

export * from './pagination';

// CRM
export interface CreateCustomerDto {
  name: string; tradingName?: string; customerType: string; email?: string;
  phone: string; address?: string; city?: string; state?: string;
  branchId: string; creditLimit?: number; notes?: string;
}
export interface CreateLeadDto {
  firstName: string; lastName: string; company?: string; email?: string;
  phone?: string; source: string; branchId: string; notes?: string;
}
export interface CreateRfqDto {
  customerId: string; subject: string; description?: string;
  requiredBy?: Date; branchId: string;
  items: { description: string; quantity: number; unit?: string }[];
}

// Inventory
export interface CreateProductDto {
  sku: string; name: string; description?: string; categoryId: string;
  vatRate?: number; whtRate?: number; reorderPoint?: number; reorderQty?: number;
  unitOfMeasure?: string; isSerialized?: boolean;
}
export interface CreateStockAdjustmentDto {
  stockItemId: string; adjustmentType: string; quantity: number;
  reason: string; branchId: string;
}

// Sales
export interface CreateQuotationDto {
  customerId: string; branchId: string; validUntil?: Date; notes?: string;
  currency?: string; exchangeRate?: number;
  lines: { productId: string; description: string; quantity: number; unitPrice: number; vatRate?: number; discount?: number }[];
}
export interface CreateSalesOrderDto {
  quotationId?: string; customerId: string; branchId: string;
  deliveryAddress?: string; expectedDelivery?: Date; notes?: string;
}
export interface RecordPaymentDto {
  invoiceId: string; amount: number; paymentMethod: string;
  reference?: string; paidAt?: Date; notes?: string;
}

// Procurement
export interface CreateVendorDto {
  name: string; phone: string; category: string; email?: string;
  city?: string; state?: string; contactPerson?: string;
  paymentTerms?: number; branchId?: string;
}
export interface CreatePurchaseOrderDto {
  vendorId: string; branchId: string; currency?: string;
  lines: { productId?: string; description: string; quantity: number; unitCost: number; vatRate?: number }[];
}

// Finance
export interface CreateJournalEntryDto {
  entryDate: Date; description: string; branchId: string;
  reference?: string; referenceType?: string; entryType?: string;
  lines: { accountId: string; debitAmount: number; creditAmount: number; description?: string; costCentre?: string }[];
}

// HR
export interface CreateEmployeeDto {
  firstName: string; lastName: string; email: string; phone?: string;
  jobTitle: string; departmentId?: string; branchId: string;
  hireDate: Date; grossSalary: number; basicSalary: number;
  housingAllowance?: number; transportAllowance?: number;
}

// Workshop
export interface CreateServiceRequestDto {
  customerId?: string; stockItemId?: string; branchId: string;
  serviceType: string; faultDescription: string; priority?: string;
  equipmentDesc?: string; make?: string; model?: string; serialNumber?: string;
}

// Fleet
export interface CreateFleetAssetDto {
  name: string; assetType: string; registrationNo?: string;
  make?: string; model?: string; year?: number; branchId: string;
  fuelType?: string; tankCapacityL?: number;
}
