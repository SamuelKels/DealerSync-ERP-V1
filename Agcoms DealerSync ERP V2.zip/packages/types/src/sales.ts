// @agcoms/types — sales types
// Detailed entity types for the sales domain
export * from './api';
