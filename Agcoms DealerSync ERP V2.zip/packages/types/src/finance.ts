// @agcoms/types — finance types
// Detailed entity types for the finance domain
export * from './api';
