"use strict";
// ── Shared enums (mirrored from Prisma) ──────────────────────
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeatureFlag = exports.AccountingPeriodStatus = exports.AccountType = exports.EmploymentStatus = exports.FleetAssetStatus = exports.JobCardStatus = exports.PurchaseOrderStatus = exports.QuotationStatus = exports.InvoiceStatus = exports.CustomerStatus = exports.CustomerType = exports.Currency = void 0;
var Currency;
(function (Currency) {
    Currency["NGN"] = "NGN";
    Currency["USD"] = "USD";
    Currency["EUR"] = "EUR";
    Currency["GBP"] = "GBP";
})(Currency || (exports.Currency = Currency = {}));
var CustomerType;
(function (CustomerType) {
    CustomerType["INDIVIDUAL"] = "INDIVIDUAL";
    CustomerType["CORPORATE"] = "CORPORATE";
    CustomerType["GOVERNMENT"] = "GOVERNMENT";
    CustomerType["NGO"] = "NGO";
})(CustomerType || (exports.CustomerType = CustomerType = {}));
var CustomerStatus;
(function (CustomerStatus) {
    CustomerStatus["ACTIVE"] = "ACTIVE";
    CustomerStatus["INACTIVE"] = "INACTIVE";
    CustomerStatus["BLACKLISTED"] = "BLACKLISTED";
    CustomerStatus["PROSPECT"] = "PROSPECT";
})(CustomerStatus || (exports.CustomerStatus = CustomerStatus = {}));
var InvoiceStatus;
(function (InvoiceStatus) {
    InvoiceStatus["DRAFT"] = "DRAFT";
    InvoiceStatus["ISSUED"] = "ISSUED";
    InvoiceStatus["PAID"] = "PAID";
    InvoiceStatus["PARTIALLY_PAID"] = "PARTIALLY_PAID";
    InvoiceStatus["OVERDUE"] = "OVERDUE";
    InvoiceStatus["CANCELLED"] = "CANCELLED";
    InvoiceStatus["CREDIT_NOTE"] = "CREDIT_NOTE";
})(InvoiceStatus || (exports.InvoiceStatus = InvoiceStatus = {}));
var QuotationStatus;
(function (QuotationStatus) {
    QuotationStatus["DRAFT"] = "DRAFT";
    QuotationStatus["SENT"] = "SENT";
    QuotationStatus["ACCEPTED"] = "ACCEPTED";
    QuotationStatus["REJECTED"] = "REJECTED";
    QuotationStatus["EXPIRED"] = "EXPIRED";
    QuotationStatus["CONVERTED"] = "CONVERTED";
})(QuotationStatus || (exports.QuotationStatus = QuotationStatus = {}));
var PurchaseOrderStatus;
(function (PurchaseOrderStatus) {
    PurchaseOrderStatus["DRAFT"] = "DRAFT";
    PurchaseOrderStatus["PENDING_APPROVAL"] = "PENDING_APPROVAL";
    PurchaseOrderStatus["APPROVED"] = "APPROVED";
    PurchaseOrderStatus["SENT_TO_VENDOR"] = "SENT_TO_VENDOR";
    PurchaseOrderStatus["PARTIALLY_RECEIVED"] = "PARTIALLY_RECEIVED";
    PurchaseOrderStatus["FULLY_RECEIVED"] = "FULLY_RECEIVED";
    PurchaseOrderStatus["INVOICED"] = "INVOICED";
    PurchaseOrderStatus["CLOSED"] = "CLOSED";
    PurchaseOrderStatus["CANCELLED"] = "CANCELLED";
})(PurchaseOrderStatus || (exports.PurchaseOrderStatus = PurchaseOrderStatus = {}));
var JobCardStatus;
(function (JobCardStatus) {
    JobCardStatus["OPEN"] = "OPEN";
    JobCardStatus["IN_PROGRESS"] = "IN_PROGRESS";
    JobCardStatus["ON_HOLD"] = "ON_HOLD";
    JobCardStatus["AWAITING_PARTS"] = "AWAITING_PARTS";
    JobCardStatus["AWAITING_APPROVAL"] = "AWAITING_APPROVAL";
    JobCardStatus["COMPLETED"] = "COMPLETED";
    JobCardStatus["INVOICED"] = "INVOICED";
    JobCardStatus["CANCELLED"] = "CANCELLED";
})(JobCardStatus || (exports.JobCardStatus = JobCardStatus = {}));
var FleetAssetStatus;
(function (FleetAssetStatus) {
    FleetAssetStatus["AVAILABLE"] = "AVAILABLE";
    FleetAssetStatus["IN_USE"] = "IN_USE";
    FleetAssetStatus["UNDER_MAINTENANCE"] = "UNDER_MAINTENANCE";
    FleetAssetStatus["OUT_OF_SERVICE"] = "OUT_OF_SERVICE";
    FleetAssetStatus["DISPOSED"] = "DISPOSED";
})(FleetAssetStatus || (exports.FleetAssetStatus = FleetAssetStatus = {}));
var EmploymentStatus;
(function (EmploymentStatus) {
    EmploymentStatus["ACTIVE"] = "ACTIVE";
    EmploymentStatus["ON_LEAVE"] = "ON_LEAVE";
    EmploymentStatus["SUSPENDED"] = "SUSPENDED";
    EmploymentStatus["TERMINATED"] = "TERMINATED";
    EmploymentStatus["RESIGNED"] = "RESIGNED";
    EmploymentStatus["RETIRED"] = "RETIRED";
})(EmploymentStatus || (exports.EmploymentStatus = EmploymentStatus = {}));
var AccountType;
(function (AccountType) {
    AccountType["ASSET"] = "ASSET";
    AccountType["LIABILITY"] = "LIABILITY";
    AccountType["EQUITY"] = "EQUITY";
    AccountType["REVENUE"] = "REVENUE";
    AccountType["COST_OF_SALES"] = "COST_OF_SALES";
    AccountType["OPERATING_EXPENSE"] = "OPERATING_EXPENSE";
    AccountType["OTHER_INCOME"] = "OTHER_INCOME";
    AccountType["OTHER_EXPENSE"] = "OTHER_EXPENSE";
    AccountType["TAX"] = "TAX";
})(AccountType || (exports.AccountType = AccountType = {}));
var AccountingPeriodStatus;
(function (AccountingPeriodStatus) {
    AccountingPeriodStatus["OPEN"] = "OPEN";
    AccountingPeriodStatus["CLOSED"] = "CLOSED";
    AccountingPeriodStatus["LOCKED"] = "LOCKED";
})(AccountingPeriodStatus || (exports.AccountingPeriodStatus = AccountingPeriodStatus = {}));
var FeatureFlag;
(function (FeatureFlag) {
    FeatureFlag["AI_ASSISTANT"] = "FEATURE_AI_ASSISTANT";
    FeatureFlag["AI_INVENTORY_FORECAST"] = "FEATURE_AI_INVENTORY_FORECAST";
    FeatureFlag["AI_NLP_SEARCH"] = "FEATURE_AI_NLP_SEARCH";
    FeatureFlag["AI_RECOMMENDATIONS"] = "FEATURE_AI_RECOMMENDATIONS";
    FeatureFlag["AI_SUMMARIZATION"] = "FEATURE_AI_SUMMARIZATION";
    FeatureFlag["AI_PREDICTIVE_ANALYTICS"] = "FEATURE_AI_PREDICTIVE_ANALYTICS";
    FeatureFlag["INTEGRATION_TELEMATICS"] = "FEATURE_INTEGRATION_TELEMATICS";
    FeatureFlag["INTEGRATION_PAYMENT"] = "FEATURE_INTEGRATION_PAYMENT";
    FeatureFlag["INTEGRATION_EMAIL"] = "FEATURE_INTEGRATION_EMAIL";
    FeatureFlag["BETA_CUSTOMER_PORTAL"] = "FEATURE_BETA_CUSTOMER_PORTAL";
    FeatureFlag["BETA_MOBILE_OFFLINE"] = "FEATURE_BETA_MOBILE_OFFLINE";
    FeatureFlag["BETA_BULK_IMPORT"] = "FEATURE_BETA_BULK_IMPORT";
    FeatureFlag["EXPERIMENTAL_REPORTS"] = "FEATURE_EXPERIMENTAL_REPORTS";
})(FeatureFlag || (exports.FeatureFlag = FeatureFlag = {}));
