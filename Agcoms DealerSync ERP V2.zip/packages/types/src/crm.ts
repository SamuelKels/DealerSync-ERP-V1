// @agcoms/types — crm types
// Detailed entity types for the crm domain
export * from './api';
