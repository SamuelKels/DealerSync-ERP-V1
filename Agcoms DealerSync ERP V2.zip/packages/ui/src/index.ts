// ============================================================
// @agcoms/ui — Main export barrel
// AGCOMS DealerSync ERP shared component library
//
// V2 NOTE: Only design tokens are exported in V2. Component primitives
// (Button, Card, Table, etc.) are declared in apps/frontend/src/components/
// using shadcn/ui patterns. They will be lifted into this package in a
// future sprint and re-exported from here.
// ============================================================

// Design tokens — colors, typography, spacing, motion
export * from './tokens';
