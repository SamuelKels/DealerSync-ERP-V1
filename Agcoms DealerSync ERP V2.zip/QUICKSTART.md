# AGCOMS DealerSync ERP — Quick Start

**This package is pre-configured.** JWT keys and all environment variables are already set.
You only need Docker Desktop and pnpm installed.

## Prerequisites
- [Docker Desktop](https://www.docker.com/products/docker-desktop/) — installed and running
- [Node.js 20 LTS](https://nodejs.org) — `node -v` should show v20.x or above
- pnpm — `npm install -g pnpm`

## 3 commands to a running system

```bash
# 1. Install dependencies
pnpm install

# 2. Start all infrastructure + database setup
docker compose up -d && sleep 30 && pnpm db:migrate && pnpm db:seed

# 3. Start all servers
pnpm dev
```

That's it. The system will be running at:

| URL | Service |
|-----|---------|
| http://localhost:3000 | ERP frontend |
| http://localhost:3001/api/docs | API documentation (Swagger) |
| http://localhost:3002 | Customer portal |
| http://localhost:3003 | Grafana dashboards |

## Log in

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@agcoms.ng | DealerSync@2025! |
| Finance Manager | finance@agcoms.ng | DealerSync@2025! |
| Sales Manager | sales@agcoms.ng | DealerSync@2025! |
| HR Manager | hr@agcoms.ng | DealerSync@2025! |
| Technician | tech@agcoms.ng | DealerSync@2025! |

> The admin@agcoms.ng user is created by the seed script.
> To create your own admin: `pnpm create:admin`

## Grafana credentials
- URL: http://localhost:3003
- Username: admin
- Password: dealersync_grafana

## MinIO console (file storage)
- URL: http://localhost:9001
- Username: minioadmin
- Password: minioadmin123

## What is pre-configured in this package
- JWT RS256 4096-bit key pair (private + public) — already in apps/backend/.env
- All database connection strings matched to docker-compose.yml
- Redis, MinIO, Typesense endpoints all pre-set
- Frontend API URL pointed to backend

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `docker: command not found` | Install Docker Desktop and ensure it is running |
| Port 3000 in use | `kill $(lsof -ti:3000)` |
| `ECONNREFUSED localhost:5432` | `docker compose up -d` (wait 30 seconds before migrating) |
| Migration fails | `docker compose ps` — confirm postgres shows "healthy" |
| `Cannot find module` | `pnpm install` was not run yet |
