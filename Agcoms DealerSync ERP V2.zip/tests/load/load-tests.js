// tests/load/load-tests.js
/**
 * AGCOMS DealerSync ERP — k6 Load Tests
 * Section 10: "Load testing: k6"
 *
 * Test scenarios:
 *   1. Baseline health check (constant 10 VU)
 *   2. Dashboard KPIs (ramping 0→50→50→0 VU)
 *   3. Invoice list with pagination (100 VU peak)
 *   4. Authentication flow (20 VU)
 *   5. Mixed ERP workload (realistic usage pattern)
 *
 * SLA targets (master prompt Section 9):
 *   - P95 latency < 2s
 *   - P99 latency < 5s
 *   - Error rate < 1%
 *   - 95%+ requests succeed
 */
import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';
import { SharedArray } from 'k6/data';

// ── Custom metrics ────────────────────────────────────────────
const errorRate          = new Rate('erp_errors');
const apiLatency         = new Trend('erp_api_latency', true);
const authLatency        = new Trend('erp_auth_latency', true);
const dashboardLatency   = new Trend('erp_dashboard_latency', true);
const successfulRequests = new Counter('erp_successful_requests');

// ── Configuration ─────────────────────────────────────────────
const BASE_URL = __ENV.BASE_URL ?? 'http://localhost:3000';
const API      = `${BASE_URL}/api/v1`;

// ── Test scenarios ────────────────────────────────────────────
export const options = {
  scenarios: {
    // Scenario 1: API health baseline — constant load
    health_baseline: {
      executor:       'constant-vus',
      vus:            10,
      duration:       '30s',
      exec:           'healthCheck',
      tags:           { scenario: 'health' },
    },

    // Scenario 2: Dashboard KPIs — ramping load
    dashboard_kpis: {
      executor:       'ramping-vus',
      startVUs:       0,
      stages: [
        { duration: '30s', target: 50 },   // Ramp up
        { duration: '1m',  target: 50 },   // Steady state
        { duration: '30s', target: 0  },   // Ramp down
      ],
      exec: 'dashboardLoad',
      tags: { scenario: 'dashboard' },
      startTime: '35s',
    },

    // Scenario 3: Invoice list — peak 100 VU
    invoice_list_peak: {
      executor: 'ramping-vus',
      startVUs: 0,
      stages: [
        { duration: '20s', target: 100 },  // Ramp to 100
        { duration: '40s', target: 100 },  // Hold
        { duration: '10s', target: 0   },  // Ramp down
      ],
      exec:      'invoiceListLoad',
      tags:      { scenario: 'invoices' },
      startTime: '2m45s',
    },

    // Scenario 4: Mixed ERP workload
    mixed_workload: {
      executor: 'ramping-arrival-rate',
      startRate: 1,
      timeUnit: '1s',
      preAllocatedVUs: 30,
      maxVUs: 60,
      stages: [
        { duration: '30s', target: 10 },
        { duration: '1m',  target: 30 },
        { duration: '30s', target: 5  },
      ],
      exec:      'mixedWorkload',
      tags:      { scenario: 'mixed' },
      startTime: '4m10s',
    },
  },

  thresholds: {
    // Section 9 SLA targets
    'http_req_duration{scenario:health}':     ['p(95)<500'],   // Health check must be fast
    'http_req_duration{scenario:dashboard}':  ['p(95)<2000'],  // Dashboard P95 < 2s
    'http_req_duration{scenario:invoices}':   ['p(95)<2000'],  // Invoice list P95 < 2s
    'http_req_duration{scenario:mixed}':      ['p(99)<5000'],  // Mixed P99 < 5s
    'erp_errors':                             ['rate<0.01'],   // Error rate < 1%
    'http_req_failed':                        ['rate<0.05'],   // HTTP failure rate < 5%
  },
};

// ── Shared auth token (obtained in setup) ──────────────────────
let authToken = '';

export function setup() {
  // Authenticate and return token for scenarios
  const loginRes = http.post(`${API}/auth/login`, JSON.stringify({
    email:    __ENV.TEST_EMAIL    ?? 'admin@agcoms.ng',
    password: __ENV.TEST_PASSWORD ?? 'SecureP@ssword123',
  }), {
    headers: { 'Content-Type': 'application/json' },
  });

  const body = loginRes.json();
  if (loginRes.status !== 200 || !body?.data?.accessToken) {
    console.error('Load test auth failed:', loginRes.status, loginRes.body);
    return { token: null };
  }

  return { token: body.data.accessToken };
}

// ── Scenario functions ────────────────────────────────────────

export function healthCheck(data) {
  group('Health Check', () => {
    const res = http.get(`${BASE_URL}/health`, { tags: { name: 'health' } });

    check(res, {
      'status is 200':         r => r.status === 200,
      'body has ok status':    r => r.json('status') === 'ok',
      'response under 200ms':  r => r.timings.duration < 200,
    });

    errorRate.add(res.status !== 200);
    apiLatency.add(res.timings.duration);
    if (res.status === 200) successfulRequests.add(1);
  });

  sleep(0.5);
}

export function dashboardLoad(data) {
  const headers = data?.token
    ? { Authorization: `Bearer ${data.token}` }
    : {};

  group('Dashboard KPIs', () => {
    const res = http.get(`${API}/dashboard/kpis`, { headers, tags: { name: 'dashboard_kpis' } });

    check(res, {
      'status is 200 or 401': r => [200, 401].includes(r.status),
      'response under 2s':    r => r.timings.duration < 2000,
    });

    errorRate.add(![200, 401].includes(res.status));
    dashboardLatency.add(res.timings.duration);
    if (res.status === 200) successfulRequests.add(1);
  });

  sleep(1);
}

export function invoiceListLoad(data) {
  const headers = data?.token
    ? { Authorization: `Bearer ${data.token}` }
    : {};

  group('Invoice List', () => {
    // Simulate paginated browsing
    const pages = [1, 2, 3];
    const page  = pages[Math.floor(Math.random() * pages.length)];

    const res = http.get(`${API}/sales/invoices?page=${page}&limit=20`, {
      headers,
      tags: { name: 'invoice_list' },
    });

    check(res, {
      'status is 200 or 401': r => [200, 401].includes(r.status),
      'response under 2s':    r => r.timings.duration < 2000,
      'returns array':        r => {
        try { const b = r.json(); return Array.isArray(b?.data?.items); } catch { return true; }
      },
    });

    errorRate.add(![200, 401].includes(res.status));
    apiLatency.add(res.timings.duration);
    if (res.status === 200) successfulRequests.add(1);
  });

  sleep(0.5 + Math.random());
}

export function mixedWorkload(data) {
  const headers = data?.token
    ? { Authorization: `Bearer ${data.token}`, 'Content-Type': 'application/json' }
    : { 'Content-Type': 'application/json' };

  // Realistic user session: browse multiple pages
  const flows = [
    () => http.get(`${API}/crm/customers?limit=20`, { headers, tags: { name: 'crm_customers' } }),
    () => http.get(`${API}/inventory/products?limit=20`, { headers, tags: { name: 'inventory_products' } }),
    () => http.get(`${API}/sales/quotations?limit=20`, { headers, tags: { name: 'sales_quotations' } }),
    () => http.get(`${API}/procurement/vendors?limit=20`, { headers, tags: { name: 'procurement_vendors' } }),
    () => http.get(`${API}/finance/journals?limit=20`, { headers, tags: { name: 'finance_journals' } }),
    () => http.get(`${API}/hr/employees?limit=20`, { headers, tags: { name: 'hr_employees' } }),
    () => http.get(`${API}/fleet/assets?limit=20`, { headers, tags: { name: 'fleet_assets' } }),
    () => http.get(`${API}/search?q=tractor`, { headers, tags: { name: 'search' } }),
  ];

  const flow = flows[Math.floor(Math.random() * flows.length)];
  const res  = flow();

  check(res, {
    'status is 200 or 401': r => [200, 401].includes(r.status),
    'response under 3s':    r => r.timings.duration < 3000,
  });

  errorRate.add(![200, 401].includes(res.status));
  apiLatency.add(res.timings.duration);
  if (res.status === 200) successfulRequests.add(1);

  sleep(1 + Math.random() * 2);
}


// ── Smoke load test (CI step 10 — quick version) ─────────────

export const smokeOptions = {
  vus:      5,
  duration: '30s',
  thresholds: {
    http_req_duration: ['p(95)<2000'],
    http_req_failed:   ['rate<0.01'],
  },
};

export function smokeTest(data) {
  const res = http.get(`${BASE_URL}/health`);
  check(res, { 'status is 200': r => r.status === 200 });
  sleep(1);
}
