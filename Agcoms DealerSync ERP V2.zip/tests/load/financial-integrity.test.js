// tests/load/financial-integrity.test.js
// k6 load test: concurrent journal posting
// Validates ACID integrity — no double-posting, no unbalanced entries under load
//
// Section 10: "finance workflow validation" under concurrent load

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Counter } from 'k6/metrics';
import { uuidv4 } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

const errorRate           = new Rate('error_rate');
const conflictRate        = new Rate('conflict_rate');
const successfulPostings  = new Counter('successful_journal_postings');

const BASE_URL = __ENV.BASE_URL || 'https://staging.agcoms-erp.agcomsinternational.com';

export const options = {
  // Test concurrent journal posting (simulates month-end close rush)
  stages: [
    { duration: '30s', target: 10 },
    { duration: '2m',  target: 20 },
    { duration: '30s', target: 0  },
  ],
  thresholds: {
    error_rate:    ['rate<0.02'],   // <2% errors
    conflict_rate: ['rate<0.05'],   // <5% conflicts (expected under concurrent load)
    http_req_duration: ['p(95)<3000'],
  },
};

export function setup() {
  const loginRes = http.post(
    `${BASE_URL}/api/v1/auth/login`,
    JSON.stringify({ email: __ENV.TEST_ADMIN_EMAIL || 'admin@agcoms.ng', password: __ENV.TEST_ADMIN_PASS || 'SecureP@ssword123' }),
    { headers: { 'Content-Type': 'application/json' } }
  );
  if (loginRes.status !== 200 && loginRes.status !== 201) return { token: '' };
  const body = JSON.parse(loginRes.body);
  return { token: body.data?.accessToken ?? body.accessToken ?? '' };
}

export default function main(data) {
  if (!data?.token) { sleep(1); return; }

  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${data.token}` };

  group('Journal ACID posting', () => {
    // Every journal entry MUST be balanced (debits = credits)
    const amount   = Math.round(Math.random() * 1_000_000) / 100;
    const ref      = `LOAD-TEST-${uuidv4().substring(0, 8)}`;

    const entry = {
      entryDate:   new Date().toISOString().split('T')[0],
      description: `Load test entry ${ref}`,
      entryType:   'MANUAL',
      reference:   ref,
      lines: [
        // Dr Cash (1100)
        { accountId: __ENV.TEST_CASH_ACCOUNT_ID || 'cash-account-id',   debitAmount: amount,  creditAmount: 0,      description: 'Load test debit' },
        // Cr Revenue (4000)
        { accountId: __ENV.TEST_REV_ACCOUNT_ID  || 'rev-account-id',    debitAmount: 0,       creditAmount: amount, description: 'Load test credit' },
      ],
    };

    const res = http.post(
      `${BASE_URL}/api/v1/finance/journals`,
      JSON.stringify(entry),
      { headers }
    );

    const isSuccess  = res.status === 201;
    const isConflict = res.status === 409;
    const isError    = res.status >= 500;

    check(res, {
      'journal post not 500':      (r) => r.status < 500,
      'journal response < 3000ms': (r) => r.timings.duration < 3000,
    });

    errorRate.add(isError);
    conflictRate.add(isConflict);
    if (isSuccess) successfulPostings.add(1);

    // Validate no unbalanced entries were accepted
    if (isSuccess) {
      const body = JSON.parse(res.body);
      const entry = body?.data;
      if (entry) {
        check(entry, {
          'posted entry is balanced': (e) => Math.abs(e.totalDebits - e.totalCredits) < 0.01,
          'posted entry has lines':   (e) => (e.lines?.length ?? 0) >= 2,
        });
      }
    }
  });

  sleep(0.5);
}
