// tests/load/api-load.test.js
// k6 load tests — Section 10: "load testing"
// Master prompt: k6 for performance baseline
//
// Run: k6 run tests/load/api-load.test.js
// Run staged: k6 run --env STAGE=full tests/load/api-load.test.js
//
// SLA targets (must all pass):
//   - P95 response time < 2000ms
//   - P99 response time < 5000ms
//   - Error rate < 1%
//   - Health check 100% success rate

import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';
import { randomItem } from 'https://jslib.k6.io/k6-utils/1.4.0/index.js';

// ── Custom metrics ─────────────────────────────────────────────
const errorRate         = new Rate('error_rate');
const dashboardDuration = new Trend('dashboard_kpi_duration', true);
const invoiceDuration   = new Trend('invoice_list_duration', true);
const authDuration      = new Trend('auth_login_duration', true);
const requestsTotal     = new Counter('requests_total');

// ── Test stages ────────────────────────────────────────────────
const BASE_URL = __ENV.BASE_URL || 'https://staging.agcoms-erp.agcomsinternational.com';
const STAGE    = __ENV.STAGE || 'smoke';

const STAGES = {
  // Smoke: minimal load — just verify the endpoints work
  smoke: {
    stages:  [{ duration: '30s', target: 5 }, { duration: '30s', target: 0 }],
    thresholds: { http_req_duration: ['p(95)<3000'], error_rate: ['rate<0.05'] },
  },
  // Soak: sustained normal load
  soak: {
    stages: [
      { duration: '2m', target: 20  },   // Ramp up
      { duration: '5m', target: 20  },   // Sustained
      { duration: '1m', target: 0   },   // Ramp down
    ],
    thresholds: { http_req_duration: ['p(95)<2000', 'p(99)<5000'], error_rate: ['rate<0.01'] },
  },
  // Spike: 100 VU per master prompt requirement
  full: {
    stages: [
      { duration: '1m',  target: 20  },  // Warm up
      { duration: '3m',  target: 100 },  // Target: 100 VU
      { duration: '2m',  target: 100 },  // Sustain
      { duration: '1m',  target: 0   },  // Ramp down
    ],
    thresholds: {
      http_req_duration:       ['p(95)<2000', 'p(99)<5000'],
      error_rate:              ['rate<0.01'],
      dashboard_kpi_duration:  ['p(95)<1500'],
      invoice_list_duration:   ['p(95)<2000'],
    },
  },
};

export const options = STAGES[STAGE] || STAGES.smoke;

// ── Shared headers ─────────────────────────────────────────────
const HEADERS = { 'Content-Type': 'application/json', 'Accept': 'application/json' };

let authToken = '';

// ── Setup: authenticate and get JWT ───────────────────────────
export function setup() {
  const loginRes = http.post(
    `${BASE_URL}/api/v1/auth/login`,
    JSON.stringify({
      email:    __ENV.TEST_ADMIN_EMAIL || 'admin@agcoms.ng',
      password: __ENV.TEST_ADMIN_PASS  || 'SecureP@ssword123',
    }),
    { headers: HEADERS }
  );

  if (loginRes.status !== 200 && loginRes.status !== 201) {
    console.error('Setup login failed:', loginRes.status, loginRes.body);
    return { token: '' };
  }

  const body = JSON.parse(loginRes.body);
  return { token: body.data?.accessToken ?? body.accessToken ?? '' };
}

// ── Main test scenario ─────────────────────────────────────────
export default function main(data) {
  const token  = data?.token ?? '';
  const authHdr = {
    ...HEADERS,
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };

  // ── 1. Health check ──────────────────────────────────────────
  group('Health check', () => {
    const res = http.get(`${BASE_URL}/api/v1/health`);
    requestsTotal.add(1);
    const ok = check(res, {
      'health check returns 200': (r) => r.status === 200,
      'health check < 500ms':     (r) => r.timings.duration < 500,
    });
    errorRate.add(!ok);
  });

  sleep(0.5);

  // ── 2. Dashboard KPIs ────────────────────────────────────────
  group('Dashboard KPIs', () => {
    const start = Date.now();
    const res = http.get(`${BASE_URL}/api/v1/dashboard/kpis`, { headers: authHdr });
    dashboardDuration.add(Date.now() - start);
    requestsTotal.add(1);

    const ok = check(res, {
      'dashboard KPIs status 200': (r) => r.status === 200 || r.status === 401,
      'dashboard KPIs < 2000ms':   (r) => r.timings.duration < 2000,
    });
    errorRate.add(res.status >= 500);
  });

  sleep(0.3);

  // ── 3. Invoice list ──────────────────────────────────────────
  group('Invoice list', () => {
    const start = Date.now();
    const res = http.get(`${BASE_URL}/api/v1/sales/invoices?limit=20&page=1`, { headers: authHdr });
    invoiceDuration.add(Date.now() - start);
    requestsTotal.add(1);

    const ok = check(res, {
      'invoice list status 200':  (r) => r.status === 200 || r.status === 401,
      'invoice list < 2000ms':    (r) => r.timings.duration < 2000,
    });
    errorRate.add(res.status >= 500);
  });

  sleep(0.3);

  // ── 4. Product catalogue search ──────────────────────────────
  group('Product search', () => {
    const queries = ['tractor', 'JD', 'excavator', 'oil', 'spare'];
    const q = randomItem(queries);
    const res = http.get(`${BASE_URL}/api/v1/search/products?q=${q}`, { headers: authHdr });
    requestsTotal.add(1);

    check(res, {
      'product search < 1500ms':  (r) => r.timings.duration < 1500,
      'product search not 500':   (r) => r.status < 500,
    });
    errorRate.add(res.status >= 500);
  });

  sleep(0.5);

  // ── 5. Customer list ─────────────────────────────────────────
  group('Customer list', () => {
    const res = http.get(`${BASE_URL}/api/v1/crm/customers?limit=20`, { headers: authHdr });
    requestsTotal.add(1);

    check(res, {
      'customer list not 500':  (r) => r.status < 500,
      'customer list < 2000ms': (r) => r.timings.duration < 2000,
    });
    errorRate.add(res.status >= 500);
  });

  sleep(1);
}

// ── Teardown: log summary ──────────────────────────────────────
export function teardown(data) {
  console.log('Load test completed');
  console.log(`Token was: ${data?.token ? 'obtained' : 'missing'}`);
}
