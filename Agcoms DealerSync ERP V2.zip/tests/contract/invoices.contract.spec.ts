// tests/contract/invoices.contract.spec.ts
/**
 * AGCOMS DealerSync ERP — Pact Contract Tests
 * Section 10: "Contract testing (Pact)"
 *
 * Consumer: @agcoms/frontend
 * Provider: @agcoms/backend
 *
 * Verifies that the frontend's API call shapes match
 * what the backend actually returns.
 * Any breaking schema change fails this test BEFORE production.
 */
import { PactV3, MatchersV3 } from '@pact-foundation/pact';
import { like, eachLike, integer, string, boolean, decimal } from '@pact-foundation/pact/src/v3/matchers';
import path from 'path';
import axios from 'axios';

const { like: l, eachLike: el, integer: int, string: str, boolean: bool } = MatchersV3;

const provider = new PactV3({
  consumer:  '@agcoms/frontend',
  provider:  '@agcoms/backend',
  dir:       path.resolve(__dirname, '../pacts'),
  logLevel:  'warn',
});

// ── Invoice contracts ─────────────────────────────────────────

describe('Invoice API — Consumer Contract', () => {

  // Contract 1: List invoices
  test('GET /api/v1/sales/invoices returns paginated invoice list', async () => {
    await provider
      .addInteraction({
        states:          [{ description: 'invoices exist for branch HQ' }],
        uponReceiving:   'a request to list invoices',
        withRequest: {
          method: 'GET',
          path:   '/api/v1/sales/invoices',
          query:  { page: '1', limit: '20' },
          headers: {
            Authorization: MatchersV3.regex(/^Bearer .+$/, 'Bearer test-token'),
          },
        },
        willRespondWith: {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
          body: {
            success: true,
            data: {
              items: MatchersV3.eachLike({
                id:           MatchersV3.uuid(),
                invoiceNo:    MatchersV3.string('INV-HQ-2025-00001'),
                status:       MatchersV3.string('ISSUED'),
                totalAmount:  MatchersV3.number(5_000_000),
                amountPaid:   MatchersV3.number(0),
                currency:     MatchersV3.string('NGN'),
                invoiceDate:  MatchersV3.timestamp('yyyy-MM-dd', '2025-01-15'),
                dueDate:      MatchersV3.timestamp('yyyy-MM-dd', '2025-02-15'),
                createdAt:    MatchersV3.timestamp("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", '2025-01-15T10:00:00.000Z'),
                customer: {
                  id:   MatchersV3.uuid(),
                  name: MatchersV3.string('NADF Federal Government'),
                },
              }),
              total:   MatchersV3.integer(1),
              hasMore: MatchersV3.boolean(false),
            },
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await axios.get(`${mockServer.url}/api/v1/sales/invoices`, {
          params:  { page: 1, limit: 20 },
          headers: { Authorization: 'Bearer test-token' },
        });

        expect(res.status).toBe(200);
        expect(res.data.success).toBe(true);
        expect(res.data.data.items).toBeDefined();
        expect(Array.isArray(res.data.data.items)).toBe(true);
        expect(res.data.data.total).toBeGreaterThanOrEqual(0);

        // Validate shape the frontend depends on
        const invoice = res.data.data.items[0];
        if (invoice) {
          expect(invoice).toHaveProperty('id');
          expect(invoice).toHaveProperty('invoiceNo');
          expect(invoice).toHaveProperty('status');
          expect(invoice).toHaveProperty('totalAmount');
          expect(invoice).toHaveProperty('customer');
          expect(invoice.customer).toHaveProperty('name');
        }
      });
  });

  // Contract 2: Get single invoice
  test('GET /api/v1/sales/invoices/:id returns invoice detail', async () => {
    const invoiceId = '550e8400-e29b-41d4-a716-446655440000';

    await provider
      .addInteraction({
        states:        [{ description: `invoice ${invoiceId} exists` }],
        uponReceiving: 'a request for a specific invoice',
        withRequest: {
          method:  'GET',
          path:    `/api/v1/sales/invoices/${invoiceId}`,
          headers: { Authorization: MatchersV3.regex(/^Bearer .+$/, 'Bearer test-token') },
        },
        willRespondWith: {
          status: 200,
          body: {
            success: true,
            data: {
              id:          invoiceId,
              invoiceNo:   MatchersV3.string('INV-HQ-2025-00001'),
              status:      MatchersV3.string('ISSUED'),
              totalAmount: MatchersV3.number(5_000_000),
              vatAmount:   MatchersV3.number(350_000),
              currency:    MatchersV3.string('NGN'),
              customer:    { id: MatchersV3.uuid(), name: MatchersV3.string('Test Customer') },
              branch:      { id: MatchersV3.uuid(), name: MatchersV3.string('HQ Branch') },
              lines: MatchersV3.eachLike({
                id:          MatchersV3.uuid(),
                description: MatchersV3.string('John Deere 6120M Tractor'),
                quantity:    MatchersV3.number(1),
                unitPrice:   MatchersV3.number(4_500_000),
                vatRate:     MatchersV3.number(7.5),
                lineTotal:   MatchersV3.number(4_837_500),
              }),
            },
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await axios.get(`${mockServer.url}/api/v1/sales/invoices/${invoiceId}`, {
          headers: { Authorization: 'Bearer test-token' },
        });

        expect(res.status).toBe(200);
        const inv = res.data.data;
        expect(inv).toHaveProperty('lines');
        expect(Array.isArray(inv.lines)).toBe(true);
      });
  });
});


// ── Quotation contracts ────────────────────────────────────────

describe('Quotation API — Consumer Contract', () => {

  test('GET /api/v1/sales/quotations returns paginated list', async () => {
    await provider
      .addInteraction({
        states:        [{ description: 'quotations exist' }],
        uponReceiving: 'a request to list quotations',
        withRequest: {
          method: 'GET',
          path:   '/api/v1/sales/quotations',
          query:  { page: '1', limit: '25' },
          headers: { Authorization: MatchersV3.regex(/^Bearer .+$/, 'Bearer test-token') },
        },
        willRespondWith: {
          status: 200,
          body: {
            success: true,
            data: {
              items: MatchersV3.eachLike({
                id:           MatchersV3.uuid(),
                quotationNo:  MatchersV3.string('QUO-HQ-2025-00001'),
                status:       MatchersV3.string('DRAFT'),
                totalAmount:  MatchersV3.number(10_000_000),
                currency:     MatchersV3.string('NGN'),
                createdAt:    MatchersV3.timestamp("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", '2025-01-15T10:00:00.000Z'),
                customer:     { name: MatchersV3.string('Test Customer') },
              }),
              total:   MatchersV3.integer(1),
              hasMore: MatchersV3.boolean(false),
            },
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await axios.get(`${mockServer.url}/api/v1/sales/quotations`, {
          params:  { page: 1, limit: 25 },
          headers: { Authorization: 'Bearer test-token' },
        });

        expect(res.status).toBe(200);
        expect(res.data.data.items).toBeDefined();
        const q = res.data.data.items[0];
        if (q) {
          expect(q).toHaveProperty('quotationNo');
          expect(q).toHaveProperty('status');
          expect(q).toHaveProperty('customer');
        }
      });
  });

  test('POST /api/v1/sales/quotations creates a quotation', async () => {
    await provider
      .addInteraction({
        states:        [{ description: 'customer and products exist' }],
        uponReceiving: 'a request to create a quotation',
        withRequest: {
          method: 'POST',
          path:   '/api/v1/sales/quotations',
          headers: {
            Authorization:    MatchersV3.regex(/^Bearer .+$/, 'Bearer test-token'),
            'Content-Type':   'application/json',
          },
          body: {
            customerId: MatchersV3.uuid(),
            branchId:   MatchersV3.uuid(),
            currency:   'NGN',
            lines: MatchersV3.eachLike({
              description: MatchersV3.string('John Deere 6120M Tractor'),
              quantity:    1,
              unitPrice:   4_500_000,
              vatRate:     7.5,
              discount:    0,
            }),
          },
        },
        willRespondWith: {
          status: 201,
          body: {
            success: true,
            data: {
              id:          MatchersV3.uuid(),
              quotationNo: MatchersV3.string('QUO-HQ-2025-00001'),
              status:      'DRAFT',
            },
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await axios.post(`${mockServer.url}/api/v1/sales/quotations`, {
          customerId: '550e8400-e29b-41d4-a716-446655440001',
          branchId:   '550e8400-e29b-41d4-a716-446655440002',
          currency:   'NGN',
          lines: [{
            description: 'John Deere 6120M Tractor',
            quantity:    1,
            unitPrice:   4_500_000,
            vatRate:     7.5,
            discount:    0,
          }],
        }, {
          headers: { Authorization: 'Bearer test-token', 'Content-Type': 'application/json' },
        });

        expect(res.status).toBe(201);
        expect(res.data.data).toHaveProperty('quotationNo');
        expect(res.data.data.status).toBe('DRAFT');
      });
  });
});
