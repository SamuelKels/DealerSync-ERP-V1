// tests/contract/consumer/invoices.pact.spec.ts
// Pact consumer contract test — Section 10: "contract testing (Pact)"
// Defines the API contract the frontend expects from the backend.
// If the backend changes the invoice schema, this test fails before deploy.

import { PactV3, MatchersV3 } from '@pact-foundation/pact';
import path from 'path';

const { like, eachLike, integer, decimal, string, datetime } = MatchersV3;

const provider = new PactV3({
  consumer:  'agcoms-frontend',
  provider:  'agcoms-backend',
  dir:       path.resolve(process.cwd(), 'tests/contract/pacts'),
  logLevel:  'warn',
});

// ── Invoice contract ───────────────────────────────────────────

describe('Invoice API contract', () => {
  test('GET /api/v1/sales/invoices — returns paginated invoice list', async () => {
    await provider
      .given('invoices exist for branch HQ')
      .uponReceiving('a request for the invoice list')
      .withRequest({
        method: 'GET',
        path:   '/api/v1/sales/invoices',
        query:  { limit: '20', page: '1' },
        headers: { Authorization: like('Bearer eyJ...') },
      })
      .willRespondWith({
        status: 200,
        headers: { 'Content-Type': 'application/json' },
        body: {
          success: true,
          data: {
            items: eachLike({
              id:          string('uuid-1234'),
              invoiceNo:   string('INV-HQ-2025-00001'),
              status:      string('ISSUED'),
              totalAmount: decimal(150_000.00),
              amountPaid:  decimal(0),
              currency:    string('NGN'),
              invoiceDate: string('2025-01-15'),
              dueDate:     string('2025-02-15'),
              customer: {
                id:   string('cust-uuid'),
                name: string('Alhaji Ibrahim Ltd'),
              },
              branch: {
                id:   string('branch-uuid'),
                name: string('HQ Abuja'),
              },
              createdAt: string('2025-01-15T10:00:00.000Z'),
            }),
            total:   integer(45),
            hasMore: like(true),
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await fetch(`${mockServer.url}/api/v1/sales/invoices?limit=20&page=1`, {
          headers: { Authorization: 'Bearer mock-token' },
        });
        expect(res.status).toBe(200);
        const body = await res.json() as any;
        expect(body.success).toBe(true);
        expect(body.data.items).toBeInstanceOf(Array);
        expect(body.data.items[0]).toHaveProperty('invoiceNo');
        expect(body.data.items[0]).toHaveProperty('totalAmount');
        expect(body.data.items[0]).toHaveProperty('customer');
      });
  });

  test('GET /api/v1/sales/invoices/:id — returns invoice detail', async () => {
    await provider
      .given('invoice INV-HQ-2025-00001 exists')
      .uponReceiving('a request for invoice detail')
      .withRequest({
        method: 'GET',
        path:   '/api/v1/sales/invoices/invoice-uuid-001',
        headers: { Authorization: like('Bearer eyJ...') },
      })
      .willRespondWith({
        status: 200,
        body: {
          success: true,
          data: {
            id:           string('invoice-uuid-001'),
            invoiceNo:    string('INV-HQ-2025-00001'),
            status:       string('ISSUED'),
            totalAmount:  decimal(150_000.00),
            vatAmount:    decimal(10_465.12),
            subtotalAmount: decimal(139_534.88),
            amountPaid:   decimal(0),
            currency:     string('NGN'),
            invoiceDate:  string('2025-01-15'),
            dueDate:      string('2025-02-15'),
            pdfS3Key:     like(null),
            customer:     like({ id: 'cust-uuid', name: 'Alhaji Ibrahim Ltd', phone: '+2348012345678' }),
            lines: eachLike({
              id:          string('line-uuid'),
              description: string('John Deere 6120M Tractor'),
              quantity:    decimal(1),
              unitPrice:   decimal(139_534.88),
              vatRate:     decimal(7.5),
              lineTotal:   decimal(150_000.00),
            }),
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await fetch(`${mockServer.url}/api/v1/sales/invoices/invoice-uuid-001`, {
          headers: { Authorization: 'Bearer mock-token' },
        });
        expect(res.status).toBe(200);
        const body = await res.json() as any;
        expect(body.data).toHaveProperty('lines');
        expect(body.data.lines).toBeInstanceOf(Array);
      });
  });

  test('POST /api/v1/sales/invoices/:id/payments — records a payment', async () => {
    await provider
      .given('invoice invoice-uuid-001 exists and is unpaid')
      .uponReceiving('a request to record a payment')
      .withRequest({
        method: 'POST',
        path:   '/api/v1/sales/invoices/invoice-uuid-001/payments',
        headers: { 'Content-Type': 'application/json', Authorization: like('Bearer eyJ...') },
        body: {
          amount:        like(50_000),
          paymentMethod: like('BANK_TRANSFER'),
          reference:     like('TRF-001234'),
        },
      })
      .willRespondWith({
        status: 201,
        body: {
          success: true,
          data: {
            invoiceId: string('invoice-uuid-001'),
            status:    string('PARTIALLY_PAID'),
            amountPaid: decimal(50_000),
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await fetch(`${mockServer.url}/api/v1/sales/invoices/invoice-uuid-001/payments`, {
          method:  'POST',
          headers: { 'Content-Type': 'application/json', Authorization: 'Bearer mock-token' },
          body:    JSON.stringify({ amount: 50_000, paymentMethod: 'BANK_TRANSFER', reference: 'TRF-001234' }),
        });
        expect(res.status).toBe(201);
      });
  });
});

// ── Quotation contract ─────────────────────────────────────────

describe('Quotation API contract', () => {
  test('GET /api/v1/sales/quotations — returns paginated quotation list', async () => {
    await provider
      .given('quotations exist')
      .uponReceiving('a request for quotation list')
      .withRequest({
        method: 'GET',
        path:   '/api/v1/sales/quotations',
        query:  { limit: '20', page: '1' },
        headers: { Authorization: like('Bearer eyJ...') },
      })
      .willRespondWith({
        status: 200,
        body: {
          success: true,
          data: {
            items: eachLike({
              id:          string('quot-uuid'),
              quotationNo: string('QUO-HQ-2025-00001'),
              status:      string('DRAFT'),
              totalAmount: decimal(500_000),
              currency:    string('NGN'),
              customer:    like({ id: 'cust-uuid', name: 'Federal Ministry of Agric' }),
              createdAt:   string('2025-01-15T10:00:00.000Z'),
            }),
            total:   integer(12),
            hasMore: like(false),
          },
        },
      })
      .executeTest(async (mockServer) => {
        const res = await fetch(`${mockServer.url}/api/v1/sales/quotations?limit=20&page=1`, {
          headers: { Authorization: 'Bearer mock-token' },
        });
        expect(res.status).toBe(200);
        const body = await res.json() as any;
        expect(body.data.items[0]).toHaveProperty('quotationNo');
      });
  });
});
