// apps/backend/stryker.procurement.conf.js
// Stryker mutation testing — procurement service
// Section 10: "mutation testing"
// Validates that unit tests genuinely catch bugs, not just achieve line coverage

/** @type {import('@stryker-mutator/api/core').PartialStrykerOptions} */
module.exports = {
  packageManager: 'npm',
  reporters:      ['html', 'clear-text', 'progress', 'json'],
  testRunner:     'jest',
  coverageAnalysis: 'perTest',

  jest: {
    projectType:    'custom',
    configFile:     'jest.config.js',
    enableFindRelatedTests: true,
  },

  mutate: [
    // Only mutate the procurement service — keep scope tight
    'src/procurement/procurement.service.ts',
    '!src/**/*.spec.ts',
    '!src/**/*.test.ts',
  ],

  thresholds: {
    high:   80,   // Mutation score >= 80% = green
    low:    60,   // Mutation score 60–79% = yellow (warn but don't fail)
    break:  50,   // Mutation score < 50% = fail the build
  },

  htmlReporter: {
    baseDir: 'reports/mutation/procurement',
    fileName: 'mutation-report.html',
  },

  jsonReporter: {
    fileName: 'reports/mutation/procurement/mutation-report.json',
  },

  // Increase timeout for slow mutations (approval matrix logic is complex)
  testRunnerNodeArgs: [],
  timeoutMS:          60_000,
  timeoutFactor:      2.0,

  // Ignore mutating logging and formatting code
  ignoreStatic: true,
  plugins: [
    '@stryker-mutator/jest-runner',
  ],
};
