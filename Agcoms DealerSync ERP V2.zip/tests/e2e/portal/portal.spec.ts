// tests/e2e/portal/portal.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Customer portal', () => {
  test.use({ storageState: { cookies: [], origins: [] } });

  test('login page has AGCOMS branding', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('text=AGCOMS').first()).toBeVisible({ timeout: 8000 });
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('shows support contact info', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('text=support@agcomsinternational.com')).toBeVisible();
  });

  test('wrong credentials stays on login', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'bad@email.ng');
    await page.fill('input[type="password"]', 'wrongpass');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL(/\/login/);
  });

  test('unauthenticated dashboard redirects to login', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login/, { timeout: 10000 });
  });
});
