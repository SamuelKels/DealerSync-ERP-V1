// tests/e2e/auth.setup.ts
// Runs ONCE before all test suites — performs login and saves storage state.
// Subsequent tests reuse the authenticated session rather than logging in each time.

import { test as setup, expect } from '@playwright/test';
import path from 'path';
import fs from 'fs';

const ADMIN_AUTH_FILE   = 'tests/e2e/.auth/admin.json';
const MANAGER_AUTH_FILE = 'tests/e2e/.auth/manager.json';

const ADMIN_EMAIL    = process.env.TEST_ADMIN_EMAIL    ?? 'admin@agcoms.ng';
const ADMIN_PASS     = process.env.TEST_ADMIN_PASS     ?? 'SecureP@ssword123';
const MANAGER_EMAIL  = process.env.TEST_MANAGER_EMAIL  ?? 'manager@agcoms.ng';
const MANAGER_PASS   = process.env.TEST_MANAGER_PASS   ?? 'SecureP@ssword123';

async function login(page: any, email: string, password: string) {
  await page.goto('/login');
  await page.waitForSelector('[data-testid="email-input"], input[type="email"]', { timeout: 10_000 });

  await page.fill('input[type="email"]',    email);
  await page.fill('input[type="password"]', password);
  await page.click('button[type="submit"]');

  // Handle MFA if presented
  const mfaInput = await page.$('input[inputmode="numeric"]');
  if (mfaInput) {
    // Use test MFA bypass code (set in test environment only)
    await page.fill('input[inputmode="numeric"]', process.env.TEST_MFA_CODE ?? '123456');
    await page.click('button[type="submit"]');
  }

  // Wait for dashboard to confirm successful login
  await page.waitForURL('**/dashboard', { timeout: 15_000 });
  await expect(page).toHaveURL(/\/dashboard/);
}

setup('authenticate as admin', async ({ page }) => {
  fs.mkdirSync(path.dirname(ADMIN_AUTH_FILE), { recursive: true });
  await login(page, ADMIN_EMAIL, ADMIN_PASS);
  await page.context().storageState({ path: ADMIN_AUTH_FILE });
});

setup('authenticate as manager', async ({ page }) => {
  fs.mkdirSync(path.dirname(MANAGER_AUTH_FILE), { recursive: true });
  await login(page, MANAGER_EMAIL, MANAGER_PASS);
  await page.context().storageState({ path: MANAGER_AUTH_FILE });
});
