// tests/e2e/sales/quotation-to-invoice.spec.ts — Critical sales workflow
import { test, expect } from '@playwright/test';

test.describe('Sales workflow E2E', () => {
  test('quotations list loads', async ({ page }) => {
    await page.goto('/sales/quotations');
    await expect(page.locator('h1:has-text("Quotations")')).toBeVisible({ timeout: 10000 });
  });
  test('quotation list has status filters', async ({ page }) => {
    await page.goto('/sales/quotations');
    await expect(page.locator('button:has-text("DRAFT")')).toBeVisible();
    await expect(page.locator('button:has-text("SENT")')).toBeVisible();
    await expect(page.locator('button:has-text("ACCEPTED")')).toBeVisible();
  });
  test('quotation table has correct columns', async ({ page }) => {
    await page.goto('/sales/quotations');
    await expect(page.locator('thead').locator('text=Reference')).toBeVisible({ timeout: 10000 });
    await expect(page.locator('thead').locator('text=Customer')).toBeVisible();
    await expect(page.locator('thead').locator('text=Status')).toBeVisible();
  });
  test('invoices page accessible', async ({ page }) => {
    await page.goto('/sales/invoices');
    await expect(page.locator('h1').first()).toBeVisible({ timeout: 10000 });
  });
  test('credit notes page accessible', async ({ page }) => {
    await page.goto('/sales/credit-notes');
    await expect(page.locator('h1:has-text("Credit Note")')).toBeVisible({ timeout: 10000 });
  });
  test('new quotation form accessible', async ({ page }) => {
    await page.goto('/sales/quotations/new');
    await expect(page.locator('h1').first()).toBeVisible({ timeout: 10000 });
  });
});
