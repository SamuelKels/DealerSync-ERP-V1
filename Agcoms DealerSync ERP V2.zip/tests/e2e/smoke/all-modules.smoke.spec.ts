// tests/e2e/smoke/all-modules.smoke.spec.ts
// Smoke test: every ERP module page must load without JS errors.
// Run on every staging deploy (CI step 10).

import { test, expect, Page } from '@playwright/test';

const ROUTES = [
  // Auth-dependent pages
  { path: '/dashboard',                   title: /Dashboard|morning|afternoon|evening/i },
  { path: '/crm/customers',               title: /Customer/i },
  { path: '/crm/leads',                   title: /Lead/i },
  { path: '/inventory/products',          title: /Product/i },
  { path: '/inventory/warehouses',        title: /Warehouse/i },
  { path: '/inventory/stock-counts',      title: /Stock Count/i },
  { path: '/sales/quotations',            title: /Quotation/i },
  { path: '/sales/orders',                title: /Order/i },
  { path: '/sales/invoices',              title: /Invoice/i },
  { path: '/sales/credit-notes',          title: /Credit Note/i },
  { path: '/procurement/vendors',         title: /Vendor/i },
  { path: '/procurement/purchase-orders', title: /Purchase Order|Procurement/i },
  { path: '/workshop/service-requests',   title: /Service Request/i },
  { path: '/workshop/job-cards',          title: /Job Card/i },
  { path: '/fleet/assets',               title: /Fleet/i },
  { path: '/finance/journals',           title: /Journal/i },
  { path: '/finance/accounts',           title: /Chart of Accounts/i },
  { path: '/finance/trial-balance',      title: /Trial Balance/i },
  { path: '/hr/employees',              title: /Employee/i },
  { path: '/hr/payroll',               title: /Payroll/i },
  { path: '/hr/performance-reviews',   title: /Performance/i },
  { path: '/reports/ar-aging',         title: /AR Aging/i },
  { path: '/reports/kpis',             title: /KPI|Dashboard/i },
  { path: '/ai',                       title: /AI Intelligence/i },
  { path: '/admin/users',             title: /User/i },
];

async function assertPageLoads(page: Page, path: string, titlePattern: RegExp) {
  const errors: string[] = [];
  page.on('pageerror', err => errors.push(err.message));

  await page.goto(path);
  await page.waitForLoadState('networkidle', { timeout: 15_000 });

  // Check no unhandled JS errors
  expect(errors.filter(e => !e.includes('ResizeObserver'))).toHaveLength(0);

  // Check page heading matches expected title
  const heading = page.locator('h1, [role="heading"][aria-level="1"]').first();
  await expect(heading).toBeVisible({ timeout: 8_000 });
  const headingText = await heading.textContent() ?? '';
  expect(headingText).toMatch(titlePattern);
}

for (const route of ROUTES) {
  test(`${route.path} loads without errors`, async ({ page }) => {
    await assertPageLoads(page, route.path, route.title);
  });
}

// ── Mobile layout smoke tests (Section 8) ─────────────────────

test.describe('Mobile layout checks', () => {
  test('mobile bottom navigation visible on small screens', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/dashboard');
    const mobileNav = page.locator('nav[aria-label="Mobile navigation"]');
    await expect(mobileNav).toBeVisible({ timeout: 8_000 });
  });

  test('sidebar hidden on mobile', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await page.goto('/dashboard');
    const sidebar = page.locator('aside');
    // On mobile, sidebar should not be visible (hidden by md: breakpoint)
    await expect(sidebar).not.toBeVisible();
  });
});

// ── Accessibility smoke tests ─────────────────────────────────

test.describe('Basic accessibility', () => {
  test('login page has correct form labels', async ({ page }) => {
    await page.goto('/login');
    await expect(page.locator('label:has-text("Email")')).toBeVisible();
    await expect(page.locator('label:has-text("Password")')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('data tables have scope=col on headers', async ({ page }) => {
    await page.goto('/crm/customers');
    await page.waitForLoadState('networkidle');
    const ths = page.locator('thead th');
    const count = await ths.count();
    if (count > 0) {
      // At least the first header should have semantic structure
      await expect(ths.first()).toBeVisible();
    }
  });
});
