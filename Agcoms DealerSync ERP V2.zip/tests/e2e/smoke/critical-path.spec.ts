// tests/e2e/smoke/critical-path.spec.ts
/**
 * AGCOMS DealerSync ERP — Smoke Tests
 * Section 11: "run smoke tests" (CI step 10)
 *
 * These run after every staging deploy.
 * They must be fast (<60s total) and cover the absolute critical path.
 * Any failure here blocks production deployment.
 */
import { test, expect } from '@playwright/test';

const API = process.env.API_URL ?? 'http://localhost:3000/api/v1';

test.describe('Smoke Tests — Critical Path', () => {

  // ── 1. API Health ────────────────────────────────────────────

  test('API health endpoint returns 200', async ({ request }) => {
    const response = await request.get(`${API.replace('/api/v1', '')}/health`);
    expect(response.status()).toBe(200);

    const body = await response.json() as { status: string };
    expect(body.status).toBe('ok');
  });

  // ── 2. Core pages render ──────────────────────────────────────

  test('login page renders within 3s', async ({ page }) => {
    const start = Date.now();
    await page.goto('/login');
    await expect(page.getByRole('button', { name: /sign in/i })).toBeVisible();
    expect(Date.now() - start).toBeLessThan(3000);
  });

  test('dashboard renders after auth', async ({ page }) => {
    await page.goto('/dashboard');
    // Should show dashboard (auth guard handled by storageState)
    await expect(page.getByText(/good (morning|afternoon|evening)/i)).toBeVisible({ timeout: 10000 });
  });

  // ── 3. Navigation works ───────────────────────────────────────

  test('sidebar navigation links are clickable', async ({ page }) => {
    await page.goto('/dashboard');

    await page.getByRole('link', { name: 'CRM' }).click();
    await expect(page).toHaveURL(/\/crm/, { timeout: 8000 });

    await page.getByRole('link', { name: 'Inventory' }).click();
    await expect(page).toHaveURL(/\/inventory/, { timeout: 8000 });
  });

  // ── 4. Core list pages load data ─────────────────────────────

  test('customers list page loads without error', async ({ page }) => {
    await page.goto('/crm/customers');

    // Should not show an error message
    await expect(page.getByText(/something went wrong/i)).not.toBeVisible();
    await expect(page.getByRole('heading', { name: /customers/i })).toBeVisible();
  });

  test('journal entries list loads without error', async ({ page }) => {
    await page.goto('/finance/journals');
    await expect(page.getByText(/something went wrong/i)).not.toBeVisible();
    await expect(page.getByRole('heading', { name: /journal entries/i })).toBeVisible();
  });

  // ── 5. Security headers ───────────────────────────────────────

  test('X-Frame-Options header is set on API', async ({ request }) => {
    const response = await request.get(`${API.replace('/api/v1', '')}/health`);
    // Should have security headers
    const xFrameOptions = response.headers()['x-frame-options'];
    expect(xFrameOptions).toBe('DENY');
  });

  test('X-Content-Type-Options header is set', async ({ request }) => {
    const response = await request.get(API.replace('/api/v1', '') + '/health');
    expect(response.headers()['x-content-type-options']).toBe('nosniff');
  });

  // ── 6. AI governance is enforced ──────────────────────────────

  test('AI page shows governance notice', async ({ page }) => {
    await page.goto('/ai');
    await expect(page.getByText(/AI Governance/i)).toBeVisible();
    await expect(page.getByText(/human approval/i)).toBeVisible();
  });

  // ── 7. 404 handling ───────────────────────────────────────────

  test('unknown route shows 404 page', async ({ page }) => {
    await page.goto('/this-page-does-not-exist');
    await expect(page.getByText('404')).toBeVisible();
    await expect(page.getByRole('link', { name: /return to dashboard/i })).toBeVisible();
  });
});
