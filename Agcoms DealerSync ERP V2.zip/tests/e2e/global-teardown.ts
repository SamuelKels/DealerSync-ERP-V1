// tests/e2e/global-teardown.ts
import { type FullConfig } from '@playwright/test';

export default async function globalTeardown(_config: FullConfig) {
  // Clean up test data if needed
  console.log('\n✅ E2E tests complete\n');
}
