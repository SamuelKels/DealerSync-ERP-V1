// tests/e2e/procurement/po-to-grn.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Procurement — Purchase Order workflow', () => {

  test('vendor directory loads', async ({ page }) => {
    await page.goto('/procurement/vendors');

    await expect(page.getByRole('heading', { name: /vendor directory/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /new vendor/i })).toBeVisible();

    // Category filter
    await expect(page.getByRole('combobox').first()).toBeVisible();
  });

  test('can search vendors', async ({ page }) => {
    await page.goto('/procurement/vendors');

    const searchInput = page.getByPlaceholder(/search vendors/i);
    await searchInput.fill('AGCO');
    await page.waitForResponse(resp => resp.url().includes('/vendors') && resp.status() === 200);

    // Table updates (either results or empty state)
    await expect(page.locator('table tbody').or(page.getByText(/no vendors/i))).toBeVisible();
  });

  test('purchase orders list loads', async ({ page }) => {
    await page.goto('/procurement/purchase-orders');

    await expect(page.getByRole('heading', { name: /purchase order/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /new purchase order/i })).toBeVisible();
  });

  test('new PO form renders with required fields', async ({ page }) => {
    await page.goto('/procurement/purchase-orders/new');

    await expect(page.getByText(/new purchase order/i)).toBeVisible();
    await expect(page.getByLabel(/vendor/i)).toBeVisible();
  });

  test('GRN list renders', async ({ page }) => {
    await page.goto('/procurement/grn');
    await expect(page.getByRole('heading', { name: /goods received/i })).toBeVisible();
  });
});


// tests/e2e/finance/journal-entry.spec.ts
test.describe('Finance — Journal Entry', () => {

  test('journal entries list loads with balanced indicator', async ({ page }) => {
    await page.goto('/finance/journals');

    await expect(page.getByRole('heading', { name: /journal entries/i })).toBeVisible();
    await expect(page.getByText(/double-entry/i)).toBeVisible();
    await expect(page.getByRole('link', { name: /new journal entry/i })).toBeVisible();
  });

  test('journal entry builder renders with 2 default lines', async ({ page }) => {
    await page.goto('/finance/journals/new');

    await expect(page.getByRole('heading', { name: /new journal entry/i })).toBeVisible();
    // Should have exactly 2 line rows by default
    const lineRows = page.locator('tbody tr');
    await expect(lineRows).toHaveCount(2);
  });

  test('double-entry balance indicator shows UNBALANCED with mismatched amounts', async ({ page }) => {
    await page.goto('/finance/journals/new');

    // Fill debit on line 1
    const debitInputs = page.locator('input[type="number"]').filter({ hasText: '' });
    await page.locator('tbody tr').nth(0).locator('input[type="number"]').nth(0).fill('1000');

    // Balance indicator should show difference
    await expect(page.getByText(/difference/i)).toBeVisible({ timeout: 3000 });
  });

  test('balance indicator shows BALANCED when debits equal credits', async ({ page }) => {
    await page.goto('/finance/journals/new');

    const rows = page.locator('tbody tr');

    // Line 1: debit ₦5000
    await rows.nth(0).locator('input[type="number"]').nth(0).fill('5000');
    // Line 2: credit ₦5000
    await rows.nth(1).locator('input[type="number"]').nth(1).fill('5000');

    await expect(page.getByText(/balanced/i)).toBeVisible({ timeout: 3000 });
  });

  test('Post button is disabled when journal is unbalanced', async ({ page }) => {
    await page.goto('/finance/journals/new');

    const postButton = page.getByRole('button', { name: /post journal/i });
    await expect(postButton).toBeDisabled();
  });

  test('chart of accounts loads with IFRS groups', async ({ page }) => {
    await page.goto('/finance/accounts');

    await expect(page.getByRole('heading', { name: /chart of accounts/i })).toBeVisible();
    await expect(page.getByText(/IFRS/i)).toBeVisible();

    // Account type groups should be visible
    await expect(page.getByText(/assets/i)).toBeVisible();
    await expect(page.getByText(/liabilities/i)).toBeVisible();
    await expect(page.getByText(/equity/i)).toBeVisible();
  });

  test('trial balance shows period selector', async ({ page }) => {
    await page.goto('/finance/trial-balance');

    await expect(page.getByRole('heading', { name: /trial balance/i })).toBeVisible();
    await expect(page.getByRole('combobox')).toBeVisible();
    await expect(page.getByText(/select an accounting period/i)).toBeVisible();
  });
});
