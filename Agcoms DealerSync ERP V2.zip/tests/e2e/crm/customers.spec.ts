// tests/e2e/crm/customers.spec.ts
import { test, expect } from '@playwright/test';

test.describe('CRM — Customer Management', () => {

  test('customer list renders with search and filters', async ({ page }) => {
    await page.goto('/crm/customers');

    await expect(page.getByRole('heading', { name: /customers/i })).toBeVisible();
    await expect(page.getByPlaceholder(/search customers/i)).toBeVisible();
    await expect(page.getByRole('link', { name: /new customer/i })).toBeVisible();

    // Type filter
    await expect(page.getByRole('combobox').first()).toBeVisible();

    // Status filter
    const statusSelect = page.locator('select').nth(1);
    await expect(statusSelect).toBeVisible();
  });

  test('customer search triggers API call', async ({ page }) => {
    await page.goto('/crm/customers');

    const searchInput = page.getByPlaceholder(/search customers/i);
    await searchInput.fill('NADF');

    const apiCall = page.waitForResponse(
      resp => resp.url().includes('/crm/customers') && resp.status() === 200
    );
    await apiCall;
  });

  test('pagination controls are functional', async ({ page }) => {
    await page.goto('/crm/customers');
    await page.waitForLoadState('networkidle');

    const nextButton = page.getByRole('button', { name: /next/i });
    await expect(nextButton).toBeVisible();
  });

  test('customer type filter filters the list', async ({ page }) => {
    await page.goto('/crm/customers');

    const typeSelect = page.locator('select').first();
    await typeSelect.selectOption('GOVERNMENT');

    await page.waitForResponse(resp => resp.url().includes('/customers') && resp.status() === 200);
  });

  test('CRM leads page renders', async ({ page }) => {
    await page.goto('/crm/leads');

    await expect(page.getByRole('heading', { name: /leads/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /new lead/i })).toBeVisible();
  });

  test('RFQ list renders', async ({ page }) => {
    await page.goto('/crm/rfq');
    await expect(page.getByRole('heading', { name: /rfq/i })).toBeVisible();
  });
});


// tests/e2e/hr/hr-modules.spec.ts
test.describe('HR — Employees and Payroll', () => {

  test('employee directory loads with avatar initials', async ({ page }) => {
    await page.goto('/hr/employees');

    await expect(page.getByRole('heading', { name: /employees/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /new employee/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /org chart/i })).toBeVisible();
    await expect(page.getByPlaceholder(/search by name/i)).toBeVisible();
  });

  test('employee status filter pills work', async ({ page }) => {
    await page.goto('/hr/employees');

    await page.getByRole('button', { name: 'ON LEAVE' }).click();
    await page.waitForResponse(resp => resp.url().includes('/employees') && resp.status() === 200);
  });

  test('payroll page renders with run payroll button', async ({ page }) => {
    await page.goto('/hr/payroll');

    await expect(page.getByRole('heading', { name: /payroll/i })).toBeVisible();
    await expect(page.getByRole('button', { name: /run payroll/i })).toBeVisible();
    await expect(page.getByText(/PAYE/i)).toBeVisible();
    await expect(page.getByText(/Pension/i)).toBeVisible();
  });

  test('performance reviews list renders with star ratings', async ({ page }) => {
    await page.goto('/hr/performance-reviews');

    await expect(page.getByRole('heading', { name: /performance reviews/i })).toBeVisible();
    await expect(page.getByRole('link', { name: /new review/i })).toBeVisible();
  });

  test('leave management page renders', async ({ page }) => {
    await page.goto('/hr/leave');

    await expect(page.getByRole('heading', { name: /leave/i })).toBeVisible();
  });
});
