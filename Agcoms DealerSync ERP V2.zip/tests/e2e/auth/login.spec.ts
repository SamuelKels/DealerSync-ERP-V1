// tests/e2e/auth/login.spec.ts
import { test, expect, type Page } from '@playwright/test';

test.describe('Authentication', () => {
  test.use({ storageState: undefined }); // These tests need no pre-auth

  // ── Login page rendering ────────────────────────────────────

  test('login page renders correctly', async ({ page }) => {
    await page.goto('/login');

    await expect(page).toHaveTitle(/AGCOMS/);
    await expect(page.getByRole('heading', { name: /sign in/i })).toBeVisible();
    await expect(page.getByPlaceholder(/email/i)).toBeVisible();
    await expect(page.getByPlaceholder(/password/i)).toBeVisible();
    await expect(page.getByRole('button', { name: /sign in/i })).toBeVisible();
  });

  // ── Validation ──────────────────────────────────────────────

  test('shows validation error for invalid email', async ({ page }) => {
    await page.goto('/login');
    await page.fill('[type="email"]', 'not-an-email');
    await page.fill('[type="password"]', 'somepassword');
    await page.getByRole('button', { name: /sign in/i }).click();
    await expect(page.getByText(/valid email/i)).toBeVisible();
  });

  test('shows error for empty password', async ({ page }) => {
    await page.goto('/login');
    await page.fill('[type="email"]', 'admin@agcoms.ng');
    await page.getByRole('button', { name: /sign in/i }).click();
    await expect(page.getByText(/password is required/i)).toBeVisible();
  });

  test('shows toast error for wrong credentials', async ({ page }) => {
    await page.goto('/login');
    await page.fill('[type="email"]', 'admin@agcoms.ng');
    await page.fill('[type="password"]', 'WrongPassword123!');
    await page.getByRole('button', { name: /sign in/i }).click();
    // Expect a Sonner toast with error message
    await expect(page.locator('[data-sonner-toast]')).toBeVisible({ timeout: 8000 });
  });

  // ── Successful login ────────────────────────────────────────

  test('successful login redirects to dashboard', async ({ page }) => {
    await page.goto('/login');
    await page.fill('[type="email"]', process.env.TEST_ADMIN_EMAIL ?? 'admin@agcoms.ng');
    await page.fill('[type="password"]', process.env.TEST_ADMIN_PASSWORD ?? 'SecureP@ssword123');
    await page.getByRole('button', { name: /sign in/i }).click();

    // Either goes to dashboard directly or to MFA page
    await expect(page).toHaveURL(/\/(dashboard|mfa)/, { timeout: 10000 });
  });

  // ── Password visibility toggle ──────────────────────────────

  test('password show/hide toggle works', async ({ page }) => {
    await page.goto('/login');
    const passwordInput = page.locator('[type="password"]');
    const toggleButton  = page.getByLabel(/show password/i);

    await expect(passwordInput).toHaveAttribute('type', 'password');
    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'text');
    await toggleButton.click();
    await expect(passwordInput).toHaveAttribute('type', 'password');
  });

  // ── Redirect to login if unauthenticated ────────────────────

  test('unauthenticated access to dashboard redirects to login', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login/, { timeout: 8000 });
  });

  // ── Forgot password link ────────────────────────────────────

  test('forgot password link is visible and navigates', async ({ page }) => {
    await page.goto('/login');
    await page.getByRole('link', { name: /forgot password/i }).click();
    await expect(page).toHaveURL(/\/reset-password/);
  });
});

// ── Authenticated tests ────────────────────────────────────────

test.describe('Authenticated session', () => {

  test('dashboard loads with greeting and KPI cards', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page.getByText(/good (morning|afternoon|evening)/i)).toBeVisible();

    // KPI cards should render (either data or skeleton)
    const kpiCards = page.locator('.kpi-card, [class*="rounded-lg"][class*="border"]').first();
    await expect(kpiCards).toBeVisible();
  });

  test('sidebar shows all 14 module links', async ({ page }) => {
    await page.goto('/dashboard');

    const sidebarLinks = [
      'Dashboard', 'CRM', 'Inventory', 'Sales',
      'Procurement', 'Workshop', 'Fleet', 'Finance',
      'HR & Payroll', 'Gov. Contracts', 'Reports & BI', 'AI Intelligence',
    ];

    for (const label of sidebarLinks) {
      await expect(page.getByRole('link', { name: label })).toBeVisible();
    }
  });

  test('command palette opens with ⌘K', async ({ page }) => {
    await page.goto('/dashboard');
    await page.keyboard.press('Meta+k');
    await expect(page.getByPlaceholder(/search products/i)).toBeVisible({ timeout: 3000 });
    await page.keyboard.press('Escape');
    await expect(page.getByPlaceholder(/search products/i)).not.toBeVisible();
  });

  test('logout clears session and redirects to login', async ({ page }) => {
    await page.goto('/dashboard');
    await page.getByRole('button', { name: /sign out/i }).click();
    await expect(page).toHaveURL(/\/login/, { timeout: 8000 });
    // Cannot go back to dashboard
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login/);
  });
});
