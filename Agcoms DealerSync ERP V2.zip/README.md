# AGCOMS DealerSync ERP v1.0

**Production-grade ERP for AGCOMS International Trading Limited**  
Agricultural & industrial equipment dealership · Abuja, Nigeria

---

## What is DealerSync?

DealerSync is a full-stack enterprise resource planning system covering:

- **Agricultural equipment** dealership (John Deere, Massey Ferguson, New Holland)
- **Construction equipment** (Caterpillar)
- **Government contract** management (NADF tractor supply programme)
- **Workshop & service** operations
- **Fleet & telematics** with live GPS tracking
- **Finance & accounting** (IFRS-ready, Nigerian tax compliance)
- **Human resources & payroll** (PAYE/PITA 2011, PenCom, NHF)
- **AI-assisted** business intelligence

---

## Quick start

### Prerequisites

| Tool | Version |
|------|---------|
| Node.js | 20 LTS |
| pnpm | 9.x |
| Docker Desktop | 4.x |

### 1. Install dependencies

```bash
pnpm install
```

### 2. Start infrastructure

```bash
docker compose up -d
```

This starts PostgreSQL 16, Redis 7, MinIO (S3), Typesense, Prometheus, and Grafana.

### 3. Configure environment

```bash
cp apps/backend/.env.example apps/backend/.env
cp apps/frontend/.env.example apps/frontend/.env.local

# Generate JWT RS256 keys
bash scripts/generate-keys.sh --env
```

Edit `apps/backend/.env` and fill in the JWT keys printed by the script.

### 4. Set up database

```bash
pnpm db:migrate    # Run Prisma migrations
pnpm db:seed       # Seed all 14 modules with demo data
pnpm create:admin  # Create the first Super Admin user
```

### 5. Start development servers

```bash
pnpm dev
```

| Service | URL |
|---------|-----|
| ERP Frontend | http://localhost:3000 |
| Backend API | http://localhost:3001 |
| API Docs (Swagger) | http://localhost:3001/api/docs |
| Customer Portal | http://localhost:3002 |
| Grafana | http://localhost:3003 |
| MinIO Console | http://localhost:9001 |

### Demo credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@agcoms.ng | DealerSync@2025! |
| Finance Manager | finance@agcoms.ng | DealerSync@2025! |
| Sales Manager | sales@agcoms.ng | DealerSync@2025! |
| HR Manager | hr@agcoms.ng | DealerSync@2025! |
| Technician | tech@agcoms.ng | DealerSync@2025! |

---

## Architecture

```
AGCOMS DealerSync ERP
├── Turborepo monorepo
├── apps/
│   ├── backend/       NestJS 10 · Node.js 20 · REST API
│   ├── frontend/      Next.js 15 · TypeScript · TailwindCSS
│   └── portal/        Customer-facing portal (Next.js 15)
├── packages/
│   ├── types/         Shared TypeScript interfaces (14 modules)
│   ├── validators/    Shared Zod schemas
│   ├── ui/            Design tokens + shared components
│   └── config/        ESLint, Prettier, TS configs
├── infrastructure/
│   ├── docker/        Production Docker Compose
│   ├── terraform/     AWS ECS/Fargate IaC
│   └── nginx/         Reverse proxy
├── monitoring/        Prometheus + Grafana dashboards
├── scripts/           Seed, key-gen, migration, health-check
└── tests/             E2E (Playwright), load (k6), contract (Pact)
```

**Database:** PostgreSQL 16 with PgBouncer connection pooling  
**Cache:** Redis 7 (BullMQ queues + cache-aside)  
**Search:** Typesense  
**Storage:** AWS S3 (MinIO in development)

---

## ERP modules

| # | Module | Status |
|---|--------|--------|
| 1 | Authentication & RBAC | ✅ Production-ready |
| 2 | Dashboard & Analytics | ✅ Production-ready |
| 3 | CRM (customers, leads, RFQ) | ✅ Production-ready |
| 4 | Inventory & Warehousing | ✅ Production-ready |
| 5 | Sales & Quotations | ✅ Production-ready |
| 6 | Procurement | ✅ Production-ready |
| 7 | Workshop & Service | ✅ Production-ready |
| 8 | Finance & Accounting | ✅ Production-ready |
| 9 | Human Resources & Payroll | ✅ Production-ready |
| 10 | Government Contracts (NADF) | ✅ Production-ready |
| 11 | Reporting & BI | ✅ Production-ready |
| 12 | Customer Portal | ✅ Production-ready |
| 13 | AI Intelligence Layer | ✅ Production-ready |
| 14 | Fleet & Telematics | ✅ Production-ready |

---

## Nigerian compliance

| Regulation | Implementation |
|-----------|---------------|
| PAYE (PITA 2011) | 6-band progressive tax · CRA deduction |
| PenCom Pension | 8% employee · 10% employer |
| NHF | 2.5% of basic salary |
| VAT (Finance Act 2020) | 7.5% standard rate |
| WHT | 5% contracts · 10% consultancy |

---

## Testing

```bash
pnpm test:unit        # Unit tests with 80% coverage enforcement
pnpm test:integration # Supertest integration tests (requires running DB)
pnpm test:e2e         # Playwright end-to-end tests
```

---

## Security

- JWT RS256 asymmetric signing
- MFA / TOTP
- Field-level PII masking (salary, NIN, bank account)
- Zero Trust RBAC with branch isolation
- Append-only audit logs
- CSRF, XSS sanitisation, Helmet, rate limiting
- AWS Secrets Manager for production secrets

---

## Deployment

```bash
# Build production images
docker compose -f infrastructure/docker/docker-compose.production.yml build

# Deploy (ECS/Fargate via Terraform)
cd infrastructure/terraform
terraform init
terraform apply
```

See `docs/ONBOARDING.md` for the full developer guide.

---

*AGCOMS International Trading Limited — Abuja, Nigeria*  
*DealerSync ERP v1.0 · Built May 2025*
