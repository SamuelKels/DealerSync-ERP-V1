/**
 * AGCOMS DealerSync ERP — Health Controller
 * Sprint 1 Fix: HealthModule was imported in app.module.ts but did not exist.
 * Provides /api/v1/health (readiness) and /api/v1/health/live (liveness).
 */
import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import {
  HealthCheckService,
  PrismaHealthIndicator,
  MemoryHealthIndicator,
} from '@nestjs/terminus';
import { HealthCheck } from '@nestjs/terminus';

import { Public } from '../../common/guards/auth.guards';
import { PrismaService } from '../../prisma/prisma.service';

@ApiTags('health')
@Controller('health')
export class HealthController {
  constructor(
    private readonly health: HealthCheckService,
    private readonly prismaIndicator: PrismaHealthIndicator,
    private readonly prisma: PrismaService,
    private readonly memory: MemoryHealthIndicator,
  ) {}

  @Get()
  @Public()
  @HealthCheck()
  @ApiOperation({ summary: 'Readiness probe — checks DB and memory' })
  check() {
    return this.health.check([
      () => this.prismaIndicator.pingCheck('database', this.prisma as any),
      () => this.memory.checkHeap('memory_heap', 512 * 1024 * 1024),
    ]);
  }

  @Get('live')
  @Public()
  @ApiOperation({ summary: 'Liveness probe — always 200 if process is running' })
  liveness() {
    return { status: 'ok', timestamp: new Date().toISOString() };
  }

  @Get('ready')
  @Public()
  @HealthCheck()
  @ApiOperation({ summary: 'Kubernetes readiness probe' })
  readiness() {
    return this.health.check([() => this.prismaIndicator.pingCheck('database', this.prisma as any)]);
  }
}
