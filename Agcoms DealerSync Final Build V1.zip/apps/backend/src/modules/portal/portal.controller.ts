/**
 * AGCOMS DealerSync ERP — Customer Portal Controller (Sprint P4)
 *
 * External-facing API for the Customer Portal (Module 12).
 * Uses a separate portal JWT (PORTAL_JWT_SECRET) so portal sessions
 * are fully isolated from internal ERP sessions.
 *
 * Public routes:  POST /portal/auth/login
 * Protected routes: everything else (PortalJwtGuard)
 */
import {
  Controller, Get, Post, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus, Req, UnauthorizedException,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { IsEmail, IsString, IsOptional, IsNumber, IsPositive,
         IsDateString, ValidateNested, ArrayMinSize, IsArray } from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Request } from 'express';

import { PortalService, PortalJwtPayload } from './portal.service';

// ── DTOs ─────────────────────────────────────────────────────────────────

class PortalLoginDto {
  @ApiProperty({ example: 'customer@example.com' })
  @IsEmail()
  email!: string;

  @ApiProperty()
  @IsString()
  password!: string;
}

class RfqItemDto {
  @ApiProperty()
  @IsString()
  description!: string;

  @ApiProperty()
  @IsNumber() @IsPositive() @Type(() => Number)
  quantity!: number;

  @ApiPropertyOptional()
  @IsOptional() @IsString()
  unit?: string;
}

class SubmitRfqDto {
  @ApiProperty()
  @IsString()
  subject!: string;

  @ApiProperty()
  @IsString()
  description!: string;

  @ApiPropertyOptional()
  @IsOptional() @IsDateString()
  requiredBy?: string;

  @ApiProperty({ type: [RfqItemDto] })
  @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => RfqItemDto)
  items!: RfqItemDto[];
}

// ── Portal JWT helper (inline guard) ────────────────────────────────────

function extractPortalCustomer(req: Request, jwt: JwtService, config: ConfigService): PortalJwtPayload {
  const auth = req.headers?.authorization ?? '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) throw new UnauthorizedException('Portal token required');
  try {
    return jwt.verify<PortalJwtPayload>(token, {
      secret: config.get<string>('PORTAL_JWT_SECRET', 'portal-secret-change-me'),
    });
  } catch {
    throw new UnauthorizedException('Invalid or expired portal token');
  }
}

// ── Controller ───────────────────────────────────────────────────────────

@ApiTags('portal')
@Controller('portal')
export class PortalController {
  constructor(
    private readonly svc: PortalService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  // ── Auth ────────────────────────────────────────────────────────────────

  @Post('auth/login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Customer portal login' })
  login(@Body() dto: PortalLoginDto, @Req() req: Request) {
    const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim()
      ?? req.socket?.remoteAddress
      ?? 'unknown';
    return this.svc.portalLogin(dto.email, dto.password, ip);
  }

  // ── Dashboard ───────────────────────────────────────────────────────────

  @Get('dashboard')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'Customer dashboard summary' })
  getDashboard(@Req() req: Request) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getPortalDashboard(customer.sub);
  }

  // ── Quotations ──────────────────────────────────────────────────────────

  @Get('quotations')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'List my quotations' })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'cursor', required: false })
  @ApiQuery({ name: 'limit',  required: false, type: Number })
  getQuotations(
    @Req() req: Request,
    @Query('status') status?: string,
    @Query('cursor') cursor?: string,
    @Query('limit')  limit  = '20',
  ) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyQuotations(customer.sub, {
      status, cursor, limit: parseInt(limit, 10),
    });
  }

  @Get('quotations/:id')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'Get quotation detail' })
  getQuotation(@Req() req: Request, @Param('id') id: string) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyQuotation(customer.sub, id);
  }

  // ── Invoices ────────────────────────────────────────────────────────────

  @Get('invoices')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'List my invoices' })
  @ApiQuery({ name: 'status', required: false })
  @ApiQuery({ name: 'cursor', required: false })
  @ApiQuery({ name: 'limit',  required: false, type: Number })
  getInvoices(
    @Req() req: Request,
    @Query('status') status?: string,
    @Query('cursor') cursor?: string,
    @Query('limit')  limit  = '20',
  ) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyInvoices(customer.sub, {
      status, cursor, limit: parseInt(limit, 10),
    });
  }

  @Get('invoices/:id')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'Get invoice detail' })
  getInvoice(@Req() req: Request, @Param('id') id: string) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyInvoice(customer.sub, id);
  }

  // ── Service Requests ────────────────────────────────────────────────────

  @Get('service-requests')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'List my service requests' })
  @ApiQuery({ name: 'cursor', required: false })
  @ApiQuery({ name: 'limit',  required: false, type: Number })
  getServiceRequests(
    @Req() req: Request,
    @Query('cursor') cursor?: string,
    @Query('limit')  limit  = '20',
  ) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyServiceRequests(customer.sub, { cursor, limit: parseInt(limit, 10) });
  }

  @Get('service-requests/:id')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'Get service request detail' })
  getServiceRequest(@Req() req: Request, @Param('id') id: string) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyServiceRequest(customer.sub, id);
  }

  // ── RFQ Submission ──────────────────────────────────────────────────────

  @Post('rfq')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'Submit a new RFQ' })
  submitRfq(@Req() req: Request, @Body() dto: SubmitRfqDto) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.submitRfq(customer.sub, {
      ...dto,
      requiredBy: dto.requiredBy ? new Date(dto.requiredBy) : undefined,
    });
  }

  // ── Equipment ───────────────────────────────────────────────────────────

  @Get('equipment')
  @ApiBearerAuth('PortalJWT')
  @ApiOperation({ summary: 'My equipment ownership history' })
  getEquipment(@Req() req: Request) {
    const customer = extractPortalCustomer(req, this.jwt, this.config);
    return this.svc.getMyEquipment(customer.sub);
  }
}
