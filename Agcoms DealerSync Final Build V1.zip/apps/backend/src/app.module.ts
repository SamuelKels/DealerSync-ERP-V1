/**
 * AGCOMS DealerSync ERP — Root Application Module
 * Registers all 14 ERP domain modules with proper dependency injection.
 * §2 Architecture: Modular Monolith — clear domain boundaries
 */
import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { TerminusModule } from '@nestjs/terminus';
import { ThrottlerModule } from '@nestjs/throttler';
import { LoggerModule } from 'nestjs-pino';

// Infrastructure modules
import { AuditModule } from './audit/audit.module';
import { CacheModule } from './cache/cache.module';
import { AiGovernanceModule } from './common/ai-governance/ai-governance.module';
import { FeatureFlagsModule } from './common/feature-flags/feature-flags.module';
import { appConfig } from './config/app.config';
import { FilesModule } from './files/files.module';
import { GatewayModule } from './gateway/gateway.module';
import { AiModule } from './modules/ai/ai.module';
import { AuthModule } from './modules/auth/auth.module';
import { ContractsModule } from './modules/contracts/contracts.module';
import { CrmModule } from './modules/crm/crm.module';
import { ExchangeRateModule } from './modules/exchange-rates/exchange-rate.module';
import { FinanceModule } from './modules/finance/finance.module';
import { LedgerModule } from './modules/finance/ledger/ledger.module';
import { FirsModule } from './modules/firs/firs.module';
import { FleetModule } from './modules/fleet/fleet.module';
import { HealthModule } from './modules/health/health.module';
import { HrModule } from './modules/hr/hr.module';
import { InventoryModule } from './modules/inventory/inventory.module';
import { PortalModule } from './modules/portal/portal.module';
import { ProcurementModule } from './modules/procurement/procurement.module';
import { ReportsModule } from './modules/reports/reports.module';
import { SalesModule } from './modules/sales/sales.module';
import { WhatsappModule } from './modules/whatsapp/whatsapp.module';
import { WorkshopModule } from './modules/workshop/workshop.module';
import { PdfModule } from './pdf/pdf.module';
import { PrismaModule } from './prisma/prisma.module';
import { ReadModelModule } from './read-model/read-model.module';
import { RedisModule } from './redis/redis.module';
import { SearchModule } from './search/search.module';
import { SecretsModule } from './secrets/secrets.module';

// Common modules

// ERP domain modules (14)

// Cross-cutting & Sprint-3/4/5 modules

@Module({
  imports: [
    // ── Configuration ───────────────────────────────────────────
    LoggerModule.forRoot({
      pinoHttp: {
        level: process.env['LOG_LEVEL'] ?? 'info',
        transport: process.env['NODE_ENV'] !== 'production' ? { target: 'pino-pretty' } : undefined,
      },
    }),
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: ['.env', '.env.local'],
      load: [appConfig],
      cache: true,
    }),

    // ── Event-driven internal architecture ───────────────────────
    // §2: event-driven internal architecture
    EventEmitterModule.forRoot({
      wildcard: false,
      maxListeners: 20,
    }),

    // ── Scheduled tasks ─────────────────────────────────────────
    ScheduleModule.forRoot(),

    // ── Rate limiting ────────────────────────────────────────────
    // §5: rate limiting
    ThrottlerModule.forRoot([
      {
        name: 'global',
        ttl: 60_000,
        limit: 100,
      },
    ]),

    // ── Health checks ────────────────────────────────────────────
    TerminusModule,

    // ── Queue infrastructure (BullMQ via Redis) ──────────────────
    // §3: Queues: BullMQ
    BullModule.forRootAsync({
      useFactory: () => ({
        redis: {
          host: process.env['REDIS_HOST'] ?? 'localhost',
          port: parseInt(process.env['REDIS_PORT'] ?? '6379'),
          // Fail fast if Redis is unreachable — prevents module init from hanging.
          // BullMQ queues will retry in the background once Redis becomes available.
          maxRetriesPerRequest: 1,
          enableReadyCheck: false,
          lazyConnect: true,
          connectTimeout: 3000,
          retryStrategy: (times: number) => {
            // Stop retrying after 3 attempts so the event loop can drain.
            if (times > 3) return null;
            return Math.min(times * 200, 1000);
          },
        },
      }),
    }),

    // ── Infrastructure modules ───────────────────────────────────
    PrismaModule,
    RedisModule,
    CacheModule,
    FilesModule,
    SearchModule,
    SecretsModule,
    PdfModule,
    GatewayModule,
    AuditModule,
    FeatureFlagsModule,
    AiGovernanceModule,

    // ── ERP Domain Modules ───────────────────────────────────────
    // §7: 14 ERP modules as per master prompt
    AuthModule, // M1 — Authentication & RBAC
    // M2 — Dashboard served from frontend (data from Reports)
    CrmModule, // M3 — CRM
    InventoryModule, // M4 — Inventory & Warehousing
    SalesModule, // M5 — Sales & Quotations
    ProcurementModule, // M6 — Procurement
    WorkshopModule, // M7 — Workshop & Service
    FinanceModule, // M8 — Finance & Accounting
    HrModule, // M9 — Human Resources
    ContractsModule, // M10 — Government Contracts
    ReportsModule, // M11 — Reporting & BI
    PortalModule, // M12 — Customer Portal
    AiModule, // M13 — AI Intelligence Layer
    FleetModule, // M14 — Fleet & Telematics

    HealthModule,
    ReadModelModule, // Sprint 4: CQRS read model (reporting queries)
    FirsModule, // Sprint 5: FIRS VAT/WHT filing
    LedgerModule, // Sprint 5: Immutable ledger event log
    WhatsappModule, // Sprint 3: WhatsApp Business API
    ExchangeRateModule, // Sprint 3: CBN exchange rate feed
  ],
})
export class AppModule {}
