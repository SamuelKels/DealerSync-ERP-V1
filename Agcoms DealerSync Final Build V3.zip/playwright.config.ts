/**
 * AGCOMS DealerSync ERP — Playwright Configuration
 *
 * Used for:
 *   - E2E smoke tests in CI (Step 10b of the CI/CD pipeline)
 *   - Local integration testing against a running stack
 *
 * Run smoke tests: npx playwright test --project=chromium tests/smoke/
 * Run all E2E:     npx playwright test
 *
 * Section 10 (Testing Strategy): E2E tests via Playwright
 */
import { defineConfig, devices } from '@playwright/test';

const BASE_URL = process.env['BASE_URL'] ?? 'http://localhost:3000';
const API_URL = process.env['API_URL'] ?? 'http://localhost:3001';

export default defineConfig({
  testDir: './tests',
  testIgnore: [
    '**/contract/**',   // Pact contract tests run separately via pact CLI
    '**/load/**',       // k6 load tests run via the k6 CLI, not Playwright
    '**/mutation/**',   // Stryker mutation tests run separately
  ],
  fullyParallel: true,

  // Fail the build on CI if a test.only or test.skip is left in code
  forbidOnly: !!process.env['CI'],
  retries: process.env['CI'] ? 1 : 0,
  workers: process.env['CI'] ? 2 : undefined,

  // Reporter: list for local dev, GitHub Actions annotation in CI
  reporter: process.env['CI']
    ? [['github'], ['html', { open: 'never' }]]
    : [['list'], ['html', { open: 'on-failure' }]],

  // Global test timeout
  timeout: 30_000,
  expect: { timeout: 5_000 },

  use: {
    baseURL: BASE_URL,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',

    // Shared context options
    extraHTTPHeaders: {
      'X-Playwright-Test': 'true',
    },
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },

    // Smoke-only project: runs a subset of tests against the API only (no browser)
    {
      name: 'smoke-api',
      testMatch: '**/smoke/api/**/*.spec.ts',
      use: {
        baseURL: API_URL,
      },
    },
  ],

  // Spin up dev servers locally (skipped in CI where services are already running)
  ...(process.env['CI']
    ? {}
    : {
        webServer: [
          {
            command: 'pnpm --filter frontend dev',
            url: BASE_URL,
            reuseExistingServer: true,
            timeout: 120_000,
          },
          {
            command: 'pnpm --filter backend start:dev',
            url: `${API_URL}/api/v1/health/live`,
            reuseExistingServer: true,
            timeout: 120_000,
          },
        ],
      }),
});
