import { z } from 'zod';

// ── Reusable primitives ───────────────────────────────────────

export const EmailSchema = z.string().email('Invalid email address').toLowerCase().trim();

export const PasswordSchema = z
  .string()
  .min(10, 'Password must be at least 10 characters')
  .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
  .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
  .regex(/[0-9]/, 'Password must contain at least one number')
  .regex(/[^A-Za-z0-9]/, 'Password must contain at least one special character');

export const UuidSchema = z.string().uuid('Invalid UUID format');

export const PhoneSchema = z
  .string()
  .regex(/^\+?[1-9]\d{7,14}$/, 'Invalid phone number (e.g. +2348012345678)');

export const NigerianAmountSchema = z
  .number()
  .nonnegative('Amount cannot be negative')
  .multipleOf(0.01, 'Amount must have at most 2 decimal places');

export const CurrencyCodeSchema = z.enum(['NGN', 'USD', 'EUR', 'GBP']);

// ── Auth schemas ──────────────────────────────────────────────

export const LoginSchema = z
  .object({
    email: EmailSchema,
    password: z.string().min(1, 'Password is required'),
  })
  .strict();
export type LoginDto = z.infer<typeof LoginSchema>;

export const MfaVerifySchema = z
  .object({
    challengeToken: z.string().min(1),
    code: z
      .string()
      .length(6, 'MFA code must be exactly 6 digits')
      .regex(/^\d{6}$/),
  })
  .strict();
export type MfaVerifyDto = z.infer<typeof MfaVerifySchema>;

export const RefreshTokenSchema = z
  .object({
    refreshToken: z.string().min(1, 'Refresh token is required'),
  })
  .strict();
export type RefreshTokenDto = z.infer<typeof RefreshTokenSchema>;

export const ChangePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: PasswordSchema,
    confirmPassword: z.string(),
  })
  .strict()
  .refine((d) => d.newPassword === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });
export type ChangePasswordDto = z.infer<typeof ChangePasswordSchema>;

export const ForgotPasswordSchema = z
  .object({
    email: EmailSchema,
  })
  .strict();
export type ForgotPasswordDto = z.infer<typeof ForgotPasswordSchema>;

export const ResetPasswordSchema = z
  .object({
    token: z.string().min(1, 'Reset token is required'),
    newPassword: PasswordSchema,
    confirmPassword: z.string(),
  })
  .strict()
  .refine((d) => d.newPassword === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });
export type ResetPasswordDto = z.infer<typeof ResetPasswordSchema>;

export const AcceptInviteSchema = z
  .object({
    token: z.string().min(1, 'Invite token is required'),
    password: PasswordSchema,
    confirmPassword: z.string(),
    firstName: z.string().min(1).max(64).trim(),
    lastName: z.string().min(1).max(64).trim(),
  })
  .strict()
  .refine((d) => d.password === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });
export type AcceptInviteDto = z.infer<typeof AcceptInviteSchema>;

export const SendInviteSchema = z
  .object({
    email: EmailSchema,
    roleIds: z.array(UuidSchema).min(1, 'At least one role required'),
    branchId: UuidSchema,
  })
  .strict();
export type SendInviteDto = z.infer<typeof SendInviteSchema>;

export const SetupMfaSchema = z
  .object({
    code: z
      .string()
      .length(6)
      .regex(/^\d{6}$/),
  })
  .strict();
export type SetupMfaDto = z.infer<typeof SetupMfaSchema>;
