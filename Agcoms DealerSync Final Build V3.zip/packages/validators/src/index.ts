// ============================================================
// @agcoms/validators — Main export
// ============================================================
export * from './schemas/auth';
export * from './schemas/crm';
export * from './schemas/finance';

// ── ZodValidationPipe for NestJS ──────────────────────────────
// Drop-in replacement for class-validator — uses Zod schemas
// Usage: @UsePipes(new ZodValidationPipe(CreateCustomerSchema))

import { z, ZodSchema, ZodError } from 'zod';
import { BadRequestException, PipeTransform, Injectable } from '@nestjs/common';

export class ZodValidationPipe implements PipeTransform {
  constructor(private readonly schema: ZodSchema) {}

  transform(value: unknown) {
    const result = this.schema.safeParse(value);
    if (!result.success) {
      const errors = result.error.errors.map((e) => ({
        field: e.path.join('.'),
        message: e.message,
        code: e.code,
      }));
      throw new BadRequestException({
        message: 'Validation failed',
        statusCode: 400,
        errors,
      });
    }
    return result.data;
  }
}

// ── Global Zod error formatter ────────────────────────────────

export function formatZodError(error: ZodError): Record<string, string[]> {
  const formatted: Record<string, string[]> = {};
  error.errors.forEach((e) => {
    const key = e.path.join('.') || '_root';
    if (!formatted[key]) formatted[key] = [];
    formatted[key].push(e.message);
  });
  return formatted;
}

// ── Safe parse helper ─────────────────────────────────────────

export function safeValidate<T>(
  schema: ZodSchema<T>,
  data: unknown,
): { success: true; data: T } | { success: false; errors: ReturnType<typeof formatZodError> } {
  const result = schema.safeParse(data);
  if (result.success) return { success: true, data: result.data };
  return { success: false, errors: formatZodError(result.error) };
}

// ── Common field helpers ──────────────────────────────────────

export const paginationQuerySchema = z
  .object({
    cursor: z.string().optional(),
    limit: z.coerce.number().int().min(1).max(100).default(20),
    sortBy: z.string().optional(),
    sortOrder: z.enum(['asc', 'desc']).default('desc'),
  })
  .partial();

export type PaginationQueryDto = z.infer<typeof paginationQuerySchema>;
