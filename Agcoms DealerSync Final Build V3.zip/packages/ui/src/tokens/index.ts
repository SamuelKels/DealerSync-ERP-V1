// ============================================================
// @agcoms/ui — Design Tokens
// Master Prompt Section 1: AGCOMS International Trading Limited
// Brand: Industrial-premium (John Deere · Bloomberg · SAP Fiori)
// ============================================================

export const colors = {
  // ── Primary brand palette ──────────────────────────────────
  primaryGreen: '#1A4D2E',
  primaryGreen50: '#EDF4EF',
  primaryGreen100: '#C8DCCF',
  primaryGreen200: '#93BA9F',
  primaryGreen700: '#14391F',
  primaryGreen900: '#0A1E10',

  secondaryYellow: '#F5C518',
  accentGold: '#E8A020',
  accentGold100: '#FDF3DC',
  accentGold700: '#B07518',

  // ── Surface & background ───────────────────────────────────
  backgroundDark: '#1C1C1E',
  surface: '#F7F4EF',
  surfaceDark: '#2C2C2E',
  white: '#FFFFFF',

  // ── Text ───────────────────────────────────────────────────
  textPrimary: '#1A1A1A',
  textSecondary: '#6B7280',
  textTertiary: '#9CA3AF',
  textInverse: '#FFFFFF',

  // ── Semantic ───────────────────────────────────────────────
  danger: '#DC2626',
  danger50: '#FEF2F2',
  danger100: '#FEE2E2',
  danger700: '#B91C1C',

  success: '#16A34A',
  success50: '#F0FDF4',
  success100: '#DCFCE7',
  success700: '#15803D',

  warning: '#D97706',
  warning50: '#FFFBEB',
  warning100: '#FEF3C7',
  warning700: '#B45309',

  info: '#0EA5E9',
  info50: '#F0F9FF',
  info100: '#E0F2FE',
  info700: '#0369A1',

  // ── Border ─────────────────────────────────────────────────
  border: '#E5E7EB',
  borderStrong: '#D1D5DB',
  borderFocus: '#1A4D2E',
} as const;

export const typography = {
  // Master prompt Section 1: exact font specifications
  fontDisplay: '"Playfair Display", Georgia, serif',
  fontHeading: '"DM Serif Display", Georgia, serif',
  fontUI: '"Outfit", system-ui, -apple-system, sans-serif',
  fontMono: '"JetBrains Mono", "Fira Code", "Cascadia Code", monospace',

  fontSizeXs: '0.75rem', // 12px
  fontSizeSm: '0.875rem', // 14px
  fontSizeBase: '1rem', // 16px
  fontSizeLg: '1.125rem', // 18px
  fontSizeXl: '1.25rem', // 20px
  fontSize2xl: '1.5rem', // 24px
  fontSize3xl: '1.875rem', // 30px
  fontSize4xl: '2.25rem', // 36px

  fontWeightNormal: '400',
  fontWeightMedium: '500',
  fontWeightSemibold: '600',
  fontWeightBold: '700',

  lineHeightTight: '1.25',
  lineHeightNormal: '1.5',
  lineHeightRelaxed: '1.75',

  letterSpacingTight: '-0.025em',
  letterSpacingNormal: '0em',
  letterSpacingWide: '0.025em',
  letterSpacingWider: '0.05em',
} as const;

export const spacing = {
  px: '1px',
  0: '0px',
  0.5: '0.125rem',
  1: '0.25rem',
  1.5: '0.375rem',
  2: '0.5rem',
  2.5: '0.625rem',
  3: '0.75rem',
  3.5: '0.875rem',
  4: '1rem',
  5: '1.25rem',
  6: '1.5rem',
  7: '1.75rem',
  8: '2rem',
  9: '2.25rem',
  10: '2.5rem',
  12: '3rem',
  14: '3.5rem',
  16: '4rem',
  20: '5rem',
  24: '6rem',
} as const;

export const borderRadius = {
  none: '0px',
  sm: '0.125rem',
  base: '0.25rem',
  md: '0.375rem',
  lg: '0.5rem',
  xl: '0.75rem',
  '2xl': '1rem',
  '3xl': '1.5rem',
  full: '9999px',
} as const;

export const shadows = {
  sm: '0 1px 2px 0 rgb(0 0 0 / 0.05)',
  base: '0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)',
  md: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)',
  lg: '0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)',
  xl: '0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1)',
} as const;

// Tailwind CSS class name utilities
export const cn = (...classes: (string | undefined | false | null)[]) =>
  classes.filter(Boolean).join(' ');

// CSS custom property strings for use in inline styles
export const cssVars = {
  green: 'var(--color-primary-green)',
  gold: 'var(--color-accent-gold)',
  surface: 'var(--color-surface)',
} as const;

export type Colors = typeof colors;
export type Typography = typeof typography;
