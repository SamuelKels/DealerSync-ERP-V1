# AGCOMS DealerSync ERP — Staging Deployment Runbook

**Audience:** Deployment / platform engineers
**Goal:** Bring the Final Build V1 package up on a real-infrastructure **staging** environment,
validate the data paths that the sandbox could not exercise, and produce a go/no-go decision for
production.

> **Why staging first?** Every gate in the build (0 TS errors, 55 modules booting, health 200,
> 63 tests passing) was verified against a *synthetic Prisma stub* with no real database, Redis,
> Typesense, or S3. This runbook validates the parts that were necessarily unverified in the
> sandbox. Treat a clean staging run as a hard prerequisite for production.

---

## 0. Prerequisites

Provision and have connection details ready for:

| Service | Version | Notes |
|---------|---------|-------|
| PostgreSQL | 16 | Managed (RDS/Cloud SQL) recommended |
| Redis | 7 | For cache + BullMQ queues |
| Typesense | latest stable | Search index |
| Object storage | S3 or MinIO | Document/asset uploads |
| Node.js | 20 LTS | Build + runtime |
| pnpm | as in `packageManager` field | `corepack enable` |

Secrets to have on hand (store in Vault / AWS Secrets Manager, inject as env):
`DATABASE_URL`, `REDIS_HOST`, `REDIS_PORT`, `JWT_PRIVATE_KEY` (base64 RSA), `JWT_PUBLIC_KEY`
(base64 RSA), `PORTAL_JWT_SECRET`, `ANTHROPIC_API_KEY`, Typesense API key, S3 credentials +
bucket, and (when testing those integrations) WhatsApp Cloud API + FIRS/TaxPro-Max credentials.

If you do not yet have an RSA keypair for JWT:
```bash
# private key (base64, single line) → JWT_PRIVATE_KEY
openssl genrsa 2048 | base64 -w0
# public key (base64, single line) → JWT_PUBLIC_KEY
#   (derive from the same private key)
```

---

## 1. Install

```bash
unzip "Agcoms DealerSync Final Build V1.zip" -d agcoms-staging
cd agcoms-staging
corepack enable
pnpm install --frozen-lockfile
```

**Gate 1:** install exits 0 with no peer-dependency errors.

---

## 2. Generate the real Prisma client ⚠️ critical

```bash
cd apps/backend
npx prisma generate
```

**This replaces the sandbox's synthetic stub with the real typed client.** It is the single most
important validation step.

**Gate 2:** `npx prisma generate` succeeds, then:
```bash
npx tsc --noEmit
```
must still report **0 errors**.

> **Expect to fix drift here.** The synthetic stub was permissive and masked schema-vs-code
> mismatches. Known examples already found and corrected in this build:
> - `auth.service.ts` derived `isSuperAdmin` from a non-existent `User.isSuperAdmin` column
>   (fixed: now derived from the `SUPER_ADMIN` role).
> - `scripts/seed.ts` (demo seeder) references `password`, `roleId`, `isSuperAdmin`, `isActive`
>   on `User`, and upserts roles by `name`. The **real** `User` uses `passwordHash`, a `status`
>   enum, and a `UserRole` join, and `Role` is unique by `code`. **The demo seed will fail against
>   a real DB until rewritten — use `scripts/create-super-admin.ts` instead (see §5).**
>
> If `tsc` surfaces further drift after `prisma generate`, fix each error before continuing.
> Do not proceed to production with `@ts-ignore` patches over schema mismatches.

---

## 3. Apply migrations

```bash
# from apps/backend, with DATABASE_URL pointed at the staging Postgres
npx prisma migrate deploy
```

**Gate 3:** migrations apply cleanly. Verify the key tables exist:
```bash
npx prisma db execute --stdin <<'SQL'
SELECT table_name FROM information_schema.tables
WHERE table_schema='public'
  AND table_name IN ('users','roles','user_roles','accounting_periods',
                     'journal_entries','chart_of_accounts');
SQL
```
All six should be present (the `accounting_periods` table comes from the P2 migration).

---

## 4. Build the apps

```bash
cd ../..                      # repo root
pnpm --filter backend build   # tsc -p tsconfig.build.json
pnpm --filter frontend build  # next build  (set USE_LOCAL_FONTS=1 if Google Fonts are blocked)
pnpm --filter portal build
```

**Gate 4:** all three builds succeed; `apps/backend/dist/apps/backend/src/main.js` exists.

---

## 5. Provision the super-admin (production-safe) ⚠️ do NOT run the demo seed in staging-for-prod

```bash
cd apps/backend
SUPERADMIN_PASSWORD='<choose-a-strong-password>' \
  npx ts-node ../../scripts/create-super-admin.ts \
    --email admin@agcoms.ng --first <First> --last <Last> --branch ABV-HQ
```

The script hashes with argon2 (matching `auth.service` verification), assigns the `SUPER_ADMIN`
role (which is how super-admin status is derived), sets `status=active`, and is idempotent.

If you need at least one branch before creating the admin, insert it first:
```bash
npx prisma db execute --stdin <<'SQL'
INSERT INTO branches (id, code, name, region)
VALUES (gen_random_uuid(), 'ABV-HQ', 'Abuja HQ', 'FCT')
ON CONFLICT (code) DO NOTHING;
SQL
```

**Gate 5:** script reports the super-admin created; the row exists with a `SUPER_ADMIN` role link.

> The demo seeder (`scripts/seed.ts`) is for local development only and currently does not match
> the production schema. Either skip it in staging-for-prod, or run it only on a throwaway dev DB
> after it is rewritten to the real schema.

---

## 6. Boot with real infrastructure

Start the backend with all real service env vars set:
```bash
cd apps/backend
node dist/apps/backend/src/main.js
```

**Gate 6 — boot:**
- Log shows `Nest application successfully started`.
- **No** `ECONNREFUSED` for Redis/Postgres/Typesense (these were expected in the sandbox; in
  staging they indicate misconfiguration — fix the connection details).
- Health probes succeed:
```bash
curl -fsS http://<host>:3001/api/v1/health/live   # liveness
curl -fsS http://<host>:3001/api/v1/health         # full readiness incl. DB ping
```
The full `/health` check pings the database via Terminus — it must return `ok`, proving the real
DB connection works end-to-end (something the sandbox could not verify).

---

## 7. Functional smoke tests (real data paths)

Authenticate as the super-admin and exercise the financial-integrity-critical paths:

1. **Auth + super-admin recognition**
   - `POST /api/v1/auth/login` with the super-admin credentials → expect tokens.
   - Decode the JWT → confirm `isSuperAdmin: true` and `roles` includes `SUPER_ADMIN`.
     *(This validates the bug fix from this build.)*

2. **RBAC enforcement**
   - Call a branch-scoped endpoint as super-admin (should bypass branch isolation) and as a
     non-super-admin (should be restricted).

3. **Accounting period lock (financial integrity)**
   - Create an accounting period → post a balanced journal entry → succeeds.
   - `POST /finance/periods/:id/close` then `/lock` → confirm a subsequent journal post into the
     locked period is **rejected with 400**.
   - Confirm a LOCKED period **cannot** be reopened (only CLOSED can).

4. **Sales → invoice → posting chain**
   - Create a quotation, convert to invoice, confirm the double-entry journal posts and the
     trial balance stays balanced.

5. **FIRS VAT**
   - Compute a VAT return for the current month from posted journals → review output/input split.

6. **Portal isolation**
   - Log in via the portal with a customer account → confirm the portal JWT cannot access internal
     ERP endpoints.

7. **File upload**
   - Upload a document → confirm signed-URL upload to S3/MinIO and that the malware-scan job
     enqueues (BullMQ → Redis).

**Gate 7:** all seven paths behave as specified, with the trial balance balanced after every
financial operation.

---

## 8. Quality + security gates

```bash
# from repo root
pnpm --filter backend test:unit        # currently 63 pass / 61 skipped — see note
pnpm --filter backend lint
pnpm --filter frontend lint
npx playwright test                     # E2E against the running staging stack
```

**Before production**, also complete (master prompt §10/§11):
- **P5.1 test debt:** extract the pending helper methods (PAYE/NHF/pension/VAT/WHT in Finance;
  leave/review/transition in HR; discount/line-total/transition in Sales) from controllers to
  services, un-skip the 61 `xdescribe` blocks, and raise coverage toward the 80% floor — with
  finance workflows fully covered.
- **SAST + dependency scan** (e.g. the CI pipeline's scan stages).
- **Load test** with k6 and an **OWASP ZAP** pass.

**Gate 8:** unit + lint + E2E green; finance test coverage at target; security scans clean.

---

## 9. Operational hardening before production

- **Global error handlers:** `main.ts` currently logs `unhandledRejection` / `uncaughtException`
  and continues (correct for sandbox). Wire these to Sentry/Loki and decide, per error class,
  whether to exit the process so a corrupted state cannot persist silently.
- **Secrets rotation:** confirm Vault/Secrets-Manager rotation is configured; no secrets in env
  files committed anywhere.
- **Backups:** enable Postgres PITR and run a restore drill.
- **Observability:** confirm OpenTelemetry traces, Prometheus metrics, Grafana dashboards, and
  alerting fire against staging before relying on them in production.
- **Change the super-admin password** if a shared one was used during testing; enable MFA.

---

## 10. Go / No-Go

Production deployment is **GO** only when:

- [ ] Gates 1–8 all pass on staging with real infrastructure
- [ ] `prisma generate` drift fully resolved (no `@ts-ignore` over schema mismatches)
- [ ] Full `/health` readiness (DB ping) returns ok
- [ ] All seven functional smoke tests pass; trial balance balanced throughout
- [ ] Finance test coverage at the 80% target; SAST/ZAP/load tests clean
- [ ] Global error handlers hardened; backups + observability verified
- [ ] Super-admin provisioned via `create-super-admin.ts` (not the demo seed), MFA enabled

Until then: **NO-GO for production.**

---

*End of staging deployment runbook.*
