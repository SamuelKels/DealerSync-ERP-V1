/**
 * AGCOMS DealerSync ERP — ESLint Configuration
 * Monorepo root config. Individual apps may extend this.
 *
 * Stack: TypeScript 5 · NestJS 10 · Next.js 15 · ESLint 8
 */

'use strict';

module.exports = {
  root: true,
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: 'module',
    // Point at root tsconfig; per-app overrides handled via .eslintrc in each app
    project: ['./tsconfig.base.json', './apps/*/tsconfig.json', './packages/*/tsconfig.json'],
    tsconfigRootDir: __dirname,
  },
  plugins: ['@typescript-eslint', 'import', 'prettier'],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:import/recommended',
    'plugin:import/typescript',
    'prettier', // Must be last — disables ESLint rules that conflict with Prettier
  ],
  rules: {
    // ── Prettier integration ──────────────────────────────────────
    'prettier/prettier': 'error',

    // ── TypeScript ────────────────────────────────────────────────
    // Allow `any` explicitly — V2 uses `as any` in Prisma delegate workarounds.
    // Remove this once real `prisma generate` produces strict types.
    '@typescript-eslint/no-explicit-any': 'warn',
    '@typescript-eslint/no-unused-vars': [
      'error',
      { argsIgnorePattern: '^_', varsIgnorePattern: '^_' },
    ],
    '@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }],
    '@typescript-eslint/no-floating-promises': 'error',
    '@typescript-eslint/await-thenable': 'error',
    '@typescript-eslint/no-misused-promises': 'error',
    // Allow non-null assertions — NestJS DI patterns use them extensively
    '@typescript-eslint/no-non-null-assertion': 'warn',
    // Allow empty functions — NestJS lifecycle hooks are often stubs
    '@typescript-eslint/no-empty-function': 'warn',

    // ── Import order ──────────────────────────────────────────────
    'import/order': [
      'error',
      {
        groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index'],
        'newlines-between': 'always',
        alphabetize: { order: 'asc', caseInsensitive: true },
      },
    ],
    'import/no-duplicates': 'error',
    'import/no-unresolved': 'off', // TypeScript handles this

    // ── General code quality ──────────────────────────────────────
    'no-console': ['warn', { allow: ['warn', 'error'] }],
    'no-debugger': 'error',
    'no-duplicate-imports': 'off', // Handled by import/no-duplicates
    'prefer-const': 'error',
    'no-var': 'error',
    eqeqeq: ['error', 'always', { null: 'ignore' }],
  },
  overrides: [
    // ── NestJS backend ────────────────────────────────────────────
    {
      files: ['apps/backend/**/*.ts'],
      rules: {
        // NestJS decorators cause false positives for these
        '@typescript-eslint/no-inferrable-types': 'off',
        // Class fields with ! assertions are common in NestJS
        '@typescript-eslint/no-non-null-assertion': 'off',
      },
    },
    // ── Next.js frontend ──────────────────────────────────────────
    {
      files: ['apps/frontend/**/*.{ts,tsx}', 'apps/portal/**/*.{ts,tsx}'],
      rules: {
        // React components often use non-null assertions
        '@typescript-eslint/no-non-null-assertion': 'off',
        // Console usage is acceptable in Next.js pages for logging
        'no-console': 'off',
      },
    },
    // ── Test files ────────────────────────────────────────────────
    {
      files: ['**/*.spec.ts', '**/*.test.ts', '**/test/**/*.ts', '**/tests/**/*.ts'],
      rules: {
        // Tests may use any for mocks
        '@typescript-eslint/no-explicit-any': 'off',
        // Tests may use non-null assertions for mocked values
        '@typescript-eslint/no-non-null-assertion': 'off',
        // Tests may not await all promises in assertion chains
        '@typescript-eslint/no-floating-promises': 'off',
      },
    },

    // ── React/Next.js component files ────────────────────────────
    {
      files: ['**/*.tsx'],
      rules: {
        // pnpm resolves `import type { X } from 'react'` and `import { Y } from 'react'`
        // to different physical paths in the store, causing false-positive duplicates.
        // The TypeScript compiler correctly deduplicates these; the ESLint plugin does not.
        'import/no-duplicates': 'off',
        // Next.js 'use client' components often have async event handlers (onSubmit, onClick)
        // that are correctly typed — the no-misused-promises check produces false positives here.
        '@typescript-eslint/no-misused-promises': 'off',
        // router.push, toast calls, etc. are legitimately fire-and-forget in event handlers
        '@typescript-eslint/no-floating-promises': 'off',
        // import/order in RSC/RCC files: 'use client' directive changes the expected order
        'import/order': ['warn', {
          groups: ['builtin', 'external', 'internal', 'parent', 'sibling', 'index'],
          'newlines-between': 'always',
          alphabetize: { order: 'asc', caseInsensitive: true },
        }],
      },
    },
    // ── NestJS backend — disable type-import enforcement to protect DI tokens ──
    {
      files: ['apps/backend/**/*.ts'],
      rules: {
        // NestJS uses emitDecoratorMetadata — injectable classes MUST be value imports.
        // `import type` erases the constructor reference at runtime, breaking DI resolution.
        '@typescript-eslint/consistent-type-imports': 'off',
      },
    },

    // ── Config files ──────────────────────────────────────────────
    {
      files: ['*.js', '*.cjs', '*.mjs'],
      env: { node: true },
      rules: {
        '@typescript-eslint/no-var-requires': 'off',
      },
    },
  ],
  env: {
    node: true,
    es2022: true,
  },
  ignorePatterns: [
    'node_modules/',
    'dist/',
    '.next/',
    '.turbo/',
    'coverage/',
    '*.tsbuildinfo',
    'pnpm-lock.yaml',
    'apps/backend/src/prisma/generated/',
  ],
  settings: {
    'import/resolver': {
      typescript: {
        alwaysTryTypes: true,
        project: ['./tsconfig.base.json', './apps/*/tsconfig.json'],
      },
    },
  },
};
