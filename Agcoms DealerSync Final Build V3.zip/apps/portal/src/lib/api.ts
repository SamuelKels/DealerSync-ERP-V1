/**
 * AGCOMS Customer Portal — API Client
 * Thin axios wrapper that attaches the portal JWT from localStorage.
 * All requests target /api/v1/portal/* on the ERP backend.
 */

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:3001/api/v1';

const TOKEN_KEY = 'agcoms_portal_token';
const CUSTOMER_KEY = 'agcoms_portal_customer';

// ── Token helpers (browser-only) ─────────────────────────────────────────
export function saveSession(token: string, customer: PortalCustomer) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(CUSTOMER_KEY, JSON.stringify(customer));
}

export function clearSession() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(CUSTOMER_KEY);
}

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function getCustomer(): PortalCustomer | null {
  if (typeof window === 'undefined') return null;
  const raw = localStorage.getItem(CUSTOMER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as PortalCustomer;
  } catch {
    return null;
  }
}

export function isAuthenticated(): boolean {
  return !!getToken();
}

// ── Types ─────────────────────────────────────────────────────────────────
export interface PortalCustomer {
  id: string;
  email: string;
  name: string;
  companyName?: string;
}

// ── HTTP ──────────────────────────────────────────────────────────────────
async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}/portal${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: 'include',
  });

  if (res.status === 401) {
    clearSession();
    if (typeof window !== 'undefined') window.location.href = '/login';
    throw new Error('Session expired');
  }

  if (!res.ok) {
    const err = await res.json().catch(() => ({ message: 'Request failed' }));
    throw new Error((err as { message?: string }).message ?? 'Request failed');
  }

  if (res.status === 204) return undefined as T;
  return res.json() as Promise<T>;
}

export const portalApi = {
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body),
  get: <T>(path: string) => request<T>('GET', path),
};

// ── Query keys ────────────────────────────────────────────────────────────
export const qk = {
  dashboard: ['portal', 'dashboard'] as const,
  quotations: (s?: string) => ['portal', 'quotations', s] as const,
  quotation: (id: string) => ['portal', 'quotation', id] as const,
  invoices: (s?: string) => ['portal', 'invoices', s] as const,
  invoice: (id: string) => ['portal', 'invoice', id] as const,
  serviceRequests: () => ['portal', 'service-requests'] as const,
  serviceRequest: (id: string) => ['portal', 'service-request', id] as const,
  equipment: () => ['portal', 'equipment'] as const,
};
