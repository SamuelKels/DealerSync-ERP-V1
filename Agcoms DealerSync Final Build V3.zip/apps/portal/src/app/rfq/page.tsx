'use client';
/**
 * AGCOMS Customer Portal — Submit RFQ (Sprint P4)
 */
import { useState, FormEvent } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Plus, Trash2, ClipboardList, CheckCircle2 } from 'lucide-react';
import PortalShell from '../../components/PortalShell';
import { portalApi } from '../../lib/api';

interface RfqItem {
  description: string;
  quantity: number;
  unit: string;
}

function emptyItem(): RfqItem {
  return { description: '', quantity: 1, unit: 'unit' };
}

export default function RfqPage() {
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [requiredBy, setRequiredBy] = useState('');
  const [items, setItems] = useState<RfqItem[]>([emptyItem()]);
  const [submitted, setSubmitted] = useState(false);
  const [rfqCode, setRfqCode] = useState('');

  const addItem = () => setItems((i) => [...i, emptyItem()]);
  const removeItem = (idx: number) =>
    setItems((i) => (i.length > 1 ? i.filter((_, n) => n !== idx) : i));
  const updateItem = (idx: number, field: keyof RfqItem, value: string | number) =>
    setItems((i) => i.map((item, n) => (n === idx ? { ...item, [field]: value } : item)));

  const submit = useMutation({
    mutationFn: () =>
      portalApi.post<{ code: string }>('/rfq', {
        subject,
        description,
        requiredBy: requiredBy || undefined,
        items,
      }),
    onSuccess: (res) => {
      setRfqCode(res.code);
      setSubmitted(true);
    },
  });

  const valid =
    subject.trim() &&
    description.trim() &&
    items.every((i) => i.description.trim() && i.quantity > 0);

  if (submitted) {
    return (
      <PortalShell>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
          <div className="p-4 bg-emerald-50 rounded-full mb-4">
            <CheckCircle2 className="h-10 w-10 text-emerald-600" />
          </div>
          <h2 className="text-lg font-semibold text-[#1A1A1A] mb-1">RFQ submitted</h2>
          <p className="text-sm text-gray-500 mb-1">
            Reference: <span className="font-mono font-semibold text-[#1A4D2E]">{rfqCode}</span>
          </p>
          <p className="text-sm text-gray-500 mb-6 max-w-sm">
            Our team will review your request and send a quotation within 2 business days.
          </p>
          <button
            onClick={() => {
              setSubmitted(false);
              setSubject('');
              setDescription('');
              setRequiredBy('');
              setItems([emptyItem()]);
            }}
            className="text-sm font-medium text-[#1A4D2E] hover:underline"
          >
            Submit another RFQ
          </button>
        </div>
      </PortalShell>
    );
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    submit.mutate();
  }

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 max-w-2xl mx-auto space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-50 rounded-lg">
            <ClipboardList className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <h1 className="text-lg font-semibold text-[#1A1A1A]">Submit RFQ</h1>
            <p className="text-xs text-gray-500">Request a quote for equipment or services</p>
          </div>
        </div>

        {submit.isError && (
          <div className="px-3 py-2 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
            {submit.error instanceof Error ? submit.error.message : 'Submission failed'}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Subject */}
          <div>
            <label className="block text-sm font-medium text-[#1A1A1A] mb-1">
              Subject <span className="text-red-500">*</span>
            </label>
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
              placeholder="e.g. 5 × John Deere 6M tractors for NADF programme"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm
                         focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-[#1A1A1A] mb-1">
              Description <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
              placeholder="Describe your requirements, specifications, and any special conditions…"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm
                         focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E] resize-none"
            />
          </div>

          {/* Required by */}
          <div>
            <label className="block text-sm font-medium text-[#1A1A1A] mb-1">
              Required by <span className="text-gray-400 font-normal">(optional)</span>
            </label>
            <input
              type="date"
              value={requiredBy}
              onChange={(e) => setRequiredBy(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm
                         focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
            />
          </div>

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-[#1A1A1A]">
                Line items <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={addItem}
                className="flex items-center gap-1 text-xs text-[#1A4D2E] font-medium hover:underline"
              >
                <Plus className="h-3.5 w-3.5" />
                Add item
              </button>
            </div>

            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <input
                    value={item.description}
                    onChange={(e) => updateItem(idx, 'description', e.target.value)}
                    required
                    placeholder="Item description"
                    className="flex-1 border border-gray-200 rounded-lg px-3 py-2 text-sm
                               focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
                  />
                  <input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateItem(idx, 'quantity', parseInt(e.target.value, 10) || 1)}
                    min={1}
                    className="w-16 border border-gray-200 rounded-lg px-2 py-2 text-sm text-center
                               focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
                  />
                  <input
                    value={item.unit}
                    onChange={(e) => updateItem(idx, 'unit', e.target.value)}
                    placeholder="unit"
                    className="w-20 border border-gray-200 rounded-lg px-2 py-2 text-sm text-center
                               focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
                  />
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeItem(idx)}
                      className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={!valid || submit.isPending}
            className="w-full bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 disabled:opacity-60
                       text-white font-medium text-sm rounded-lg py-3 transition-colors"
          >
            {submit.isPending ? 'Submitting…' : 'Submit RFQ'}
          </button>
        </form>
      </div>
    </PortalShell>
  );
}
