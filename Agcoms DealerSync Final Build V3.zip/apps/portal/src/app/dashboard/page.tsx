'use client';
/**
 * AGCOMS Customer Portal — Dashboard (Sprint P4)
 */
import { useQuery } from '@tanstack/react-query';
import { FileText, Receipt, Wrench, Package, AlertTriangle, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import PortalShell from '../../components/PortalShell';
import { portalApi, qk, getCustomer } from '../../lib/api';
import { Card, StatusBadge, Skeleton, formatNGN, formatDate } from '../../components/ui';

interface Dashboard {
  openInvoices: number;
  openSRs: number;
  openRfqs: number;
  equipmentCount: number;
  overdueInvoice: {
    code: string;
    amountDue: number;
    dueDate: string;
  } | null;
}

const TILES = [
  {
    key: 'openInvoices',
    label: 'Outstanding Invoices',
    icon: Receipt,
    href: '/invoices',
    color: 'text-blue-600 bg-blue-50',
  },
  {
    key: 'openSRs',
    label: 'Active Service Reqs',
    icon: Wrench,
    href: '/service',
    color: 'text-amber-600 bg-amber-50',
  },
  {
    key: 'openRfqs',
    label: 'Open RFQs',
    icon: FileText,
    href: '/rfq',
    color: 'text-purple-600 bg-purple-50',
  },
  {
    key: 'equipmentCount',
    label: 'Equipment on Record',
    icon: Package,
    href: '/equipment',
    color: 'text-emerald-600 bg-emerald-50',
  },
] as const;

export default function DashboardPage() {
  const customer = getCustomer();
  const { data, isLoading } = useQuery<Dashboard>({
    queryKey: qk.dashboard,
    queryFn: () => portalApi.get<Dashboard>('/dashboard'),
  });

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 space-y-6 max-w-3xl mx-auto">
        {/* Welcome */}
        <div>
          <h1 className="text-xl font-semibold text-[#1A1A1A]">
            Welcome back{customer?.name ? `, ${customer.name.split(' ')[0]}` : ''}
          </h1>
          <p className="text-sm text-gray-500 mt-0.5">
            {customer?.companyName ?? 'Your AGCOMS account'}
          </p>
        </div>

        {/* Overdue alert */}
        {data?.overdueInvoice && (
          <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-xl">
            <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-red-800">Overdue invoice</p>
              <p className="text-xs text-red-700 mt-0.5">
                {data.overdueInvoice.code} · {formatNGN(data.overdueInvoice.amountDue)} · due{' '}
                {formatDate(data.overdueInvoice.dueDate)}
              </p>
            </div>
            <Link
              href="/invoices"
              className="text-xs font-medium text-red-700 hover:text-red-800 whitespace-nowrap"
            >
              View →
            </Link>
          </div>
        )}

        {/* KPI tiles */}
        <div className="grid grid-cols-2 gap-3">
          {TILES.map(({ key, label, icon: Icon, href, color }) => (
            <Link key={key} href={href}>
              <Card className="p-4 hover:shadow-sm transition-shadow cursor-pointer">
                <div className={`inline-flex p-2 rounded-lg ${color} mb-3`}>
                  <Icon className="h-4 w-4" />
                </div>
                {isLoading ? (
                  <Skeleton className="h-8 w-12 mb-1" />
                ) : (
                  <p className="text-2xl font-bold text-[#1A1A1A]">{data?.[key] ?? 0}</p>
                )}
                <p className="text-xs text-gray-500 mt-0.5">{label}</p>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick links */}
        <Card>
          <div className="px-4 py-3 border-b border-gray-100">
            <p className="text-sm font-semibold text-[#1A1A1A]">Quick actions</p>
          </div>
          <div className="divide-y divide-gray-100">
            {[
              { href: '/rfq', label: 'Submit a new RFQ', sub: 'Request a quote for equipment' },
              {
                href: '/invoices',
                label: 'View & download invoices',
                sub: 'Access all your invoices',
              },
              {
                href: '/service',
                label: 'Track service requests',
                sub: 'Check technician progress',
              },
              { href: '/equipment', label: 'My equipment', sub: 'Ownership and warranty history' },
            ].map(({ href, label, sub }) => (
              <Link
                key={href}
                href={href}
                className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium text-[#1A1A1A]">{label}</p>
                  <p className="text-xs text-gray-500">{sub}</p>
                </div>
                <ChevronRight className="h-4 w-4 text-gray-400 shrink-0" />
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}
