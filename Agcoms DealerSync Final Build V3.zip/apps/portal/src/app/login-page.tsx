/**
 * AGCOMS Customer Portal — Login Page (V2 stub)
 * Full portal authentication will land in V2.1
 */
'use client';
import { useState } from 'react';

export default function PortalLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <main className="min-h-screen flex items-center justify-center bg-agcoms-surface p-6">
      <div className="max-w-md w-full bg-white rounded-xl p-8 shadow-sm">
        <h1 className="text-2xl font-semibold text-agcoms-green mb-2">Sign in</h1>
        <p className="text-sm text-gray-600 mb-6">Access your AGCOMS customer portal</p>
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="email@company.ng"
            className="w-full px-4 py-2 border border-gray-200 rounded-lg"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full px-4 py-2 border border-gray-200 rounded-lg"
          />
          <button type="submit" className="w-full py-2 bg-agcoms-green text-white rounded-lg">
            Sign in
          </button>
        </form>
      </div>
    </main>
  );
}
