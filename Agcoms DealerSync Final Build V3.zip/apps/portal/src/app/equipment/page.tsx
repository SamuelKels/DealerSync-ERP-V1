'use client';
/**
 * AGCOMS Customer Portal — Equipment Ownership History (Sprint P4)
 */
import { useQuery } from '@tanstack/react-query';
import { Package, Shield, Wrench } from 'lucide-react';
import PortalShell from '../../components/PortalShell';
import { portalApi, qk } from '../../lib/api';
import { Card, StatusBadge, EmptyState, Skeleton, formatDate } from '../../components/ui';

interface Equipment {
  id: string;
  serialNumber: string | null;
  productName: string;
  sku: string;
  description: string | null;
  purchaseDate: string | null;
  warranties: Array<{
    id: string;
    warrantyType: string;
    startDate: string;
    endDate: string;
    status: string;
  }>;
  recentServiceRequests: Array<{
    id: string;
    code: string;
    status: string;
    faultDescription: string;
    reportedAt: string;
  }>;
}

function EquipmentCard({ eq }: { eq: Equipment }) {
  const activeWarranty = eq.warranties.find((w) => w.status === 'ACTIVE');
  const warrantyDaysLeft = activeWarranty
    ? Math.ceil((new Date(activeWarranty.endDate).getTime() - Date.now()) / 86_400_000)
    : null;

  return (
    <Card>
      <div className="p-4 border-b border-gray-100">
        <div className="flex items-start gap-3">
          <div className="p-2.5 bg-gray-100 rounded-lg flex-shrink-0">
            <Package className="h-5 w-5 text-gray-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-[#1A1A1A]">{eq.productName}</p>
            <p className="text-xs text-gray-500 font-mono mt-0.5">{eq.sku}</p>
            {eq.serialNumber && <p className="text-xs text-gray-500">S/N: {eq.serialNumber}</p>}
            {eq.purchaseDate && (
              <p className="text-xs text-gray-400 mt-0.5">
                Purchased {formatDate(eq.purchaseDate)}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Warranty section */}
      {eq.warranties.length > 0 && (
        <div className="px-4 py-3 border-b border-gray-100">
          <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2 flex items-center gap-1.5">
            <Shield className="h-3.5 w-3.5" /> Warranty
          </p>
          <div className="space-y-1.5">
            {eq.warranties.map((w) => (
              <div key={w.id} className="flex items-center justify-between text-sm">
                <span className="text-gray-700">{w.warrantyType.replace(/_/g, ' ')}</span>
                <div className="flex items-center gap-2">
                  <StatusBadge status={w.status} />
                  {w.status === 'ACTIVE' && warrantyDaysLeft !== null && (
                    <span
                      className={`text-xs font-medium ${warrantyDaysLeft < 30 ? 'text-amber-600' : 'text-emerald-600'}`}
                    >
                      {warrantyDaysLeft}d left
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent service requests */}
      {eq.recentServiceRequests.length > 0 && (
        <div className="px-4 py-3">
          <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2 flex items-center gap-1.5">
            <Wrench className="h-3.5 w-3.5" /> Recent Service
          </p>
          <div className="space-y-1.5">
            {eq.recentServiceRequests.map((sr) => (
              <div key={sr.id} className="flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-mono text-[#1A4D2E] font-semibold">{sr.code}</p>
                  <p className="text-xs text-gray-500 truncate">{sr.faultDescription}</p>
                </div>
                <div className="flex-shrink-0 flex items-center gap-2">
                  <StatusBadge status={sr.status} />
                  <span className="text-xs text-gray-400">{formatDate(sr.reportedAt)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}

export default function EquipmentPage() {
  const { data = [], isLoading } = useQuery<Equipment[]>({
    queryKey: qk.equipment(),
    queryFn: () => portalApi.get<Equipment[]>('/equipment'),
  });

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 space-y-5 max-w-3xl mx-auto">
        <div>
          <h1 className="text-lg font-semibold text-[#1A1A1A]">My Equipment</h1>
          <p className="text-xs text-gray-500 mt-0.5">
            Equipment linked to your service history and warranties
          </p>
        </div>

        {isLoading && (
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <Skeleton key={i} className="h-40 w-full" />
            ))}
          </div>
        )}

        {!isLoading && data.length === 0 && (
          <EmptyState
            icon={<Package className="h-10 w-10" />}
            title="No equipment on record"
            description="Equipment linked to your service requests will appear here"
          />
        )}

        <div className="space-y-3">
          {data.map((eq) => (
            <EquipmentCard key={eq.id} eq={eq} />
          ))}
        </div>
      </div>
    </PortalShell>
  );
}
