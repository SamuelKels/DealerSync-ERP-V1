/**
 * AGCOMS Customer Portal — Root Layout (Sprint P4)
 */
import type { Metadata } from 'next';
import QueryProvider from '../components/QueryProvider';
import './globals.css';

export const metadata: Metadata = {
  title: 'AGCOMS Customer Portal',
  description: 'Access your quotations, invoices, and service history',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#F7F4EF] min-h-screen font-sans antialiased">
        <QueryProvider>{children}</QueryProvider>
      </body>
    </html>
  );
}
