'use client';
/**
 * AGCOMS Customer Portal — Login Page (Sprint P4)
 */
import { useState, FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, saveSession, type PortalCustomer } from '../../lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await portalApi.post<{
        accessToken: string;
        customer: PortalCustomer;
      }>('/auth/login', { email, password });
      saveSession(res.accessToken, res.customer);
      router.push('/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign in failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-[#F7F4EF] p-6">
      {/* Logo / brand */}
      <div className="mb-8 text-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="https://agcomsinternational.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FAgcoms%20Logo.fdf9aaf5.png&w=256&q=75"
          alt="AGCOMS"
          className="h-12 mx-auto mb-4 object-contain"
        />
        <p className="text-sm text-gray-500">Customer Portal</p>
      </div>

      {/* Card */}
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
        <h1 className="text-xl font-semibold text-[#1A1A1A] mb-1">Sign in</h1>
        <p className="text-sm text-gray-500 mb-6">
          Access your quotations, invoices and service history
        </p>

        {error && (
          <div className="mb-4 px-3 py-2 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Email address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="you@company.com"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm
                         focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm
                         focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/30 focus:border-[#1A4D2E]"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 disabled:opacity-60
                       text-white font-medium text-sm rounded-lg py-2.5 transition-colors"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <p className="text-xs text-center text-gray-400 mt-6">
          Need access? Contact your AGCOMS account manager.
        </p>
      </div>
    </main>
  );
}
