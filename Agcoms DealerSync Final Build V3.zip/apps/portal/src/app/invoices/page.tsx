'use client';
/**
 * AGCOMS Customer Portal — Invoices (Sprint P4)
 */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Receipt, Download, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import PortalShell from '../../components/PortalShell';
import { portalApi, qk } from '../../lib/api';
import {
  Card,
  StatusBadge,
  EmptyState,
  Skeleton,
  formatNGN,
  formatDate,
} from '../../components/ui';

interface Invoice {
  id: string;
  code: string;
  status: string;
  totalAmount: number;
  amountPaid: number;
  amountDue: number;
  issueDate: string;
  dueDate: string | null;
}

const STATUSES = ['', 'ISSUED', 'PARTIALLY_PAID', 'PAID', 'OVERDUE'];

export default function InvoicesPage() {
  const [status, setStatus] = useState('');

  const { data, isLoading } = useQuery<{ items: Invoice[]; total: number }>({
    queryKey: qk.invoices(status || undefined),
    queryFn: () =>
      portalApi.get<{ items: Invoice[]; total: number }>(
        `/invoices${status ? `?status=${status}` : ''}`,
      ),
  });

  const invoices = data?.items ?? [];

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 space-y-5 max-w-3xl mx-auto">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <h1 className="text-lg font-semibold text-[#1A1A1A]">My Invoices</h1>
          <div className="flex gap-1 bg-gray-100 rounded-lg p-0.5 text-xs flex-wrap">
            {STATUSES.map((s) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  status === s
                    ? 'bg-white shadow-sm text-[#1A4D2E]'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {s.replace('_', ' ') || 'All'}
              </button>
            ))}
          </div>
        </div>

        {isLoading && (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-24 w-full" />
            ))}
          </div>
        )}

        {!isLoading && invoices.length === 0 && (
          <EmptyState
            icon={<Receipt className="h-10 w-10" />}
            title="No invoices"
            description="Invoices from AGCOMS will appear here once issued"
          />
        )}

        <div className="space-y-2">
          {invoices.map((inv) => {
            const overdue =
              inv.status !== 'PAID' && inv.dueDate && new Date(inv.dueDate) < new Date();

            return (
              <Card
                key={inv.id}
                className={`hover:shadow-sm transition-shadow ${overdue ? 'border-red-200 bg-red-50/30' : ''}`}
              >
                <div className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-mono text-xs font-semibold text-[#1A4D2E]">{inv.code}</p>
                        <StatusBadge status={overdue ? 'OVERDUE' : inv.status} />
                      </div>
                      <p className="text-lg font-bold text-[#1A1A1A]">
                        {formatNGN(inv.totalAmount)}
                      </p>
                      <div className="flex gap-3 text-xs text-gray-500 mt-1">
                        <span>Issued {formatDate(inv.issueDate)}</span>
                        {inv.dueDate && <span>Due {formatDate(inv.dueDate)}</span>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <button
                        onClick={() => window.open(`/api/v1/portal/invoices/${inv.id}/pdf`)}
                        className="flex items-center gap-1 text-xs text-[#1A4D2E] font-medium hover:underline"
                      >
                        <Download className="h-3.5 w-3.5" />
                        PDF
                      </button>
                      <Link href={`/invoices/${inv.id}`}>
                        <ChevronRight className="h-4 w-4 text-gray-400" />
                      </Link>
                    </div>
                  </div>

                  {/* Payment progress bar */}
                  {inv.totalAmount > 0 && inv.status !== 'PAID' && (
                    <div className="mt-3">
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Paid {formatNGN(inv.amountPaid)}</span>
                        <span>Due {formatNGN(inv.amountDue)}</span>
                      </div>
                      <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#1A4D2E] rounded-full"
                          style={{
                            width: `${Math.min(100, (inv.amountPaid / inv.totalAmount) * 100)}%`,
                          }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </PortalShell>
  );
}
