'use client';
/**
 * AGCOMS Customer Portal — Quotations (Sprint P4)
 */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileText, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import PortalShell from '../../components/PortalShell';
import { portalApi, qk } from '../../lib/api';
import {
  Card,
  StatusBadge,
  EmptyState,
  Skeleton,
  formatNGN,
  formatDate,
} from '../../components/ui';

interface Quotation {
  id: string;
  code: string;
  subject: string;
  status: string;
  totalAmount: number;
  validUntil: string | null;
  createdAt: string;
}

const STATUSES = ['', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED'];

export default function QuotationsPage() {
  const [status, setStatus] = useState('');

  const { data, isLoading } = useQuery<{ items: Quotation[]; total: number }>({
    queryKey: qk.quotations(status || undefined),
    queryFn: () =>
      portalApi.get<{ items: Quotation[]; total: number }>(
        `/quotations${status ? `?status=${status}` : ''}`,
      ),
  });

  const quotes = data?.items ?? [];

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 space-y-5 max-w-3xl mx-auto">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-[#1A1A1A]">My Quotations</h1>
          {/* Status filter tabs */}
          <div className="flex gap-1 bg-gray-100 rounded-lg p-0.5 text-xs">
            {STATUSES.map((s) => (
              <button
                key={s}
                onClick={() => setStatus(s)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  status === s
                    ? 'bg-white shadow-sm text-[#1A4D2E]'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {s || 'All'}
              </button>
            ))}
          </div>
        </div>

        {isLoading && (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        )}

        {!isLoading && quotes.length === 0 && (
          <EmptyState
            icon={<FileText className="h-10 w-10" />}
            title="No quotations yet"
            description="Quotations from AGCOMS will appear here once issued"
          />
        )}

        <div className="space-y-2">
          {quotes.map((q) => (
            <Card key={q.id} className="hover:shadow-sm transition-shadow">
              <Link href={`/quotations/${q.id}`} className="flex items-center gap-3 p-4">
                <div className="p-2 rounded-lg bg-blue-50">
                  <FileText className="h-4 w-4 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="font-mono text-xs font-semibold text-[#1A4D2E]">{q.code}</p>
                    <StatusBadge status={q.status} />
                  </div>
                  <p className="text-sm font-medium text-[#1A1A1A] truncate">{q.subject}</p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {formatNGN(q.totalAmount)} · {formatDate(q.createdAt)}
                    {q.validUntil && ` · Valid until ${formatDate(q.validUntil)}`}
                  </p>
                </div>
                <ChevronRight className="h-4 w-4 text-gray-400 shrink-0" />
              </Link>
            </Card>
          ))}
        </div>
      </div>
    </PortalShell>
  );
}
