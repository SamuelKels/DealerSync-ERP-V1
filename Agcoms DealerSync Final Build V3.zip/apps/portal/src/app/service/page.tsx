'use client';
/**
 * AGCOMS Customer Portal — Service Requests (Sprint P4)
 */
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Wrench, Clock, CheckCircle2, ChevronRight, ChevronDown } from 'lucide-react';
import PortalShell from '../../components/PortalShell';
import { portalApi, qk } from '../../lib/api';
import { Card, StatusBadge, EmptyState, Skeleton, formatDate } from '../../components/ui';

interface ServiceRequest {
  id: string;
  code: string;
  status: string;
  faultDescription: string;
  reportedAt: string;
  resolvedAt: string | null;
  equipmentSerial: string | null;
  productName: string | null;
  jobCards: Array<{
    id: string;
    code: string;
    status: string;
    technicianName: string | null;
    notes: string | null;
    startedAt: string | null;
    completedAt: string | null;
  }>;
}

const STATUS_ICON: Record<string, React.FC<{ className?: string }>> = {
  OPEN: Clock as React.FC<{ className?: string }>,
  IN_PROGRESS: Wrench as React.FC<{ className?: string }>,
  COMPLETED: CheckCircle2 as React.FC<{ className?: string }>,
};

function ServiceRequestCard({ sr }: { sr: ServiceRequest }) {
  const [open, setOpen] = useState(false);
  const Icon = STATUS_ICON[sr.status] ?? Clock;

  return (
    <Card className="overflow-hidden">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full text-left p-4 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-start gap-3">
          <div
            className={`p-2 rounded-lg flex-shrink-0 ${
              sr.status === 'COMPLETED'
                ? 'bg-emerald-50'
                : sr.status === 'IN_PROGRESS'
                  ? 'bg-amber-50'
                  : 'bg-blue-50'
            }`}
          >
            <Icon
              className={`h-4 w-4 ${
                sr.status === 'COMPLETED'
                  ? 'text-emerald-600'
                  : sr.status === 'IN_PROGRESS'
                    ? 'text-amber-600'
                    : 'text-blue-600'
              }`}
            />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="font-mono text-xs font-semibold text-[#1A4D2E]">{sr.code}</p>
              <StatusBadge status={sr.status} />
            </div>
            <p className="text-sm text-[#1A1A1A] truncate">{sr.faultDescription}</p>
            <p className="text-xs text-gray-500 mt-0.5">
              {sr.productName ?? 'Equipment'} · Reported {formatDate(sr.reportedAt)}
              {sr.resolvedAt && ` · Resolved ${formatDate(sr.resolvedAt)}`}
            </p>
          </div>
          {open ? (
            <ChevronDown className="h-4 w-4 text-gray-400 shrink-0 mt-1" />
          ) : (
            <ChevronRight className="h-4 w-4 text-gray-400 shrink-0 mt-1" />
          )}
        </div>
      </button>

      {open && sr.jobCards.length > 0 && (
        <div className="border-t border-gray-100 px-4 py-3 bg-gray-50">
          <p className="text-xs font-semibold text-gray-600 mb-2 uppercase tracking-wide">
            Job Card Progress
          </p>
          <div className="space-y-2">
            {sr.jobCards.map((jc) => (
              <div key={jc.id} className="bg-white rounded-lg p-3 border border-gray-100">
                <div className="flex items-center justify-between mb-1">
                  <p className="font-mono text-xs font-semibold text-[#1A4D2E]">{jc.code}</p>
                  <StatusBadge status={jc.status} />
                </div>
                {jc.technicianName && (
                  <p className="text-xs text-gray-600">
                    Technician: <span className="font-medium">{jc.technicianName}</span>
                  </p>
                )}
                {jc.notes && (
                  <p className="text-xs text-gray-500 mt-1 italic">&quot;{jc.notes}&quot;</p>
                )}
                {(jc.startedAt || jc.completedAt) && (
                  <p className="text-xs text-gray-400 mt-1">
                    {jc.startedAt && `Started ${formatDate(jc.startedAt)}`}
                    {jc.startedAt && jc.completedAt && ' · '}
                    {jc.completedAt && `Completed ${formatDate(jc.completedAt)}`}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {open && sr.jobCards.length === 0 && (
        <div className="border-t border-gray-100 px-4 py-3 bg-gray-50">
          <p className="text-xs text-gray-500">No job cards assigned yet</p>
        </div>
      )}
    </Card>
  );
}

export default function ServicePage() {
  const { data, isLoading } = useQuery<{ items: ServiceRequest[] }>({
    queryKey: qk.serviceRequests(),
    queryFn: () => portalApi.get<{ items: ServiceRequest[] }>('/service-requests'),
  });

  const requests = data?.items ?? [];

  return (
    <PortalShell>
      <div className="p-4 sm:p-6 space-y-5 max-w-3xl mx-auto">
        <h1 className="text-lg font-semibold text-[#1A1A1A]">Service Requests</h1>

        {isLoading && (
          <div className="space-y-2">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        )}

        {!isLoading && requests.length === 0 && (
          <EmptyState
            icon={<Wrench className="h-10 w-10" />}
            title="No service requests"
            description="Your equipment service history will appear here"
          />
        )}

        <div className="space-y-3">
          {requests.map((sr) => (
            <ServiceRequestCard key={sr.id} sr={sr} />
          ))}
        </div>
      </div>
    </PortalShell>
  );
}
