'use client';
/**
 * AGCOMS Customer Portal — Authenticated Shell Layout (Sprint P4)
 * Bottom navigation for mobile-first UX. Auth redirect on no token.
 */
import type { ReactNode } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  FileText,
  Receipt,
  Wrench,
  ClipboardList,
  Package,
  LogOut,
} from 'lucide-react';
import { clearSession, getCustomer, isAuthenticated, type PortalCustomer } from '../lib/api';

const NAV = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/quotations', label: 'Quotes', icon: FileText },
  { href: '/invoices', label: 'Invoices', icon: Receipt },
  { href: '/service', label: 'Service', icon: Wrench },
  { href: '/rfq', label: 'RFQ', icon: ClipboardList },
];

export default function PortalShell({ children }: { children: ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [customer, setCustomer] = useState<PortalCustomer | null>(null);

  useEffect(() => {
    if (!isAuthenticated()) {
      router.replace('/login');
      return;
    }
    setCustomer(getCustomer());
  }, [router]);

  function handleLogout() {
    clearSession();
    router.push('/login');
  }

  if (!customer) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F7F4EF]">
        <div className="h-8 w-8 rounded-full border-4 border-[#1A4D2E] border-t-transparent animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F4EF]">
      {/* ── Top header ───────────────────────────────────────────── */}
      <header className="bg-[#1A4D2E] text-white px-4 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://agcomsinternational.com/_next/image?url=%2F_next%2Fstatic%2Fmedia%2FAgcoms%20Logo.fdf9aaf5.png&w=96&q=75"
            alt="AGCOMS"
            className="h-6 object-contain brightness-0 invert"
          />
          <span className="text-xs text-white/60 ml-1 hidden sm:inline">Customer Portal</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium leading-none">{customer.name}</p>
            {customer.companyName && (
              <p className="text-xs text-white/60 mt-0.5">{customer.companyName}</p>
            )}
          </div>
          <button
            onClick={handleLogout}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* ── Desktop sidebar (≥ md) ─────────────────────────────── */}
      <div className="flex flex-1 overflow-hidden">
        <aside className="hidden md:flex flex-col w-56 bg-white border-r border-gray-200 py-4">
          <nav className="flex-1 px-2 space-y-0.5">
            {NAV.map(({ href, label, icon: Icon }) => {
              const active = pathname === href || pathname?.startsWith(href + '/');
              return (
                <Link
                  key={href}
                  href={href}
                  className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                    active ? 'bg-[#1A4D2E] text-white' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="h-4 w-4 flex-shrink-0" />
                  {label}
                </Link>
              );
            })}
            <Link
              href="/equipment"
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${
                pathname?.startsWith('/equipment')
                  ? 'bg-[#1A4D2E] text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Package className="h-4 w-4 flex-shrink-0" />
              Equipment
            </Link>
          </nav>

          <div className="px-3 pt-3 border-t border-gray-200 mx-2">
            <p className="text-xs font-medium text-gray-800 truncate">{customer.name}</p>
            {customer.companyName && (
              <p className="text-xs text-gray-500 truncate">{customer.companyName}</p>
            )}
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 text-xs text-gray-500 hover:text-red-600 mt-2 transition-colors"
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign out
            </button>
          </div>
        </aside>

        {/* ── Main content ───────────────────────────────────────── */}
        <main className="flex-1 overflow-y-auto pb-20 md:pb-0">{children}</main>
      </div>

      {/* ── Mobile bottom nav (< md) ───────────────────────────── */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30
                      flex items-center justify-around px-2 py-1 safe-bottom"
      >
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname?.startsWith(href + '/');
          return (
            <Link
              key={href}
              href={href}
              className={`flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-lg text-[10px]
                          font-medium transition-colors min-w-[48px] ${
                            active ? 'text-[#1A4D2E]' : 'text-gray-500'
                          }`}
            >
              <Icon className={`h-5 w-5 ${active ? 'text-[#1A4D2E]' : 'text-gray-400'}`} />
              {label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
