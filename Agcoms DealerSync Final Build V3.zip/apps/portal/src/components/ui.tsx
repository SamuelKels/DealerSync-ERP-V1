/**
 * AGCOMS Customer Portal — Shared UI Components
 */
import type { ReactNode } from 'react';

// ── Card ──────────────────────────────────────────────────────────────────
export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`bg-white rounded-xl border border-gray-200 ${className}`}>{children}</div>
  );
}

// ── Badge ─────────────────────────────────────────────────────────────────
const BADGE_STYLES: Record<string, string> = {
  // Invoices
  DRAFT: 'bg-zinc-100 text-zinc-700',
  ISSUED: 'bg-blue-50 text-blue-700',
  PARTIALLY_PAID: 'bg-amber-50 text-amber-700',
  PAID: 'bg-emerald-50 text-emerald-800',
  OVERDUE: 'bg-red-50 text-red-700',
  VOID: 'bg-zinc-200 text-zinc-500',
  // Service
  OPEN: 'bg-blue-50 text-blue-700',
  IN_PROGRESS: 'bg-amber-50 text-amber-700',
  COMPLETED: 'bg-emerald-50 text-emerald-800',
  CANCELLED: 'bg-zinc-100 text-zinc-600',
  // Quotations
  SENT: 'bg-blue-50 text-blue-700',
  ACCEPTED: 'bg-emerald-50 text-emerald-800',
  REJECTED: 'bg-red-50 text-red-700',
  EXPIRED: 'bg-zinc-100 text-zinc-500',
  // RFQ
  SUBMITTED: 'bg-blue-50 text-blue-700',
  UNDER_REVIEW: 'bg-amber-50 text-amber-700',
  QUOTED: 'bg-purple-50 text-purple-700',
  // Warranty
  ACTIVE: 'bg-emerald-50 text-emerald-800',
  EXPIRED_W: 'bg-zinc-100 text-zinc-500',
};

export function StatusBadge({ status }: { status: string }) {
  const cls = BADGE_STYLES[status] ?? 'bg-zinc-100 text-zinc-600';
  const label = status.replace(/_/g, ' ');
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${cls}`}
    >
      {label}
    </span>
  );
}

// ── Loading skeleton ──────────────────────────────────────────────────────
export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse bg-gray-200 rounded ${className}`} />;
}

// ── Empty state ───────────────────────────────────────────────────────────
export function EmptyState({
  icon,
  title,
  description,
}: {
  icon: ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center px-4">
      <div className="text-gray-300 mb-3">{icon}</div>
      <p className="font-medium text-gray-700 mb-1">{title}</p>
      <p className="text-sm text-gray-500 max-w-sm">{description}</p>
    </div>
  );
}

// ── Format helpers ────────────────────────────────────────────────────────
export function formatNGN(amount: number | string): string {
  const n = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    minimumFractionDigits: 2,
  }).format(n);
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}
