'use client';
// app/(auth)/mfa/page.tsx
import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { ShieldCheck, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';
import { useAuthStore } from '../../../stores/auth.store';

export default function MfaPage() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const { verifyMfa, step, error, clearError, isLoading, challengeToken } = useAuthStore();
  const [code, setCode] = useState('');

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (step === 'authenticated') router.push('/dashboard');
    if (step === 'credentials' && !challengeToken) router.push('/login');
  }, [step, challengeToken, router]);

  useEffect(() => {
    if (error) {
      toast.error(error);
      clearError();
    }
  }, [error, clearError]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length === 6) verifyMfa(code);
  };

  return (
    <div className="animate-fade-up text-center">
      <div
        className="mx-auto mb-4 w-14 h-14 rounded-full flex items-center justify-center border"
        style={{ background: 'rgba(26,77,46,.12)', borderColor: 'rgba(26,77,46,.2)' }}
      >
        <ShieldCheck className="h-6 w-6" style={{ color: '#1A4D2E' }} />
      </div>
      <h2 className="font-heading text-[22px] text-[#1A1A1A]">Two-factor verification</h2>
      <p className="mt-2 text-[13px] text-[#6B7280]">
        Enter the 6-digit code from your authenticator app
      </p>

      <form onSubmit={handleSubmit} className="mt-6 space-y-4">
        <input
          ref={inputRef}
          type="text"
          inputMode="numeric"
          maxLength={6}
          value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
          placeholder="000000"
          className="w-full h-16 text-center font-mono text-3xl tracking-[12px] rounded-lg border border-[#D1D5DB] bg-white text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#1A4D2E] transition-colors"
        />
        <button
          type="submit"
          disabled={isLoading || code.length !== 6}
          className="w-full h-10 rounded-md text-sm font-medium text-white flex items-center justify-center gap-2 disabled:opacity-60 transition-all"
          style={{ background: '#1A4D2E' }}
        >
          {isLoading ? (
            <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
          ) : (
            'Verify'
          )}
        </button>
        <button
          type="button"
          onClick={() => router.push('/login')}
          className="flex items-center gap-1.5 mx-auto text-[12px] text-[#6B7280] hover:text-[#1A1A1A]"
        >
          <ArrowLeft className="h-3 w-3" /> Back to login
        </button>
      </form>
      <p
        className="mt-4 p-2.5 rounded-md text-[11px] text-[#6B7280]"
        style={{ background: '#F7F4EF' }}
      >
        Demo: enter any 6 digits, e.g. <strong className="font-mono">123456</strong>
      </p>
    </div>
  );
}
