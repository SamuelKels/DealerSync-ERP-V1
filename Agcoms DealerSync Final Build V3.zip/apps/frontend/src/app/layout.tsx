/**
 * AGCOMS DealerSync ERP — Root Layout
 * §1 Brand: DM Serif Display, Playfair Display, Outfit, JetBrains Mono
 *
 * V2 NOTE: next/font/google requires network access to fonts.googleapis.com at build time.
 * In sandboxed CI environments without network, set USE_LOCAL_FONTS=1 to use system fallbacks.
 * In production (with network), this falls back to live Google Fonts loading.
 */
import type { Metadata, Viewport } from 'next';
import { Toaster } from 'sonner';
import './globals.css';

// CSS variable shape — matches what next/font/google returns
type FontShape = { variable: string; className: string; style: { fontFamily: string } };

const useLocal = process.env['USE_LOCAL_FONTS'] === '1' || process.env['NODE_ENV'] !== 'production';

let dmSerif: FontShape, playfair: FontShape, outfit: FontShape, jetbrains: FontShape;

if (useLocal) {
  // System-font fallback for offline / sandboxed builds
  dmSerif = { variable: 'font-heading', className: '', style: { fontFamily: 'Georgia, serif' } };
  playfair = { variable: 'font-display', className: '', style: { fontFamily: 'Georgia, serif' } };
  outfit = {
    variable: 'font-ui',
    className: '',
    style: { fontFamily: 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  };
  jetbrains = {
    variable: 'font-mono',
    className: '',
    style: { fontFamily: 'ui-monospace, "SF Mono", Menlo, monospace' },
  };
} else {
  // Production path — fetches from Google Fonts at build time
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  /* eslint-disable @typescript-eslint/no-var-requires */
  const {
    DM_Serif_Display,
    Playfair_Display,
    Outfit,
    JetBrains_Mono,
    // eslint-disable-next-line @typescript-eslint/no-var-requires
  } = require('next/font/google');
  /* eslint-enable @typescript-eslint/no-var-requires */
  dmSerif = DM_Serif_Display({
    subsets: ['latin'],
    weight: ['400'],
    variable: '--font-heading',
    display: 'swap',
  });
  playfair = Playfair_Display({
    subsets: ['latin'],
    weight: ['400', '500', '700'],
    variable: '--font-display',
    display: 'swap',
  });
  outfit = Outfit({
    subsets: ['latin'],
    weight: ['300', '400', '500', '600'],
    variable: '--font-ui',
    display: 'swap',
  });
  jetbrains = JetBrains_Mono({
    subsets: ['latin'],
    weight: ['400', '500'],
    variable: '--font-mono',
    display: 'swap',
  });
}

export const metadata: Metadata = {
  title: 'AGCOMS DealerSync ERP',
  description: 'AGCOMS International Trading Limited — Enterprise Resource Planning system',
  manifest: '/manifest.json',
};

export const viewport: Viewport = {
  themeColor: '#1A4D2E',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${dmSerif.variable} ${playfair.variable} ${outfit.variable} ${jetbrains.variable}`}
    >
      <body className="antialiased bg-[#F7F4EF] text-[#1A1A1A]">
        {children}
        <Toaster position="top-right" richColors closeButton />
      </body>
    </html>
  );
}
