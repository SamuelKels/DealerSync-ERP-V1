'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { BarChart3, Download, RefreshCw } from 'lucide-react';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN } from '../../../../lib/utils';
// Tremor — §3 Tech Stack: Charts: Tremor
import {
  Card,
  Metric,
  Text,
  AreaChart,
  BarChart,
  DonutChart,
  Legend,
  BadgeDelta,
  Flex,
  Title,
  Grid,
  ProgressBar,
  Bold,
} from '@tremor/react';

interface KpiData {
  revenue: { current: number; previous: number; trend: 'up' | 'down' | 'flat' };
  invoices: { outstanding: number; overdue: number; paid30d: number };
  sales: { quotationsCount: number; conversionRate: number; avgDealSize: number };
  inventory: { lowStockAlerts: number; warehouseUtilisation: number; totalSkus: number };
  contracts: { active: number; deliveryPct: number; tractorsDelivered: number };
  hr: { headcount: number; onLeave: number; openPositions: number };
  revenueByMonth: Array<{ month: string; revenue: number; target: number }>;
  revenueByBranch: Array<{ branch: string; value: number }>;
  invoiceAgeing: Array<{ bucket: string; amount: number }>;
}

export default function KpiDashboardPage() {
  const [period, setPeriod] = useState<'thisMonth' | 'lastMonth' | 'ytd' | 'lastYear'>('thisMonth');
  const { user } = useAuthStore();
  const branchParam = user?.branchId && !user.isSuperAdmin ? `&branchId=${user.branchId}` : '';

  const { data, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['kpis', period],
    queryFn: () => api.get<KpiData>(`/reports/kpis?period=${period}${branchParam}`),
    staleTime: 120_000,
  });

  const periodLabels = {
    thisMonth: 'This month',
    lastMonth: 'Last month',
    ytd: 'Year to date',
    lastYear: 'Last year',
  };

  const deltaType = (trend?: 'up' | 'down' | 'flat') =>
    trend === 'up' ? 'moderateIncrease' : trend === 'down' ? 'moderateDecrease' : 'unchanged';

  const pct = (current: number, previous: number) => {
    if (!previous) return 0;
    return Math.round(((current - previous) / previous) * 100);
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">KPI Dashboard</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            Business intelligence — key performance indicators
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Period selector */}
          <div className="flex items-center gap-1 bg-[#F7F4EF] rounded-lg p-1">
            {(Object.entries(periodLabels) as [typeof period, string][]).map(([k, v]) => (
              <button
                key={k}
                onClick={() => setPeriod(k)}
                className="px-3 py-1.5 rounded-md text-[12px] font-medium transition-all"
                style={
                  period === k
                    ? {
                        background: '#fff',
                        color: '#1A4D2E',
                        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
                      }
                    : { color: '#6B7280' }
                }
              >
                {v}
              </button>
            ))}
          </div>
          <button
            onClick={() => refetch()}
            disabled={isFetching}
            className="flex items-center gap-1.5 px-3 py-2 rounded-md text-[12px] border border-[#E5E7EB] hover:bg-[#F7F4EF] disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isFetching ? 'animate-spin' : ''}`} />
          </button>
          <button className="flex items-center gap-1.5 px-3 py-2 rounded-md text-[12px] border border-[#E5E7EB] hover:bg-[#F7F4EF]">
            <Download className="h-3.5 w-3.5" /> Export
          </button>
        </div>
      </div>

      {/* Top KPI cards using Tremor */}
      <Grid numItemsMd={2} numItemsLg={4} className="gap-4">
        {/* Revenue */}
        <Card className="border border-[#E5E7EB]">
          <Text>Revenue ({periodLabels[period]})</Text>
          {isLoading ? (
            <div className="h-8 bg-[#F3F4F6] rounded animate-pulse mt-2 w-40" />
          ) : (
            <Flex alignItems="end" className="space-x-2">
              <Metric>{data ? formatNGN(data.revenue.current) : '—'}</Metric>
              {data && (
                <BadgeDelta deltaType={deltaType(data.revenue.trend)} size="xs">
                  {pct(data.revenue.current, data.revenue.previous)}%
                </BadgeDelta>
              )}
            </Flex>
          )}
          {data && (
            <Text className="mt-1 text-[11px]">
              vs {formatNGN(data.revenue.previous)} prior period
            </Text>
          )}
        </Card>

        {/* Outstanding invoices */}
        <Card className="border border-[#E5E7EB]">
          <Text>Outstanding invoices</Text>
          {isLoading ? (
            <div className="h-8 bg-[#F3F4F6] rounded animate-pulse mt-2 w-32" />
          ) : (
            <Metric>{data ? formatNGN(data.invoices.outstanding) : '—'}</Metric>
          )}
          {data && (
            <Flex className="mt-2 space-x-2">
              <Text className="text-[11px]">
                Overdue: <Bold>{formatNGN(data.invoices.overdue)}</Bold>
              </Text>
              <Text className="text-[11px]">
                Collected 30d: <Bold>{formatNGN(data.invoices.paid30d)}</Bold>
              </Text>
            </Flex>
          )}
        </Card>

        {/* Sales pipeline */}
        <Card className="border border-[#E5E7EB]">
          <Text>Sales conversion rate</Text>
          {isLoading ? (
            <div className="h-8 bg-[#F3F4F6] rounded animate-pulse mt-2 w-24" />
          ) : (
            <Metric>{data ? `${data.sales.conversionRate}%` : '—'}</Metric>
          )}
          {data && <ProgressBar value={data.sales.conversionRate} className="mt-2" color="green" />}
          {data && (
            <Text className="mt-1 text-[11px]">
              {data.sales.quotationsCount} quotations · avg {formatNGN(data.sales.avgDealSize)}
            </Text>
          )}
        </Card>

        {/* NADF / Gov contracts */}
        <Card className="border border-[#E5E7EB]">
          <Text>NADF delivery progress</Text>
          {isLoading ? (
            <div className="h-8 bg-[#F3F4F6] rounded animate-pulse mt-2 w-20" />
          ) : (
            <Metric>{data ? `${data.contracts.deliveryPct}%` : '—'}</Metric>
          )}
          {data && <ProgressBar value={data.contracts.deliveryPct} className="mt-2" color="teal" />}
          {data && (
            <Text className="mt-1 text-[11px]">
              {data.contracts.tractorsDelivered} tractors delivered · {data.contracts.active} active
              contracts
            </Text>
          )}
        </Card>
      </Grid>

      {/* Secondary KPI row */}
      <Grid numItemsMd={3} className="gap-4">
        <Card className="border border-[#E5E7EB]">
          <Text>Inventory health</Text>
          {isLoading ? (
            <div className="h-6 bg-[#F3F4F6] rounded animate-pulse mt-2 w-28" />
          ) : (
            <Metric>{data?.inventory.totalSkus ?? '—'} SKUs</Metric>
          )}
          {data && (
            <Flex className="mt-2 space-x-4">
              <Text className="text-[11px]">
                Warehouse: <Bold>{data.inventory.warehouseUtilisation}%</Bold>
              </Text>
              {data.inventory.lowStockAlerts > 0 && (
                <Text className="text-[11px]" style={{ color: '#DC2626' }}>
                  ⚠ {data.inventory.lowStockAlerts} low stock alerts
                </Text>
              )}
            </Flex>
          )}
          {data && (
            <ProgressBar
              value={data.inventory.warehouseUtilisation}
              className="mt-2"
              color={data.inventory.warehouseUtilisation > 85 ? 'red' : 'amber'}
            />
          )}
        </Card>

        <Card className="border border-[#E5E7EB]">
          <Text>HR overview</Text>
          {isLoading ? (
            <div className="h-6 bg-[#F3F4F6] rounded animate-pulse mt-2 w-24" />
          ) : (
            <Metric>{data?.hr.headcount ?? '—'} staff</Metric>
          )}
          {data && (
            <Flex className="mt-2 space-x-4">
              <Text className="text-[11px]">
                On leave: <Bold>{data.hr.onLeave}</Bold>
              </Text>
              <Text className="text-[11px]">
                Open positions: <Bold>{data.hr.openPositions}</Bold>
              </Text>
            </Flex>
          )}
        </Card>

        {/* Invoice ageing donut */}
        <Card className="border border-[#E5E7EB]">
          <Title className="text-[13px]">AR ageing</Title>
          {isLoading ? (
            <div className="h-24 bg-[#F3F4F6] rounded animate-pulse mt-2" />
          ) : data?.invoiceAgeing ? (
            <>
              <DonutChart
                data={data.invoiceAgeing}
                category="amount"
                index="bucket"
                colors={['green', 'yellow', 'orange', 'red', 'rose']}
                className="h-28 mt-2"
                valueFormatter={(v) => `₦${(v / 1_000_000).toFixed(1)}M`}
              />
              <Legend
                categories={data.invoiceAgeing.map((d) => d.bucket)}
                colors={['green', 'yellow', 'orange', 'red', 'rose']}
                className="mt-2 text-[10px]"
              />
            </>
          ) : null}
        </Card>
      </Grid>

      {/* Revenue trend chart */}
      <Card className="border border-[#E5E7EB]">
        <Title className="text-[13px] mb-1">Revenue vs target — monthly trend</Title>
        {isLoading ? (
          <div className="h-48 bg-[#F3F4F6] rounded animate-pulse" />
        ) : data?.revenueByMonth ? (
          <AreaChart
            data={data.revenueByMonth}
            index="month"
            categories={['revenue', 'target']}
            colors={['green', 'gray']}
            className="h-48 mt-2"
            valueFormatter={(v) => `₦${(v / 1_000_000).toFixed(1)}M`}
            showAnimation
          />
        ) : null}
      </Card>

      {/* Revenue by branch */}
      <Card className="border border-[#E5E7EB]">
        <Title className="text-[13px] mb-1">Revenue by branch</Title>
        {isLoading ? (
          <div className="h-40 bg-[#F3F4F6] rounded animate-pulse" />
        ) : data?.revenueByBranch ? (
          <BarChart
            data={data.revenueByBranch}
            index="branch"
            categories={['value']}
            colors={['green']}
            className="h-40 mt-2"
            valueFormatter={(v) => `₦${(v / 1_000_000).toFixed(1)}M`}
            showAnimation
          />
        ) : null}
      </Card>

      {/* Report links */}
      <div className="bg-white rounded-lg border border-[#E5E7EB] p-4">
        <h2 className="text-[13px] font-semibold text-[#1A1A1A] mb-3">Detailed reports</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'AR Aging Report', href: '/reports/ar-aging', icon: '📋' },
            { label: 'Trial Balance', href: '/finance/trial-balance', icon: '⚖️' },
            { label: 'Payroll Summary', href: '/hr/payroll', icon: '💰' },
            { label: 'NADF Compliance', href: '/contracts', icon: '📑' },
          ].map((r) => (
            <a
              key={r.href}
              href={r.href}
              className="flex items-center gap-2.5 p-3 rounded-lg border border-[#E5E7EB] hover:border-[#1A4D2E]/40 hover:bg-[#F7F4EF] transition-all group"
            >
              <span className="text-[18px]">{r.icon}</span>
              <span className="text-[12px] font-medium text-[#1A1A1A] group-hover:text-[#1A4D2E]">
                {r.label}
              </span>
              <BarChart3 className="h-3.5 w-3.5 ml-auto text-[#D1D5DB] group-hover:text-[#1A4D2E]" />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
