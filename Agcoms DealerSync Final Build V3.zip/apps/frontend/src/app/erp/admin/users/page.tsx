'use client';
// app/(erp)/admin/users/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, UserPlus, ChevronRight, ShieldCheck, ShieldOff } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import {
  formatDate,
  formatRelative,
  getStatusStyle,
  buildSearchParams,
} from '../../../../lib/utils';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  isActive: boolean;
  mfaEnabled: boolean;
  isSuperAdmin: boolean;
  roles: { name: string }[];
  branch: { name: string };
  lastLoginAt?: string;
  createdAt: string;
}
interface PagedUsers {
  items: User[];
  total: number;
  hasMore: boolean;
}

export default function AdminUsersPage() {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const params = buildSearchParams({ q, limit: 25, page });

  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'users', { q, page }],
    queryFn: () => api.get<PagedUsers>(`/users?${params}`),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">User Management</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total} users` : 'Loading…'} · Invite-only
            onboarding
          </p>
        </div>
        <Link
          href="/admin/users/invite"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <UserPlus className="h-4 w-4" /> Invite User
        </Link>
      </div>

      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setPage(1);
          }}
          placeholder="Search by name or email…"
          className="pl-8 pr-3 h-8 w-[260px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        />
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['User', 'Roles', 'Branch', 'MFA', 'Status', 'Last Login', 'Joined', ''].map((h) => (
                <th
                  key={h}
                  className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 8 }).map((_, j) => (
                      <td key={j} className="px-3 py-3">
                        <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              : (data?.items ?? []).map((u) => {
                  const ss = getStatusStyle(u.isActive ? 'ACTIVE' : 'INACTIVE');
                  return (
                    <tr
                      key={u.id}
                      className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                    >
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2.5">
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-semibold text-white flex-shrink-0"
                            style={{ background: '#1A4D2E' }}
                          >
                            {u.firstName[0]}
                            {u.lastName[0]}
                          </div>
                          <div>
                            <div className="text-[13px] font-medium text-[#1A1A1A]">
                              {u.fullName}
                            </div>
                            <div className="text-[10px] text-[#9CA3AF] font-mono">{u.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex flex-wrap gap-1">
                          {u.isSuperAdmin && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-[#FEF3C7] text-[#B45309]">
                              SUPER ADMIN
                            </span>
                          )}
                          {u.roles.slice(0, 2).map((r) => (
                            <span
                              key={r.name}
                              className="text-[9px] px-1.5 py-0.5 rounded font-semibold bg-[#EDF4EF] text-[#1A4D2E]"
                            >
                              {r.name}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{u.branch.name}</td>
                      <td className="px-3 py-2.5">
                        {u.mfaEnabled ? (
                          <ShieldCheck className="h-4 w-4 text-[#16A34A]" />
                        ) : (
                          <ShieldOff className="h-4 w-4 text-[#9CA3AF]" />
                        )}
                      </td>
                      <td className="px-3 py-2.5">
                        <span
                          className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                          style={{ background: ss.bg, color: ss.color }}
                        >
                          {u.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-[11px] text-[#9CA3AF]">
                        {u.lastLoginAt ? formatRelative(u.lastLoginAt) : '—'}
                      </td>
                      <td className="px-3 py-2.5 text-[11px] text-[#9CA3AF]">
                        {formatDate(u.createdAt)}
                      </td>
                      <td className="px-3 py-2.5">
                        <Link
                          href={`/admin/users/${u.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total} users</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
