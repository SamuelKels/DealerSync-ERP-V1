'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Landmark, Plus, ChevronRight, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../lib/api';
import { useAuthStore } from '../../../stores/auth.store';
import { formatDate, formatNGN } from '../../../lib/utils';

interface Contract {
  id: string;
  contractNo: string;
  title: string;
  contractorName: string;
  status: string;
  contractValue: number;
  currency: string;
  milestoneCount: number;
  completedMilestones: number;
  nadfTracking?: { tractorsAllocated: number; tractorsDelivered: number; beneficiaryCount: number };
  startDate?: string;
  endDate?: string;
  createdAt: string;
}

interface Tender {
  id: string;
  tenderNo: string;
  title: string;
  status: string;
  estimatedValue: number;
  closingDate?: string;
  createdAt: string;
}

interface Analytics {
  activeContracts: number;
  totalContractValue: number;
  tractorsAllocated: number;
  tractorsDelivered: number;
  pendingTenders: number;
  wonTenders: number;
  winRate: number;
}

export default function ContractsPage() {
  const [tab, setTab] = useState<'contracts' | 'tenders'>('contracts');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();
  const branchParam = user?.branchId && !user.isSuperAdmin ? `&branchId=${user.branchId}` : '';

  const contractParams = new URLSearchParams({
    ...(status ? { status } : {}),
    limit: '20',
    page: String(page),
    ...(user?.branchId && !user.isSuperAdmin ? { branchId: user.branchId } : {}),
  });

  const { data: contracts, isLoading: loadingContracts } = useQuery({
    queryKey: ['gov-contracts', { status, page }],
    queryFn: () =>
      api.get<{ items: Contract[]; total: number; hasMore: boolean }>(
        `/contracts?${contractParams}`,
      ),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
    enabled: tab === 'contracts',
  });

  const { data: tenders, isLoading: loadingTenders } = useQuery({
    queryKey: ['tenders', { page }],
    queryFn: () =>
      api.get<{ items: Tender[]; total: number; hasMore: boolean }>(
        `/contracts/tenders?limit=20&page=${page}${branchParam}`,
      ),
    staleTime: 30_000,
    enabled: tab === 'tenders',
  });

  const { data: analytics } = useQuery({
    queryKey: ['contracts-analytics'],
    queryFn: () =>
      api.get<Analytics>(`/contracts/analytics${branchParam ? `?${branchParam.slice(1)}` : ''}`),
    staleTime: 60_000,
  });

  const CONTRACT_STATUSES = ['ACTIVE', 'SUSPENDED', 'COMPLETED', 'TERMINATED', 'PENDING_SIGNATURE'];
  const TENDER_STATUSES = [
    'DRAFT',
    'SUBMITTED',
    'EVALUATING',
    'AWARDED',
    'CONTRACT_CREATED',
    'REJECTED',
  ];

  const contractStatusStyle: Record<string, { bg: string; color: string }> = {
    ACTIVE: { bg: '#DCFCE7', color: '#15803D' },
    SUSPENDED: { bg: '#FEF3C7', color: '#92400E' },
    COMPLETED: { bg: '#E6F1FB', color: '#0C447C' },
    TERMINATED: { bg: '#FEE2E2', color: '#B91C1C' },
    PENDING_SIGNATURE: { bg: '#EEEDFE', color: '#3C3489' },
  };

  const tenderStatusStyle: Record<string, { bg: string; color: string }> = {
    DRAFT: { bg: '#F3F4F6', color: '#6B7280' },
    SUBMITTED: { bg: '#E6F1FB', color: '#0C447C' },
    EVALUATING: { bg: '#FAEEDA', color: '#633806' },
    AWARDED: { bg: '#DCFCE7', color: '#15803D' },
    CONTRACT_CREATED: { bg: '#EAF3DE', color: '#27500A' },
    REJECTED: { bg: '#FEE2E2', color: '#B91C1C' },
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Government Contracts</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            NADF programme, tenders &amp; contract management
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/contracts/tenders/new"
            className="flex items-center gap-1.5 px-3 py-2 rounded-md text-[13px] font-medium border border-[#E5E7EB] hover:bg-[#F7F4EF]"
          >
            <Plus className="h-3.5 w-3.5" /> New Tender
          </Link>
          <Link
            href="/contracts/new"
            className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
            style={{ background: '#1A4D2E' }}
          >
            <Plus className="h-4 w-4" /> New Contract
          </Link>
        </div>
      </div>

      {/* Analytics strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { label: 'Active contracts', value: analytics?.activeContracts ?? '—', color: '#16A34A' },
          {
            label: 'Contract value',
            value: analytics?.totalContractValue ? formatNGN(analytics.totalContractValue) : '—',
            color: '#1A4D2E',
          },
          {
            label: 'Tractors allocated',
            value: analytics?.tractorsAllocated ?? '—',
            color: '#1A4D2E',
          },
          {
            label: 'Tractors delivered',
            value: analytics?.tractorsDelivered ?? '—',
            color: '#16A34A',
          },
          {
            label: 'Delivery rate',
            value:
              analytics && analytics.tractorsAllocated > 0
                ? `${Math.round((analytics.tractorsDelivered / analytics.tractorsAllocated) * 100)}%`
                : '—',
            color: '#D97706',
          },
          { label: 'Open tenders', value: analytics?.pendingTenders ?? '—', color: '#0369A1' },
          {
            label: 'Win rate',
            value: analytics?.winRate !== undefined ? `${analytics.winRate}%` : '—',
            color: '#7C3AED',
          },
        ].map((kpi) => (
          <div
            key={kpi.label}
            className="bg-white rounded-lg border border-[#E5E7EB] p-3 text-center"
          >
            <div className="text-[20px] font-semibold font-mono" style={{ color: kpi.color }}>
              {kpi.value}
            </div>
            <div className="text-[10px] text-[#6B7280] mt-0.5 leading-tight">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Tab switcher */}
      <div className="flex items-center gap-1 bg-[#F7F4EF] rounded-lg p-1 w-fit">
        {(['contracts', 'tenders'] as const).map((t) => (
          <button
            key={t}
            onClick={() => {
              setTab(t);
              setStatus('');
              setPage(1);
            }}
            className="px-5 py-1.5 rounded-md text-[13px] font-medium transition-all capitalize"
            style={
              tab === t
                ? { background: '#fff', color: '#1A4D2E', boxShadow: '0 1px 3px rgba(0,0,0,0.08)' }
                : { color: '#6B7280' }
            }
          >
            {t}
          </button>
        ))}
      </div>

      {/* Status filters */}
      <div className="flex items-center gap-2 flex-wrap">
        {(tab === 'contracts' ? CONTRACT_STATUSES : TENDER_STATUSES).map((s) => {
          const sc = (tab === 'contracts' ? contractStatusStyle : tenderStatusStyle)[s] ?? {
            bg: '#F3F4F6',
            color: '#6B7280',
          };
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(status === s ? '' : s);
                setPage(1);
              }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={
                status === s
                  ? { background: sc.bg, color: sc.color, borderColor: 'transparent' }
                  : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
              }
            >
              {s.replace(/_/g, ' ')}
            </button>
          );
        })}
      </div>

      {/* Contracts table */}
      {tab === 'contracts' && (
        <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-[#E5E7EB]">
                {[
                  'Contract #',
                  'Title',
                  'Contractor',
                  'Value',
                  'Status',
                  'Milestones',
                  'NADF Progress',
                  'End Date',
                  '',
                ].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loadingContracts ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 9 }).map((_, j) => (
                      <td key={j} className="px-3 py-3">
                        <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : (contracts?.items ?? []).length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-16 text-center">
                    <Landmark className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                    <p className="text-[13px] text-[#9CA3AF]">No government contracts found</p>
                  </td>
                </tr>
              ) : (
                (contracts?.items ?? []).map((c) => {
                  const sc = contractStatusStyle[c.status] ?? { bg: '#F3F4F6', color: '#6B7280' };
                  const milestonePct =
                    c.milestoneCount > 0
                      ? Math.round((c.completedMilestones / c.milestoneCount) * 100)
                      : 0;
                  const nadf = c.nadfTracking;
                  const nadfPct =
                    nadf && nadf.tractorsAllocated > 0
                      ? Math.round((nadf.tractorsDelivered / nadf.tractorsAllocated) * 100)
                      : null;
                  return (
                    <tr
                      key={c.id}
                      className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                    >
                      <td className="px-3 py-2.5">
                        <Link
                          href={`/contracts/${c.id}`}
                          className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline"
                        >
                          {c.contractNo}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#1A1A1A] max-w-[180px] truncate">
                        {c.title}
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{c.contractorName}</td>
                      <td className="px-3 py-2.5 font-mono text-[12px] font-semibold text-right">
                        {formatNGN(c.contractValue)}
                      </td>
                      <td className="px-3 py-2.5">
                        <span
                          className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                          style={{ background: sc.bg, color: sc.color }}
                        >
                          {c.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-20 bg-[#E5E7EB] rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${milestonePct}%`,
                                background: milestonePct === 100 ? '#16A34A' : '#1A4D2E',
                              }}
                            />
                          </div>
                          <span className="text-[11px] text-[#6B7280] whitespace-nowrap">
                            {c.completedMilestones}/{c.milestoneCount}
                          </span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5">
                        {nadf ? (
                          <div className="flex items-center gap-1.5">
                            {nadfPct !== null && nadfPct >= 100 ? (
                              <CheckCircle2 className="h-3.5 w-3.5 text-[#16A34A]" />
                            ) : (
                              <Clock className="h-3.5 w-3.5 text-[#D97706]" />
                            )}
                            <span className="text-[11px] text-[#6B7280]">
                              {nadf.tractorsDelivered}/{nadf.tractorsAllocated} tractors
                            </span>
                          </div>
                        ) : (
                          <span className="text-[11px] text-[#D1D5DB]">—</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-[11px] text-[#6B7280] whitespace-nowrap">
                        {c.endDate ? formatDate(c.endDate) : '—'}
                      </td>
                      <td className="px-3 py-2.5">
                        <Link
                          href={`/contracts/${c.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
          <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
            <span className="text-[11px] text-[#6B7280]">
              {contracts?.total?.toLocaleString()} contracts
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
              >
                ← Prev
              </button>
              <span className="text-[11px] text-[#6B7280] w-10 text-center">Page {page}</span>
              <button
                onClick={() => setPage((p) => p + 1)}
                disabled={!contracts?.hasMore}
                className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
              >
                Next →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tenders table */}
      {tab === 'tenders' && (
        <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-[#E5E7EB]">
                {['Tender #', 'Title', 'Est. Value', 'Status', 'Closing Date', ''].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280]"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loadingTenders ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-3 py-3">
                        <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : (tenders?.items ?? []).length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-14 text-center">
                    <p className="text-[13px] text-[#9CA3AF]">No tenders found</p>
                  </td>
                </tr>
              ) : (
                (tenders?.items ?? []).map((t) => {
                  const sc = tenderStatusStyle[t.status] ?? { bg: '#F3F4F6', color: '#6B7280' };
                  const closing = t.closingDate ? new Date(t.closingDate) : null;
                  const isClosingSoon =
                    closing &&
                    closing < new Date(Date.now() + 7 * 86400_000) &&
                    t.status === 'OPEN';
                  return (
                    <tr
                      key={t.id}
                      className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                    >
                      <td className="px-3 py-2.5">
                        <Link
                          href={`/contracts/tenders/${t.id}`}
                          className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline"
                        >
                          {t.tenderNo}
                        </Link>
                      </td>
                      <td className="px-3 py-2.5 text-[12px] text-[#1A1A1A] max-w-[260px] truncate">
                        {t.title}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-[12px] font-semibold text-right">
                        {formatNGN(t.estimatedValue)}
                      </td>
                      <td className="px-3 py-2.5">
                        <span
                          className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                          style={{ background: sc.bg, color: sc.color }}
                        >
                          {t.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td
                        className="px-3 py-2.5 text-[11px] whitespace-nowrap"
                        style={{ color: isClosingSoon ? '#DC2626' : '#6B7280' }}
                      >
                        {closing ? (
                          <span className="flex items-center gap-1">
                            {isClosingSoon && <AlertCircle className="h-3 w-3" />}
                            {formatDate(t.closingDate!)}
                          </span>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="px-3 py-2.5">
                        <Link
                          href={`/contracts/tenders/${t.id}`}
                          className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                        >
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
          <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
            <span className="text-[11px] text-[#6B7280]">
              {tenders?.total?.toLocaleString()} tenders
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
              >
                ← Prev
              </button>
              <span className="text-[11px] text-[#6B7280] w-10 text-center">Page {page}</span>
              <button
                onClick={() => setPage((p) => p + 1)}
                disabled={!tenders?.hasMore}
                className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
              >
                Next →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
