'use client';
/**
 * AGCOMS DealerSync ERP — WHT Certificates (Sprint P3)
 *
 * Withholding Tax deduction certificates.
 * Rates per Finance Act: Contract 5%, Consultancy 10%, Rent 10%, Technical 10%.
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, FileText, RefreshCw, Building2 } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

import { Button } from '../../../../components/ui/button';
import { api, queryKeys } from '../../../../lib/api';
import { formatNGN, formatDate } from '../../../../lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────
interface WhtCertificate {
  id: string;
  certificateNo: string;
  recipientName: string;
  recipientTin: string | null;
  transactionType: 'CONTRACT' | 'CONSULTANCY' | 'RENT' | 'TECHNICAL';
  grossAmount: number;
  whtRate: number;
  whtAmount: number;
  netAmount: number;
  referenceType: string;
  referenceId: string;
  periodYear: number;
  periodMonth: number;
  issuedAt: string;
}

const WHT_RATES: Record<string, number> = {
  CONTRACT: 5,
  CONSULTANCY: 10,
  RENT: 10,
  TECHNICAL: 10,
};

const TYPE_LABELS: Record<string, string> = {
  CONTRACT: 'Contract',
  CONSULTANCY: 'Consultancy',
  RENT: 'Rent',
  TECHNICAL: 'Technical Services',
};

const MONTH_NAMES = [
  '',
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

// ── Issue WHT modal ────────────────────────────────────────────────────────
function IssueWhtModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const now = new Date();

  const [form, setForm] = useState({
    recipientName: '',
    recipientTin: '',
    transactionType: 'CONTRACT' as const,
    grossAmount: '',
    referenceType: 'Invoice',
    referenceId: '',
    year: now.getFullYear(),
    month: now.getMonth() + 1,
  });

  const set = (k: string, v: string | number) => setForm((f) => ({ ...f, [k]: v }));

  const rate = WHT_RATES[form.transactionType] ?? 5;
  const gross = parseFloat(form.grossAmount) || 0;
  const whtAmt = (gross * rate) / 100;
  const netAmt = gross - whtAmt;

  const issue = useMutation({
    mutationFn: () =>
      api.post('/firs/wht-certificates', {
        ...form,
        grossAmount: gross,
      }),
    onSuccess: () => {
      toast.success(`WHT certificate issued for ${form.recipientName}`);
      void qc.invalidateQueries({ queryKey: queryKeys.firs.whtCertificates() });
      onClose();
    },
    onError: () => toast.error('Failed to issue certificate'),
  });

  const valid = form.recipientName.trim() && gross > 0 && form.referenceId.trim();

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
        <h2 className="font-['DM_Serif_Display',serif] text-xl text-[#1A1A1A] mb-1">
          Issue WHT Certificate
        </h2>
        <p className="text-sm text-[#6B7280] mb-5">
          Generate a Withholding Tax deduction certificate for a vendor or contractor.
        </p>

        <div className="space-y-4">
          {/* Recipient */}
          <div>
            <label className="block text-xs font-medium text-[#6B7280] mb-1">
              Recipient Name *
            </label>
            <input
              type="text"
              value={form.recipientName}
              onChange={(e) => set('recipientName', e.target.value)}
              placeholder="Dangote Farms Ltd"
              className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#6B7280] mb-1">
              Recipient TIN <span className="text-[#9CA3AF]">(optional)</span>
            </label>
            <input
              type="text"
              value={form.recipientTin}
              onChange={(e) => set('recipientTin', e.target.value)}
              placeholder="12345678-0001"
              className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
            />
          </div>

          {/* Transaction type */}
          <div>
            <label className="block text-xs font-medium text-[#6B7280] mb-1">
              Transaction Type *
            </label>
            <select
              value={form.transactionType}
              onChange={(e) => set('transactionType', e.target.value)}
              className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40 bg-white"
            >
              {Object.entries(TYPE_LABELS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v} ({WHT_RATES[k]}% WHT)
                </option>
              ))}
            </select>
          </div>

          {/* Amount */}
          <div>
            <label className="block text-xs font-medium text-[#6B7280] mb-1">
              Gross Amount (NGN) *
            </label>
            <input
              type="number"
              value={form.grossAmount}
              onChange={(e) => set('grossAmount', e.target.value)}
              placeholder="1000000"
              min={0}
              className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
            />
          </div>

          {/* WHT summary */}
          {gross > 0 && (
            <div className="bg-[#F7F4EF] rounded-lg p-3 text-sm space-y-1.5">
              <div className="flex justify-between text-[#6B7280]">
                <span>Gross Amount</span>
                <span className="font-medium text-[#1A1A1A]">{formatNGN(gross)}</span>
              </div>
              <div className="flex justify-between text-[#6B7280]">
                <span>WHT @ {rate}%</span>
                <span className="font-medium text-amber-700">−{formatNGN(whtAmt)}</span>
              </div>
              <div className="flex justify-between border-t border-[#E5E7EB] pt-1.5 mt-1">
                <span className="font-semibold text-[#1A1A1A]">Net Payable</span>
                <span className="font-bold text-[#1A4D2E]">{formatNGN(netAmt)}</span>
              </div>
            </div>
          )}

          {/* Reference */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#6B7280] mb-1">
                Reference Type *
              </label>
              <input
                type="text"
                value={form.referenceType}
                onChange={(e) => set('referenceType', e.target.value)}
                placeholder="Invoice"
                className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6B7280] mb-1">
                Reference ID *
              </label>
              <input
                type="text"
                value={form.referenceId}
                onChange={(e) => set('referenceId', e.target.value)}
                placeholder="INV-2025-0042"
                className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
              />
            </div>
          </div>

          {/* Period */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#6B7280] mb-1">Period Year</label>
              <input
                type="number"
                value={form.year}
                onChange={(e) => set('year', parseInt(e.target.value, 10))}
                min={2020}
                max={2100}
                className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#6B7280] mb-1">Period Month</label>
              <select
                value={form.month}
                onChange={(e) => set('month', parseInt(e.target.value, 10))}
                className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40 bg-white"
              >
                {MONTH_NAMES.slice(1).map((name, i) => (
                  <option key={i + 1} value={i + 1}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={() => issue.mutate()}
            disabled={!valid || issue.isPending}
            className="flex-1 bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 text-white"
          >
            {issue.isPending ? 'Issuing…' : 'Issue Certificate'}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────
export default function WhtCertificatesPage() {
  const [yearFilter, setYearFilter] = useState(new Date().getFullYear());
  const [showModal, setShowModal] = useState(false);
  const qc = useQueryClient();

  const { data: certs = [], isLoading } = useQuery<WhtCertificate[]>({
    queryKey: queryKeys.firs.whtCertificates(yearFilter),
    queryFn: () => api.get(`/firs/wht-certificates?year=${yearFilter}`),
  });

  return (
    <div className="p-6 space-y-6">
      {showModal && <IssueWhtModal onClose={() => setShowModal(false)} />}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-[#1A1A1A]">WHT Certificates</h2>
          <p className="text-xs text-[#6B7280] mt-0.5">
            Withholding Tax deduction certificates · Contract 5% · Consultancy/Rent/Technical 10%
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={yearFilter}
            onChange={(e) => setYearFilter(parseInt(e.target.value, 10))}
            className="border border-[#E5E7EB] rounded-lg px-3 py-1.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40"
          >
            {[0, 1, 2].map((offset) => {
              const y = new Date().getFullYear() - offset;
              return (
                <option key={y} value={y}>
                  {y}
                </option>
              );
            })}
          </select>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              void qc.invalidateQueries({ queryKey: queryKeys.firs.whtCertificates(yearFilter) })
            }
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </Button>
          <Button
            size="sm"
            onClick={() => setShowModal(true)}
            className="gap-1.5 bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 text-white"
          >
            <Plus className="h-3.5 w-3.5" />
            Issue Certificate
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#F7F4EF] border-b border-[#E5E7EB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Certificate
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Recipient
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Type
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Gross
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                WHT
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Net
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Period
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Issued
              </th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center text-sm text-[#6B7280]">
                  Loading certificates…
                </td>
              </tr>
            )}
            {!isLoading && certs.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center">
                  <div className="flex flex-col items-center gap-2">
                    <Building2 className="h-8 w-8 text-[#E5E7EB]" />
                    <p className="text-sm text-[#6B7280]">No WHT certificates for {yearFilter}</p>
                    <p className="text-xs text-[#9CA3AF]">
                      Issue certificates when withholding tax from vendor payments
                    </p>
                  </div>
                </td>
              </tr>
            )}
            {certs.map((cert) => (
              <tr
                key={cert.id}
                className="border-b border-[#E5E7EB] hover:bg-[#F7F4EF]/50 transition-colors"
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <FileText className="h-3.5 w-3.5 text-[#6B7280]" />
                    <span className="font-mono text-xs font-semibold text-[#1A4D2E]">
                      {cert.certificateNo}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <p className="font-medium text-[#1A1A1A]">{cert.recipientName}</p>
                  {cert.recipientTin && (
                    <p className="text-xs text-[#6B7280]">TIN: {cert.recipientTin}</p>
                  )}
                </td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-zinc-100 text-zinc-700">
                    {TYPE_LABELS[cert.transactionType]}
                  </span>
                </td>
                <td className="px-4 py-3 text-right text-sm">{formatNGN(cert.grossAmount)}</td>
                <td className="px-4 py-3 text-right text-sm text-amber-700 font-medium">
                  {formatNGN(cert.whtAmount)} ({cert.whtRate}%)
                </td>
                <td className="px-4 py-3 text-right text-sm font-semibold text-[#1A4D2E]">
                  {formatNGN(cert.netAmount)}
                </td>
                <td className="px-4 py-3 text-sm text-[#6B7280]">
                  {(MONTH_NAMES[cert.periodMonth] ?? 'Unk').slice(0, 3)} {cert.periodYear}
                </td>
                <td className="px-4 py-3 text-sm text-[#6B7280]">{formatDate(cert.issuedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
