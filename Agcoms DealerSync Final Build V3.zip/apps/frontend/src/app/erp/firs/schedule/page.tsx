'use client';
/**
 * AGCOMS DealerSync ERP — FIRS Filing Schedule (Sprint P3)
 *
 * 6-month rolling schedule showing VAT due dates (21st of following month).
 * Alerts for overdue and upcoming filings.
 */
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, AlertTriangle, Clock, Calendar, RefreshCw, ArrowRight } from 'lucide-react';
import Link from 'next/link';

import { Button } from '../../../../components/ui/button';
import { api, queryKeys } from '../../../../lib/api';
import { cn } from '../../../../lib/cn';

// ── Types ─────────────────────────────────────────────────────────────────
interface ScheduleEntry {
  year: number;
  month: number;
  dueDate: string;
  status: string;
  daysUntilDue: number;
}

interface ScheduleResponse {
  schedule: ScheduleEntry[];
  overdue: ScheduleEntry[];
  duesSoon: ScheduleEntry[];
  alertCount: number;
}

const MONTH_NAMES = [
  '',
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

// ── Status helpers ────────────────────────────────────────────────────────
function getStatusDisplay(entry: ScheduleEntry) {
  const { status, daysUntilDue } = entry;

  if (status === 'SUBMITTED' || status === 'ACCEPTED') {
    return {
      label: status === 'ACCEPTED' ? 'Filed & Accepted' : 'Submitted',
      className: 'bg-emerald-50 text-emerald-800 ring-1 ring-emerald-200',
      Icon: CheckCircle2 as React.FC<{ className?: string }>,
      rowClass: '',
    };
  }
  if (daysUntilDue < 0) {
    return {
      label: 'Overdue',
      className: 'bg-red-50 text-red-700 ring-1 ring-red-200',
      Icon: AlertTriangle as React.FC<{ className?: string }>,
      rowClass: 'bg-red-50/30',
    };
  }
  if (daysUntilDue <= 7) {
    return {
      label: `Due in ${daysUntilDue}d`,
      className: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
      Icon: AlertTriangle as React.FC<{ className?: string }>,
      rowClass: 'bg-amber-50/20',
    };
  }
  if (status === 'COMPUTED') {
    return {
      label: 'Computed',
      className: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
      Icon: Clock as React.FC<{ className?: string }>,
      rowClass: '',
    };
  }
  return {
    label: 'Pending',
    className: 'bg-zinc-100 text-zinc-600',
    Icon: Clock as React.FC<{ className?: string }>,
    rowClass: '',
  };
}

// ── Main page ─────────────────────────────────────────────────────────────
export default function FilingSchedulePage() {
  const qc = useQueryClient();
  const currentYear = new Date().getFullYear();

  const { data, isLoading } = useQuery<ScheduleResponse>({
    queryKey: queryKeys.firs.schedule(currentYear),
    queryFn: () => api.get('/firs/schedule'),
    staleTime: 60_000,
  });

  const schedule = data?.schedule ?? [];
  const overdue = data?.overdue ?? [];
  const duesSoon = data?.duesSoon ?? [];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-[#1A1A1A]">Filing Schedule</h2>
          <p className="text-xs text-[#6B7280] mt-0.5">
            VAT returns due by 21st of the following month · 6-month rolling view
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() =>
            void qc.invalidateQueries({ queryKey: queryKeys.firs.schedule(currentYear) })
          }
          className="gap-1.5"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Refresh
        </Button>
      </div>

      {/* Alert banners */}
      {overdue.length > 0 && (
        <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-xl">
          <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-red-800">
              {overdue.length} overdue filing{overdue.length > 1 ? 's' : ''}
            </p>
            <p className="text-xs text-red-700 mt-0.5">
              {overdue
                .map((e) => `${(MONTH_NAMES[e.month] ?? 'Unk').slice(0, 3)} ${e.year}`)
                .join(', ')}{' '}
              — submit immediately to avoid FIRS penalties
            </p>
          </div>
          <Link href="/erp/firs/vat-returns">
            <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white gap-1.5 shrink-0">
              Go to VAT Returns <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>
      )}

      {duesSoon.length > 0 && overdue.length === 0 && (
        <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl">
          <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-800">
              {duesSoon.length} filing{duesSoon.length > 1 ? 's' : ''} due within 7 days
            </p>
            <p className="text-xs text-amber-700 mt-0.5">
              {duesSoon
                .map(
                  (e) =>
                    `${(MONTH_NAMES[e.month] ?? 'Unk').slice(0, 3)} ${e.year} (${e.daysUntilDue}d)`,
                )
                .join(', ')}
            </p>
          </div>
          <Link href="/erp/firs/vat-returns">
            <Button
              size="sm"
              variant="outline"
              className="gap-1.5 shrink-0 border-amber-300 text-amber-800"
            >
              Compute VAT <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </Link>
        </div>
      )}

      {/* Schedule table */}
      <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#F7F4EF] border-b border-[#E5E7EB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Tax Period
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Due Date
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Days Remaining
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Status
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={5} className="px-4 py-12 text-center text-sm text-[#6B7280]">
                  Loading schedule…
                </td>
              </tr>
            )}
            {!isLoading && schedule.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-12 text-center">
                  <div className="flex flex-col items-center gap-2">
                    <Calendar className="h-8 w-8 text-[#E5E7EB]" />
                    <p className="text-sm text-[#6B7280]">No schedule data available</p>
                  </div>
                </td>
              </tr>
            )}
            {schedule.map((entry) => {
              const sd = getStatusDisplay(entry);
              const StatusIcon = sd.Icon;
              const dueDate = new Date(entry.dueDate);
              const isToday = dueDate.toDateString() === new Date().toDateString();

              return (
                <tr
                  key={`${entry.year}-${entry.month}`}
                  className={cn(
                    'border-b border-[#E5E7EB] transition-colors',
                    sd.rowClass || 'hover:bg-[#F7F4EF]/40',
                  )}
                >
                  <td className="px-4 py-3">
                    <p className="font-medium text-[#1A1A1A]">
                      {MONTH_NAMES[entry.month] ?? 'Unknown'} {entry.year}
                    </p>
                    <p className="text-xs text-[#6B7280]">
                      01–{new Date(entry.year, entry.month, 0).getDate()}{' '}
                      {(MONTH_NAMES[entry.month] ?? 'Unknown').slice(0, 3)}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <p className={cn('font-medium', isToday && 'text-amber-600')}>
                      {dueDate.toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </p>
                    {isToday && <p className="text-xs text-amber-600 font-medium">Due today!</p>}
                  </td>
                  <td className="px-4 py-3">
                    {entry.daysUntilDue < 0 ? (
                      <span className="text-red-600 font-medium">
                        {Math.abs(entry.daysUntilDue)} days overdue
                      </span>
                    ) : entry.daysUntilDue === 0 ? (
                      <span className="text-amber-600 font-semibold">Due today</span>
                    ) : (
                      <span
                        className={cn(
                          'font-medium',
                          entry.daysUntilDue <= 7 ? 'text-amber-700' : 'text-[#6B7280]',
                        )}
                      >
                        {entry.daysUntilDue} days
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={cn(
                        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium',
                        sd.className,
                      )}
                    >
                      <StatusIcon className="h-3 w-3" />
                      {sd.label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    {!['SUBMITTED', 'ACCEPTED'].includes(entry.status) && (
                      <Link href="/erp/firs/vat-returns">
                        <Button size="sm" variant="outline" className="text-xs gap-1 h-7">
                          {entry.status === 'COMPUTED' ? 'Submit' : 'Compute'}
                          <ArrowRight className="h-3 w-3" />
                        </Button>
                      </Link>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Compliance note */}
      <div className="flex items-start gap-3 p-4 bg-white border border-[#E5E7EB] rounded-xl text-xs text-[#6B7280]">
        <Calendar className="h-4 w-4 text-[#1A4D2E] shrink-0 mt-0.5" />
        <p>
          <span className="font-semibold text-[#1A1A1A]">FIRS Compliance:</span> VAT returns must be
          filed by the 21st of the month following the taxable period via the TaxPro-Max portal. WHT
          remittance is due by the 21st of the month after deduction. Late filing attracts a penalty
          of 10% of tax due + interest at the CBN Monetary Policy Rate.
        </p>
      </div>
    </div>
  );
}
