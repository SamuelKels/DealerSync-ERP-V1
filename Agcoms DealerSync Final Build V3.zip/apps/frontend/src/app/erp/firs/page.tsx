'use client';
/**
 * AGCOMS DealerSync ERP — FIRS / Tax Filing Module (Sprint P3)
 *
 * Nigerian FIRS compliance hub:
 *  - VAT Returns (TaxPro-Max format, 7.5% standard rate)
 *  - WHT Certificates (deduction certificates for vendors/contractors)
 *  - 6-month rolling filing schedule with due-date alerts
 *
 * All figures in Naira (NGN). Due date: 21st of the month following the taxable period.
 */
import { useQuery } from '@tanstack/react-query';
import { AlertTriangle, FileText, Receipt, CalendarClock } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

import { api, queryKeys } from '../../../lib/api';
import { cn } from '../../../lib/cn';

const TABS = [
  {
    href: '/erp/firs/vat-returns',
    label: 'VAT Returns',
    icon: Receipt,
    description: 'Monthly output/input VAT computation and FIRS submission',
  },
  {
    href: '/erp/firs/wht-certificates',
    label: 'WHT Certificates',
    icon: FileText,
    description: 'Withholding Tax deduction certificates for vendors',
  },
  {
    href: '/erp/firs/schedule',
    label: 'Filing Schedule',
    icon: CalendarClock,
    description: '6-month rolling due-date calendar with overdue alerts',
  },
];

export default function FirsPage() {
  const pathname = usePathname();
  const currentYear = new Date().getFullYear();

  // Fetch schedule to drive the alert badge on the layout
  const { data: scheduleData } = useQuery({
    queryKey: queryKeys.firs.schedule(currentYear),
    queryFn: () => api.get<{ alertCount: number }>('/firs/schedule'),
    staleTime: 60_000,
  });

  const alertCount = scheduleData?.alertCount ?? 0;

  return (
    <div className="min-h-screen bg-[#F7F4EF]">
      {/* ── Page header ─────────────────────────────────────────── */}
      <header className="bg-white border-b border-[#E5E7EB] px-6 py-5">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#6B7280]">
                Nigerian Tax Compliance
              </span>
            </div>
            <h1 className="font-['DM_Serif_Display',serif] text-2xl text-[#1A1A1A]">
              FIRS Tax Filing
            </h1>
            <p className="text-sm text-[#6B7280] mt-0.5">
              VAT (7.5%) · WHT · TaxPro-Max submissions · FIRS compliance
            </p>
          </div>
          {alertCount > 0 && (
            <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-amber-50 border border-amber-200">
              <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
              <span className="text-sm font-medium text-amber-800">
                {alertCount} filing deadline{alertCount > 1 ? 's' : ''} require attention
              </span>
            </div>
          )}
        </div>

        {/* ── Tab navigation ───────────────────────────────────── */}
        <nav className="flex gap-1 mt-5 -mb-px">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const active = pathname === tab.href || pathname?.startsWith(tab.href + '/');
            return (
              <Link
                key={tab.href}
                href={tab.href}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors',
                  active
                    ? 'border-[#1A4D2E] text-[#1A4D2E]'
                    : 'border-transparent text-[#6B7280] hover:text-[#1A1A1A] hover:border-[#E5E7EB]',
                )}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
              </Link>
            );
          })}
        </nav>
      </header>

      {/* ── Landing state (no tab selected) ─────────────────────── */}
      <main className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            return (
              <Link
                key={tab.href}
                href={tab.href}
                className="group block p-5 bg-white rounded-xl border border-[#E5E7EB]
                           hover:border-[#1A4D2E] hover:shadow-sm transition-all"
              >
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-[#1A4D2E]/8 group-hover:bg-[#1A4D2E]/12 transition-colors">
                    <Icon className="h-5 w-5 text-[#1A4D2E]" />
                  </div>
                  <span className="font-semibold text-[#1A1A1A]">{tab.label}</span>
                </div>
                <p className="text-xs text-[#6B7280] leading-relaxed">{tab.description}</p>
              </Link>
            );
          })}
        </div>
      </main>
    </div>
  );
}
