'use client';
/**
 * AGCOMS DealerSync ERP — FIRS VAT Returns (Sprint P3)
 *
 * Monthly VAT computation and submission to FIRS TaxPro-Max portal.
 * Nigerian standard VAT rate: 7.5% (Finance Act 2019).
 * Due date: 21st of the month following the taxable period.
 *
 * Workflow: Compute → Review → Download Excel → Submit (enter FIRS receipt no.)
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Calculator,
  Download,
  Send,
  CheckCircle2,
  Clock,
  XCircle,
  RefreshCw,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

import { Button } from '../../../../components/ui/button';
import { api, queryKeys } from '../../../../lib/api';
import { formatNGN, formatDate } from '../../../../lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────
interface VatReturn {
  id: string;
  branchId: string;
  code: string;
  periodYear: number;
  periodMonth: number;
  outputVatAmount: number;
  inputVatAmount: number;
  netVatPayable: number;
  status: 'DRAFT' | 'COMPUTED' | 'SUBMITTED' | 'ACCEPTED' | 'REJECTED';
  firsReceiptNo: string | null;
  submittedAt: string | null;
  totalSales: number;
  taxableSales: number;
  exemptSales: number;
  taxablePurchases: number;
}

const MONTH_NAMES = [
  '',
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const STATUS_CONFIG: Record<
  string,
  { label: string; className: string; Icon: React.FC<{ className?: string }> }
> = {
  DRAFT: {
    label: 'Draft',
    className: 'bg-zinc-100 text-zinc-700',
    Icon: Clock as React.FC<{ className?: string }>,
  },
  COMPUTED: {
    label: 'Computed',
    className: 'bg-blue-50 text-blue-700',
    Icon: Calculator as React.FC<{ className?: string }>,
  },
  SUBMITTED: {
    label: 'Submitted',
    className: 'bg-amber-50 text-amber-700',
    Icon: Send as React.FC<{ className?: string }>,
  },
  ACCEPTED: {
    label: 'Accepted',
    className: 'bg-emerald-50 text-emerald-800',
    Icon: CheckCircle2 as React.FC<{ className?: string }>,
  },
  REJECTED: {
    label: 'Rejected',
    className: 'bg-red-50 text-red-700',
    Icon: XCircle as React.FC<{ className?: string }>,
  },
};

// ── Submit modal ──────────────────────────────────────────────────────────
function SubmitModal({ vatReturn, onClose }: { vatReturn: VatReturn; onClose: () => void }) {
  const qc = useQueryClient();
  const [receiptNo, setReceiptNo] = useState('');

  const submit = useMutation({
    mutationFn: (firsReceiptNo: string) =>
      api.post(`/firs/vat-returns/${vatReturn.id}/submit`, { firsReceiptNo }),
    onSuccess: () => {
      toast.success(`VAT return ${vatReturn.code} submitted to FIRS`);
      void qc.invalidateQueries({ queryKey: queryKeys.firs.vatReturns() });
      onClose();
    },
    onError: () => toast.error('Submission failed — please try again'),
  });

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
        <h2 className="font-['DM_Serif_Display',serif] text-xl text-[#1A1A1A] mb-1">
          Submit to FIRS TaxPro-Max
        </h2>
        <p className="text-sm text-[#6B7280] mb-5">
          Enter the receipt number from the FIRS TaxPro-Max portal after submitting{' '}
          <strong>{vatReturn.code}</strong>.
        </p>

        <div className="bg-[#F7F4EF] rounded-lg p-4 mb-5 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-[#6B7280]">Period</span>
            <span className="font-medium">
              {MONTH_NAMES[vatReturn.periodMonth]} {vatReturn.periodYear}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#6B7280]">Output VAT</span>
            <span className="font-medium">{formatNGN(vatReturn.outputVatAmount)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#6B7280]">Input VAT</span>
            <span className="font-medium text-emerald-700">
              −{formatNGN(vatReturn.inputVatAmount)}
            </span>
          </div>
          <div className="flex justify-between border-t border-[#E5E7EB] pt-2 mt-2">
            <span className="font-semibold">Net VAT Payable</span>
            <span className="font-bold text-[#1A4D2E]">{formatNGN(vatReturn.netVatPayable)}</span>
          </div>
        </div>

        <label className="block mb-1 text-sm font-medium text-[#1A1A1A]">FIRS Receipt Number</label>
        <input
          type="text"
          value={receiptNo}
          onChange={(e) => setReceiptNo(e.target.value)}
          placeholder="e.g. FIRS-2025-VAT-000123"
          className="w-full border border-[#E5E7EB] rounded-lg px-3 py-2 text-sm
                     focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]/40 mb-5"
        />

        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={() => submit.mutate(receiptNo)}
            disabled={!receiptNo.trim() || submit.isPending}
            className="flex-1 bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 text-white"
          >
            {submit.isPending ? 'Submitting…' : 'Confirm Submission'}
          </Button>
        </div>
      </div>
    </div>
  );
}

// ── Row detail accordion ──────────────────────────────────────────────────
function VatReturnRow({ vr }: { vr: VatReturn }) {
  const [open, setOpen] = useState(false);
  const [submitOpen, setSubmitOpen] = useState(false);
  const qc = useQueryClient();

  const computeMutation = useMutation({
    mutationFn: () =>
      api.post('/firs/vat-returns/compute', { year: vr.periodYear, month: vr.periodMonth }),
    onSuccess: () => {
      toast.success('VAT return recomputed from posted journals');
      void qc.invalidateQueries({ queryKey: queryKeys.firs.vatReturns() });
    },
    onError: () => toast.error('Compute failed — check posted journal entries'),
  });

  const cfg = (STATUS_CONFIG[vr.status] ?? STATUS_CONFIG.DRAFT)!;
  const StatusIcon = cfg.Icon;

  return (
    <>
      <tr
        className="border-b border-[#E5E7EB] hover:bg-[#F7F4EF]/60 cursor-pointer transition-colors"
        onClick={() => setOpen((o) => !o)}
      >
        <td className="px-4 py-3 font-mono text-sm font-semibold text-[#1A4D2E]">{vr.code}</td>
        <td className="px-4 py-3 text-sm">
          {MONTH_NAMES[vr.periodMonth]} {vr.periodYear}
        </td>
        <td className="px-4 py-3 text-right text-sm font-medium">
          {formatNGN(vr.outputVatAmount)}
        </td>
        <td className="px-4 py-3 text-right text-sm font-medium text-emerald-700">
          {formatNGN(vr.inputVatAmount)}
        </td>
        <td className="px-4 py-3 text-right text-sm font-bold">{formatNGN(vr.netVatPayable)}</td>
        <td className="px-4 py-3">
          <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${cfg.className}`}
          >
            <StatusIcon className="h-3 w-3" />
            {cfg.label}
          </span>
        </td>
        <td className="px-4 py-3 text-right">
          {open ? (
            <ChevronUp className="h-4 w-4 text-[#6B7280] ml-auto" />
          ) : (
            <ChevronDown className="h-4 w-4 text-[#6B7280] ml-auto" />
          )}
        </td>
      </tr>

      {open && (
        <tr className="bg-[#F7F4EF]">
          <td colSpan={7} className="px-4 py-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
              <div>
                <p className="text-[#6B7280] text-xs mb-0.5">Total Sales</p>
                <p className="font-medium">{formatNGN(vr.totalSales)}</p>
              </div>
              <div>
                <p className="text-[#6B7280] text-xs mb-0.5">Taxable Sales</p>
                <p className="font-medium">{formatNGN(vr.taxableSales)}</p>
              </div>
              <div>
                <p className="text-[#6B7280] text-xs mb-0.5">Exempt Sales</p>
                <p className="font-medium">{formatNGN(vr.exemptSales)}</p>
              </div>
              <div>
                <p className="text-[#6B7280] text-xs mb-0.5">Taxable Purchases</p>
                <p className="font-medium">{formatNGN(vr.taxablePurchases)}</p>
              </div>
            </div>

            {vr.firsReceiptNo && (
              <p className="text-xs text-[#6B7280] mb-4">
                FIRS Receipt: <span className="font-mono font-semibold">{vr.firsReceiptNo}</span>
                {vr.submittedAt && ` · Submitted ${formatDate(vr.submittedAt)}`}
              </p>
            )}

            <div className="flex gap-2 flex-wrap">
              {(['DRAFT', 'COMPUTED'] as const).includes(vr.status as 'DRAFT' | 'COMPUTED') && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e.stopPropagation();
                    computeMutation.mutate();
                  }}
                  disabled={computeMutation.isPending}
                  className="gap-1.5"
                >
                  <Calculator className="h-3.5 w-3.5" />
                  {computeMutation.isPending ? 'Computing…' : 'Recompute'}
                </Button>
              )}
              {vr.status === 'COMPUTED' && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      window.open(`/api/v1/firs/vat-returns/${vr.id}/excel`);
                    }}
                    className="gap-1.5"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Download Excel
                  </Button>
                  <Button
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSubmitOpen(true);
                    }}
                    className="gap-1.5 bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 text-white"
                  >
                    <Send className="h-3.5 w-3.5" />
                    Submit to FIRS
                  </Button>
                </>
              )}
            </div>
          </td>
        </tr>
      )}

      {submitOpen && <SubmitModal vatReturn={vr} onClose={() => setSubmitOpen(false)} />}
    </>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────
export default function VatReturnsPage() {
  const qc = useQueryClient();
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const {
    data: returns = [],
    isLoading,
    error,
  } = useQuery<VatReturn[]>({
    queryKey: queryKeys.firs.vatReturns(),
    queryFn: () => api.get('/firs/vat-returns'),
  });

  const computeNew = useMutation({
    mutationFn: () =>
      api.post('/firs/vat-returns/compute', {
        year: currentYear,
        month: currentMonth,
      }),
    onSuccess: () => {
      toast.success(`VAT return computed for ${MONTH_NAMES[currentMonth]} ${currentYear}`);
      void qc.invalidateQueries({ queryKey: queryKeys.firs.vatReturns() });
    },
    onError: () => toast.error('Compute failed — ensure journals are posted for this period'),
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-semibold text-[#1A1A1A]">VAT Returns</h2>
          <p className="text-xs text-[#6B7280] mt-0.5">
            7.5% standard rate · Due 21st of following month
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => void qc.invalidateQueries({ queryKey: queryKeys.firs.vatReturns() })}
            className="gap-1.5"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Refresh
          </Button>
          <Button
            size="sm"
            onClick={() => computeNew.mutate()}
            disabled={computeNew.isPending}
            className="gap-1.5 bg-[#1A4D2E] hover:bg-[#1A4D2E]/90 text-white"
          >
            <Calculator className="h-3.5 w-3.5" />
            {computeNew.isPending ? 'Computing…' : `Compute ${MONTH_NAMES[currentMonth]} VAT`}
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-[#F7F4EF] border-b border-[#E5E7EB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Code
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Period
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Output VAT
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Input VAT
              </th>
              <th className="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Net Payable
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-[#6B7280]">
                Status
              </th>
              <th className="px-4 py-3 w-8" />
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-sm text-[#6B7280]">
                  Loading VAT returns…
                </td>
              </tr>
            )}
            {error && (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center text-sm text-red-600">
                  Failed to load VAT returns
                </td>
              </tr>
            )}
            {!isLoading && !error && returns.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center">
                  <p className="text-sm text-[#6B7280] mb-3">No VAT returns yet</p>
                  <p className="text-xs text-[#6B7280]">
                    Click &quot;Compute VAT&quot; to generate the current month&apos;s return from
                    posted journals
                  </p>
                </td>
              </tr>
            )}
            {returns.map((vr) => (
              <VatReturnRow key={vr.id} vr={vr} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
