'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileSearch, Plus, ChevronRight, Clock } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatDate, formatNGN } from '../../../../lib/utils';

interface Rfq {
  id: string;
  rfqNo: string;
  status: string;
  customer: { name: string; id: string };
  subject: string;
  dueDate?: string;
  estimatedValue?: number;
  lineCount?: number;
  assignedTo?: { firstName: string; lastName: string };
  createdAt: string;
}

export default function RfqPage() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = new URLSearchParams({
    ...(status ? { status } : {}),
    ...(user?.branchId && !user.isSuperAdmin ? { branchId: user.branchId } : {}),
    limit: '25',
    page: String(page),
  });

  const { data, isLoading } = useQuery({
    queryKey: ['rfqs', { status, page }],
    queryFn: () =>
      api.get<{ items: Rfq[]; total: number; hasMore: boolean }>(`/crm/rfqs?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  const STATUSES = ['OPEN', 'IN_REVIEW', 'QUOTED', 'AWARDED', 'LOST', 'CANCELLED'];
  const statusStyle: Record<string, { bg: string; color: string }> = {
    OPEN: { bg: '#E6F1FB', color: '#0C447C' },
    IN_REVIEW: { bg: '#FAEEDA', color: '#633806' },
    QUOTED: { bg: '#EEEDFE', color: '#3C3489' },
    AWARDED: { bg: '#DCFCE7', color: '#15803D' },
    LOST: { bg: '#FEE2E2', color: '#B91C1C' },
    CANCELLED: { bg: '#F3F4F6', color: '#6B7280' },
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">RFQ — Requests for Quotation</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data ? `${data.total.toLocaleString()} requests` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/crm/rfq/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New RFQ
        </Link>
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {STATUSES.map((s) => {
          const sc = statusStyle[s] ?? { bg: '#F3F4F6', color: '#6B7280' };
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(status === s ? '' : s);
                setPage(1);
              }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={
                status === s
                  ? { background: sc.bg, color: sc.color, borderColor: 'transparent' }
                  : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
              }
            >
              {s.replace(/_/g, ' ')}
            </button>
          );
        })}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {[
                'RFQ #',
                'Customer',
                'Subject',
                'Status',
                'Lines',
                'Est. Value',
                'Due',
                'Assigned',
                '',
              ].map((h) => (
                <th
                  key={h}
                  className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 9 }).map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr>
                <td colSpan={9} className="py-16 text-center">
                  <FileSearch className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                  <p className="text-[13px] text-[#9CA3AF]">No RFQs found</p>
                </td>
              </tr>
            ) : (
              (data?.items ?? []).map((rfq) => {
                const sc = statusStyle[rfq.status] ?? { bg: '#F3F4F6', color: '#6B7280' };
                const isUrgent =
                  rfq.dueDate &&
                  new Date(rfq.dueDate) < new Date(Date.now() + 3 * 86400_000) &&
                  !['AWARDED', 'LOST', 'CANCELLED'].includes(rfq.status);
                return (
                  <tr
                    key={rfq.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/crm/rfq/${rfq.id}`}
                        className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline"
                      >
                        {rfq.rfqNo}
                      </Link>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#1A1A1A]">{rfq.customer.name}</td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280] max-w-[200px] truncate">
                      {rfq.subject}
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{ background: sc.bg, color: sc.color }}
                      >
                        {rfq.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-center font-semibold">
                      {rfq.lineCount ?? '—'}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[11px] text-right">
                      {rfq.estimatedValue ? formatNGN(rfq.estimatedValue) : '—'}
                    </td>
                    <td
                      className="px-3 py-2.5 text-[11px] whitespace-nowrap"
                      style={{ color: isUrgent ? '#DC2626' : '#6B7280' }}
                    >
                      {rfq.dueDate ? (
                        <span className="flex items-center gap-1">
                          {isUrgent && <Clock className="h-3 w-3" />}
                          {formatDate(rfq.dueDate)}
                        </span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                      {rfq.assignedTo
                        ? `${rfq.assignedTo.firstName} ${rfq.assignedTo.lastName}`
                        : '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/crm/rfq/${rfq.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total?.toLocaleString()} RFQs</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">Page {page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
