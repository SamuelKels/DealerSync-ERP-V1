'use client';
// app/(erp)/hr/leave/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Calendar, Plus, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

export default function LeavePage() {
  const [status, setStatus] = useState('');
  const [type, setType] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();
  const params = buildSearchParams({
    status,
    leaveType: type,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 25,
    page,
  });
  const { data, isLoading } = useQuery({
    queryKey: ['leave-requests', { status, type, page }],
    queryFn: () => api.get<any>(`/hr/leave?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });
  const LEAVE_TYPES = ['ANNUAL', 'SICK', 'MATERNITY', 'PATERNITY', 'STUDY', 'UNPAID'];
  const STATUSES = ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'];
  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Leave Requests</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total} requests` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/hr/leave/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> Request Leave
        </Link>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[11px] font-semibold text-[#6B7280]">Type:</span>
        {LEAVE_TYPES.map((t) => (
          <button
            key={t}
            onClick={() => {
              setType(type === t ? '' : t);
              setPage(1);
            }}
            className="px-3 py-1 rounded-full text-[11px] font-semibold border"
            style={
              type === t
                ? { background: '#E6F1FB', color: '#0C447C', borderColor: 'transparent' }
                : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
            }
          >
            {t}
          </button>
        ))}
        <span className="text-[11px] font-semibold text-[#6B7280] ml-2">Status:</span>
        {STATUSES.map((s) => {
          const ss = getStatusStyle(s);
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(status === s ? '' : s);
                setPage(1);
              }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border"
              style={
                status === s
                  ? { background: ss.bg, color: ss.color, borderColor: 'transparent' }
                  : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
              }
            >
              {s}
            </button>
          );
        })}
      </div>
      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['Employee', 'Type', 'From', 'To', 'Days', 'Status', 'Applied', ''].map((h) => (
                <th
                  key={h}
                  className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280]"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr>
                <td colSpan={8} className="py-14 text-center">
                  <Calendar className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                  <p className="text-[13px] text-[#9CA3AF]">No leave requests found</p>
                </td>
              </tr>
            ) : (
              (data?.items ?? []).map((lr: any) => {
                const ss = getStatusStyle(lr.status);
                return (
                  <tr
                    key={lr.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    <td className="px-3 py-2.5 text-[12px] font-medium">
                      {lr.employee?.firstName} {lr.employee?.lastName}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-[#E6F1FB] text-[#0C447C] font-semibold">
                        {lr.leaveType}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-[#6B7280]">
                      {formatDate(lr.startDate)}
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-[#6B7280]">
                      {formatDate(lr.endDate)}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] font-semibold text-center">
                      {lr.daysRequested ?? '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase"
                        style={{ background: ss.bg, color: ss.color }}
                      >
                        {lr.status}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-[#6B7280]">
                      {formatDate(lr.createdAt)}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/hr/leave/${lr.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">{data?.total} requests</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
