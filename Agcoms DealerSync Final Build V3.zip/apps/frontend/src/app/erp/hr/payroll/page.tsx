'use client';
// app/(erp)/hr/payroll/page.tsx
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { CheckCircle2, Download, Calculator } from 'lucide-react';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate } from '../../../../lib/utils';

interface PayrollRun {
  id: string;
  runNo: string;
  periodName: string;
  status: 'DRAFT' | 'CALCULATED' | 'APPROVED' | 'PAID';
  payDate: string;
  totalGross: number;
  totalPaye: number;
  totalPension: number;
  totalNhf: number;
  totalNetPay: number;
  employeeCount: number;
  branchId: string;
  createdAt: string;
}
interface PayrollLine {
  employeeId: string;
  employeeNo: string;
  fullName: string;
  jobTitle?: string;
  grossSalary: number;
  basicSalary: number;
  totalAllowances: number;
  taxableIncome: number;
  cra: number;
  paye: number;
  employeePension: number;
  employerPension: number;
  nhf: number;
  wht: number;
  totalDeductions: number;
  netPay: number;
}
interface PayrollDetail {
  run: PayrollRun;
  lines: PayrollLine[];
}

export default function PayrollPage() {
  const [selectedRun, setSelectedRun] = useState<string>('');
  const { user } = useAuthStore();
  const qc = useQueryClient();

  const { data: runs = [], isLoading: runsLoading } = useQuery({
    queryKey: ['payroll-runs', user?.branchId],
    queryFn: () => api.get<PayrollRun[]>(`/hr/payroll?branchId=${user?.branchId ?? ''}`),
    staleTime: 60_000,
  });

  const { data: detail, isLoading: detailLoading } = useQuery({
    queryKey: ['payroll-detail', selectedRun],
    queryFn: () => api.get<PayrollDetail>(`/hr/payroll/${selectedRun}`),
    enabled: !!selectedRun,
    staleTime: 60_000,
  });

  const { mutate: runPayroll, isPending: running } = useMutation({
    mutationFn: () => api.post<PayrollRun>('/hr/payroll/run', { branchId: user?.branchId }),
    onSuccess: (run) => {
      toast.success(`Payroll run ${run.runNo} calculated successfully`);
      qc.invalidateQueries({ queryKey: ['payroll-runs'] });
      setSelectedRun(run.id);
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const { mutate: approve, isPending: approving } = useMutation({
    mutationFn: () => api.post(`/hr/payroll/${selectedRun}/approve`),
    onSuccess: () => {
      toast.success('Payroll approved — payments will be processed on pay date');
      qc.invalidateQueries({ queryKey: ['payroll-runs'] });
      qc.invalidateQueries({ queryKey: ['payroll-detail', selectedRun] });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const run = detail?.run;
  const lines = detail?.lines ?? [];

  const STATUS_STYLES: Record<string, { bg: string; color: string }> = {
    DRAFT: { bg: '#F3F4F6', color: '#6B7280' },
    CALCULATED: { bg: '#E0F2FE', color: '#0369A1' },
    APPROVED: { bg: '#DCFCE7', color: '#15803D' },
    PAID: { bg: '#EDF4EF', color: '#1A4D2E' },
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Payroll</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            PAYE · Pension (PenCom) · NHF · Net Pay calculation
          </p>
        </div>
        <button
          onClick={() => runPayroll()}
          disabled={running}
          className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white rounded-md disabled:opacity-60 transition-all"
          style={{ background: '#1A4D2E' }}
        >
          {running ? (
            <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
          ) : (
            <Calculator className="h-4 w-4" />
          )}
          {running ? 'Calculating…' : 'Run Payroll'}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Run history */}
        <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <div className="px-3 py-2.5 border-b border-[#E5E7EB]">
            <h2 className="text-[12px] font-semibold text-[#1A1A1A]">Payroll Runs</h2>
          </div>
          <div className="overflow-y-auto max-h-[400px]">
            {runsLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="px-3 py-2.5 border-b border-[#F3F4F6] space-y-1">
                  <div className="h-3.5 w-20 bg-[#F3F4F6] rounded animate-pulse" />
                  <div className="h-3 w-14 bg-[#F3F4F6] rounded animate-pulse" />
                </div>
              ))
            ) : runs.length === 0 ? (
              <div className="px-3 py-6 text-center text-[12px] text-[#9CA3AF]">
                No payroll runs yet
              </div>
            ) : (
              runs.map((r) => {
                const ss = STATUS_STYLES[r.status] ?? STATUS_STYLES.DRAFT!;
                return (
                  <button
                    key={r.id}
                    onClick={() => setSelectedRun(r.id)}
                    className="w-full text-left px-3 py-2.5 border-b border-[#F3F4F6] hover:bg-[#F7F4EF] transition-colors"
                    style={selectedRun === r.id ? { background: '#EDF4EF' } : {}}
                  >
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-mono text-[11px] font-semibold text-[#1A4D2E]">
                        {r.runNo}
                      </span>
                      <span
                        className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wide"
                        style={{ background: ss.bg, color: ss.color }}
                      >
                        {r.status}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#9CA3AF]">
                      {r.periodName} · {r.employeeCount} employees
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Run detail */}
        <div className="col-span-3 space-y-4">
          {!selectedRun ? (
            <div className="bg-white rounded-lg border border-[#E5E7EB] py-16 text-center">
              <Calculator className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
              <p className="text-[13px] text-[#9CA3AF]">Select a payroll run to view details</p>
            </div>
          ) : detailLoading ? (
            <div className="bg-white rounded-lg border border-[#E5E7EB] p-6 space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-5 bg-[#F3F4F6] rounded animate-pulse" />
              ))}
            </div>
          ) : run ? (
            <>
              {/* Summary cards */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {[
                  { label: 'Gross Pay', value: formatNGN(run.totalGross, true), color: '#1A4D2E' },
                  { label: 'PAYE', value: formatNGN(run.totalPaye, true), color: '#DC2626' },
                  { label: 'Pension', value: formatNGN(run.totalPension, true), color: '#D97706' },
                  { label: 'NHF', value: formatNGN(run.totalNhf, true), color: '#6D28D9' },
                  { label: 'Net Pay', value: formatNGN(run.totalNetPay, true), color: '#16A34A' },
                ].map(({ label, value, color }) => (
                  <div key={label} className="bg-white rounded-lg border border-[#E5E7EB] p-3">
                    <div className="text-[9px] font-semibold uppercase tracking-wider text-[#6B7280]">
                      {label}
                    </div>
                    <div className="font-heading text-lg mt-0.5" style={{ color }}>
                      {value}
                    </div>
                  </div>
                ))}
              </div>

              {/* Approve button */}
              {run.status === 'CALCULATED' && (
                <div
                  className="flex items-center justify-between px-4 py-3 rounded-lg border"
                  style={{ background: '#FFFBEB', borderColor: '#FEF3C7' }}
                >
                  <div>
                    <p className="text-[12px] font-semibold text-[#B45309]">Ready for approval</p>
                    <p className="text-[11px] text-[#B45309] mt-0.5">
                      Pay date: {formatDate(run.payDate)} · {run.employeeCount} employees
                    </p>
                  </div>
                  <button
                    onClick={() => approve()}
                    disabled={approving}
                    className="flex items-center gap-1.5 px-4 py-2 text-sm font-medium text-white rounded-md disabled:opacity-60"
                    style={{ background: '#16A34A' }}
                  >
                    {approving ? (
                      <span className="h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin" />
                    ) : (
                      <CheckCircle2 className="h-4 w-4" />
                    )}
                    Approve Payroll
                  </button>
                </div>
              )}

              {/* Lines table */}
              <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
                <div className="px-4 py-3 flex items-center justify-between border-b border-[#E5E7EB]">
                  <h2 className="font-heading text-[15px] text-[#1A1A1A]">
                    Payroll Lines ({lines.length})
                  </h2>
                  <button className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium rounded border border-[#D1D5DB] hover:bg-[#F7F4EF]">
                    <Download className="h-3.5 w-3.5" /> Export CSV
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b border-[#E5E7EB]">
                        {[
                          'Employee',
                          'Gross',
                          'CRA',
                          'Tax. Income',
                          'PAYE',
                          'Emp. Pension',
                          'NHF',
                          'Deductions',
                          'Net Pay',
                        ].map((h) => (
                          <th
                            key={h}
                            className="px-2.5 py-2 text-right text-[9px] font-semibold uppercase tracking-wider text-[#6B7280] first:text-left whitespace-nowrap"
                          >
                            {h}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {lines.map((l) => (
                        <tr
                          key={l.employeeId}
                          className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA]"
                        >
                          <td className="px-2.5 py-2">
                            <div className="text-[12px] font-medium text-[#1A1A1A]">
                              {l.fullName}
                            </div>
                            <div className="text-[10px] text-[#9CA3AF]">{l.employeeNo}</div>
                          </td>
                          {[
                            l.grossSalary,
                            l.cra,
                            l.taxableIncome,
                            l.paye,
                            l.employeePension,
                            l.nhf,
                            l.totalDeductions,
                            l.netPay,
                          ].map((v, i) => (
                            <td
                              key={i}
                              className="px-2.5 py-2 font-mono text-[11px] text-right"
                              style={i === 7 ? { fontWeight: 700, color: '#16A34A' } : {}}
                            >
                              {formatNGN(v)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr style={{ background: '#1A4D2E' }}>
                        <td className="px-2.5 py-2 text-[11px] font-bold text-white">Totals</td>
                        {[
                          run.totalGross,
                          0,
                          0,
                          run.totalPaye,
                          run.totalPension,
                          run.totalNhf,
                          run.totalPaye + run.totalPension + run.totalNhf,
                          run.totalNetPay,
                        ].map((v, i) => (
                          <td
                            key={i}
                            className="px-2.5 py-2 font-mono text-[11px] font-bold text-right text-white"
                          >
                            {v > 0 ? formatNGN(v) : '—'}
                          </td>
                        ))}
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
}
