'use client';
// app/(erp)/hr/employees/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, ChevronRight, Users } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface Employee {
  id: string;
  employeeNo: string;
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  phone?: string;
  jobTitle?: string;
  department?: { name: string };
  branch: { name: string };
  status: string;
  employmentType: string;
  hireDate: string;
  grossSalary: number;
}
interface PagedEmployees {
  items: Employee[];
  total: number;
  hasMore: boolean;
}

const EMP_TYPE_COLORS: Record<string, string> = {
  FULL_TIME: '#EDF4EF',
  PART_TIME: '#E0F2FE',
  CONTRACT: '#FEF3C7',
  INTERN: '#EDE9FE',
  CONSULTANT: '#FFF7ED',
};
const EMP_TYPE_TEXT: Record<string, string> = {
  FULL_TIME: '#1A4D2E',
  PART_TIME: '#0369A1',
  CONTRACT: '#B45309',
  INTERN: '#6D28D9',
  CONSULTANT: '#C2410C',
};

export default function EmployeesPage() {
  const [q, setQ] = useState('');
  const [dept, setDept] = useState('');
  const [status, setStatus] = useState('ACTIVE');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    q,
    departmentId: dept,
    status,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 25,
    page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['employees', 'list', { q, dept, status, page }],
    queryFn: () => api.get<PagedEmployees>(`/hr/employees?${params}`),
    staleTime: 60_000,
    placeholderData: (prev) => prev,
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => api.get<{ id: string; name: string }[]>('/hr/departments'),
    staleTime: 300_000,
  });

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Employees</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} employees` : 'Loading…'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/hr/org-chart"
            className="flex items-center gap-1.5 px-3 py-2 text-[12px] font-medium rounded-md border border-[#E5E7EB] hover:bg-[#F7F4EF] text-[#1A1A1A] transition-colors"
          >
            <Users className="h-3.5 w-3.5" /> Org Chart
          </Link>
          <Link
            href="/hr/employees/new"
            className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
            style={{ background: '#1A4D2E' }}
          >
            <Plus className="h-4 w-4" /> New Employee
          </Link>
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Search by name or email…"
            className="pl-8 pr-3 h-8 w-[240px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
          />
        </div>
        <select
          value={dept}
          onChange={(e) => {
            setDept(e.target.value);
            setPage(1);
          }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All departments</option>
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
        {['ACTIVE', 'ON_LEAVE', 'SUSPENDED', 'TERMINATED'].map((s) => {
          const st = getStatusStyle(s);
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(status === s ? '' : s);
                setPage(1);
              }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={
                status === s
                  ? { background: st.bg, color: st.color, borderColor: 'transparent' }
                  : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
              }
            >
              {s.replace(/_/g, ' ')}
            </button>
          );
        })}
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {[
                'Employee',
                'Job Title',
                'Department',
                'Branch',
                'Type',
                'Status',
                'Hire Date',
                'Gross Salary',
                '',
              ].map((h) => (
                <th
                  key={h}
                  className="px-3 py-2.5 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 9 }).map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr>
                <td colSpan={9} className="py-16 text-center">
                  <Users className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                  <p className="text-[13px] text-[#9CA3AF]">No employees found</p>
                </td>
              </tr>
            ) : (
              (data?.items ?? []).map((emp) => {
                const ss = getStatusStyle(emp.status);
                return (
                  <tr
                    key={emp.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-semibold text-white flex-shrink-0"
                          style={{ background: '#1A4D2E' }}
                        >
                          {emp.firstName[0]}
                          {emp.lastName[0]}
                        </div>
                        <div>
                          <Link
                            href={`/hr/employees/${emp.id}`}
                            className="text-[13px] font-medium text-[#1A4D2E] hover:underline"
                          >
                            {emp.fullName}
                          </Link>
                          <div className="text-[10px] font-mono text-[#9CA3AF]">
                            {emp.employeeNo}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                      {emp.jobTitle ?? '—'}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                      {emp.department?.name ?? '—'}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{emp.branch.name}</td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{
                          background: EMP_TYPE_COLORS[emp.employmentType] ?? '#F3F4F6',
                          color: EMP_TYPE_TEXT[emp.employmentType] ?? '#6B7280',
                        }}
                      >
                        {emp.employmentType.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{ background: ss.bg, color: ss.color }}
                      >
                        {emp.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280] whitespace-nowrap">
                      {formatDate(emp.hireDate)}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[12px] font-semibold text-right">
                      {formatNGN(emp.grossSalary)}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/hr/employees/${emp.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">
            {data?.total?.toLocaleString()} employees
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
