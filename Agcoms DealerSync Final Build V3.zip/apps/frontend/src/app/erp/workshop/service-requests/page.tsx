'use client';
// app/(erp)/workshop/service-requests/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, Wrench, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api, queryKeys } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatRelative, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface ServiceRequest {
  id: string;
  srNo: string;
  serviceType: string;
  priority: string;
  status: string;
  customer?: { name: string };
  faultDescription: string;
  equipmentDesc?: string;
  make?: string;
  model?: string;
  serialNumber?: string;
  assignedTechnician?: { fullName: string };
  createdAt: string;
  updatedAt: string;
}
interface PagedSRs {
  items: ServiceRequest[];
  total: number;
  hasMore: boolean;
}

const PRIORITY_STYLES: Record<string, { bg: string; color: string }> = {
  CRITICAL: { bg: '#FEE2E2', color: '#B91C1C' },
  HIGH: { bg: '#FEF3C7', color: '#B45309' },
  MEDIUM: { bg: '#E0F2FE', color: '#0369A1' },
  LOW: { bg: '#F3F4F6', color: '#6B7280' },
};

export default function ServiceRequestsPage() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    q,
    status,
    priority,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 25,
    page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.serviceRequests.list({ q, status, priority, page }),
    queryFn: () => api.get<PagedSRs>(`/workshop/service-requests?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  const STATUSES = [
    'OPEN',
    'IN_PROGRESS',
    'ON_HOLD',
    'AWAITING_PARTS',
    'AWAITING_APPROVAL',
    'COMPLETED',
  ];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Service Requests</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} requests` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/workshop/service-requests/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Service Request
        </Link>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Search by SR# or description…"
            className="pl-8 pr-3 h-8 w-[240px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
          />
        </div>
        <select
          value={status}
          onChange={(e) => {
            setStatus(e.target.value);
            setPage(1);
          }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All statuses</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {s.replace(/_/g, ' ')}
            </option>
          ))}
        </select>
        <select
          value={priority}
          onChange={(e) => {
            setPriority(e.target.value);
            setPage(1);
          }}
          className="h-8 px-3 text-[12px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        >
          <option value="">All priorities</option>
          {['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].map((p) => (
            <option key={p} value={p}>
              {p}
            </option>
          ))}
        </select>
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {[
                'SR#',
                'Type',
                'Customer / Equipment',
                'Priority',
                'Status',
                'Technician',
                'Updated',
                '',
              ].map((h) => (
                <th
                  key={h}
                  className="px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-[#6B7280] whitespace-nowrap"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 8 }).map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr>
                <td colSpan={8} className="py-16 text-center">
                  <Wrench className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                  <p className="text-[13px] text-[#9CA3AF]">No service requests found</p>
                </td>
              </tr>
            ) : (
              (data?.items ?? []).map((sr) => {
                const ss = getStatusStyle(sr.status);
                const ps = PRIORITY_STYLES[sr.priority] ?? PRIORITY_STYLES['LOW']!;
                return (
                  <tr
                    key={sr.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/workshop/service-requests/${sr.id}`}
                        className="font-mono text-[11px] font-semibold text-[#1A4D2E] hover:underline"
                      >
                        {sr.srNo}
                      </Link>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">{sr.serviceType}</td>
                    <td className="px-3 py-2.5">
                      {sr.customer && (
                        <div className="text-[12px] font-medium text-[#1A1A1A]">
                          {sr.customer.name}
                        </div>
                      )}
                      <div className="text-[11px] text-[#6B7280] max-w-[180px] truncate">
                        {[sr.make, sr.model, sr.serialNumber].filter(Boolean).join(' · ') ||
                          sr.equipmentDesc ||
                          sr.faultDescription}
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{ background: ps.bg, color: ps.color }}
                      >
                        {sr.priority}
                      </span>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{ background: ss.bg, color: ss.color }}
                      >
                        {sr.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                      {sr.assignedTechnician?.fullName ?? (
                        <span className="text-[#9CA3AF]">Unassigned</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-[#9CA3AF]">
                      {formatRelative(sr.updatedAt)}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/workshop/service-requests/${sr.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E] transition-colors"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">
            {data?.total?.toLocaleString()} requests
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
