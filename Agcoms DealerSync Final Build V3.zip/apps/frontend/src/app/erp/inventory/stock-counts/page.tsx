'use client';
// app/(erp)/inventory/stock-counts/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ClipboardList, Plus, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatRelative, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface PhysicalCount {
  id: string;
  countNo: string;
  title: string;
  status: string;
  fullCount: boolean;
  warehouse: { name: string; code: string };
  branch: { name: string };
  createdBy: { fullName: string };
  linesCount: number;
  countedLines: number;
  adjustmentsMade?: number;
  createdAt: string;
  submittedAt?: string;
  closedAt?: string;
}
interface PagedCounts {
  items: PhysicalCount[];
  total: number;
  hasMore: boolean;
}

const STATUS_STEPS = ['OPEN', 'IN_PROGRESS', 'SUBMITTED', 'CLOSED'];

export default function StockCountsPage() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    status,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 20,
    page,
  });

  const { data, isLoading } = useQuery({
    queryKey: ['stock-counts', { status, page }],
    queryFn: () => api.get<PagedCounts>(`/inventory/stock-counts?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Stock Counts</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">Physical inventory counting workflow</p>
        </div>
        <Link
          href="/inventory/stock-counts/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Stock Count
        </Link>
      </div>

      {/* Status filter */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setStatus('')}
          className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors ${!status ? 'bg-[#1A4D2E] text-white border-transparent' : 'bg-white text-[#6B7280] border-[#E5E7EB]'}`}
        >
          All
        </button>
        {STATUS_STEPS.map((s) => {
          const ss = getStatusStyle(
            s === 'OPEN' || s === 'IN_PROGRESS'
              ? 'PENDING'
              : s === 'SUBMITTED'
                ? 'WARNING'
                : 'ACTIVE',
          );
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(s);
                setPage(1);
              }}
              className="px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors"
              style={
                status === s
                  ? { background: ss.bg, color: ss.color, borderColor: 'transparent' }
                  : { background: '#fff', color: '#6B7280', borderColor: '#E5E7EB' }
              }
            >
              {s.replace(/_/g, ' ')}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-lg border border-[#E5E7EB] p-4 space-y-3 animate-pulse"
            >
              <div className="h-4 w-24 bg-[#F3F4F6] rounded" />
              <div className="h-5 w-3/4 bg-[#F3F4F6] rounded" />
              <div className="h-3 w-1/2 bg-[#F3F4F6] rounded" />
            </div>
          ))
        ) : (data?.items ?? []).length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <ClipboardList className="h-12 w-12 mx-auto mb-3 text-[#D1D5DB]" />
            <p className="text-[13px] text-[#9CA3AF]">No stock counts found</p>
          </div>
        ) : (
          (data?.items ?? []).map((count) => {
            const ss = getStatusStyle(count.status);
            const progress =
              count.linesCount > 0 ? (count.countedLines / count.linesCount) * 100 : 0;
            return (
              <Link
                key={count.id}
                href={`/inventory/stock-counts/${count.id}`}
                className="bg-white rounded-lg border border-[#E5E7EB] p-4 hover:shadow-md transition-shadow"
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-[11px] font-semibold text-[#1A4D2E]">
                    {count.countNo}
                  </span>
                  <span
                    className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                    style={{ background: ss.bg, color: ss.color }}
                  >
                    {count.status.replace(/_/g, ' ')}
                  </span>
                </div>
                <h3 className="text-[13px] font-medium text-[#1A1A1A] mb-1">{count.title}</h3>
                <p className="text-[11px] text-[#6B7280] mb-3">
                  {count.warehouse.name} · {count.fullCount ? 'Full count' : 'Partial'}
                </p>

                {/* Progress bar */}
                {['OPEN', 'IN_PROGRESS'].includes(count.status) && (
                  <div className="mb-3">
                    <div className="flex justify-between text-[10px] text-[#9CA3AF] mb-1">
                      <span>Progress</span>
                      <span>
                        {count.countedLines}/{count.linesCount} items
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-[#E5E7EB] overflow-hidden">
                      <div
                        className="h-full rounded-full bg-[#1A4D2E] transition-[width]"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                )}

                {count.status === 'CLOSED' && (
                  <p className="text-[11px] text-[#16A34A]">
                    ✓ {count.adjustmentsMade} adjustment{count.adjustmentsMade !== 1 ? 's' : ''}{' '}
                    made
                  </p>
                )}

                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-[#9CA3AF]">
                    {formatRelative(count.createdAt)}
                  </span>
                  <ChevronRight className="h-4 w-4 text-[#9CA3AF]" />
                </div>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
}
