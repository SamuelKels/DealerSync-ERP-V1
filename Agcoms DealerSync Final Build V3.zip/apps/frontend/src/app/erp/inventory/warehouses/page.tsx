'use client';
// app/(erp)/inventory/warehouses/page.tsx
import { useQuery } from '@tanstack/react-query';
import { Package, Plus, MapPin, ChevronRight } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { buildSearchParams } from '../../../../lib/utils';

export default function WarehousesPage() {
  const { user } = useAuthStore();
  const params = buildSearchParams({ branchId: user?.isSuperAdmin ? undefined : user?.branchId });
  const { data, isLoading } = useQuery({
    queryKey: ['warehouses'],
    queryFn: () => api.get<any>(`/inventory/warehouses?${params}`),
    staleTime: 60_000,
  });
  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Warehouses</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total} warehouse locations` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/inventory/warehouses/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> Add Warehouse
        </Link>
      </div>
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-lg border border-[#E5E7EB] p-5 h-36 animate-pulse"
            />
          ))}
        </div>
      ) : (data?.items ?? []).length === 0 ? (
        <div className="bg-white rounded-lg border border-[#E5E7EB] py-16 text-center">
          <Package className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
          <p className="text-[13px] text-[#9CA3AF]">No warehouses configured</p>
          <Link
            href="/inventory/warehouses/new"
            className="mt-3 inline-block text-[12px] text-[#1A4D2E] underline"
          >
            Add first warehouse
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(data?.items ?? []).map((wh: any) => (
            <Link
              key={wh.id}
              href={`/inventory/warehouses/${wh.id}`}
              className="bg-white rounded-lg border border-[#E5E7EB] p-5 hover:border-[#1A4D2E]/40 hover:shadow-sm transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <span className="font-mono text-[11px] font-semibold text-[#1A4D2E] bg-[#EAF3DE] px-1.5 py-0.5 rounded">
                    {wh.code}
                  </span>
                  <h3 className="font-medium text-[14px] mt-1.5 text-[#1A1A1A]">{wh.name}</h3>
                </div>
                <ChevronRight className="h-4 w-4 text-[#D1D5DB] group-hover:text-[#1A4D2E] mt-1 flex-shrink-0" />
              </div>
              {wh.address && (
                <p className="flex items-start gap-1 text-[11px] text-[#6B7280]">
                  <MapPin className="h-3 w-3 mt-0.5 flex-shrink-0" />
                  {wh.address}
                </p>
              )}
              <div className="mt-4 pt-3 border-t border-[#F3F4F6] flex items-center justify-between">
                <div className="text-center">
                  <div className="font-mono text-[16px] font-semibold text-[#1A1A1A]">
                    {wh.stockItemCount ?? 0}
                  </div>
                  <div className="text-[10px] text-[#6B7280]">SKUs</div>
                </div>
                <div className="text-center">
                  <div className="font-mono text-[16px] font-semibold text-[#1A1A1A]">
                    {wh.totalItems ?? 0}
                  </div>
                  <div className="text-[10px] text-[#6B7280]">Units</div>
                </div>
                <div className="text-center">
                  <span
                    className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase"
                    style={{
                      background: wh.isActive ? '#DCFCE7' : '#FEE2E2',
                      color: wh.isActive ? '#15803D' : '#B91C1C',
                    }}
                  >
                    {wh.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
