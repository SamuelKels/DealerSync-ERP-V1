/**
 * AGCOMS DealerSync ERP — Accounting Periods Page (Sprint P2)
 *
 * Lists accounting periods with status (OPEN/CLOSED/LOCKED), allows
 * authorised users to close, lock, and reopen periods.
 *
 * IFRS compliance UI:
 *   - LOCKED periods show a permanent lock icon (cannot reopen)
 *   - Close action requires confirmation dialog
 *   - Lock action requires double confirmation (irreversible)
 */
'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Lock,
  Unlock,
  ShieldCheck,
  CalendarRange,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
} from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

import { Badge } from '../../../../components/ui/badge';
import { Button } from '../../../../components/ui/button';
import { api } from '../../../../lib/api';
import { formatDate } from '../../../../lib/utils';
import { useAuthStore } from '../../../../stores/auth.store';

interface AccountingPeriod {
  id: string;
  name: string;
  branchId: string;
  year: number;
  month: number | null;
  quarter: number | null;
  startDate: string;
  endDate: string;
  status: 'OPEN' | 'CLOSED' | 'LOCKED';
  closedAt: string | null;
  lockedAt: string | null;
  notes: string | null;
}

const STATUS_STYLES: Record<string, string> = {
  OPEN: 'bg-emerald-100 text-emerald-900 ring-1 ring-emerald-200',
  CLOSED: 'bg-amber-100 text-amber-900 ring-1 ring-amber-200',
  LOCKED: 'bg-zinc-200 text-zinc-900 ring-1 ring-zinc-300',
};

const STATUS_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  OPEN: Unlock,
  CLOSED: ShieldCheck,
  LOCKED: Lock,
};

export default function AccountingPeriodsPage() {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const [filterYear, setFilterYear] = useState<number | undefined>(new Date().getFullYear());
  const [filterStatus, setFilterStatus] = useState<string | undefined>();

  // ── Load periods ─────────────────────────────────────────
  const { data, isLoading, error } = useQuery({
    queryKey: ['finance', 'periods', { year: filterYear, status: filterStatus }],
    queryFn: () =>
      api.get<AccountingPeriod[]>('/finance/periods', {
        params: { year: filterYear, status: filterStatus },
      }),
  });

  const periods = data ?? [];

  // ── Close period mutation ────────────────────────────────
  const closePeriodMutation = useMutation({
    mutationFn: (id: string) => api.post<AccountingPeriod>(`/finance/periods/${id}/close`, {}),
    onSuccess: () => {
      toast.success('Period closed successfully');
      void queryClient.invalidateQueries({ queryKey: ['finance', 'periods'] });
    },
    onError: (err: any) => toast.error(err?.response?.data?.message ?? 'Failed to close period'),
  });

  // ── Lock period mutation ─────────────────────────────────
  const lockPeriodMutation = useMutation({
    mutationFn: (id: string) => api.post<AccountingPeriod>(`/finance/periods/${id}/lock`, {}),
    onSuccess: () => {
      toast.success('Period locked — no further changes possible');
      void queryClient.invalidateQueries({ queryKey: ['finance', 'periods'] });
    },
    onError: (err: any) => toast.error(err?.response?.data?.message ?? 'Failed to lock period'),
  });

  // ── Reopen period mutation ───────────────────────────────
  const reopenPeriodMutation = useMutation({
    mutationFn: (id: string) => api.post<AccountingPeriod>(`/finance/periods/${id}/reopen`, {}),
    onSuccess: () => {
      toast.success('Period reopened');
      void queryClient.invalidateQueries({ queryKey: ['finance', 'periods'] });
    },
    onError: (err: any) => toast.error(err?.response?.data?.message ?? 'Failed to reopen period'),
  });

  const handleClose = (period: AccountingPeriod) => {
    if (
      !confirm(
        `Close period "${period.name}"?\n\nThis blocks new draft entries but allows correction journals via reversal.`,
      )
    )
      return;
    closePeriodMutation.mutate(period.id);
  };

  const handleLock = (period: AccountingPeriod) => {
    const confirm1 = confirm(
      `LOCK period "${period.name}"?\n\n⚠️ This action is IRREVERSIBLE. No journals can be posted, modified, or reversed once locked.`,
    );
    if (!confirm1) return;
    const confirm2 = prompt(`Type "LOCK ${period.name}" to confirm:`);
    if (confirm2 !== `LOCK ${period.name}`) {
      toast.error('Lock cancelled — confirmation phrase did not match');
      return;
    }
    lockPeriodMutation.mutate(period.id);
  };

  const handleReopen = (period: AccountingPeriod) => {
    if (!confirm(`Reopen period "${period.name}"? This allows new draft journal entries again.`))
      return;
    reopenPeriodMutation.mutate(period.id);
  };

  const isSuperAdmin = (user as any)?.isSuperAdmin;

  return (
    <div className="space-y-6 p-6 max-w-7xl mx-auto">
      {/* ── Header ─────────────────────────────────────── */}
      <div className="flex items-start justify-between border-b border-gray-200 pb-4">
        <div>
          <h1 className="text-2xl font-semibold text-[#1A4D2E] flex items-center gap-2">
            <CalendarRange className="h-7 w-7" />
            Accounting Periods
          </h1>
          <p className="mt-1 text-sm text-gray-600">
            Manage monthly, quarterly, and annual close cycles. Period locks enforce IFRS-compliant
            immutability.
          </p>
        </div>
      </div>

      {/* ── Filters ────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-3">
        <select
          value={filterYear ?? ''}
          onChange={(e) => setFilterYear(e.target.value ? parseInt(e.target.value, 10) : undefined)}
          className="rounded-lg border border-gray-200 px-4 py-2 text-sm"
        >
          <option value="">All years</option>
          {[2026, 2025, 2024, 2023, 2022].map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>

        <select
          value={filterStatus ?? ''}
          onChange={(e) => setFilterStatus(e.target.value || undefined)}
          className="rounded-lg border border-gray-200 px-4 py-2 text-sm"
        >
          <option value="">All statuses</option>
          <option value="OPEN">Open</option>
          <option value="CLOSED">Closed</option>
          <option value="LOCKED">Locked</option>
        </select>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => void queryClient.invalidateQueries({ queryKey: ['finance', 'periods'] })}
          className="ml-auto"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* ── Period table ───────────────────────────────── */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-gray-500">Loading periods…</div>
        ) : error ? (
          <div className="p-8 text-center text-red-600 flex items-center justify-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Failed to load periods: {(error as any)?.message}
          </div>
        ) : periods.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <CalendarRange className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p className="text-base">No accounting periods defined</p>
            <p className="text-sm mt-1">Create one to begin posting journal entries</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-xs uppercase tracking-wide text-gray-500">
                <th className="px-4 py-3 text-left">Period</th>
                <th className="px-4 py-3 text-left">Date range</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Closed</th>
                <th className="px-4 py-3 text-left">Locked</th>
                <th className="px-4 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {periods.map((p) => {
                const StatusIcon = STATUS_ICONS[p.status] as React.FC<{ className?: string }>;
                return (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{p.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {formatDate(p.startDate)} → {formatDate(p.endDate)}
                    </td>
                    <td className="px-4 py-3">
                      <Badge className={STATUS_STYLES[p.status]}>
                        <StatusIcon className="h-3 w-3 mr-1.5 inline" />
                        {p.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {p.closedAt ? formatDate(p.closedAt) : '—'}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {p.lockedAt ? formatDate(p.lockedAt) : '—'}
                    </td>
                    <td className="px-4 py-3 text-right space-x-2">
                      {p.status === 'OPEN' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleClose(p)}
                          disabled={closePeriodMutation.isPending}
                        >
                          <ShieldCheck className="h-4 w-4 mr-1" />
                          Close
                        </Button>
                      )}
                      {p.status === 'CLOSED' && isSuperAdmin && (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleReopen(p)}
                            disabled={reopenPeriodMutation.isPending}
                          >
                            <Unlock className="h-4 w-4 mr-1" />
                            Reopen
                          </Button>
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleLock(p)}
                            disabled={lockPeriodMutation.isPending}
                            className="bg-[#1A4D2E] hover:bg-[#0F3320]"
                          >
                            <Lock className="h-4 w-4 mr-1" />
                            Lock
                          </Button>
                        </>
                      )}
                      {p.status === 'LOCKED' && (
                        <span className="text-xs text-gray-500 flex items-center justify-end gap-1">
                          <CheckCircle2 className="h-4 w-4 text-zinc-400" />
                          Immutable
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* ── Helper text ─────────────────────────────────── */}
      <div className="text-xs text-gray-500 bg-amber-50 border border-amber-200 rounded-lg p-4">
        <p className="font-medium text-amber-900 mb-1">Period lifecycle: OPEN → CLOSED → LOCKED</p>
        <ul className="list-disc list-inside space-y-1 text-amber-800">
          <li>
            <strong>OPEN:</strong> Draft journals can be created, posted, modified, voided.
          </li>
          <li>
            <strong>CLOSED:</strong> No new draft entries. Existing posted entries can be reversed
            via correction journals.
          </li>
          <li>
            <strong>LOCKED:</strong> Immutable. No journals can be posted, modified, or reversed.
            Super-admin only. Cannot be reopened.
          </li>
        </ul>
      </div>
    </div>
  );
}
