'use client';
// app/(erp)/finance/accounts/page.tsx
import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, ChevronRight, ChevronDown, Lock } from 'lucide-react';
import Link from 'next/link';
import { api } from '../../../../lib/api';
import { formatNGN } from '../../../../lib/utils';

interface Account {
  id: string;
  code: string;
  name: string;
  accountType: string;
  normalBalance: 'DEBIT' | 'CREDIT';
  isActive: boolean;
  parentId?: string;
  level: number;
  balance?: number;
  children?: Account[];
}

// IFRS account type ordering
const TYPE_ORDER = [
  'ASSET',
  'LIABILITY',
  'EQUITY',
  'REVENUE',
  'COST_OF_SALES',
  'OPERATING_EXPENSE',
  'OTHER_INCOME',
  'OTHER_EXPENSE',
  'TAX',
];
const TYPE_LABELS: Record<string, string> = {
  ASSET: 'Assets (1xxx)',
  LIABILITY: 'Liabilities (2xxx)',
  EQUITY: 'Equity (3xxx)',
  REVENUE: 'Revenue (4xxx)',
  COST_OF_SALES: 'Cost of Sales (5xxx)',
  OPERATING_EXPENSE: 'Operating Expenses (6xxx)',
  OTHER_INCOME: 'Other Income (7xxx)',
  OTHER_EXPENSE: 'Other Expenses (8xxx)',
  TAX: 'Tax Accounts (9xxx)',
};
const TYPE_COLORS: Record<string, string> = {
  ASSET: '#0EA5E9',
  LIABILITY: '#DC2626',
  EQUITY: '#6D28D9',
  REVENUE: '#16A34A',
  COST_OF_SALES: '#D97706',
  OPERATING_EXPENSE: '#D97706',
  OTHER_INCOME: '#16A34A',
  OTHER_EXPENSE: '#DC2626',
  TAX: '#9CA3AF',
};

function AccountRow({ account, depth = 0 }: { account: Account; depth?: number }) {
  const [open, setOpen] = useState(depth < 2);
  const hasChildren = (account.children?.length ?? 0) > 0;
  const indent = depth * 16;

  return (
    <>
      <tr className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors">
        <td className="px-3 py-2">
          <div className="flex items-center gap-1.5" style={{ paddingLeft: indent }}>
            {hasChildren ? (
              <button
                onClick={() => setOpen((v) => !v)}
                className="flex-shrink-0 w-4 h-4 flex items-center justify-center text-[#6B7280] hover:text-[#1A4D2E]"
              >
                {open ? (
                  <ChevronDown className="h-3.5 w-3.5" />
                ) : (
                  <ChevronRight className="h-3.5 w-3.5" />
                )}
              </button>
            ) : (
              <span className="w-4 flex-shrink-0" />
            )}
            <span className="font-mono text-[11px] font-semibold" style={{ color: '#1A4D2E' }}>
              {account.code}
            </span>
          </div>
        </td>
        <td className="px-3 py-2">
          <div className="flex items-center gap-1.5" style={{ paddingLeft: indent + 20 }}>
            {!account.isActive && <Lock className="h-3 w-3 text-[#9CA3AF] flex-shrink-0" />}
            <span
              className={`text-[13px] ${account.level === 0 ? 'font-semibold' : ''} text-[#1A1A1A]`}
            >
              {account.name}
            </span>
          </div>
        </td>
        <td className="px-3 py-2">
          <span
            className="text-[9.5px] font-semibold uppercase tracking-wide px-1.5 py-0.5 rounded"
            style={{
              background: `${TYPE_COLORS[account.accountType]}15`,
              color: TYPE_COLORS[account.accountType],
            }}
          >
            {account.normalBalance}
          </span>
        </td>
        <td className="px-3 py-2 text-right font-mono text-[12px] font-semibold text-[#1A1A1A]">
          {account.balance !== undefined ? formatNGN(account.balance) : '—'}
        </td>
        <td className="px-3 py-2">
          <span
            className={`text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide ${
              account.isActive ? 'bg-[#DCFCE7] text-[#15803D]' : 'bg-[#F3F4F6] text-[#9CA3AF]'
            }`}
          >
            {account.isActive ? 'Active' : 'Inactive'}
          </span>
        </td>
        <td className="px-3 py-2">
          <Link
            href={`/finance/accounts/${account.id}`}
            className="flex items-center justify-center w-6 h-6 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E]"
          >
            <ChevronRight className="h-3.5 w-3.5" />
          </Link>
        </td>
      </tr>
      {open &&
        account.children?.map((child) => (
          <AccountRow key={child.id} account={child} depth={depth + 1} />
        ))}
    </>
  );
}

export default function ChartOfAccountsPage() {
  const [q, setQ] = useState('');

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ['accounts', 'tree'],
    queryFn: () => api.get<Account[]>('/finance/accounts?tree=true'),
    staleTime: 300_000,
  });

  const grouped = useMemo(() => {
    const map: Record<string, Account[]> = {};
    accounts.forEach((a) => {
      if (!map[a.accountType]) map[a.accountType] = [];
      map[a.accountType]!.push(a);
    });
    return map;
  }, [accounts]);

  const filtered = useMemo(() => {
    if (!q) return grouped;
    const lower = q.toLowerCase();
    const match = (a: Account): boolean =>
      a.code.toLowerCase().includes(lower) || a.name.toLowerCase().includes(lower);
    const out: Record<string, Account[]> = {};
    Object.entries(grouped).forEach(([type, accts]) => {
      const matches = accts.filter((a) => match(a) || a.children?.some(match));
      if (matches.length) out[type] = matches;
    });
    return out;
  }, [grouped, q]);

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Chart of Accounts</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">IFRS-compliant account structure</p>
        </div>
        <Link
          href="/finance/accounts/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Account
        </Link>
      </div>

      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search by code or name…"
          className="pl-8 pr-3 h-8 w-[260px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
        />
      </div>

      {TYPE_ORDER.filter((t) => filtered[t]?.length).map((type) => (
        <div key={type} className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <div
            className="px-4 py-2.5 flex items-center gap-3"
            style={{ background: `${TYPE_COLORS[type]}08`, borderBottom: '1px solid #E5E7EB' }}
          >
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: TYPE_COLORS[type] }} />
            <span className="text-[12px] font-semibold text-[#1A1A1A]">
              {TYPE_LABELS[type] ?? type}
            </span>
          </div>
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-[#E5E7EB]">
                {['Code', 'Account Name', 'Normal Balance', 'Balance', 'Status', ''].map((h) => (
                  <th
                    key={h}
                    className="px-3 py-2 text-left text-[9.5px] font-semibold uppercase tracking-wider text-[#6B7280]"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <tr key={i} className="border-b border-[#F3F4F6]">
                      {[80, 200, 80, 120, 60, 30].map((w, j) => (
                        <td key={j} className="px-3 py-2.5">
                          <div
                            className="h-4 bg-[#F3F4F6] rounded animate-pulse"
                            style={{ width: w }}
                          />
                        </td>
                      ))}
                    </tr>
                  ))
                : (filtered[type] ?? []).map((a) => <AccountRow key={a.id} account={a} />)}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
}
