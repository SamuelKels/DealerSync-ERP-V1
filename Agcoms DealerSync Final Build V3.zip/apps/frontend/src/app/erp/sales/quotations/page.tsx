'use client';
// app/(erp)/sales/quotations/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, ChevronRight, FileText } from 'lucide-react';
import Link from 'next/link';
import { api, queryKeys } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatNGN, formatDate, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface Quotation {
  id: string;
  quotationNo: string;
  customer: { name: string };
  status: string;
  totalAmount: number;
  currency: string;
  validUntil?: string;
  createdAt: string;
  lines: { count: number };
}
interface PagedQuotations {
  items: Quotation[];
  total: number;
  hasMore: boolean;
}

export default function QuotationsPage() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    q,
    status,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 25,
    page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.quotations.list({ q, status, page }),
    queryFn: () => api.get<PagedQuotations>(`/sales/quotations?${params}`),
    staleTime: 30_000,
    placeholderData: (prev) => prev,
  });

  const STATUSES = ['DRAFT', 'SENT', 'ACCEPTED', 'REJECTED', 'EXPIRED', 'CONVERTED'];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Quotations</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} quotations` : 'Loading…'}
          </p>
        </div>
        <Link
          href="/sales/quotations/new"
          className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
          style={{ background: '#1A4D2E' }}
        >
          <Plus className="h-4 w-4" /> New Quotation
        </Link>
      </div>

      {/* Status filter pills */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => setStatus('')}
          className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors ${status === '' ? 'bg-[#1A4D2E] text-white border-transparent' : 'bg-white text-[#6B7280] border-[#E5E7EB] hover:border-[#D1D5DB]'}`}
        >
          All
        </button>
        {STATUSES.map((s) => {
          const st = getStatusStyle(s);
          return (
            <button
              key={s}
              onClick={() => {
                setStatus(s);
                setPage(1);
              }}
              className={`px-3 py-1 rounded-full text-[11px] font-semibold border transition-colors ${status === s ? '' : 'bg-white border-[#E5E7EB] text-[#6B7280] hover:border-[#D1D5DB]'}`}
              style={
                status === s
                  ? { background: st.bg, color: st.color, borderColor: 'transparent' }
                  : {}
              }
            >
              {s}
            </button>
          );
        })}
        <div className="flex-1" />
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
          <input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setPage(1);
            }}
            placeholder="Search by customer or ref…"
            className="pl-8 pr-3 h-8 w-[220px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
          />
        </div>
        {isFetching && !isLoading && (
          <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
        )}
      </div>

      <div className="bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-[#E5E7EB]">
              {['Reference', 'Customer', 'Status', 'Amount', 'Valid Until', 'Created', ''].map(
                (h) => (
                  <th
                    key={h}
                    className="px-3 py-2.5 text-left text-[10px] font-semibold uppercase tracking-wider text-[#6B7280]"
                  >
                    {h}
                  </th>
                ),
              )}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <tr key={i} className="border-b border-[#F3F4F6]">
                  {Array.from({ length: 7 }).map((_, j) => (
                    <td key={j} className="px-3 py-3">
                      <div className="h-4 bg-[#F3F4F6] rounded animate-pulse" />
                    </td>
                  ))}
                </tr>
              ))
            ) : (data?.items ?? []).length === 0 ? (
              <tr>
                <td colSpan={7} className="py-16 text-center">
                  <FileText className="h-10 w-10 mx-auto mb-2 text-[#D1D5DB]" />
                  <p className="text-[13px] text-[#9CA3AF]">
                    No quotations yet. Create your first quotation.
                  </p>
                </td>
              </tr>
            ) : (
              (data?.items ?? []).map((q) => {
                const s = getStatusStyle(q.status);
                return (
                  <tr
                    key={q.id}
                    className="border-b border-[#F3F4F6] hover:bg-[#FAFAFA] transition-colors"
                  >
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/sales/quotations/${q.id}`}
                        className="font-mono text-[12px] font-semibold text-[#1A4D2E] hover:underline"
                      >
                        {q.quotationNo}
                      </Link>
                    </td>
                    <td className="px-3 py-2.5 text-[13px] text-[#1A1A1A]">{q.customer.name}</td>
                    <td className="px-3 py-2.5">
                      <span
                        className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                        style={{ background: s.bg, color: s.color }}
                      >
                        {q.status}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[12px] font-semibold text-right">
                      {formatNGN(q.totalAmount)}
                    </td>
                    <td className="px-3 py-2.5 text-[12px] text-[#6B7280]">
                      {q.validUntil ? formatDate(q.validUntil) : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-[11px] text-[#9CA3AF]">
                      {formatDate(q.createdAt)}
                    </td>
                    <td className="px-3 py-2.5">
                      <Link
                        href={`/sales/quotations/${q.id}`}
                        className="flex items-center justify-center w-7 h-7 rounded hover:bg-[#F7F4EF] text-[#9CA3AF] hover:text-[#1A4D2E] transition-colors"
                      >
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-2.5 border-t border-[#E5E7EB]">
          <span className="text-[11px] text-[#6B7280]">
            {data?.total?.toLocaleString()} quotations
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              ← Prev
            </button>
            <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={!data?.hasMore}
              className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
            >
              Next →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
