'use client';
// app/(erp)/fleet/assets/page.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, MapPin, AlertTriangle, Truck } from 'lucide-react';
import Link from 'next/link';
import { api, queryKeys } from '../../../../lib/api';
import { useAuthStore } from '../../../../stores/auth.store';
import { formatRelative, getStatusStyle, buildSearchParams } from '../../../../lib/utils';

interface FleetAsset {
  id: string;
  assetNo: string;
  name: string;
  assetType: string;
  registrationNo?: string;
  make?: string;
  model?: string;
  year?: number;
  status: string;
  fuelType?: string;
  lastGpsReading?: { latitude: number; longitude: number; recordedAt: string; speedKph?: number };
  activeAlerts: number;
  branchId: string;
}
interface PagedAssets {
  items: FleetAsset[];
  total: number;
  hasMore: boolean;
}

const STATUS_DOT: Record<string, string> = {
  AVAILABLE: '#16A34A',
  IN_USE: '#0EA5E9',
  UNDER_MAINTENANCE: '#D97706',
  OUT_OF_SERVICE: '#DC2626',
  DISPOSED: '#9CA3AF',
};

export default function FleetAssetsPage() {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const { user } = useAuthStore();

  const params = buildSearchParams({
    q,
    status,
    branchId: user?.isSuperAdmin ? undefined : user?.branchId,
    limit: 24,
    page,
  });

  const { data, isLoading, isFetching } = useQuery({
    queryKey: queryKeys.fleetAssets.list({ q, status, page }),
    queryFn: () => api.get<PagedAssets>(`/fleet/assets?${params}`),
    staleTime: 30_000,
    refetchInterval: 60_000, // Refresh every minute for live GPS status
    placeholderData: (prev) => prev,
  });

  const STATUSES = ['AVAILABLE', 'IN_USE', 'UNDER_MAINTENANCE', 'OUT_OF_SERVICE'];

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Fleet Assets</h1>
          <p className="text-[12px] text-[#6B7280] mt-0.5">
            {data?.total !== undefined ? `${data.total.toLocaleString()} assets` : 'Loading…'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href="/fleet/tracking"
            className="flex items-center gap-1.5 px-3 py-2 rounded-md text-[12px] font-medium border border-[#E5E7EB] hover:bg-[#F7F4EF] text-[#1A1A1A] transition-colors"
          >
            <MapPin className="h-3.5 w-3.5" /> Live Map
          </Link>
          <Link
            href="/fleet/assets/new"
            className="flex items-center gap-1.5 px-4 py-2 rounded-md text-sm font-medium text-white"
            style={{ background: '#1A4D2E' }}
          >
            <Plus className="h-4 w-4" /> New Asset
          </Link>
        </div>
      </div>

      {/* Status summary pills */}
      {data && (
        <div className="flex items-center gap-2 flex-wrap">
          {STATUSES.map((s) => {
            const count = data.items.filter((a) => a.status === s).length;
            return (
              <button
                key={s}
                onClick={() => {
                  setStatus(status === s ? '' : s);
                  setPage(1);
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium border transition-colors"
                style={
                  status === s
                    ? {
                        background: STATUS_DOT[s] ?? '#6B7280',
                        color: '#fff',
                        borderColor: 'transparent',
                      }
                    : { borderColor: '#E5E7EB', color: '#6B7280' }
                }
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: status === s ? '#fff' : (STATUS_DOT[s] ?? '#6B7280') }}
                />
                {s.replace(/_/g, ' ')} ({count})
              </button>
            );
          })}
          <div className="flex-1" />
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#9CA3AF]" />
            <input
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(1);
              }}
              placeholder="Search assets…"
              className="pl-8 pr-3 h-8 w-[200px] text-[13px] rounded-md border border-[#D1D5DB] bg-white focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
            />
          </div>
          {isFetching && !isLoading && (
            <span className="h-4 w-4 rounded-full border-2 border-[#1A4D2E] border-t-transparent animate-spin" />
          )}
        </div>
      )}

      {/* Asset cards grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-lg border border-[#E5E7EB] p-4 space-y-3 animate-pulse"
            >
              <div className="flex items-center justify-between">
                <div className="h-4 w-20 bg-[#F3F4F6] rounded" />
                <div className="h-4 w-16 bg-[#F3F4F6] rounded" />
              </div>
              <div className="h-5 w-3/4 bg-[#F3F4F6] rounded" />
              <div className="h-3 w-1/2 bg-[#F3F4F6] rounded" />
              <div className="h-3 w-2/3 bg-[#F3F4F6] rounded" />
            </div>
          ))
        ) : (data?.items ?? []).length === 0 ? (
          <div className="col-span-full py-16 text-center">
            <Truck className="h-12 w-12 mx-auto mb-3 text-[#D1D5DB]" />
            <p className="text-[13px] text-[#9CA3AF]">No fleet assets found</p>
          </div>
        ) : (
          (data?.items ?? []).map((asset) => {
            const ss = getStatusStyle(asset.status);
            const dotColor = STATUS_DOT[asset.status] ?? '#9CA3AF';
            return (
              <Link
                key={asset.id}
                href={`/fleet/assets/${asset.id}`}
                className="bg-white rounded-lg border border-[#E5E7EB] p-4 hover:shadow-md transition-shadow animate-fade-up group"
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: dotColor }} />
                    <span
                      className="font-mono text-[11px] font-semibold"
                      style={{ color: '#1A4D2E' }}
                    >
                      {asset.assetNo}
                    </span>
                  </div>
                  <span
                    className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                    style={{ background: ss.bg, color: ss.color }}
                  >
                    {asset.status.replace(/_/g, ' ')}
                  </span>
                </div>

                {/* Name */}
                <div className="font-medium text-[13px] text-[#1A1A1A] group-hover:text-[#1A4D2E] transition-colors mb-1">
                  {asset.name}
                </div>

                {/* Details */}
                <div className="text-[11px] text-[#6B7280] space-y-0.5 mb-3">
                  <div>{[asset.make, asset.model, asset.year].filter(Boolean).join(' ')}</div>
                  {asset.registrationNo && <div className="font-mono">{asset.registrationNo}</div>}
                  <div className="text-[10px] uppercase tracking-wide">
                    {asset.assetType.replace(/_/g, ' ')}
                  </div>
                </div>

                {/* GPS status */}
                {asset.lastGpsReading ? (
                  <div className="flex items-center gap-1.5 text-[11px] text-[#6B7280]">
                    <MapPin className="h-3 w-3 text-[#0EA5E9]" />
                    <span>Last seen {formatRelative(asset.lastGpsReading.recordedAt)}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-[11px] text-[#9CA3AF]">
                    <MapPin className="h-3 w-3" />
                    <span>No GPS data</span>
                  </div>
                )}

                {/* Alerts */}
                {asset.activeAlerts > 0 && (
                  <div className="mt-2 flex items-center gap-1 text-[11px] text-[#DC2626]">
                    <AlertTriangle className="h-3 w-3" />
                    {asset.activeAlerts} active alert{asset.activeAlerts > 1 ? 's' : ''}
                  </div>
                )}
              </Link>
            );
          })
        )}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] text-[#6B7280]">{data?.total?.toLocaleString()} assets</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
          >
            ← Prev
          </button>
          <span className="text-[11px] text-[#6B7280] w-10 text-center">{page}</span>
          <button
            onClick={() => setPage((p) => p + 1)}
            disabled={!data?.hasMore}
            className="px-2.5 py-1 text-[11px] rounded border border-[#E5E7EB] disabled:opacity-40 hover:bg-[#F7F4EF]"
          >
            Next →
          </button>
        </div>
      </div>
    </div>
  );
}
