'use client';
import { useQuery } from '@tanstack/react-query';
import { Activity, Fuel, AlertTriangle, MapPin, Radio } from 'lucide-react';
import { useEffect, useState, useRef } from 'react';
import { io } from 'socket.io-client';
import type { Socket } from 'socket.io-client';

import { api } from '../../../../lib/api';
import { formatDate } from '../../../../lib/utils';
import { useAuthStore } from '../../../../stores/auth.store';

interface Asset {
  id: string;
  assetCode: string;
  name: string;
  make: string;
  model: string;
  status: 'ACTIVE' | 'IDLE' | 'OFFLINE' | 'MAINTENANCE';
  lastLat?: number;
  lastLng?: number;
  lastSpeed?: number;
  fuelLevel?: number;
  engineHours?: number;
  lastPing?: string;
  driver?: { firstName: string; lastName: string };
  alerts: Array<{ type: string; message: string; createdAt: string }>;
}

export default function GpsLivePage() {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [liveAssets, setLiveAssets] = useState<Map<string, Partial<Asset>>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const { user } = useAuthStore();

  const branchParam = user?.branchId && !user.isSuperAdmin ? `&branchId=${user.branchId}` : '';

  const { data, isLoading } = useQuery({
    queryKey: ['fleet-assets-live'],
    queryFn: () =>
      api.get<{ items: Asset[] }>(`/fleet/assets?status=ACTIVE,IDLE&limit=100${branchParam}`),
    staleTime: 60_000,
  });

  // Socket.IO for live GPS updates — §5 Realtime: Socket.IO
  useEffect(() => {
    const socket = io(process.env['NEXT_PUBLIC_API_URL'] ?? 'http://localhost:3001', {
      path: '/socket.io',
      auth: { token: localStorage.getItem('access_token') ?? '' },
    });

    socket.on('connect', () => setIsConnected(true));
    socket.on('disconnect', () => setIsConnected(false));
    socket.on(
      'gps:update',
      (update: {
        assetId: string;
        lat: number;
        lng: number;
        speed: number;
        fuelLevel?: number;
        timestamp: string;
      }) => {
        setLiveAssets((prev) => {
          const next = new Map(prev);
          next.set(update.assetId, {
            ...next.get(update.assetId),
            lastLat: update.lat,
            lastLng: update.lng,
            lastSpeed: update.speed,
            fuelLevel: update.fuelLevel,
            lastPing: update.timestamp,
            status: 'ACTIVE',
          });
          return next;
        });
      },
    );

    socketRef.current = socket;
    return () => {
      socket.disconnect();
    };
  }, []);

  const statusColor: Record<string, { bg: string; color: string; dot: string }> = {
    ACTIVE: { bg: '#DCFCE7', color: '#15803D', dot: '#16A34A' },
    IDLE: { bg: '#FEF3C7', color: '#92400E', dot: '#D97706' },
    OFFLINE: { bg: '#F3F4F6', color: '#6B7280', dot: '#9CA3AF' },
    MAINTENANCE: { bg: '#FEE2E2', color: '#B91C1C', dot: '#DC2626' },
  };

  const assets = data?.items ?? [];
  const selected = assets.find((a) => a.id === selectedId);
  const liveData = selectedId ? liveAssets.get(selectedId) : null;

  const assetCounts = {
    active: assets.filter((a) => a.status === 'ACTIVE').length,
    idle: assets.filter((a) => a.status === 'IDLE').length,
    offline: assets.filter((a) => a.status === 'OFFLINE').length,
    maintenance: assets.filter((a) => a.status === 'MAINTENANCE').length,
  };

  return (
    <div className="p-6 max-w-screen-xl mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-xl text-[#1A1A1A]">Live Fleet Tracking</h1>
          <div className="flex items-center gap-2 mt-0.5">
            <span
              className={`h-2 w-2 rounded-full ${isConnected ? 'bg-[#16A34A]' : 'bg-[#DC2626]'} animate-pulse`}
            />
            <p className="text-[12px] text-[#6B7280]">
              {isConnected ? `Live — ${assets.length} assets` : 'Connecting to live feed…'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <Radio className="h-4 w-4" style={{ color: isConnected ? '#16A34A' : '#9CA3AF' }} />
          <span
            className="text-[12px] font-medium"
            style={{ color: isConnected ? '#16A34A' : '#9CA3AF' }}
          >
            {isConnected ? 'Socket connected' : 'Offline'}
          </span>
        </div>
      </div>

      {/* Fleet status summary */}
      <div className="grid grid-cols-4 gap-3">
        {[
          {
            label: 'Active',
            value: assetCounts.active,
            dot: '#16A34A',
            bg: '#DCFCE7',
            color: '#15803D',
          },
          {
            label: 'Idle',
            value: assetCounts.idle,
            dot: '#D97706',
            bg: '#FEF3C7',
            color: '#92400E',
          },
          {
            label: 'Offline',
            value: assetCounts.offline,
            dot: '#9CA3AF',
            bg: '#F3F4F6',
            color: '#6B7280',
          },
          {
            label: 'Maintenance',
            value: assetCounts.maintenance,
            dot: '#DC2626',
            bg: '#FEE2E2',
            color: '#B91C1C',
          },
        ].map((s) => (
          <div
            key={s.label}
            className="bg-white rounded-lg border border-[#E5E7EB] p-3 flex items-center gap-3"
          >
            <span className="h-3 w-3 rounded-full flex-shrink-0" style={{ background: s.dot }} />
            <div>
              <div className="text-[20px] font-semibold font-mono" style={{ color: s.color }}>
                {isLoading ? '—' : s.value}
              </div>
              <div className="text-[10px] text-[#6B7280]">{s.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-4">
        {/* Asset list panel */}
        <div className="w-[320px] flex-shrink-0 bg-white rounded-lg border border-[#E5E7EB] overflow-hidden">
          <div className="px-4 py-3 border-b border-[#E5E7EB]">
            <span className="text-[12px] font-semibold text-[#1A1A1A]">Fleet assets</span>
          </div>
          <div className="overflow-y-auto" style={{ maxHeight: '520px' }}>
            {isLoading
              ? Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="px-4 py-3 border-b border-[#F3F4F6] animate-pulse">
                    <div className="h-4 bg-[#F3F4F6] rounded w-32 mb-1" />
                    <div className="h-3 bg-[#F3F4F6] rounded w-20" />
                  </div>
                ))
              : assets.map((asset) => {
                  const live = liveAssets.get(asset.id);
                  const sc = statusColor[live?.status ?? asset.status] ?? statusColor['OFFLINE']!;
                  const hasAlert = asset.alerts?.length > 0;
                  return (
                    <button
                      key={asset.id}
                      onClick={() => setSelectedId(selectedId === asset.id ? null : asset.id)}
                      className="w-full px-4 py-3 border-b border-[#F3F4F6] text-left transition-colors flex items-start gap-3"
                      style={{ background: selectedId === asset.id ? '#F7F4EF' : undefined }}
                    >
                      <span
                        className="h-2.5 w-2.5 rounded-full mt-1 flex-shrink-0"
                        style={{ background: sc.dot }}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="text-[12px] font-medium text-[#1A1A1A] truncate">
                            {asset.name}
                          </span>
                          {hasAlert && (
                            <AlertTriangle className="h-3.5 w-3.5 text-[#DC2626] flex-shrink-0" />
                          )}
                        </div>
                        <span className="font-mono text-[10px] text-[#9CA3AF]">
                          {asset.assetCode}
                        </span>
                        <div className="flex items-center gap-2 mt-1">
                          <span
                            className="text-[9.5px] px-1.5 py-0.5 rounded font-semibold"
                            style={{ background: sc.bg, color: sc.color }}
                          >
                            {live?.status ?? asset.status}
                          </span>
                          {(live?.lastSpeed ?? asset.lastSpeed) !== undefined && (
                            <span className="text-[10px] text-[#6B7280]">
                              {live?.lastSpeed ?? asset.lastSpeed} km/h
                            </span>
                          )}
                        </div>
                      </div>
                    </button>
                  );
                })}
          </div>
        </div>

        {/* Detail / map panel */}
        <div className="flex-1 bg-white rounded-lg border border-[#E5E7EB] overflow-hidden flex flex-col">
          {!selected ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 text-center p-8">
              <MapPin className="h-12 w-12 text-[#D1D5DB]" />
              <p className="text-[13px] font-medium text-[#6B7280]">
                Select an asset to view live details
              </p>
              <p className="text-[12px] text-[#9CA3AF]">
                GPS coordinates and telemetry will appear here
              </p>
            </div>
          ) : (
            <div className="p-5 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-[16px] font-semibold text-[#1A1A1A]">{selected.name}</h2>
                  <p className="text-[12px] text-[#6B7280]">
                    {selected.make} {selected.model} · {selected.assetCode}
                  </p>
                </div>
                <span
                  className="text-[11px] px-2 py-1 rounded font-semibold"
                  style={{
                    background: statusColor[liveData?.status ?? selected.status]?.bg,
                    color: statusColor[liveData?.status ?? selected.status]?.color,
                  }}
                >
                  {liveData?.status ?? selected.status}
                </span>
              </div>

              {/* Telemetry grid */}
              <div className="grid grid-cols-3 gap-3">
                {[
                  {
                    label: 'Speed',
                    value: `${liveData?.lastSpeed ?? selected.lastSpeed ?? 0} km/h`,
                    icon: Activity,
                  },
                  {
                    label: 'Fuel level',
                    value: `${liveData?.fuelLevel ?? selected.fuelLevel ?? 0}%`,
                    icon: Fuel,
                  },
                  {
                    label: 'Engine hours',
                    value: `${selected.engineHours ?? '—'} hrs`,
                    icon: Activity,
                  },
                ].map((m) => (
                  <div key={m.label} className="bg-[#F7F4EF] rounded-lg p-3">
                    <div className="flex items-center gap-1.5 mb-1">
                      <m.icon className="h-3.5 w-3.5 text-[#6B7280]" />
                      <span className="text-[10px] text-[#6B7280] uppercase tracking-wide font-semibold">
                        {m.label}
                      </span>
                    </div>
                    <span className="text-[18px] font-semibold font-mono text-[#1A1A1A]">
                      {m.value}
                    </span>
                  </div>
                ))}
              </div>

              {/* GPS coords */}
              <div className="bg-[#F7F4EF] rounded-lg p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <MapPin className="h-3.5 w-3.5 text-[#1A4D2E]" />
                  <span className="text-[11px] font-semibold text-[#1A4D2E] uppercase tracking-wide">
                    GPS position
                  </span>
                  <span className="ml-auto text-[10px] text-[#9CA3AF]">
                    Last ping:{' '}
                    {liveData?.lastPing
                      ? formatDate(liveData.lastPing)
                      : formatDate(selected.lastPing ?? '')}
                  </span>
                </div>
                <div className="font-mono text-[13px] text-[#1A1A1A]">
                  {(liveData?.lastLat ?? selected.lastLat)
                    ? `${(liveData?.lastLat ?? selected.lastLat)?.toFixed(6)}, ${(liveData?.lastLng ?? selected.lastLng)?.toFixed(6)}`
                    : 'No GPS fix'}
                </div>
              </div>

              {/* Driver */}
              {selected.driver && (
                <div className="flex items-center gap-3 p-3 bg-[#F7F4EF] rounded-lg">
                  <div className="h-8 w-8 rounded-full bg-[#1A4D2E] flex items-center justify-center text-white text-[11px] font-semibold">
                    {selected.driver.firstName[0]}
                    {selected.driver.lastName[0]}
                  </div>
                  <div>
                    <div className="text-[12px] font-medium text-[#1A1A1A]">
                      {selected.driver.firstName} {selected.driver.lastName}
                    </div>
                    <div className="text-[10px] text-[#6B7280]">Assigned driver</div>
                  </div>
                </div>
              )}

              {/* Alerts */}
              {selected.alerts?.length > 0 && (
                <div className="space-y-2">
                  <span className="text-[11px] font-semibold text-[#DC2626] uppercase tracking-wide">
                    Active alerts
                  </span>
                  {selected.alerts.map((alert, i) => (
                    <div
                      key={i}
                      className="flex items-start gap-2 p-3 bg-[#FEF2F2] rounded-lg border border-[#FECACA]"
                    >
                      <AlertTriangle className="h-4 w-4 text-[#DC2626] mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="text-[12px] font-medium text-[#B91C1C]">
                          {alert.type.replace(/_/g, ' ')}
                        </div>
                        <div className="text-[11px] text-[#DC2626]">{alert.message}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
