'use client';
/**
 * AGCOMS DealerSync ERP — /erp Route Group Layout
 * Sprint 2 Fix S2-01: This file was completely missing.
 * All 34 ERP pages were rendering in an isolated void with no navigation.
 *
 * This layout:
 *   1. Wraps all /erp/* pages with the QueryClientProvider (S2-04)
 *   2. Enforces authentication — redirects to /auth/login if no token
 *   3. Renders the Sidebar + Header shell (S2-03)
 *   4. Manages sidebar collapse state
 *   5. Provides the mobile bottom navigation for §8 mobile-first
 *   6. Mounts the OnboardingTour for first-login users
 */
import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { QueryProvider } from '../../providers/QueryProvider';
import { Sidebar } from '../../components/layout/Sidebar';
import { Header } from '../../components/layout/Header';
import { MobileNav } from '../../components/layout/MobileNav';
import { OnboardingTour } from '../../components/onboarding/OnboardingTour';
import { useAuthStore } from '../../stores/auth.store';
import { cn } from '../../lib/cn';

interface ErpLayoutProps {
  children: React.ReactNode;
}

export default function ErpLayout({ children }: ErpLayoutProps) {
  const { user, accessToken } = useAuthStore();
  const router = useRouter();
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // ── Auth guard — redirect unauthenticated users ───────────────────────
  useEffect(() => {
    if (!accessToken && !user) {
      router.replace(`/auth/login?redirect=${encodeURIComponent(pathname)}`);
    }
  }, [accessToken, user, router, pathname]);

  // ── Persist sidebar collapse to localStorage ──────────────────────────
  useEffect(() => {
    const stored = localStorage.getItem('sidebar_collapsed');
    if (stored !== null) setCollapsed(stored === 'true');
  }, []);

  const handleCollapseToggle = () => {
    setCollapsed((prev) => {
      localStorage.setItem('sidebar_collapsed', String(!prev));
      return !prev;
    });
  };

  // Show nothing while checking auth (avoids flash of protected content)
  if (!accessToken && !user) return null;

  return (
    <QueryProvider>
      <div className="flex h-screen bg-[#F7F4EF] overflow-hidden">
        {/* ── Desktop Sidebar ────────────────────────────────────────── */}
        <aside
          className={cn(
            'hidden lg:flex flex-col flex-shrink-0 border-r border-[#E5E7EB] bg-white',
            'transition-[width] duration-200 ease-in-out overflow-hidden',
            collapsed ? 'w-[60px]' : 'w-[220px]',
          )}
          aria-label="Main navigation"
        >
          <Sidebar collapsed={collapsed} onCollapseToggle={handleCollapseToggle} />
        </aside>

        {/* ── Mobile sidebar overlay ─────────────────────────────────── */}
        {mobileSidebarOpen && (
          <>
            <div
              className="fixed inset-0 z-30 bg-black/50 lg:hidden"
              onClick={() => setMobileSidebarOpen(false)}
              aria-hidden="true"
            />
            <aside
              className="fixed inset-y-0 left-0 z-40 w-[260px] bg-white border-r border-[#E5E7EB] flex flex-col lg:hidden"
              aria-label="Mobile navigation"
            >
              <Sidebar
                collapsed={false}
                onCollapseToggle={() => setMobileSidebarOpen(false)}
                isMobile
              />
            </aside>
          </>
        )}

        {/* ── Main content area ──────────────────────────────────────── */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
          <Header onMobileMenuToggle={() => setMobileSidebarOpen((o) => !o)} />

          <main id="main-content" className="flex-1 overflow-y-auto pb-safe" tabIndex={-1}>
            {children}
          </main>

          {/* ── Mobile bottom navigation — §8 mobile-first ────────── */}
          <MobileNav />
        </div>
      </div>

      {/* Onboarding tour — first login only (§8 UX: onboarding tours) */}
      <OnboardingTour tourId="dashboard" />
    </QueryProvider>
  );
}
