/**
 * AGCOMS DealerSync ERP — Auth Store (Zustand)
 * §3 State: Zustand for lightweight UI state
 * Persists authenticated user context across page navigation.
 */
import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface AuthUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  role: string;
  permissions: string[];
  branchId: string;
  branchCode: string;
  branchName: string;
  isSuperAdmin: boolean;
  mfaEnabled: boolean;
  avatarUrl?: string;
}

interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  isLoading: boolean;
  lastActivity: number;
  setUser: (user: AuthUser, token: string) => void;
  clearAuth: () => void;
  hasPermission: (permission: string) => boolean;
  hasRole: (role: string) => boolean;
  updateToken: (token: string) => void;
  setLoading: (loading: boolean) => void;
  step: 'login' | 'credentials' | 'mfa' | 'done' | 'authenticated';
  error: string | null;
  clearError: () => void;
  setStep: (step: 'login' | 'credentials' | 'mfa' | 'done' | 'authenticated') => void;
  setError: (error: string | null) => void;
  verifyMfa: (code: string) => Promise<boolean>;
  login: (email: string, password: string) => Promise<void>;
  challengeToken: string | null;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      isLoading: false,
      lastActivity: Date.now(),
      challengeToken: null,
      step: 'login' as const,
      error: null,

      setUser: (user, token) => {
        // S2-08 Fix: access token in memory only (not localStorage — XSS risk)
        set({ user, accessToken: token, lastActivity: Date.now() });
      },

      clearAuth: () => {
        // S2-08 Fix: httpOnly refresh cookie cleared by server on /auth/logout
        set({ user: null, accessToken: null });
      },

      updateToken: (token) => {
        // S2-08 Fix: access token in memory only (not localStorage — XSS risk)
        set({ accessToken: token, lastActivity: Date.now() });
      },

      hasPermission: (permission) => {
        const { user } = get();
        if (!user) return false;
        if (user.isSuperAdmin) return true;
        return user.permissions.includes(permission);
      },

      hasRole: (role) => {
        const { user } = get();
        if (!user) return false;
        if (user.isSuperAdmin) return true;
        return user.role === role;
      },

      setLoading: (isLoading) => set({ isLoading }),
      clearError: () => set({ error: null }),
      setStep: (step) => set({ step }),
      setError: (error) => set({ error }),
      verifyMfa: async (_code: string) => {
        /* Implemented in auth service */ return false;
      },
      login: async (_email: string, _password: string) => {
        /* Implemented in auth service */
      },
    }),
    {
      name: 'agcoms_auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        user: state.user,
        // S2-08 Fix: accessToken NOT persisted to localStorage
        lastActivity: state.lastActivity,
      }),
    },
  ),
);
