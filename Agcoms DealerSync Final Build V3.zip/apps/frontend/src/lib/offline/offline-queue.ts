/**
 * AGCOMS DealerSync ERP — Offline Queue (IndexedDB)
 * Sprint 4 / S4-C: Offline-first mutations for field technicians.
 *
 * Field technicians service tractors on NADF farms in rural Nigeria where
 * mobile connectivity is intermittent. This module queues mutations
 * (job card updates, GPS delivery confirmations) in IndexedDB when offline
 * and replays them automatically when the connection is restored.
 *
 * Uses the `idb` library for a promise-based IndexedDB API.
 *
 * Queued mutation types:
 *   - JOB_CARD_UPDATE       — complete checklist, record labour hours
 *   - JOB_CARD_COMPLETE     — mark job card as completed
 *   - DELIVERY_CONFIRM      — GPS-confirmed NADF tractor delivery
 *   - STOCK_ADJUSTMENT      — quick stock count updates
 *
 * Conflict resolution: last-write-wins (ERP context — field updates are
 * typically append-only and don't conflict with office edits).
 */

import { openDB, type IDBPDatabase } from 'idb';

const DB_NAME = 'agcoms_offline_queue';
const DB_VERSION = 1;
const STORE_NAME = 'mutations';

export type OfflineMutationType =
  | 'JOB_CARD_UPDATE'
  | 'JOB_CARD_COMPLETE'
  | 'DELIVERY_CONFIRM'
  | 'STOCK_ADJUSTMENT';

export interface OfflineMutation {
  id: string; // UUID generated client-side
  type: OfflineMutationType;
  endpoint: string; // API path: /api/v1/workshop/job-cards/:id
  method: 'POST' | 'PATCH' | 'PUT';
  payload: unknown; // Request body
  createdAt: number; // Date.now() — for ordering on replay
  retryCount: number; // Number of replay attempts
  lastError?: string; // Last error message if replay failed
  status: 'PENDING' | 'SYNCING' | 'SYNCED' | 'FAILED';
}

class OfflineQueueService {
  private db: IDBPDatabase | null = null;

  async init(): Promise<void> {
    if (typeof window === 'undefined') return; // SSR guard
    this.db = await openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
          store.createIndex('status', 'status', { unique: false });
          store.createIndex('createdAt', 'createdAt', { unique: false });
          store.createIndex('type', 'type', { unique: false });
        }
      },
    });
  }

  private async getDb(): Promise<IDBPDatabase> {
    if (!this.db) await this.init();
    if (!this.db) throw new Error('IndexedDB not available');
    return this.db;
  }

  /** Enqueue a mutation for later replay */
  async enqueue(
    mutation: Omit<OfflineMutation, 'id' | 'createdAt' | 'retryCount' | 'status'>,
  ): Promise<string> {
    const db = await this.getDb();
    const id = crypto.randomUUID();
    const entry: OfflineMutation = {
      ...mutation,
      id,
      createdAt: Date.now(),
      retryCount: 0,
      status: 'PENDING',
    };
    await db.put(STORE_NAME, entry);
    return id;
  }

  /** Get all pending mutations ordered by creation time */
  async getPending(): Promise<OfflineMutation[]> {
    const db = await this.getDb();
    const all = await db.getAllFromIndex(STORE_NAME, 'status', 'PENDING');
    return all.sort((a, b) => a.createdAt - b.createdAt);
  }

  /** Update mutation status after replay attempt */
  async updateStatus(id: string, status: OfflineMutation['status'], error?: string): Promise<void> {
    const db = await this.getDb();
    const existing = (await db.get(STORE_NAME, id)) as OfflineMutation | undefined;
    if (!existing) return;
    await db.put(STORE_NAME, {
      ...existing,
      status,
      retryCount: existing.retryCount + (status === 'FAILED' ? 1 : 0),
      lastError: error,
    });
  }

  /** Remove successfully synced mutations */
  async clearSynced(): Promise<number> {
    const db = await this.getDb();
    const synced = await db.getAllFromIndex(STORE_NAME, 'status', 'SYNCED');
    const tx = db.transaction(STORE_NAME, 'readwrite');
    await Promise.all(synced.map((m) => tx.store.delete(m.id)));
    await tx.done;
    return synced.length;
  }

  /** Count pending mutations (for badge display) */
  async pendingCount(): Promise<number> {
    const db = await this.getDb();
    const idx = db.transaction(STORE_NAME).store.index('status');
    return idx.count('PENDING');
  }

  /** Replay all pending mutations against the live API */
  async replayAll(accessToken: string): Promise<{
    replayed: number;
    failed: number;
    errors: string[];
  }> {
    const pending = await this.getPending();
    let replayed = 0;
    let failed = 0;
    const errors: string[] = [];

    for (const mutation of pending) {
      await this.updateStatus(mutation.id, 'SYNCING');
      try {
        const res = await fetch(mutation.endpoint, {
          method: mutation.method,
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${accessToken}`,
            'X-Offline-Sync': '1', // Header so backend can identify offline replays
          },
          body: JSON.stringify(mutation.payload),
        });

        if (!res.ok) {
          const errorText = await res.text().catch(() => `HTTP ${res.status}`);
          throw new Error(errorText);
        }

        await this.updateStatus(mutation.id, 'SYNCED');
        replayed++;
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        await this.updateStatus(mutation.id, 'FAILED', errMsg);
        errors.push(`${mutation.type}: ${errMsg}`);
        failed++;
      }
    }

    // Clean up synced entries after replay
    await this.clearSynced();

    return { replayed, failed, errors };
  }
}

// Singleton
export const offlineQueue = new OfflineQueueService();
