'use client';
/**
 * AGCOMS DealerSync ERP — useOfflineSync hook
 * Sprint 4 / S4-C: Manages offline state, connectivity detection, and mutation replay.
 *
 * Usage in any field-facing component:
 *   const { isOnline, pendingCount, syncNow, isSyncing } = useOfflineSync();
 *
 * The hook:
 *   - Monitors navigator.onLine events
 *   - Auto-replays the offline queue when connectivity is restored
 *   - Exposes pending mutation count for badge display
 *   - Provides syncNow() for manual sync trigger
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'sonner';

import { useAuthStore } from '../../stores/auth.store';
import { offlineQueue, type OfflineMutation } from '../offline/offline-queue';

interface OfflineSyncState {
  isOnline: boolean;
  pendingCount: number;
  isSyncing: boolean;
  lastSyncAt: Date | null;
  lastSyncResult: { replayed: number; failed: number } | null;
  syncNow: () => Promise<void>;
  enqueue: (
    mutation: Omit<OfflineMutation, 'id' | 'createdAt' | 'retryCount' | 'status'>,
  ) => Promise<string>;
}

export function useOfflineSync(): OfflineSyncState {
  const [isOnline, setIsOnline] = useState(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  );
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncAt, setLastSyncAt] = useState<Date | null>(null);
  const [lastSyncResult, setLastSyncResult] = useState<{ replayed: number; failed: number } | null>(
    null,
  );
  const syncInProgress = useRef(false);
  const { accessToken } = useAuthStore();

  // Initialise the IndexedDB queue
  useEffect(() => {
    offlineQueue.init().catch(console.error);
  }, []);

  // Refresh pending count periodically
  const refreshCount = useCallback(async () => {
    try {
      const count = await offlineQueue.pendingCount();
      setPendingCount(count);
    } catch {
      /* IndexedDB not available — ignore */
    }
  }, []);

  useEffect(() => {
    void refreshCount();
    const interval = setInterval(() => {
      void refreshCount();
    }, 15_000);
    return () => clearInterval(interval);
  }, [refreshCount]);

  // Sync function
  const syncNow = useCallback(async () => {
    if (syncInProgress.current || !accessToken) return;
    syncInProgress.current = true;
    setIsSyncing(true);
    try {
      const result = await offlineQueue.replayAll(accessToken);
      setLastSyncAt(new Date());
      setLastSyncResult({ replayed: result.replayed, failed: result.failed });
      await refreshCount();

      if (result.replayed > 0) {
        toast.success(`Synced ${result.replayed} offline action${result.replayed > 1 ? 's' : ''}`, {
          description:
            result.failed > 0 ? `${result.failed} failed — will retry` : 'All synced successfully',
        });
      }
      if (result.failed > 0 && result.replayed === 0) {
        toast.error(`Sync failed for ${result.failed} action${result.failed > 1 ? 's' : ''}`, {
          description: result.errors[0],
        });
      }
    } catch (err) {
      toast.error('Sync error', { description: String(err) });
    } finally {
      syncInProgress.current = false;
      setIsSyncing(false);
    }
  }, [accessToken, refreshCount]);

  // Listen to online/offline events
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.info('Connection restored — syncing offline actions…', { duration: 3000 });
      // Auto-sync after 2s delay (give connection time to stabilise)
      setTimeout(() => {
        void syncNow();
      }, 2000);
    };

    const handleOffline = () => {
      setIsOnline(false);
      toast.warning('You are offline. Actions will be saved and synced when reconnected.', {
        duration: 5000,
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [syncNow]);

  const enqueue = useCallback(
    (mutation: Omit<OfflineMutation, 'id' | 'createdAt' | 'retryCount' | 'status'>) => {
      const id = offlineQueue.enqueue(mutation);
      void refreshCount();
      return id;
    },
    [refreshCount],
  );

  return { isOnline, pendingCount, isSyncing, lastSyncAt, lastSyncResult, syncNow, enqueue };
}
