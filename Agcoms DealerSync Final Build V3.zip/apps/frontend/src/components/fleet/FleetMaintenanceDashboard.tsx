'use client';
/**
 * AGCOMS DealerSync ERP — Fleet Maintenance Risk Dashboard
 * Sprint 6 / S6-A: Predictive maintenance status for all fleet assets.
 */
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { RefreshCw, Wrench } from 'lucide-react';
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { api } from '../../lib/api';
import { Button } from '../ui/button';
import { StatusBadge } from '../ui/status-badge';
import { cn } from '../../lib/cn';
import { toast } from 'sonner';

interface MaintenanceScore {
  id: string;
  riskLevel: 'CRITICAL' | 'HIGH' | 'MODERATE' | 'LOW';
  riskScore: number;
  engineHoursNow: number;
  hoursSinceService?: number;
  anomalyFlags: string[];
  aiRecommendation?: string;
  recommendedServiceDate?: string;
  scoredAt: string;
  asset: {
    assetCode: string;
    name: string;
    make: string;
    model: string;
    status: string;
    lastPing: string | null;
  };
}

interface Summary {
  CRITICAL: number;
  HIGH: number;
  MODERATE: number;
  LOW: number;
  total: number;
}

const RISK_COLOURS: Record<string, string> = {
  CRITICAL: '#DC2626',
  HIGH: '#D97706',
  MODERATE: '#2563EB',
  LOW: '#16A34A',
};

const _RISK_BG: Record<string, string> = {
  CRITICAL: '#FEF2F2',
  HIGH: '#FFFBEB',
  MODERATE: '#EFF6FF',
  LOW: '#F0FDF4',
};

export function FleetMaintenanceDashboard() {
  const qc = useQueryClient();

  const { data: summary } = useQuery({
    queryKey: ['fleet-maintenance-summary'],
    queryFn: () => api.get<Summary>('/fleet/maintenance/summary'),
    staleTime: 60_000,
  });

  const { data: scores, isLoading } = useQuery({
    queryKey: ['fleet-maintenance-scores'],
    queryFn: () => api.get<MaintenanceScore[]>('/fleet/maintenance/scores'),
    staleTime: 60_000,
  });

  const scoreMutation = useMutation({
    mutationFn: () =>
      api.post<{ scored: number; critical: number; high: number }>('/fleet/maintenance/score'),
    onSuccess: (d) => {
      toast.success(`Fleet scoring complete`, {
        description: `${d.scored} assets scored — ${d.critical} critical, ${d.high} high`,
      });
      qc.invalidateQueries({ queryKey: ['fleet-maintenance'] });
    },
    onError: () => toast.error('Fleet scoring failed'),
  });

  // Chart data
  const chartData = [
    { label: 'Critical', count: summary?.CRITICAL ?? 0, fill: RISK_COLOURS.CRITICAL },
    { label: 'High', count: summary?.HIGH ?? 0, fill: RISK_COLOURS.HIGH },
    { label: 'Moderate', count: summary?.MODERATE ?? 0, fill: RISK_COLOURS.MODERATE },
    { label: 'Low', count: summary?.LOW ?? 0, fill: RISK_COLOURS.LOW },
  ];

  return (
    <div className="space-y-4">
      {/* Summary cards + chart */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {(['CRITICAL', 'HIGH', 'MODERATE', 'LOW'] as const).map((level) => (
          <div
            key={level}
            className={cn(
              'rounded-xl border p-4',
              level === 'CRITICAL'
                ? 'border-[#FECACA] bg-[#FEF2F2]'
                : level === 'HIGH'
                  ? 'border-[#FED7AA] bg-[#FFFBEB]'
                  : level === 'MODERATE'
                    ? 'border-[#BFDBFE] bg-[#EFF6FF]'
                    : 'border-[#BBF7D0] bg-[#F0FDF4]',
            )}
          >
            <p
              className="text-[10px] font-semibold uppercase tracking-wider mb-1"
              style={{ color: RISK_COLOURS[level] }}
            >
              {level}
            </p>
            <p className="text-[28px] font-semibold" style={{ color: RISK_COLOURS[level] }}>
              {summary?.[level] ?? '—'}
            </p>
            <p className="text-[10px] text-[#9CA3AF] mt-0.5">assets</p>
          </div>
        ))}

        {/* Mini bar chart */}
        <div className="rounded-xl border border-[#E5E7EB] bg-white p-4 lg:col-span-1">
          <p className="text-[10px] font-semibold text-[#9CA3AF] uppercase tracking-wider mb-2">
            Distribution
          </p>
          <ResponsiveContainer width="100%" height={60}>
            <BarChart data={chartData} barCategoryGap="20%">
              <Bar dataKey="count" radius={[3, 3, 0, 0]}>
                {chartData.map((d, i) => (
                  <Cell key={i} fill={d.fill} />
                ))}
              </Bar>
              <XAxis
                dataKey="label"
                tick={{ fontSize: 8, fill: '#9CA3AF' }}
                axisLine={false}
                tickLine={false}
              />
              <Tooltip
                contentStyle={{ fontSize: 11, borderRadius: 6, border: '0.5px solid #E5E7EB' }}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Asset risk table */}
      <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#E5E7EB]">
          <div className="flex items-center gap-2">
            <Wrench className="h-4 w-4 text-[#6B7280]" aria-hidden="true" />
            <h2 className="font-heading text-[14px] text-[#1A1A1A]">Fleet Risk Scores</h2>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => scoreMutation.mutate()}
            loading={scoreMutation.isPending}
          >
            <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
            Run scoring
          </Button>
        </div>

        <div className="divide-y divide-[#F3F4F6]">
          {isLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-16 bg-[#F3F4F6] animate-pulse mx-4 my-2 rounded-lg" />
            ))
          ) : scores && scores.length > 0 ? (
            scores.map((s) => (
              <div key={s.id} className="flex items-start gap-4 px-5 py-3.5 hover:bg-[#FAFAFA]">
                {/* Risk indicator bar */}
                <div
                  className="w-1 self-stretch rounded-full flex-shrink-0"
                  style={{ background: RISK_COLOURS[s.riskLevel] }}
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="text-[13px] font-medium text-[#1A1A1A]">{s.asset.name}</span>
                    <span className="font-mono text-[11px] text-[#9CA3AF]">
                      {s.asset.assetCode}
                    </span>
                    <StatusBadge status={s.riskLevel} />
                    {s.anomalyFlags.slice(0, 2).map((f) => (
                      <span
                        key={f}
                        className="text-[9px] font-medium px-1.5 py-0.5 rounded bg-[#FEF3C7] text-[#92400E]"
                      >
                        {f.replace(/_/g, ' ')}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-[#6B7280]">
                    <span>Engine: {s.engineHoursNow.toLocaleString()}h</span>
                    {s.hoursSinceService != null && (
                      <span>{s.hoursSinceService}h since service</span>
                    )}
                    {s.recommendedServiceDate && (
                      <span
                        className={cn(
                          'font-medium',
                          s.riskLevel === 'CRITICAL'
                            ? 'text-[#DC2626]'
                            : s.riskLevel === 'HIGH'
                              ? 'text-[#D97706]'
                              : 'text-[#374151]',
                        )}
                      >
                        Service by:{' '}
                        {new Date(s.recommendedServiceDate).toLocaleDateString('en-NG', {
                          day: '2-digit',
                          month: 'short',
                        })}
                      </span>
                    )}
                  </div>
                  {s.aiRecommendation && (
                    <p className="text-[11px] text-[#6B7280] mt-1 italic leading-relaxed">
                      💡 {s.aiRecommendation}
                    </p>
                  )}
                </div>

                {/* Risk gauge */}
                <div className="flex-shrink-0 text-right">
                  <div
                    className="text-[22px] font-semibold leading-none"
                    style={{ color: RISK_COLOURS[s.riskLevel] }}
                  >
                    {s.riskScore}
                  </div>
                  <div className="text-[9px] text-[#9CA3AF] mt-0.5">/ 100</div>
                </div>
              </div>
            ))
          ) : (
            <div className="py-12 text-center">
              <p className="text-[13px] text-[#9CA3AF]">
                No scores yet — click Run scoring to analyse your fleet
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
