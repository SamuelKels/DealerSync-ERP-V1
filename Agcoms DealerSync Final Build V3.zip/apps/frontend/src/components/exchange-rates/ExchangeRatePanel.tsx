'use client';
/**
 * AGCOMS DealerSync ERP — Exchange Rate Components
 * Sprint 3 / S3-B: Live CBN rate display for dashboard and sales pages.
 *
 * ExchangeRateBadge: compact pill showing current rate, auto-refreshes every 6h
 * ExchangeRatePanel: full rate table with history chart for the dashboard
 * CurrencyConverter: inline converter for sales quotation forms
 */
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { RefreshCw, AlertTriangle } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { api } from '../../lib/api';
import { formatNGN } from '../../lib/utils';
import { Button } from '../ui/button';
import { cn } from '../../lib/cn';

// ── Types ──────────────────────────────────────────────────────────────────

interface RateData {
  baseCurrency: string;
  quoteCurrency: string;
  rate: number;
  source: string;
  rateDate: string;
  isStale?: boolean;
}

interface AllRatesData {
  base: string;
  rates: Record<string, RateData>;
  updatedAt: string;
  source: string;
}

interface HistoryPoint {
  date: string;
  rate: number;
  source: string;
}

// ── Exchange Rate Badge ────────────────────────────────────────────────────

interface ExchangeRateBadgeProps {
  currency?: 'USD' | 'EUR' | 'GBP';
  className?: string;
}

export function ExchangeRateBadge({ currency = 'USD', className }: ExchangeRateBadgeProps) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['exchange-rate', currency],
    queryFn: () => api.get<RateData>(`/exchange-rates/${currency}`),
    staleTime: 6 * 60 * 60 * 1000, // 6h — matches server cache TTL
    refetchInterval: 6 * 60 * 60 * 1000,
  });

  if (isLoading) {
    return (
      <span
        className={cn('inline-flex items-center gap-1 px-2 py-1 rounded text-[11px]', className)}
      >
        <span className="h-2.5 w-16 bg-[#F3F4F6] rounded animate-pulse" />
      </span>
    );
  }

  if (isError || !data) {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] bg-[#FEF3C7] text-[#92400E]',
          className,
        )}
      >
        <AlertTriangle className="h-3 w-3" aria-hidden="true" />
        Rate unavailable
      </span>
    );
  }

  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold',
        data.isStale ? 'bg-[#FEF3C7] text-[#92400E]' : 'bg-[#EAF3DE] text-[#27500A]',
        className,
      )}
      title={`Source: ${data.source} · Date: ${data.rateDate}${data.isStale ? ' · Rate may be outdated' : ''}`}
    >
      {data.isStale && <AlertTriangle className="h-3 w-3" aria-hidden="true" />}
      <span className="font-mono">
        1 {currency} = ₦{data.rate.toLocaleString('en-NG', { maximumFractionDigits: 2 })}
      </span>
      <span className="text-[9px] opacity-70">CBN</span>
    </span>
  );
}

// ── Exchange Rate Panel ────────────────────────────────────────────────────

export function ExchangeRatePanel() {
  const [selectedCurrency, setSelectedCurrency] = useState<'USD' | 'EUR' | 'GBP'>('USD');

  const {
    data: allRates,
    isLoading,
    refetch,
    isFetching,
  } = useQuery({
    queryKey: ['exchange-rates', 'all'],
    queryFn: () => api.get<AllRatesData>('/exchange-rates/current'),
    staleTime: 6 * 60 * 60 * 1000,
    refetchInterval: 6 * 60 * 60 * 1000,
  });

  const { data: history } = useQuery({
    queryKey: ['exchange-rates', 'history', selectedCurrency],
    queryFn: () => api.get<HistoryPoint[]>(`/exchange-rates/${selectedCurrency}/history?days=30`),
    staleTime: 60 * 60 * 1000, // 1h for history
  });

  const syncMutation = useMutation({
    mutationFn: () => api.post('/exchange-rates/sync'),
    onSuccess: () => refetch(),
  });

  const currencies = ['USD', 'EUR', 'GBP'] as const;

  return (
    <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#E5E7EB]">
        <div>
          <h3 className="font-heading text-[14px] text-[#1A1A1A]">CBN Exchange Rates</h3>
          {allRates && (
            <p className="text-[10px] text-[#9CA3AF] mt-0.5">
              Source: {allRates.source.replace(/_/g, ' ')} · Updated:{' '}
              {new Date(allRates.updatedAt).toLocaleTimeString('en-NG')}
            </p>
          )}
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => syncMutation.mutate()}
          disabled={syncMutation.isPending || isFetching}
          aria-label="Sync latest exchange rates"
        >
          <RefreshCw
            className={cn('h-4 w-4', (syncMutation.isPending || isFetching) && 'animate-spin')}
          />
        </Button>
      </div>

      {/* Currency selector tabs */}
      <div className="flex border-b border-[#E5E7EB]">
        {currencies.map((cur) => (
          <button
            key={cur}
            onClick={() => setSelectedCurrency(cur)}
            className={cn(
              'flex-1 py-2.5 text-[12px] font-medium transition-colors',
              selectedCurrency === cur
                ? 'text-[#1A4D2E] border-b-2 border-[#1A4D2E] -mb-px'
                : 'text-[#6B7280] hover:text-[#1A1A1A]',
            )}
          >
            {cur} / NGN
          </button>
        ))}
      </div>

      {/* Rate cards */}
      <div className="grid grid-cols-3 gap-0 border-b border-[#E5E7EB]">
        {currencies.map((cur) => {
          const rate = allRates?.rates[cur];
          const isSelected = cur === selectedCurrency;
          return (
            <button
              key={cur}
              onClick={() => setSelectedCurrency(cur)}
              className={cn(
                'flex flex-col items-center py-4 border-r border-[#E5E7EB] last:border-r-0 transition-colors',
                isSelected ? 'bg-[#F7F4EF]' : 'hover:bg-[#FAFAFA]',
              )}
            >
              <span className="text-[10px] text-[#9CA3AF] font-semibold uppercase tracking-wide mb-1">
                {cur}
              </span>
              {isLoading ? (
                <div className="h-5 w-20 bg-[#F3F4F6] rounded animate-pulse" />
              ) : rate ? (
                <span className="font-mono text-[15px] font-semibold text-[#1A1A1A]">
                  ₦{rate.rate.toLocaleString('en-NG', { maximumFractionDigits: 0 })}
                </span>
              ) : (
                <span className="text-[12px] text-[#9CA3AF]">—</span>
              )}
            </button>
          );
        })}
      </div>

      {/* 30-day history chart */}
      <div className="p-4">
        <p className="text-[11px] text-[#9CA3AF] mb-3">{selectedCurrency}/NGN — 30-day trend</p>
        {history && history.length > 0 ? (
          <ResponsiveContainer width="100%" height={90}>
            <AreaChart data={history} margin={{ top: 4, right: 4, left: 4, bottom: 4 }}>
              <defs>
                <linearGradient id="rateGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#1A4D2E" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#1A4D2E" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="date" hide />
              <YAxis
                domain={['dataMin - 10', 'dataMax + 10']}
                tickCount={3}
                tick={{ fontSize: 9, fill: '#9CA3AF' }}
                width={45}
                tickFormatter={(v) => `₦${(v / 1000).toFixed(1)}k`}
              />
              <Tooltip
                contentStyle={{
                  fontSize: 11,
                  border: '0.5px solid #E5E7EB',
                  borderRadius: 6,
                  padding: '4px 8px',
                }}
                formatter={(v: number) => [`₦${v.toLocaleString('en-NG')}`, selectedCurrency]}
                labelFormatter={(l) => `Date: ${l}`}
              />
              <Area
                type="monotone"
                dataKey="rate"
                stroke="#1A4D2E"
                strokeWidth={1.5}
                fill="url(#rateGrad)"
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[90px] flex items-center justify-center">
            <p className="text-[11px] text-[#D1D5DB]">
              {isLoading
                ? 'Loading history…'
                : 'No history data yet — rates sync daily at 09:30 WAT'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Currency Converter ─────────────────────────────────────────────────────
// Used inline on the sales quotation form

interface CurrencyConverterProps {
  amount: number;
  fromCurrency: 'USD' | 'EUR' | 'GBP';
  className?: string;
}

export function CurrencyConverter({ amount, fromCurrency, className }: CurrencyConverterProps) {
  const { data, isLoading } = useQuery({
    queryKey: ['fx-convert', amount, fromCurrency],
    queryFn: () =>
      api.post<{ ngn: number; rate: number; rateSource: string; rateDate: string }>(
        '/exchange-rates/convert',
        { amount, fromCurrency },
      ),
    enabled: amount > 0 && fromCurrency !== ('NGN' as any),
    staleTime: 6 * 60 * 60 * 1000,
  });

  if (!amount || fromCurrency === ('NGN' as any)) return null;

  return (
    <span className={cn('inline-flex items-center gap-1.5 text-[11px] text-[#6B7280]', className)}>
      ≈
      {isLoading ? (
        <span className="h-3 w-20 bg-[#F3F4F6] rounded animate-pulse inline-block" />
      ) : data ? (
        <span className="font-semibold text-[#1A1A1A]">
          {formatNGN(data.ngn)}
          <span className="font-normal text-[#9CA3AF] ml-1">
            (@ ₦{data.rate.toLocaleString('en-NG', { maximumFractionDigits: 0 })}/{fromCurrency} ·{' '}
            {data.rateSource.replace(/_/g, ' ')})
          </span>
        </span>
      ) : (
        <span className="text-[#DC2626]">Rate unavailable</span>
      )}
    </span>
  );
}
