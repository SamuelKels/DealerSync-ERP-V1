/**
 * AGCOMS DealerSync ERP — OnboardingTour
 *
 * V2 NOTE: react-joyride 2.x has incompatibilities with React 18.3.x
 * (uses deprecated unmountComponentAtNode, removed in React 18). The tour
 * UI is shipped as a no-op stub in V2 to maintain layout integration.
 * A V2.1 task will replace this with @reactour/tour or driver.js.
 */
'use client';

import { useEffect } from 'react';

export type TourId =
  | 'dashboard'
  | 'crm'
  | 'inventory'
  | 'sales'
  | 'procurement'
  | 'workshop'
  | 'finance'
  | 'fleet'
  | 'firs'
  | 'reports';

interface OnboardingTourProps {
  tourId: TourId;
  autoStart?: boolean;
  onComplete?: () => void;
}

// In V2: no-op tour. Renders nothing; preserves contract.
export function OnboardingTour({ tourId, autoStart, onComplete }: OnboardingTourProps) {
  useEffect(() => {
    if (autoStart && onComplete) {
      const t = setTimeout(() => onComplete(), 0);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [tourId, autoStart, onComplete]);
  return null;
}

const TOURS_KEY = 'agcoms_completed_tours';

function getCompletedTours(): Set<TourId> {
  if (typeof window === 'undefined') return new Set();
  try {
    const raw = localStorage.getItem(TOURS_KEY);
    return new Set(raw ? (JSON.parse(raw) as TourId[]) : []);
  } catch {
    return new Set();
  }
}

function setCompletedTours(tours: Set<TourId>) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(TOURS_KEY, JSON.stringify(Array.from(tours)));
}

export function useOnboardingTour(tourId: TourId) {
  // V2: tours are stubbed out — return inert API
  const startTour = () => {};
  const restartTour = () => {
    const c = getCompletedTours();
    c.delete(tourId);
    setCompletedTours(c);
  };
  const resetAllTours = () => setCompletedTours(new Set());
  return { run: false, startTour, restartTour, resetAllTours };
}

export function TourTrigger({ tourId, label = '?' }: { tourId: TourId; label?: string }) {
  const { startTour } = useOnboardingTour(tourId);
  return (
    <button
      onClick={startTour}
      aria-label={`Help for ${tourId}`}
      className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-[#1A4D2E] text-white text-[10px] font-semibold hover:bg-[#0F3320]"
    >
      {label}
    </button>
  );
}
