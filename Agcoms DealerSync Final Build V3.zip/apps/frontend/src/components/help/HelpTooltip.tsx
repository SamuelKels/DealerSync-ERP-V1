'use client';
/**
 * AGCOMS DealerSync ERP — HelpTooltip
 * §8 UX Principles: "contextual help"
 *
 * A ? icon that opens a popover with field-specific guidance.
 * Self-positioning — detects viewport edges and flips direction.
 * Used on complex fields: PAYE inputs, credit limits, approval matrix,
 * VAT fields, WHT type selectors, and gov contract milestones.
 *
 * Usage:
 *   <HelpTooltip topic="paye" />
 *   <HelpTooltip topic="credit_limit" position="left" />
 *   <HelpTooltip topic="wht_type" triggerClassName="text-[#D97706]" />
 */

import { useState, useRef, useEffect, useCallback } from 'react';
import { HelpCircle, X, ExternalLink } from 'lucide-react';

// ── Help content registry ──────────────────────────────────────

export type HelpTopic =
  | 'paye'
  | 'pension'
  | 'nhf'
  | 'cra'
  | 'credit_limit'
  | 'credit_terms'
  | 'vat'
  | 'wht_type'
  | 'discount_approval'
  | 'approval_matrix'
  | 'landed_cost_method'
  | 'nadf_beneficiary'
  | 'journal_debit_credit'
  | 'accounting_period_lock'
  | 'budget_variance'
  | 'stock_serial'
  | 'mfa_totp'
  | 'branch_isolation';

interface HelpContent {
  title: string;
  body: string;
  detail?: string;
  link?: { label: string; href: string };
}

const HELP_REGISTRY: Record<HelpTopic, HelpContent> = {
  paye: {
    title: 'PAYE — Personal Income Tax',
    body: 'Pay As You Earn tax deducted monthly from employee salary per PITA 2011. Rates: 7% on first ₦300K, 11% next ₦300K, 15% next ₦500K, 19% next ₦500K, 21% next ₦1.6M, 24% above ₦3.2M.',
    detail:
      'CRA (Consolidated Relief Allowance) = max(₦200,000; 1% of gross) + 20% of gross. PAYE is calculated on gross minus CRA minus pension.',
  },
  pension: {
    title: 'PenCom Pension Contributions',
    body: "Employee contributes 8% of gross salary. Employer contributes 10% of gross salary. Both remitted to the employee's PFA monthly.",
    detail: 'Per PenCom Act 2004 as amended 2014. Deducted before PAYE calculation.',
  },
  nhf: {
    title: 'NHF — National Housing Fund',
    body: '2.5% of basic salary (not gross) deducted monthly and remitted to Federal Mortgage Bank of Nigeria.',
    detail: 'Applicable to all employees earning above ₦3,000/month. Employer does not contribute.',
  },
  cra: {
    title: 'Consolidated Relief Allowance',
    body: 'Tax-free income allowance before PAYE is calculated. CRA = higher of ₦200,000 or 1% of gross income, plus 20% of gross income.',
    detail: 'A very low earner may have CRA exceeding gross income, resulting in zero PAYE.',
  },
  credit_limit: {
    title: 'Customer credit limit',
    body: 'Maximum outstanding invoice balance this customer is permitted to carry. New sales orders are blocked when credit utilisation reaches 100%.',
    detail:
      'A WARNING is triggered at 80% utilisation. BLOCKED status prevents new orders. Set to 0 for cash-only customers.',
  },
  credit_terms: {
    title: 'Credit payment terms',
    body: 'Number of calendar days the customer has to pay an issued invoice before it becomes overdue. Standard terms: Net 30, Net 60, or Net 90.',
  },
  vat: {
    title: 'VAT — Value Added Tax',
    body: 'Standard rate is 7.5% per the Finance Act 2020 (effective February 2020). Applied to taxable goods and services supplied in Nigeria.',
    detail:
      'Basic food items, medical services, educational materials, and exported services are VAT-exempt. Check the FIRS exemption schedule for your product category.',
    link: { label: 'FIRS VAT guidelines', href: 'https://www.firs.gov.ng/vat' },
  },
  wht_type: {
    title: 'Withholding Tax type',
    body: 'WHT rate depends on transaction type: Contracts (supply of goods): 5%. Consultancy / professional services: 10%. Technical services: 10%. Rent: 10%.',
    detail:
      'WHT is deducted at source by the paying party and remitted to FIRS on behalf of the recipient.',
  },
  discount_approval: {
    title: 'Discount approval levels',
    body: '0–5%: Sales Rep. 5–15%: Sales Manager. 15–30%: Director. Above 30%: CEO / Super Admin only.',
    detail:
      'Discounts above your approval level will require escalation. The quotation will enter PENDING_APPROVAL status until a senior user approves.',
  },
  approval_matrix: {
    title: 'Procurement approval matrix',
    body: 'Purchase order value determines who must approve: Up to ₦500K: Procurement Officer. ₦500K–₦5M: Procurement Manager. ₦5M–₦20M: Director. Above ₦20M: CEO.',
    detail:
      'Approvals are sequential. Each approver receives a notification and has 72 hours to act before an escalation reminder is sent.',
  },
  landed_cost_method: {
    title: 'Landed cost allocation method',
    body: 'WEIGHT: allocates by product weight (kg × qty). VALUE: allocates by line value (qty × cost). QUANTITY: allocates equally by units. EQUAL: splits total equally across all GRN lines.',
    detail:
      'WEIGHT is recommended for heavy equipment shipments. VALUE is recommended for mixed high/low-value goods. Contact your finance team if unsure.',
  },
  nadf_beneficiary: {
    title: 'NADF beneficiary registration',
    body: 'Register the farmer or cooperative receiving the tractor under this government contract. A unique beneficiary number is assigned for tracking through allocation, transit, and GPS-confirmed delivery.',
    detail:
      'Required fields: name, phone, state, and LGA. NIN (for individuals) or CAC number (for cooperatives) is strongly recommended for audit compliance.',
  },
  journal_debit_credit: {
    title: 'Debit and credit rules',
    body: 'Assets & Expenses: increase with DEBIT, decrease with CREDIT. Liabilities, Equity & Revenue: increase with CREDIT, decrease with DEBIT.',
    detail:
      'Every journal entry must balance: total debits = total credits. The system validates this before posting.',
  },
  accounting_period_lock: {
    title: 'Accounting period status',
    body: 'OPEN: transactions can be posted. CLOSED: no new postings (end of month). LOCKED: permanently closed, cannot be reopened without Finance Manager approval.',
    detail:
      'Posting to a closed or locked period is blocked to protect the integrity of reported financial statements.',
  },
  budget_variance: {
    title: 'Budget variance',
    body: 'Actual spend vs budgeted amount. ON_TRACK: within 10% of budget. OVER_BUDGET: more than 10% above budget. UNDER_BUDGET: more than 10% below budget.',
    detail:
      'Variance is calculated against the current (reforecast) budget amount, not the original amount.',
  },
  stock_serial: {
    title: 'Serialised vs non-serialised stock',
    body: 'Serialised: each unit has a unique serial number (tractors, heavy equipment). Every unit is tracked individually. Non-serialised: tracked by quantity only (spare parts, consumables).',
    detail:
      'NADF programme allocations require serialised equipment so each tractor can be traced to its beneficiary.',
  },
  mfa_totp: {
    title: 'Two-factor authentication (TOTP)',
    body: 'Scan the QR code with an authenticator app (Google Authenticator, Authy, or Microsoft Authenticator). Enter the 6-digit code shown in the app when logging in.',
    detail:
      'Store your backup codes securely — they are the only way to recover access if you lose your device.',
  },
  branch_isolation: {
    title: 'Branch data isolation',
    body: 'Your account is scoped to your branch. You can only see customers, inventory, and financial data belonging to your branch unless you hold a Director or Super Admin role.',
  },
};

// ── Component ──────────────────────────────────────────────────

type Position = 'top' | 'bottom' | 'left' | 'right';

interface HelpTooltipProps {
  topic: HelpTopic;
  position?: Position;
  triggerClassName?: string;
  iconSize?: number;
}

export function HelpTooltip({
  topic,
  position = 'top',
  triggerClassName = '',
  iconSize = 14,
}: HelpTooltipProps) {
  const [open, setOpen] = useState(false);
  const [actualPos, setActualPos] = useState<Position>(position);
  const btnRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);

  const content = HELP_REGISTRY[topic];

  // Auto-flip position if popover would go offscreen
  const adjustPosition = useCallback(() => {
    if (!btnRef.current || !popRef.current) return;
    const btn = btnRef.current.getBoundingClientRect();
    const pop = popRef.current.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    let pos: Position = position;
    if (position === 'top' && btn.top < pop.height + 8) pos = 'bottom';
    if (position === 'bottom' && btn.bottom + pop.height + 8 > vh) pos = 'top';
    if (position === 'left' && btn.left < pop.width + 8) pos = 'right';
    if (position === 'right' && btn.right + pop.width + 8 > vw) pos = 'left';
    setActualPos(pos);
  }, [position]);

  useEffect(() => {
    if (open) {
      setTimeout(adjustPosition, 0);
      const close = (e: MouseEvent) => {
        if (
          popRef.current &&
          !popRef.current.contains(e.target as Node) &&
          btnRef.current &&
          !btnRef.current.contains(e.target as Node)
        ) {
          setOpen(false);
        }
      };
      document.addEventListener('mousedown', close);
      return () => document.removeEventListener('mousedown', close);
    }
    return undefined;
  }, [open, adjustPosition]);

  const positionStyles: Record<Position, React.CSSProperties> = {
    top: { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: '8px' },
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: '8px' },
    left: { right: '100%', top: '50%', transform: 'translateY(-50%)', marginRight: '8px' },
    right: { left: '100%', top: '50%', transform: 'translateY(-50%)', marginLeft: '8px' },
  };

  return (
    <span className="relative inline-flex items-center">
      <button
        ref={btnRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`inline-flex items-center justify-center rounded-full transition-colors hover:text-[#1A4D2E] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#1A4D2E] ${triggerClassName}`}
        style={{ color: open ? '#1A4D2E' : '#9CA3AF' }}
        aria-label={`Help: ${content.title}`}
        aria-expanded={open}
      >
        <HelpCircle style={{ width: iconSize, height: iconSize }} />
      </button>

      {open && (
        <div
          ref={popRef}
          role="tooltip"
          className="absolute z-50 w-[300px]"
          style={positionStyles[actualPos]}
        >
          <div className="bg-white rounded-xl border border-[#E5E7EB] shadow-lg overflow-hidden">
            {/* Header */}
            <div
              className="flex items-center justify-between px-4 py-3 border-b border-[#F3F4F6]"
              style={{ background: '#1A4D2E' }}
            >
              <span className="text-[12px] font-semibold text-white leading-tight">
                {content.title}
              </span>
              <button
                onClick={() => setOpen(false)}
                className="text-white/70 hover:text-white p-0.5 rounded"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
            {/* Body */}
            <div className="px-4 py-3 space-y-2">
              <p className="text-[12px] text-[#374151] leading-relaxed">{content.body}</p>
              {content.detail && (
                <p className="text-[11px] text-[#6B7280] leading-relaxed border-t border-[#F3F4F6] pt-2">
                  {content.detail}
                </p>
              )}
              {content.link && (
                <a
                  href={content.link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[11px] font-medium text-[#1A4D2E] hover:underline"
                >
                  {content.link.label}
                  <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </div>
          </div>
        </div>
      )}
    </span>
  );
}

// ── Inline label helper — label + tooltip side by side ─────────

export function LabelWithHelp({
  label,
  topic,
  required = false,
}: {
  label: string;
  topic: HelpTopic;
  required?: boolean;
}) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="text-[13px] font-medium text-[#374151]">{label}</span>
      {required && <span className="text-[#DC2626] text-[11px]">*</span>}
      <HelpTooltip topic={topic} iconSize={13} />
    </span>
  );
}

export default HelpTooltip;
