'use client';
/**
 * AGCOMS DealerSync ERP — Header
 * Sprint 2 Fix S2-03: No header component existed.
 * Provides: mobile menu toggle, global search (⌘K), notification bell, user menu.
 */
import { useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Menu, Search, Bell, ChevronDown, LogOut, Settings, User } from 'lucide-react';
import { useAuthStore } from '../../stores/auth.store';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Button } from '../ui/button';
import { Separator } from '../ui/separator';
import { cn } from '../../lib/cn';
import { api } from '../../lib/api';
import { toast } from 'sonner';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

interface HeaderProps {
  onMobileMenuToggle: () => void;
}

export function Header({ onMobileMenuToggle }: HeaderProps) {
  const { user, clearAuth } = useAuthStore();
  const router = useRouter();

  const initials = user
    ? `${user.firstName[0] ?? ''}${user.lastName[0] ?? ''}`.toUpperCase()
    : '??';

  const handleLogout = useCallback(async () => {
    try {
      await api.post('/auth/logout');
    } catch {
      // Ignore API errors on logout
    } finally {
      clearAuth();
      router.replace('/auth/login');
      toast.success('Logged out successfully');
    }
  }, [clearAuth, router]);

  return (
    <header
      className="flex-shrink-0 h-14 bg-white border-b border-[#E5E7EB] flex items-center px-4 gap-3 z-10"
      role="banner"
    >
      {/* Mobile menu toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="lg:hidden"
        onClick={onMobileMenuToggle}
        aria-label="Open navigation menu"
      >
        <Menu className="h-5 w-5" />
      </Button>

      {/* AGCOMS wordmark — mobile only */}
      <span className="lg:hidden font-heading text-[#1A4D2E] text-[15px] font-semibold flex-1">
        DealerSync
      </span>

      {/* Global search trigger — §8 UX: global command palette */}
      <button
        data-tour="command-palette"
        onClick={() =>
          document.dispatchEvent(
            new KeyboardEvent('keydown', { key: 'k', metaKey: true, bubbles: true }),
          )
        }
        className={cn(
          'hidden md:flex items-center gap-2 h-8 px-3 rounded-md text-[13px]',
          'text-[#9CA3AF] bg-[#F7F4EF] border border-[#E5E7EB]',
          'hover:border-[#1A4D2E]/30 transition-colors cursor-pointer flex-1 max-w-[320px]',
        )}
        aria-label="Open command palette (⌘K)"
      >
        <Search className="h-3.5 w-3.5 flex-shrink-0" aria-hidden="true" />
        <span>Search anything…</span>
        <kbd className="ml-auto font-mono text-[10px] bg-white border border-[#E5E7EB] rounded px-1.5 py-0.5">
          ⌘K
        </kbd>
      </button>

      <div className="flex items-center gap-1 ml-auto">
        {/* Notifications */}
        <Button variant="ghost" size="icon" aria-label="Notifications">
          <Bell className="h-4.5 w-4.5" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-[#F7F4EF] transition-colors"
              aria-label="User menu"
            >
              <Avatar className="h-7 w-7">
                <AvatarFallback className="text-[11px] bg-[#1A4D2E] text-white font-semibold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div className="hidden md:block text-left">
                <p className="text-[12px] font-medium text-[#1A1A1A] leading-tight">
                  {user?.firstName} {user?.lastName}
                </p>
                <p className="text-[10px] text-[#6B7280] leading-tight">
                  {user?.role?.replace(/_/g, ' ')}
                </p>
              </div>
              <ChevronDown
                className="h-3.5 w-3.5 text-[#9CA3AF] hidden md:block"
                aria-hidden="true"
              />
            </button>
          </DropdownMenuTrigger>

          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col gap-0.5">
                <span className="text-[13px] font-medium">
                  {user?.firstName} {user?.lastName}
                </span>
                <span className="text-[11px] text-[#6B7280] truncate">{user?.email}</span>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => router.push('/erp/admin/profile')}>
              <User className="h-4 w-4 mr-2" aria-hidden="true" />
              My profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => router.push('/erp/admin/users')}>
              <Settings className="h-4 w-4 mr-2" aria-hidden="true" />
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={handleLogout}
              className="text-[#DC2626] focus:text-[#DC2626] focus:bg-[#FEF2F2]"
            >
              <LogOut className="h-4 w-4 mr-2" aria-hidden="true" />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
