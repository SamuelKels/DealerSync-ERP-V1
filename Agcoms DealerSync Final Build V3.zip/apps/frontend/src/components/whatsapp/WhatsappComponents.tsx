'use client';
/**
 * AGCOMS DealerSync ERP — WhatsApp Components
 * Sprint 3 / S3-A: Frontend components for WhatsApp message dispatch.
 *
 * WhatsappSendButton: one-click send for invoices, quotations, job cards
 * WhatsappOptInPanel: customer preference management
 * WhatsappStatusBadge: delivery status indicator on sent messages
 */
import { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { MessageCircle, Check, Clock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '../../lib/api';
import { Button } from '../ui/button';
import { cn } from '../../lib/cn';

// ── Types ──────────────────────────────────────────────────────────────────

type WaStatus = 'QUEUED' | 'SENT' | 'DELIVERED' | 'READ' | 'FAILED';

interface SendPayload {
  recipientPhone: string;
  recipientName?: string;
  templateKey: string;
  variables: string[];
  referenceType?: string;
  referenceId?: string;
}

// ── WhatsApp Send Button ───────────────────────────────────────────────────
// Used on Invoice detail, Quotation detail, Job Card detail pages.

interface WhatsappSendButtonProps {
  payload: SendPayload;
  label?: string;
  size?: 'sm' | 'default';
  variant?: 'outline' | 'ghost';
  className?: string;
  onSent?: (logId: string) => void;
}

export function WhatsappSendButton({
  payload,
  label = 'Send via WhatsApp',
  size = 'sm',
  variant = 'outline',
  className,
  onSent,
}: WhatsappSendButtonProps) {
  const mutation = useMutation({
    mutationFn: () => api.post<{ logId: string; queued: boolean }>('/whatsapp/send', payload),
    onSuccess: ({ logId, queued }) => {
      if (queued) {
        toast.success('WhatsApp message queued for delivery', {
          description: `Sending to ${payload.recipientPhone}`,
          duration: 4000,
        });
        onSent?.(logId);
      } else {
        toast.info('WhatsApp skipped — recipient not opted in', { duration: 4000 });
      }
    },
    onError: (err: any) => {
      toast.error('Failed to queue WhatsApp message', {
        description: err?.message ?? 'Please try again',
      });
    },
  });

  return (
    <Button
      variant={variant}
      size={size}
      onClick={() => mutation.mutate()}
      loading={mutation.isPending}
      disabled={mutation.isPending || mutation.isSuccess}
      className={cn('gap-1.5', mutation.isSuccess && 'text-[#16A34A]', className)}
      aria-label={label}
    >
      <MessageCircle
        className="h-3.5 w-3.5"
        style={{ color: mutation.isSuccess ? '#16A34A' : '#25D366' }}
        aria-hidden="true"
      />
      {mutation.isSuccess ? 'Sent!' : label}
    </Button>
  );
}

// ── Delivery Status Badge ──────────────────────────────────────────────────

const STATUS_CONFIG: Record<
  WaStatus,
  { label: string; icon: typeof Check; color: string; bg: string }
> = {
  QUEUED: { label: 'Queued', icon: Clock, color: '#92400E', bg: '#FEF3C7' },
  SENT: { label: 'Sent', icon: Check, color: '#0C447C', bg: '#E6F1FB' },
  DELIVERED: { label: 'Delivered', icon: Check, color: '#15803D', bg: '#DCFCE7' },
  READ: { label: 'Read', icon: Check, color: '#1A4D2E', bg: '#EAF3DE' },
  FAILED: { label: 'Failed', icon: AlertCircle, color: '#B91C1C', bg: '#FEE2E2' },
};

export function WhatsappStatusBadge({ status }: { status: WaStatus }) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.QUEUED;
  const Icon = cfg.icon;

  return (
    <span
      className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold"
      style={{ background: cfg.bg, color: cfg.color }}
    >
      <Icon className="h-3 w-3" aria-hidden="true" />
      {cfg.label}
    </span>
  );
}

// ── Opt-in Settings Panel ──────────────────────────────────────────────────
// Rendered on the customer detail page (CRM module)

interface WhatsappOptInPanelProps {
  customerId: string;
  className?: string;
}

export function WhatsappOptInPanel({ customerId, className }: WhatsappOptInPanelProps) {
  const [phone, setPhone] = useState('');

  const { data: prefs, refetch } = useQuery({
    queryKey: ['whatsapp-prefs', customerId],
    queryFn: () => api.get<any>(`/whatsapp/customers/${customerId}/opt-in`),
    staleTime: 60_000,
  });

  const mutation = useMutation({
    mutationFn: (updates: any) => api.put(`/whatsapp/customers/${customerId}/opt-in`, updates),
    onSuccess: () => {
      refetch();
      toast.success('WhatsApp preferences updated');
    },
    onError: () => toast.error('Failed to update preferences'),
  });

  const togglePref = (field: string, current: boolean) => {
    mutation.mutate({
      ...(prefs ?? {}),
      whatsappPhone: prefs?.whatsappPhone ?? phone,
      [field]: !current,
    });
  };

  const PREF_FIELDS = [
    { key: 'invoiceAlerts', label: 'Invoice notifications' },
    { key: 'quotationAlerts', label: 'Quotation notifications' },
    { key: 'serviceAlerts', label: 'Service updates' },
    { key: 'paymentReminders', label: 'Payment reminders' },
  ] as const;

  return (
    <div className={cn('bg-white rounded-xl border border-[#E5E7EB] p-4', className)}>
      <div className="flex items-center gap-2 mb-4">
        <div
          className="h-8 w-8 rounded-lg flex items-center justify-center"
          style={{ background: '#EAF3DE' }}
        >
          <MessageCircle className="h-4 w-4" style={{ color: '#25D366' }} aria-hidden="true" />
        </div>
        <div>
          <h3 className="text-[13px] font-semibold text-[#1A1A1A]">WhatsApp notifications</h3>
          <p className="text-[11px] text-[#9CA3AF]">
            {prefs?.optedIn ? `Active: ${prefs.whatsappPhone}` : 'Not enrolled'}
          </p>
        </div>
      </div>

      {/* Phone number field — shown if not yet enrolled */}
      {!prefs && (
        <div className="mb-3">
          <label className="block text-[11px] font-medium text-[#374151] mb-1">
            WhatsApp number (E.164)
          </label>
          <div className="flex gap-2">
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+2348012345678"
              className="flex-1 h-8 px-3 text-[13px] rounded-md border border-[#E5E7EB] focus:outline-none focus:ring-2 focus:ring-[#1A4D2E]"
            />
            <Button
              size="sm"
              onClick={() => mutation.mutate({ whatsappPhone: phone, optedIn: true })}
              loading={mutation.isPending}
              disabled={!phone.match(/^\+\d{10,15}$/)}
            >
              Enrol
            </Button>
          </div>
        </div>
      )}

      {/* Per-type toggles */}
      {prefs && (
        <div className="space-y-2">
          {PREF_FIELDS.map(({ key, label }) => (
            <div key={key} className="flex items-center justify-between py-1">
              <span className="text-[12px] text-[#374151]">{label}</span>
              <button
                onClick={() => togglePref(key, prefs[key])}
                disabled={mutation.isPending}
                className={cn(
                  'relative inline-flex h-5 w-9 items-center rounded-full transition-colors',
                  prefs[key] ? 'bg-[#1A4D2E]' : 'bg-[#D1D5DB]',
                )}
                role="switch"
                aria-checked={prefs[key]}
                aria-label={label}
              >
                <span
                  className={cn(
                    'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                    prefs[key] ? 'translate-x-4' : 'translate-x-0.5',
                  )}
                />
              </button>
            </div>
          ))}

          {/* Opt out entirely */}
          <div className="pt-2 border-t border-[#F3F4F6]">
            <button
              onClick={() =>
                mutation.mutate({
                  ...prefs,
                  whatsappPhone: prefs.whatsappPhone,
                  optedIn: !prefs.optedIn,
                })
              }
              className="text-[11px] text-[#DC2626] hover:underline"
            >
              {prefs.optedIn
                ? 'Opt out of all WhatsApp messages'
                : 'Re-enable WhatsApp notifications'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
