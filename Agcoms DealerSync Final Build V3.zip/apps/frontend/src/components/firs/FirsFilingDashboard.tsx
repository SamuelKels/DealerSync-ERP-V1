'use client';
/**
 * AGCOMS DealerSync ERP — FIRS Filing Dashboard
 * Sprint 5 / S5-A: Monthly VAT and WHT filing status overview.
 *
 * Shows the 12-month filing schedule with:
 *  - Status per month (PENDING / COMPUTED / SUBMITTED / OVERDUE)
 *  - Net VAT payable amount per month
 *  - Days-to-deadline countdown
 *  - Compute, download Excel, and mark-submitted actions
 */
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FileSpreadsheet,
  CheckCircle,
  Clock,
  AlertTriangle,
  Download,
  Calculator,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';
import { toast } from 'sonner';
import { api } from '../../lib/api';
import { formatNGN } from '../../lib/utils';
import { Button } from '../ui/button';
import { StatusBadge } from '../ui/status-badge';
import { cn } from '../../lib/cn';

interface FilingMonth {
  month: number;
  periodLabel: string;
  deadline: string;
  status: string;
  netVatPayable: number | null;
  submittedAt: string | null;
  firsReceiptNo: string | null;
  returnId: string | null;
  daysToDeadline: number;
}

interface FilingSchedule {
  year: number;
  schedule: FilingMonth[];
  submitted: number;
}

const MONTH_NAMES = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

export function FirsFilingDashboard() {
  const qc = useQueryClient();
  const year = new Date().getFullYear();
  const [computingMonth, setComputingMonth] = useState<number | null>(null);

  const { data: schedule, isLoading } = useQuery({
    queryKey: ['firs-schedule', year],
    queryFn: () => api.get<FilingSchedule>(`/firs/schedule/${year}`),
    staleTime: 5 * 60_000,
  });

  const computeMutation = useMutation({
    mutationFn: ({ month }: { month: number }) =>
      api.post('/firs/vat-returns/compute', { year, month }),
    onSuccess: (_, { month }) => {
      toast.success(`VAT return computed for ${MONTH_NAMES[month - 1]} ${year}`);
      qc.invalidateQueries({ queryKey: ['firs-schedule'] });
      setComputingMonth(null);
    },
    onError: () => {
      toast.error('Failed to compute VAT return');
      setComputingMonth(null);
    },
  });

  const downloadExcel = async (month: number) => {
    try {
      const response = await fetch(`/api/v1/firs/vat-returns/${year}/${month}/excel`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('access_token') ?? ''}` },
      });
      if (!response.ok) throw new Error('Download failed');
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `VAT-Return-${year}-${String(month).padStart(2, '0')}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success('TaxPro-Max Excel downloaded');
    } catch {
      toast.error('Download failed — ensure the VAT return has been computed first');
    }
  };

  const getStatusIcon = (status: string, daysToDeadline: number) => {
    if (status === 'SUBMITTED') return <CheckCircle className="h-4 w-4 text-[#16A34A]" />;
    if (status === 'OVERDUE') return <AlertTriangle className="h-4 w-4 text-[#DC2626]" />;
    if (daysToDeadline <= 7) return <AlertTriangle className="h-4 w-4 text-[#D97706]" />;
    return <Clock className="h-4 w-4 text-[#9CA3AF]" />;
  };

  const currentMonth = new Date().getMonth() + 1;

  return (
    <div className="bg-white rounded-xl border border-[#E5E7EB] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-lg bg-[#EAF3DE] flex items-center justify-center">
            <FileSpreadsheet className="h-4.5 w-4.5 text-[#1A4D2E]" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-heading text-[15px] text-[#1A1A1A]">FIRS VAT Filing — {year}</h2>
            <p className="text-[11px] text-[#9CA3AF] mt-0.5">
              {schedule?.submitted ?? 0} of 12 months submitted · Due 21st of following month · VAT
              7.5% (Finance Act 2020)
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => qc.invalidateQueries({ queryKey: ['firs-schedule'] })}
        >
          <RefreshCw className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* Month grid */}
      {isLoading ? (
        <div className="p-5 grid grid-cols-3 gap-3">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="h-24 bg-[#F3F4F6] rounded-lg animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="p-4 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {schedule?.schedule.map((m) => {
            const isPast = m.month < currentMonth;
            const isCurrent = m.month === currentMonth;
            const urgent =
              m.daysToDeadline <= 7 && m.daysToDeadline > 0 && m.status !== 'SUBMITTED';
            const overdue =
              m.status === 'OVERDUE' ||
              (isPast && m.status !== 'SUBMITTED' && m.status !== 'PENDING');

            return (
              <div
                key={m.month}
                className={cn(
                  'rounded-xl border p-3.5 flex flex-col gap-2 relative transition-colors',
                  m.status === 'SUBMITTED'
                    ? 'border-[#BBF7D0] bg-[#F0FDF4]'
                    : overdue
                      ? 'border-[#FECACA] bg-[#FEF2F2]'
                      : urgent
                        ? 'border-[#FED7AA] bg-[#FFFBEB]'
                        : isCurrent
                          ? 'border-[#1A4D2E]/20 bg-[#F0FDF4]'
                          : 'border-[#E5E7EB] bg-white',
                )}
              >
                {/* Month header */}
                <div className="flex items-center justify-between">
                  <span className="text-[13px] font-semibold text-[#1A1A1A]">
                    {MONTH_NAMES[m.month - 1]}
                    {isCurrent && (
                      <span className="ml-1 text-[10px] text-[#1A4D2E] font-medium">(current)</span>
                    )}
                  </span>
                  {getStatusIcon(m.status, m.daysToDeadline)}
                </div>

                {/* Status + amount */}
                <div>
                  <StatusBadge status={m.status} className="text-[9px] mb-1" />
                  {m.netVatPayable !== null && (
                    <p
                      className={cn(
                        'text-[12px] font-semibold mt-1',
                        m.netVatPayable > 0 ? 'text-[#1A1A1A]' : 'text-[#9CA3AF]',
                      )}
                    >
                      {m.netVatPayable > 0 ? formatNGN(m.netVatPayable) : 'NIL'}
                    </p>
                  )}
                  {m.daysToDeadline > 0 && m.status !== 'SUBMITTED' && (
                    <p className="text-[10px] text-[#9CA3AF]">{m.daysToDeadline}d to deadline</p>
                  )}
                  {m.status === 'SUBMITTED' && m.firsReceiptNo && (
                    <p className="text-[10px] text-[#6B7280] font-mono truncate">
                      {m.firsReceiptNo}
                    </p>
                  )}
                </div>

                {/* Actions */}
                {(isPast || isCurrent) && m.status !== 'SUBMITTED' && (
                  <div className="flex gap-1.5 mt-auto">
                    {m.status === 'PENDING' || m.status === 'OVERDUE' ? (
                      <button
                        onClick={() => {
                          setComputingMonth(m.month);
                          computeMutation.mutate({ month: m.month });
                        }}
                        disabled={computeMutation.isPending && computingMonth === m.month}
                        className="flex items-center gap-1 text-[10px] font-medium text-[#1A4D2E] hover:underline disabled:opacity-50"
                      >
                        <Calculator className="h-3 w-3" />
                        {computeMutation.isPending && computingMonth === m.month
                          ? 'Computing…'
                          : 'Compute'}
                      </button>
                    ) : (
                      <button
                        onClick={() => downloadExcel(m.month)}
                        className="flex items-center gap-1 text-[10px] font-medium text-[#0C447C] hover:underline"
                      >
                        <Download className="h-3 w-3" />
                        TaxPro-Max
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Footer */}
      <div className="px-5 py-3 border-t border-[#E5E7EB] bg-[#FAFAFA] flex items-center justify-between">
        <p className="text-[11px] text-[#9CA3AF]">
          WHT certificates:{' '}
          <span className="font-medium text-[#374151]">issued per transaction</span>
        </p>
        <a
          href="https://taxpromax.firs.gov.ng"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-[11px] text-[#1A4D2E] hover:underline"
        >
          FIRS TaxPro-Max portal
          <ChevronRight className="h-3 w-3" />
        </a>
      </div>
    </div>
  );
}
