/**
 * AGCOMS DealerSync ERP — StatusBadge
 * Sprint 2 Fix S2-05: No shared status badge — every page duplicated inline styles.
 * Centralises all status colour mappings in one place.
 */
import { cn } from '../../lib/cn';

type Status =
  | 'DRAFT'
  | 'PENDING'
  | 'PENDING_APPROVAL'
  | 'SUBMITTED'
  | 'ACTIVE'
  | 'APPROVED'
  | 'CONFIRMED'
  | 'POSTED'
  | 'ISSUED'
  | 'OPEN'
  | 'IN_PROGRESS'
  | 'PROCESSING'
  | 'EVALUATING'
  | 'PAID'
  | 'DELIVERED'
  | 'COMPLETED'
  | 'AWARDED'
  | 'WON'
  | 'PARTIALLY_PAID'
  | 'ALLOCATED'
  | 'IN_TRANSIT'
  | 'WARNING'
  | 'OVERDUE'
  | 'CANCELLED'
  | 'REJECTED'
  | 'BLOCKED'
  | 'FAILED'
  | 'VOIDED'
  | 'TERMINATED'
  | 'LOST'
  | 'CLOSED'
  | 'LOCKED'
  | 'OFFLINE'
  | 'MAINTENANCE'
  | 'QUOTED'
  | 'IN_REVIEW'
  | 'CONTRACT_CREATED'
  | string;

const STATUS_MAP: Record<string, { bg: string; text: string }> = {
  // Success / active
  ACTIVE: { bg: '#DCFCE7', text: '#15803D' },
  APPROVED: { bg: '#DCFCE7', text: '#15803D' },
  PAID: { bg: '#DCFCE7', text: '#15803D' },
  DELIVERED: { bg: '#DCFCE7', text: '#15803D' },
  COMPLETED: { bg: '#DCFCE7', text: '#15803D' },
  CONFIRMED: { bg: '#DCFCE7', text: '#15803D' },
  POSTED: { bg: '#DCFCE7', text: '#15803D' },
  AWARDED: { bg: '#DCFCE7', text: '#15803D' },
  WON: { bg: '#DCFCE7', text: '#15803D' },
  CONTRACT_CREATED: { bg: '#DCFCE7', text: '#15803D' },
  HEALTHY: { bg: '#DCFCE7', text: '#15803D' },
  // Warning / in-progress
  WARNING: { bg: '#FEF3C7', text: '#92400E' },
  OVERDUE: { bg: '#FEF3C7', text: '#92400E' },
  IN_PROGRESS: { bg: '#FEF3C7', text: '#92400E' },
  PROCESSING: { bg: '#FEF3C7', text: '#92400E' },
  EVALUATING: { bg: '#FEF3C7', text: '#92400E' },
  PARTIALLY_PAID: { bg: '#FEF3C7', text: '#92400E' },
  ALLOCATED: { bg: '#FEF3C7', text: '#92400E' },
  IN_TRANSIT: { bg: '#FEF3C7', text: '#92400E' },
  IN_REVIEW: { bg: '#FEF3C7', text: '#92400E' },
  PENDING_APPROVAL: { bg: '#FEF3C7', text: '#92400E' },
  // Info / neutral-positive
  DRAFT: { bg: '#E6F1FB', text: '#0C447C' },
  PENDING: { bg: '#E6F1FB', text: '#0C447C' },
  SUBMITTED: { bg: '#E6F1FB', text: '#0C447C' },
  OPEN: { bg: '#E6F1FB', text: '#0C447C' },
  ISSUED: { bg: '#E6F1FB', text: '#0C447C' },
  QUOTED: { bg: '#EEEDFE', text: '#3C3489' },
  // Danger
  CANCELLED: { bg: '#FEE2E2', text: '#B91C1C' },
  REJECTED: { bg: '#FEE2E2', text: '#B91C1C' },
  BLOCKED: { bg: '#FEE2E2', text: '#B91C1C' },
  FAILED: { bg: '#FEE2E2', text: '#B91C1C' },
  VOIDED: { bg: '#FEE2E2', text: '#B91C1C' },
  TERMINATED: { bg: '#FEE2E2', text: '#B91C1C' },
  LOST: { bg: '#FEE2E2', text: '#B91C1C' },
  // Muted
  CLOSED: { bg: '#F3F4F6', text: '#6B7280' },
  LOCKED: { bg: '#F3F4F6', text: '#6B7280' },
  OFFLINE: { bg: '#F3F4F6', text: '#6B7280' },
  MAINTENANCE: { bg: '#F3F4F6', text: '#6B7280' },
};

interface StatusBadgeProps {
  status: Status;
  className?: string;
  /** Override display text (defaults to status with _ → space) */
  label?: string;
}

export function StatusBadge({ status, className, label }: StatusBadgeProps) {
  const colours = STATUS_MAP[status] ?? { bg: '#F3F4F6', text: '#6B7280' };
  return (
    <span
      className={cn(
        'inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wide whitespace-nowrap',
        className,
      )}
      style={{ background: colours.bg, color: colours.text }}
    >
      {label ?? status.replace(/_/g, ' ')}
    </span>
  );
}
