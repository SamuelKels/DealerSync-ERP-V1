/**
 * AGCOMS DealerSync ERP — Button (shadcn/ui)
 * Sprint 2 Fix: shadcn/ui was specified in master prompt but not installed.
 * Brand variant uses Primary Green #1A4D2E.
 */
import * as React from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../../lib/cn';

const buttonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1A4D2E] focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50',
  {
    variants: {
      variant: {
        default: 'bg-[#1A4D2E] text-white hover:bg-[#2D6A4A]',
        secondary: 'bg-[#F7F4EF] text-[#1A1A1A] border border-[#E5E7EB] hover:bg-[#EDEBE5]',
        destructive: 'bg-[#DC2626] text-white hover:bg-[#B91C1C]',
        outline: 'border border-[#E5E7EB] bg-white text-[#1A1A1A] hover:bg-[#F7F4EF]',
        ghost: 'text-[#1A1A1A] hover:bg-[#F7F4EF]',
        link: 'text-[#1A4D2E] underline-offset-4 hover:underline',
        gold: 'bg-[#E8A020] text-white hover:bg-[#C8881A]',
      },
      size: {
        default: 'h-9 px-4 py-2',
        sm: 'h-8 rounded-md px-3 text-xs',
        lg: 'h-10 rounded-md px-8',
        icon: 'h-9 w-9',
        xs: 'h-6 rounded-md px-2 text-[11px]',
      },
    },
    defaultVariants: { variant: 'default', size: 'default' },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : 'button';
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = 'Button';

export { Button, buttonVariants };
