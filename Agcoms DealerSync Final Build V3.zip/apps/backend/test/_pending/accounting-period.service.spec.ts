/**
 * AGCOMS DealerSync ERP — AccountingPeriodService tests (Sprint P2)
 *
 * Validates: create, list, close, lock, reopen lifecycle.
 * Critical assertions: LOCKED cannot reopen, draft journals block close,
 * imbalanced trial balance blocks close.
 */
import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';

import { AccountingPeriodService } from '../../src/modules/finance/periods/accounting-period.service';
import { PrismaService } from '../../src/prisma/prisma.service';
import { AuditService } from '../../src/audit/audit.service';
import type { JwtPayload } from '@agcoms/types';

describe('AccountingPeriodService', () => {
  let service: AccountingPeriodService;
  let prisma: any;
  let audit: any;

  const superAdmin: JwtPayload = {
    sub: 'admin-1', email: 'admin@agcoms.ng', firstName: 'A', lastName: 'A',
    branchId: 'br-1', branchCode: 'ABJ', branchIds: ['br-1'],
    roles: ['super_admin'], permissions: ['finance:close-period'],
    isSuperAdmin: true, type: 'internal', sessionId: 'sess-1',
  };

  const branchAdmin: JwtPayload = {
    ...superAdmin, sub: 'b-1', roles: ['finance_manager'],
    isSuperAdmin: false, permissions: ['finance:close-period'],
  };

  const accountant: JwtPayload = {
    ...superAdmin, sub: 'acc-1', roles: ['accountant'],
    isSuperAdmin: false, permissions: ['finance:read'],
  };

  beforeEach(async () => {
    prisma = {
      accountingPeriod: {
        findUnique: jest.fn(), findMany: jest.fn(), findFirst: jest.fn(),
        create: jest.fn(), update: jest.fn(),
      },
      journalEntry: { count: jest.fn(), aggregate: jest.fn() },
    };
    audit = { log: jest.fn().mockResolvedValue(undefined) };

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AccountingPeriodService,
        { provide: PrismaService, useValue: prisma },
        { provide: AuditService, useValue: audit },
      ],
    }).compile();

    service = module.get(AccountingPeriodService);
  });

  describe('createPeriod', () => {
    it('creates a monthly period with name YYYY-MM', async () => {
      prisma.accountingPeriod.create.mockResolvedValue({ id: 'p-1', name: '2025-03' });
      const result = await service.createPeriod({
        branchId: 'br-1', year: 2025, month: 3,
        startDate: '2025-03-01', endDate: '2025-03-31',
      }, superAdmin);
      expect(result.name).toBe('p-1' as any === 'p-1' ? 'p-1' : '2025-03');  // mock returns 'p-1'
      expect(prisma.accountingPeriod.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ name: '2025-03', status: 'OPEN' }) })
      );
      expect(audit.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'finance.period.created' }));
    });

    it('rejects both month AND quarter', async () => {
      await expect(service.createPeriod({
        branchId: 'br-1', year: 2025, month: 1, quarter: 1,
        startDate: '2025-01-01', endDate: '2025-03-31',
      }, superAdmin)).rejects.toThrow(BadRequestException);
    });

    it('rejects cross-branch creation by non-super-admin', async () => {
      await expect(service.createPeriod({
        branchId: 'br-2', year: 2025, month: 1,
        startDate: '2025-01-01', endDate: '2025-01-31',
      }, branchAdmin)).rejects.toThrow(ForbiddenException);
    });
  });

  describe('closePeriod', () => {
    it('closes OPEN period when no drafts remain and trial balance balances', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'OPEN' });
      prisma.journalEntry.count.mockResolvedValue(0);
      prisma.journalEntry.aggregate.mockResolvedValue({ _sum: { totalDebits: 1000, totalCredits: 1000 } });
      prisma.accountingPeriod.update.mockResolvedValue({ id: 'p-1', status: 'CLOSED', closedAt: new Date() });

      const result = await service.closePeriod('p-1', superAdmin);
      expect(result.status).toBe('CLOSED');
      expect(audit.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'finance.period.closed' }));
    });

    it('refuses to close period with remaining draft entries', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'OPEN' });
      prisma.journalEntry.count.mockResolvedValue(3);
      await expect(service.closePeriod('p-1', superAdmin))
        .rejects.toThrow(/3 draft journal entries remain/);
    });

    it('refuses to close period with imbalanced trial balance', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'OPEN' });
      prisma.journalEntry.count.mockResolvedValue(0);
      prisma.journalEntry.aggregate.mockResolvedValue({ _sum: { totalDebits: 1000, totalCredits: 950 } });
      await expect(service.closePeriod('p-1', superAdmin))
        .rejects.toThrow(/trial balance out of balance/);
    });

    it('refuses to close LOCKED period', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'LOCKED' });
      await expect(service.closePeriod('p-1', superAdmin))
        .rejects.toThrow(/Period is locked/);
    });

    it('refuses to close already CLOSED period', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'CLOSED' });
      await expect(service.closePeriod('p-1', superAdmin))
        .rejects.toThrow(/already closed/);
    });

    it('rejects close by user without finance:close-period permission', async () => {
      await expect(service.closePeriod('p-1', accountant)).rejects.toThrow(ForbiddenException);
    });
  });

  describe('lockPeriod', () => {
    it('locks CLOSED period when super-admin requests', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'CLOSED' });
      prisma.accountingPeriod.update.mockResolvedValue({ id: 'p-1', status: 'LOCKED', lockedAt: new Date() });

      const result = await service.lockPeriod('p-1', superAdmin);
      expect(result.status).toBe('LOCKED');
      expect(audit.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'finance.period.locked' }));
    });

    it('refuses to lock OPEN period directly (must close first)', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'OPEN' });
      await expect(service.lockPeriod('p-1', superAdmin))
        .rejects.toThrow(/must be CLOSED before it can be LOCKED/);
    });

    it('rejects lock by non-super-admin', async () => {
      await expect(service.lockPeriod('p-1', branchAdmin)).rejects.toThrow(ForbiddenException);
    });
  });

  describe('reopenPeriod', () => {
    it('reopens CLOSED period when super-admin requests', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'CLOSED' });
      prisma.accountingPeriod.update.mockResolvedValue({ id: 'p-1', status: 'OPEN', closedAt: null });

      const result = await service.reopenPeriod('p-1', superAdmin);
      expect(result.status).toBe('OPEN');
      expect(audit.log).toHaveBeenCalledWith(expect.objectContaining({ action: 'finance.period.reopened' }));
    });

    it('refuses to reopen LOCKED period (IMMUTABLE — critical IFRS rule)', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ id: 'p-1', status: 'LOCKED' });
      await expect(service.reopenPeriod('p-1', superAdmin))
        .rejects.toThrow(/LOCKED periods cannot be reopened/);
    });

    it('rejects reopen by non-super-admin', async () => {
      await expect(service.reopenPeriod('p-1', branchAdmin)).rejects.toThrow(ForbiddenException);
    });
  });

  describe('isPeriodLocked', () => {
    it('returns true for LOCKED period', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ status: 'LOCKED' });
      expect(await service.isPeriodLocked('p-1')).toBe(true);
    });
    it('returns false for OPEN period', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ status: 'OPEN' });
      expect(await service.isPeriodLocked('p-1')).toBe(false);
    });
    it('returns false for CLOSED period (allows correction journals)', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue({ status: 'CLOSED' });
      expect(await service.isPeriodLocked('p-1')).toBe(false);
    });
    it('throws when period not found', async () => {
      prisma.accountingPeriod.findUnique.mockResolvedValue(null);
      await expect(service.isPeriodLocked('nope')).rejects.toThrow(NotFoundException);
    });
  });

  describe('resolvePeriodForDate', () => {
    it('finds the period containing the given date', async () => {
      const period = { id: 'p-1', name: '2025-03', startDate: '2025-03-01', endDate: '2025-03-31' };
      prisma.accountingPeriod.findFirst.mockResolvedValue(period);
      const result = await service.resolvePeriodForDate('br-1', new Date('2025-03-15'));
      expect(result.id).toBe('p-1');
    });

    it('throws when no period covers the date', async () => {
      prisma.accountingPeriod.findFirst.mockResolvedValue(null);
      await expect(service.resolvePeriodForDate('br-1', new Date('2099-01-01')))
        .rejects.toThrow(/No accounting period defined/);
    });
  });
});
