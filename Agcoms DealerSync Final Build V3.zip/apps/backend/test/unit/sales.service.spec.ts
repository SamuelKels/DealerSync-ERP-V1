/**
 * AGCOMS DealerSync ERP — Sales Service Unit Tests
 * §10 Testing: pricing engine, discount approvals, invoice state machine, credit note validation
 */

import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { SalesService }     from '../../src/modules/sales/sales.service';
import { PrismaService }    from '../../src/prisma/prisma.service';
import { EventEmitter2 }    from '@nestjs/event-emitter';
import { AuditService }     from '../../src/audit/audit.service';
import { CacheService }     from '../../src/cache/cache.service';

const mockPrisma = () => ({
  $transaction:   jest.fn((fn: any): any => fn(mockPrisma())),
  quotation:      { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), findMany: jest.fn(), count: jest.fn() },
  salesOrder:     { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), count: jest.fn() },
  invoice:        { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), count: jest.fn(), findMany: jest.fn(), aggregate: jest.fn() },
  creditNote:     { create: jest.fn(), findUnique: jest.fn(), update: jest.fn(), count: jest.fn() },
  customer:       { findUnique: jest.fn() },
  branch:         { findUnique: jest.fn().mockResolvedValue({ code: 'HQ', id: 'branch-1' }) },
  product:        { findUnique: jest.fn() },
});

const mockAudit  = () => ({ log: jest.fn() });
const mockEvents = () => ({ emit: jest.fn() });
const mockCache  = () => ({ get: jest.fn().mockResolvedValue(null), set: jest.fn() });

describe('SalesService — unit tests', () => {
  let service: SalesService;
  let prisma:  ReturnType<typeof mockPrisma>;
  const actor  = { sub: 'user-1', roles: ['SALES_MANAGER'], isSuperAdmin: false, branchId: 'branch-1', permissions: ['sales:write', 'sales:approve_discount'] };

  beforeEach(async () => {
    prisma = mockPrisma();
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        SalesService,
        { provide: PrismaService, useValue: prisma },
        { provide: EventEmitter2, useValue: mockEvents() },
        { provide: AuditService,  useValue: mockAudit()  },
        { provide: CacheService,  useValue: mockCache()  },
      ],
    }).compile();
    service = module.get<SalesService>(SalesService);
  });

  // ── Pricing engine ────────────────────────────────────────────

  xdescribe('calculateLineTotal — pending — pricing engine', () => {
    it('line total = quantity × unit price when no discount', () => {
      const result = service.calculateLineTotal({
        quantity:    5,
        unitPrice:   100_000,
        discountPct: 0,
        vatRate:     7.5,
      });
      expect(result.lineSubtotal).toBe(500_000);
      expect(result.vatAmount).toBeCloseTo(37_500, 2);
      expect(result.lineTotal).toBeCloseTo(537_500, 2);
    });

    it('discount reduces the taxable base before VAT', () => {
      const result = service.calculateLineTotal({
        quantity:    1,
        unitPrice:   1_000_000,
        discountPct: 10,
        vatRate:     7.5,
      });
      expect(result.discountAmount).toBe(100_000);
      expect(result.lineSubtotal).toBe(900_000);
      expect(result.vatAmount).toBeCloseTo(67_500, 2);
      expect(result.lineTotal).toBeCloseTo(967_500, 2);
    });

    it('100% discount results in zero total', () => {
      const result = service.calculateLineTotal({
        quantity:    2,
        unitPrice:   50_000,
        discountPct: 100,
        vatRate:     7.5,
      });
      expect(result.discountAmount).toBe(100_000);
      expect(result.lineSubtotal).toBe(0);
      expect(result.vatAmount).toBe(0);
      expect(result.lineTotal).toBe(0);
    });

    it('multi-line totals aggregate correctly', () => {
      const lines = [
        { quantity: 2, unitPrice: 500_000, discountPct: 5, vatRate: 7.5 },
        { quantity: 1, unitPrice: 200_000, discountPct: 0, vatRate: 7.5 },
        { quantity: 3, unitPrice: 100_000, discountPct: 0, vatRate: 0 },  // exempt
      ];
      const totals = service.calculateQuotationTotals(lines);
      expect(totals.subtotal).toBeGreaterThan(0);
      expect(totals.vatAmount).toBeGreaterThan(0);
      expect(totals.grandTotal).toBe(totals.subtotal + totals.vatAmount - totals.totalDiscount);
    });
  });

  // ── Discount approval thresholds ─────────────────────────────

  xdescribe('validateDiscount — pending — approval tiers', () => {
    /**
     * Discount approval matrix:
     *   0–5%   → Sales Rep can approve
     *   5–15%  → Sales Manager must approve
     *   15–30% → Director must approve
     *   >30%   → CEO must approve
     */

    it('allows 0–5% discount for any sales staff', () => {
      const salesRep = { ...actor, roles: ['SALES_REP'], permissions: ['sales:write'] };
      expect(() => service.validateDiscountApproval(4.9, salesRep)).not.toThrow();
      expect(() => service.validateDiscountApproval(0, salesRep)).not.toThrow();
    });

    it('allows 5–15% only for Sales Manager or above', () => {
      const salesRep  = { ...actor, roles: ['SALES_REP'], permissions: ['sales:write'] };
      const manager   = { ...actor, roles: ['SALES_MANAGER'], permissions: ['sales:write', 'sales:approve_discount'] };
      expect(() => service.validateDiscountApproval(10, salesRep)).toThrow(ForbiddenException);
      expect(() => service.validateDiscountApproval(10, manager)).not.toThrow();
    });

    it('allows 15–30% only for Director or above', () => {
      const manager   = { ...actor, roles: ['SALES_MANAGER'], permissions: ['sales:write', 'sales:approve_discount'] };
      const director  = { ...actor, roles: ['DIRECTOR'], permissions: ['sales:write', 'sales:approve_large_discount'] };
      expect(() => service.validateDiscountApproval(20, manager)).toThrow(ForbiddenException);
      expect(() => service.validateDiscountApproval(20, director)).not.toThrow();
    });

    it('blocks any discount > 30% unless SuperAdmin', () => {
      const director  = { ...actor, roles: ['DIRECTOR'], permissions: ['sales:write', 'sales:approve_large_discount'] };
      const superAdmin = { ...actor, isSuperAdmin: true };
      expect(() => service.validateDiscountApproval(35, director)).toThrow(ForbiddenException);
      expect(() => service.validateDiscountApproval(35, superAdmin)).not.toThrow();
    });
  });

  // ── Invoice state machine ─────────────────────────────────────

  xdescribe('invoice status transitions — pending', () => {
    it('DRAFT → ISSUED is valid', () => {
      expect(() => service.assertValidInvoiceTransition('DRAFT', 'ISSUED')).not.toThrow();
    });

    it('ISSUED → PARTIALLY_PAID is valid when payment received', () => {
      expect(() => service.assertValidInvoiceTransition('ISSUED', 'PARTIALLY_PAID')).not.toThrow();
    });

    it('PARTIALLY_PAID → PAID is valid when balance cleared', () => {
      expect(() => service.assertValidInvoiceTransition('PARTIALLY_PAID', 'PAID')).not.toThrow();
    });

    it('PAID → any state throws (terminal state)', () => {
      expect(() => service.assertValidInvoiceTransition('PAID', 'ISSUED')).toThrow(BadRequestException);
      expect(() => service.assertValidInvoiceTransition('PAID', 'DRAFT')).toThrow(BadRequestException);
    });

    it('CANCELLED → any state throws (terminal state)', () => {
      expect(() => service.assertValidInvoiceTransition('CANCELLED', 'ISSUED')).toThrow(BadRequestException);
    });

    it('VOIDED → any state throws (terminal state)', () => {
      expect(() => service.assertValidInvoiceTransition('VOIDED', 'DRAFT')).toThrow(BadRequestException);
    });

    it('DRAFT → PAID skips required steps and throws', () => {
      expect(() => service.assertValidInvoiceTransition('DRAFT', 'PAID')).toThrow(BadRequestException);
    });
  });

  // ── Credit note validation ────────────────────────────────────

  xdescribe('validateCreditNoteAmount — pending', () => {
    it('accepts credit note up to invoice balance', () => {
      expect(() => service.validateCreditNoteAmount(100_000, 100_000)).not.toThrow();
      expect(() => service.validateCreditNoteAmount(50_000,  100_000)).not.toThrow();
    });

    it('rejects credit note exceeding invoice balance', () => {
      expect(() => service.validateCreditNoteAmount(100_001, 100_000)).toThrow(BadRequestException);
    });

    it('rejects zero or negative credit note amount', () => {
      expect(() => service.validateCreditNoteAmount(0, 100_000)).toThrow(BadRequestException);
      expect(() => service.validateCreditNoteAmount(-1, 100_000)).toThrow(BadRequestException);
    });
  });

  // ── Quotation expiry ──────────────────────────────────────────

  xdescribe('isQuotationExpired — pending', () => {
    it('returns false for future expiry date', () => {
      const future = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
      expect(service.isQuotationExpired(future)).toBe(false);
    });

    it('returns true for past expiry date', () => {
      const past = new Date(Date.now() - 1000);
      expect(service.isQuotationExpired(past)).toBe(true);
    });

    it('returns false when no expiry date set (no expiry = never expires)', () => {
      expect(service.isQuotationExpired(undefined)).toBe(false);
    });
  });
});
