/**
 * AGCOMS DealerSync ERP — PiiMaskInterceptor Unit Tests
 * §5 Security: field-level masking must work correctly for all PII categories
 */

import { PiiMaskInterceptor }  from '../../src/common/interceptors/pii-mask.interceptor';
import { PII_FIELD_REGISTRY }  from '../../src/common/interceptors/pii-field.registry';
import { of }                  from 'rxjs';

// ── Mock execution context ─────────────────────────────────────
function makeContext(user: Partial<{
  isSuperAdmin: boolean;
  permissions: string[];
  sub: string;
}>) {
  return {
    switchToHttp: () => ({
      getRequest: () => ({ user }),
    }),
  } as any;
}

function makeCallHandler(body: unknown) {
  return { handle: () => of(body) };
}

// ── Helper: intercept and resolve observable ───────────────────
async function mask(interceptor: PiiMaskInterceptor, context: any, body: unknown): Promise<unknown> {
  return new Promise((resolve, reject) => {
    interceptor.intercept(context, makeCallHandler(body)).subscribe({
      next:  resolve,
      error: reject,
    });
  });
}

describe('PiiMaskInterceptor', () => {
  let interceptor: PiiMaskInterceptor;

  beforeEach(() => {
    interceptor = new PiiMaskInterceptor();
  });

  // ── Registry completeness ─────────────────────────────────────

  describe('PII field registry', () => {
    it('all registered fields have a required permission', () => {
      PII_FIELD_REGISTRY.forEach(config => {
        expect(config.requiredPermission).toBeTruthy();
        expect(config.requiredPermission).toContain(':');
      });
    });

    it('all registered fields have a mask sentinel', () => {
      PII_FIELD_REGISTRY.forEach(config => {
        expect(['***', 0, null]).toContain(config.maskWith);
      });
    });

    it('salary fields are masked with 0 (numeric)', () => {
      const salaryFields = ['grossSalary', 'basicSalary', 'netPay', 'paye', 'nhf'];
      salaryFields.forEach(field => {
        const config = PII_FIELD_REGISTRY.find(c => c.field === field);
        expect(config?.maskWith).toBe(0);
      });
    });

    it('identity fields are masked with "***" (string)', () => {
      const identityFields = ['bankAccountNo', 'nin', 'taxIdentification', 'pensionPin'];
      identityFields.forEach(field => {
        const config = PII_FIELD_REGISTRY.find(c => c.field === field);
        expect(config?.maskWith).toBe('***');
      });
    });
  });

  // ── SuperAdmin bypass ─────────────────────────────────────────

  describe('SuperAdmin bypass', () => {
    it('SuperAdmin sees unmasked salary data', async () => {
      const context = makeContext({ isSuperAdmin: true, permissions: [] });
      const body    = { grossSalary: 500_000, bankAccountNo: '0123456789' };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.grossSalary).toBe(500_000);
      expect(result.bankAccountNo).toBe('0123456789');
    });
  });

  // ── Permission-based masking ──────────────────────────────────

  describe('Permission-based field masking', () => {
    it('masks grossSalary to 0 for users without hr:read_sensitive', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: ['sales:write'] });
      const body    = { grossSalary: 500_000, firstName: 'Amaka', lastName: 'Osei' };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.grossSalary).toBe(0);
      expect(result.firstName).toBe('Amaka');   // Non-PII fields unaffected
    });

    it('reveals grossSalary to users with hr:read_sensitive', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: ['hr:read_sensitive'] });
      const body    = { grossSalary: 500_000 };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.grossSalary).toBe(500_000);
    });

    it('masks bankAccountNo to "***" for users without hr:read_sensitive', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = { bankAccountNo: '0123456789' };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.bankAccountNo).toBe('***');
    });

    it('masks creditLimit for users without customers:read_financial', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: ['crm:read'] });
      const body    = { creditLimit: 5_000_000, name: 'ACME Corp' };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.creditLimit).toBe(0);
      expect(result.name).toBe('ACME Corp');
    });
  });

  // ── Array traversal ───────────────────────────────────────────

  describe('Array traversal', () => {
    it('masks PII fields in each array element', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = [
        { id: '1', grossSalary: 300_000 },
        { id: '2', grossSalary: 400_000 },
      ];

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result[0]!.grossSalary).toBe(0);
      expect(result[1]!.grossSalary).toBe(0);
      expect(result[0]!.id).toBe('1');
    });
  });

  // ── Nested objects ────────────────────────────────────────────

  describe('Nested object traversal', () => {
    it('masks PII fields in nested payrollLine objects', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = {
        id:     'run-1',
        status: 'APPROVED',
        lines: [
          { employeeId: 'emp-1', grossSalary: 200_000, netPay: 170_000 },
        ],
      };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.status).toBe('APPROVED');
      expect(result.lines[0]!.grossSalary).toBe(0);
      expect(result.lines[0]!.netPay).toBe(0);
    });
  });

  // ── Null / undefined passthrough ──────────────────────────────

  describe('Null and undefined passthrough', () => {
    it('null PII fields are replaced with maskWith (0) when lacking permission', async () => {
      // grossSalary has maskWith: 0 — even null values get masked when user lacks permission
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = { grossSalary: null };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.grossSalary).toBe(0);  // masked to maskWith value regardless of null
    });

    it('null non-PII fields pass through as null', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = { someNonPiiField: null };

      const result = await mask(interceptor, context, body) as any;
      expect(result.someNonPiiField).toBeNull();
    });

    it('passes non-PII fields through unmasked', async () => {
      const context = makeContext({ isSuperAdmin: false, permissions: [] });
      const body    = {
        id:    'emp-1',
        email: 'amaka@agcoms.ng',
        jobTitle: 'Senior Technician',
      };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.email).toBe('amaka@agcoms.ng');
      expect(result.jobTitle).toBe('Senior Technician');
    });
  });

  // ── No user in context ────────────────────────────────────────

  describe('Unauthenticated requests', () => {
    it('masks all PII fields when no user is in context', async () => {
      const context = makeContext({} as any); // No user
      const body    = { grossSalary: 500_000, firstName: 'Test' };

      const result = await mask(interceptor, context, body) as typeof body;
      expect(result.grossSalary).toBe(0);
      expect(result.firstName).toBe('Test');
    });
  });
});
