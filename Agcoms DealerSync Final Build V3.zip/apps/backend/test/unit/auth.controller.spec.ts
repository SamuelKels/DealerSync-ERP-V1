/**
 * AGCOMS DealerSync ERP — Auth Controller tests (HTTP layer, mocked service)
 *
 * These run in CI/sandbox WITHOUT a database. AuthService is mocked, so they verify
 * exactly the layer the controller owns: routing, input validation, guards, cookie
 * handling, and response shaping — including the success path the DB-backed
 * integration suite cannot exercise without real Postgres.
 *
 * The end-to-end round-trip against a real database lives in
 * test/integration/auth/auth.integration.spec.ts (staging only).
 */
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { APP_GUARD, Reflector } from '@nestjs/core';
import { ThrottlerModule } from '@nestjs/throttler';
import cookieParser from 'cookie-parser';
import supertest from 'supertest';

import { AuthController } from '../../src/modules/auth/auth.controller';
import { AuthService } from '../../src/modules/auth/auth.service';
import { JwtAuthGuard } from '../../src/common/guards/auth.guards';

// ── Mock AuthService: deterministic, no database ─────────────────────────────
const SESSION = {
  requiresMfa: false,
  user: { id: 'u-1', email: 'admin@agcoms.ng', firstName: 'Emeka', lastName: 'Okonkwo',
          roles: ['SUPER_ADMIN'], permissions: ['*'], branchId: 'b-1', mfaEnabled: false },
  tokens: { accessToken: 'access.jwt.token', refreshToken: 'refresh-secret-token',
            expiresIn: 900, tokenType: 'Bearer' as const },
};

const mockAuthService = {
  login: jest.fn(),
  verifyMfa: jest.fn(),
  refresh: jest.fn(),
  logout: jest.fn().mockResolvedValue(undefined),
  logoutAll: jest.fn().mockResolvedValue(undefined),
};

// A stub JwtAuthGuard: rejects when no Bearer header, otherwise injects a fake user.
class StubJwtAuthGuard {
  canActivate(ctx: any): boolean {
    const req = ctx.switchToHttp().getRequest();
    const auth = req.headers?.authorization ?? '';
    if (!auth.startsWith('Bearer ')) {
      const { UnauthorizedException } = require('@nestjs/common');
      throw new UnauthorizedException();
    }
    req.user = { sub: 'u-1', sessionId: 's-1', roles: ['SUPER_ADMIN'], isSuperAdmin: true };
    return true;
  }
}

describe('AuthController (HTTP layer, mocked service)', () => {
  let app: INestApplication;
  let http: () => ReturnType<typeof supertest>;

  beforeAll(async () => {
    const moduleRef: TestingModule = await Test.createTestingModule({
      imports: [ThrottlerModule.forRoot([{ name: 'global', ttl: 60_000, limit: 100 }])],
      controllers: [AuthController],
      providers: [
        { provide: AuthService, useValue: mockAuthService },
        // Throttler neutralized here — rate limiting is verified separately (live 429 test).
        { provide: APP_GUARD, useValue: { canActivate: () => true } },
      ],
    })
      .overrideGuard(JwtAuthGuard)
      .useClass(StubJwtAuthGuard)
      .compile();

    app = moduleRef.createNestApplication();
    app.setGlobalPrefix('api/v1');
    app.use(cookieParser());
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    await app.init();
    http = () => supertest(app.getHttpServer());
  });

  afterAll(async () => { await app.close(); });
  beforeEach(() => { jest.clearAllMocks(); });

  // ── Login ──────────────────────────────────────────────────────────────────
  describe('POST /auth/login', () => {
    it('200 + accessToken in body and refresh token in HttpOnly cookie on success', async () => {
      mockAuthService.login.mockResolvedValueOnce(SESSION);
      const res = await http()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: 'SecureP@ssword123' })
        .expect(200);

      // access token returned in body
      expect(res.body.tokens.accessToken).toBe('access.jwt.token');
      // refresh token must NOT be in the body
      expect(res.body.tokens.refreshToken).toBeUndefined();
      // refresh token delivered as HttpOnly cookie
      const cookies = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
      const refresh = cookies.find((c) => c.startsWith('refresh_token='));
      expect(refresh).toBeDefined();
      expect(refresh).toMatch(/HttpOnly/i);
      expect(refresh).toMatch(/SameSite=Strict/i);
    });

    it('returns the MFA challenge (no cookie) when MFA is required', async () => {
      mockAuthService.login.mockResolvedValueOnce({ requiresMfa: true, mfaChallengeId: 'ch-1' });
      const res = await http()
        .post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: 'SecureP@ssword123' })
        .expect(200);
      expect(res.body.requiresMfa).toBe(true);
      expect(res.body.mfaChallengeId).toBe('ch-1');
      expect(res.headers['set-cookie']).toBeUndefined();
    });

    it('400 for invalid email format', async () => {
      await http().post('/api/v1/auth/login')
        .send({ email: 'not-an-email', password: 'SecureP@ssword123' }).expect(400);
      expect(mockAuthService.login).not.toHaveBeenCalled();
    });

    it('400 for missing password', async () => {
      await http().post('/api/v1/auth/login').send({ email: 'admin@agcoms.ng' }).expect(400);
    });

    it('400 and strips unknown properties (forbidNonWhitelisted)', async () => {
      await http().post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: 'SecureP@ssword123', role: 'SUPER_ADMIN' })
        .expect(400);
    });

    it('propagates 401 when the service rejects bad credentials', async () => {
      const { UnauthorizedException } = require('@nestjs/common');
      mockAuthService.login.mockRejectedValueOnce(new UnauthorizedException('Invalid credentials'));
      await http().post('/api/v1/auth/login')
        .send({ email: 'admin@agcoms.ng', password: 'WrongPassword1!' }).expect(401);
    });
  });

  // ── MFA verify ───────────────────────────────────────────────────────────────
  describe('POST /auth/mfa/verify', () => {
    it('200 + sets refresh cookie on success', async () => {
      mockAuthService.verifyMfa.mockResolvedValueOnce(SESSION);
      const res = await http().post('/api/v1/auth/mfa/verify')
        .send({ code: '123456', challengeToken: 'ch-1' }).expect(200);
      expect(res.body.tokens.accessToken).toBe('access.jwt.token');
      const cookies = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
      expect(cookies.some((c) => c.startsWith('refresh_token='))).toBe(true);
    });

    it('400 for a non-numeric MFA code', async () => {
      await http().post('/api/v1/auth/mfa/verify')
        .send({ code: 'abcdef', challengeToken: 'ch-1' }).expect(400);
    });
  });

  // ── Refresh ────────────────────────────────────────────────────────────────
  describe('POST /auth/refresh', () => {
    it('200 + new cookie when refreshing with a valid cookie', async () => {
      mockAuthService.refresh.mockResolvedValueOnce(SESSION);
      const res = await http().post('/api/v1/auth/refresh')
        .set('Cookie', 'refresh_token=valid-refresh-token').expect(200);
      expect(res.body.tokens.accessToken).toBe('access.jwt.token');
      expect(mockAuthService.refresh).toHaveBeenCalledWith('valid-refresh-token', expect.any(Object));
    });

    it('falls back to a refreshToken body field for non-browser API clients', async () => {
      mockAuthService.refresh.mockResolvedValueOnce(SESSION);
      await http().post('/api/v1/auth/refresh').send({ refreshToken: 'body-token' }).expect(200);
      expect(mockAuthService.refresh).toHaveBeenCalledWith('body-token', expect.any(Object));
    });

    it('401 when no refresh token is present', async () => {
      await http().post('/api/v1/auth/refresh').expect(401);
      expect(mockAuthService.refresh).not.toHaveBeenCalled();
    });
  });

  // ── Logout (guard enforcement) ───────────────────────────────────────────────
  describe('POST /auth/logout', () => {
    it('401 without a Bearer token', async () => {
      await http().post('/api/v1/auth/logout').expect(401);
      expect(mockAuthService.logout).not.toHaveBeenCalled();
    });

    it('200 + clears the refresh cookie with a valid token', async () => {
      const res = await http().post('/api/v1/auth/logout')
        .set('Authorization', 'Bearer fake.jwt').expect(200);
      expect(mockAuthService.logout).toHaveBeenCalledWith('s-1', 'u-1', expect.any(Object));
      const cookies = ([] as string[]).concat(res.headers['set-cookie'] ?? []);
      // cleared cookie has an expiry in the past / Max-Age=0
      expect(cookies.some((c) => c.startsWith('refresh_token='))).toBe(true);
    });
  });

  describe('POST /auth/logout-all', () => {
    it('401 without a Bearer token', async () => {
      await http().post('/api/v1/auth/logout-all').expect(401);
    });
    it('200 and revokes all sessions with a valid token', async () => {
      await http().post('/api/v1/auth/logout-all').set('Authorization', 'Bearer fake.jwt').expect(200);
      expect(mockAuthService.logoutAll).toHaveBeenCalledWith('u-1', expect.any(Object));
    });
  });
});
