/**
 * AGCOMS DealerSync ERP — CRM Service Unit Tests
 * §10 Testing: credit control thresholds, customer segmentation,
 *              AI governance enforcement, AR aging buckets
 */

import { Test, TestingModule } from '@nestjs/testing';
import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { CrmService }           from '../../src/modules/crm/crm.service';
import { CreditControlService } from '../../src/modules/crm/credit-control.service';
import { AiService }            from '../../src/modules/ai/ai.service';
import { AnthropicClientService } from '../../src/modules/ai/strategies/anthropic-client.service';
import { PrismaService }        from '../../src/prisma/prisma.service';
import { EventEmitter2 }        from '@nestjs/event-emitter';
import { AuditService }         from '../../src/audit/audit.service';
import { CacheService }         from '../../src/cache/cache.service';
import { FeatureFlagsService }  from '../../src/common/feature-flags/feature-flags.service';

// ── Mocks ──────────────────────────────────────────────────────
const mockPrisma = () => ({
  customer:        { findUnique: jest.fn(), findFirst: jest.fn(), findMany: jest.fn(), create: jest.fn(), update: jest.fn(), count: jest.fn() },
  lead:            { findMany: jest.fn(), create: jest.fn(), count: jest.fn(), update: jest.fn() },
  invoice:         { aggregate: jest.fn(), findMany: jest.fn() },
  branch:          { findUnique: jest.fn().mockResolvedValue({ code: 'LG' }) },
  rfq:             { create: jest.fn(), findMany: jest.fn() },
});

// ── CRM / Credit Control ───────────────────────────────────────

describe('CreditControlService — unit tests', () => {
  let service: CreditControlService;
  let prisma:  ReturnType<typeof mockPrisma>;

  beforeEach(async () => {
    prisma = mockPrisma();
    const module = await Test.createTestingModule({
      providers: [
        CreditControlService,
        { provide: PrismaService, useValue: prisma },
      ],
    }).compile();
    service = module.get<CreditControlService>(CreditControlService);
  });

  describe('checkCredit — utilisation thresholds', () => {
    const mockCustomer = { id: 'cust-1', name: 'TestCo Ltd', creditLimit: 1_000_000, status: 'ACTIVE' };

    it('returns CLEAR when utilisation < 80%', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      // Outstanding invoices: ₦500K
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 500_000, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 0, 'invoice');
      expect(result.status).toBe('CLEAR');
      expect(result.utilisationPct).toBe(50);
    });

    it('returns WARNING when utilisation is 80–99%', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 850_000, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 0, 'invoice');
      expect(result.status).toBe('WARNING');
      expect(result.utilisationPct).toBe(85);
    });

    it('returns BLOCKED when utilisation reaches 100%', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 1_000_000, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 0, 'invoice');
      expect(result.status).toBe('BLOCKED');
      expect(result.utilisationPct).toBe(100);
    });

    it('includes new transaction value in utilisation calculation', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      // Outstanding: ₦700K, new transaction: ₦400K → 110% → BLOCKED
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 700_000, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 400_000, 'sales_order');
      expect(result.status).toBe('BLOCKED');
    });

    it('customer with zero credit limit is always CLEAR (cash-only)', async () => {
      prisma.customer.findUnique.mockResolvedValue({ ...mockCustomer, creditLimit: 0 });
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 999_999, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 0, 'invoice');
      expect(result.status).toBe('CLEAR');
    });

    it('BLACKLISTED customer always throws regardless of credit balance', async () => {
      prisma.customer.findUnique.mockResolvedValue({ ...mockCustomer, status: 'BLACKLISTED', creditLimit: 10_000_000 });

      await expect(service.checkCredit('cust-1', 0, 'invoice')).rejects.toThrow(BadRequestException);
    });

    it('enforceCredit throws BadRequestException when BLOCKED', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 1_000_000, amountPaid: 0 } });

      await expect(service.enforceCredit('cust-1', 100_000, 'sales_order')).rejects.toThrow(BadRequestException);
    });

    it('available credit is zero (floor) when over-limit', async () => {
      prisma.customer.findUnique.mockResolvedValue(mockCustomer);
      prisma.invoice.aggregate.mockResolvedValue({ _sum: { totalAmount: 1_200_000, amountPaid: 0 } });

      const result = await service.checkCredit('cust-1', 0, 'invoice');
      expect(result.availableCredit).toBe(0); // floor — never negative
    });
  });

  xdescribe('AR aging bucket assignment — pending: getAgingBucket not yet implemented', () => {
    it('assigns to Current bucket for invoices 0 days overdue', () => {
      const today = new Date();
      expect(service.getAgingBucket(today)).toBe('CURRENT');
    });

    it('assigns to 1–30 bucket for 15 days overdue', () => {
      const past = new Date(Date.now() - 15 * 86400_000);
      expect(service.getAgingBucket(past)).toBe('DAYS_1_30');
    });

    it('assigns to 31–60 bucket for 45 days overdue', () => {
      const past = new Date(Date.now() - 45 * 86400_000);
      expect(service.getAgingBucket(past)).toBe('DAYS_31_60');
    });

    it('assigns to 61–90 bucket for 75 days overdue', () => {
      const past = new Date(Date.now() - 75 * 86400_000);
      expect(service.getAgingBucket(past)).toBe('DAYS_61_90');
    });

    it('assigns to Over 90 bucket for 91+ days overdue', () => {
      const past = new Date(Date.now() - 100 * 86400_000);
      expect(service.getAgingBucket(past)).toBe('OVER_90');
    });
  });
});

// ── AI Governance ──────────────────────────────────────────────

describe('AiService — governance enforcement', () => {
  let service: AiService;
  let prisma: ReturnType<typeof mockPrisma>;

  const mockFlags   = () => ({ isEnabled: jest.fn().mockResolvedValue(true) });
  const mockCache   = () => ({ get: jest.fn().mockResolvedValue(null), set: jest.fn() });

  beforeEach(async () => {
    prisma = mockPrisma();
    const module = await Test.createTestingModule({
      providers: [
        AiService,
        { provide: AnthropicClientService, useValue: {
          complete: jest.fn(),
          assertActionPermitted: jest.fn().mockImplementation((action) => {
            const BLOCKED = new Set(['approve_financial_transaction','modify_inventory','alter_accounting_records','override_approval','bypass_rbac']);
            if (BLOCKED.has(action)) { const { ForbiddenException } = require('@nestjs/common'); throw new ForbiddenException('BLOCKED_ACTION: ' + action); }
          }),
        } },
        { provide: PrismaService,      useValue: prisma },
        { provide: EventEmitter2,      useValue: { emit: jest.fn() } },
        { provide: CacheService,       useValue: mockCache() },
        { provide: FeatureFlagsService, useValue: mockFlags() },
      ],
    }).compile();
    service = module.get<AiService>(AiService);
  });

  // §7 M13 / §13 AI Governance Rules
  describe('assertAiActionPermitted — §7 AI governance', () => {
    it('permits: summarize', () => {
      expect(() => service.assertAiActionPermitted('summarize')).not.toThrow();
    });

    it('permits: recommend', () => {
      expect(() => service.assertAiActionPermitted('recommend')).not.toThrow();
    });

    it('permits: draft', () => {
      expect(() => service.assertAiActionPermitted('draft')).not.toThrow();
    });

    it('permits: forecast', () => {
      expect(() => service.assertAiActionPermitted('forecast')).not.toThrow();
    });

    it('permits: classify', () => {
      expect(() => service.assertAiActionPermitted('classify')).not.toThrow();
    });

    it('BLOCKS: approve_financial_transaction', () => {
      expect(() => service.assertAiActionPermitted('approve_financial_transaction')).toThrow(ForbiddenException);
    });

    it('BLOCKS: modify_inventory', () => {
      expect(() => service.assertAiActionPermitted('modify_inventory')).toThrow(ForbiddenException);
    });

    it('BLOCKS: alter_accounting_records', () => {
      expect(() => service.assertAiActionPermitted('alter_accounting_records')).toThrow(ForbiddenException);
    });

    it('BLOCKS: override_approval', () => {
      expect(() => service.assertAiActionPermitted('override_approval')).toThrow(ForbiddenException);
    });

    it('BLOCKS: bypass_rbac', () => {
      expect(() => service.assertAiActionPermitted('bypass_rbac')).toThrow(ForbiddenException);
    });
  });

  describe('wrapInAiAdvisory — advisory envelope', () => {
    it('wraps output with human_action_required: true', () => {
      const advisory = service.wrapInAiAdvisory({ forecast: [1, 2, 3] }, 'inventory forecast');
      expect(advisory.human_action_required).toBe(true);
    });

    it('includes governance metadata', () => {
      const advisory = service.wrapInAiAdvisory('some summary', 'crm summary');
      expect(advisory.governance).toBeDefined();
      expect(advisory.governance.disclaimer).toContain('advisory');
    });

    it('includes generated_at timestamp', () => {
      const advisory = service.wrapInAiAdvisory({}, 'test');
      expect(advisory.governance.generated_at).toBeDefined();
      expect(new Date(advisory.governance.generated_at).getTime()).not.toBeNaN();
    });
  });
});
