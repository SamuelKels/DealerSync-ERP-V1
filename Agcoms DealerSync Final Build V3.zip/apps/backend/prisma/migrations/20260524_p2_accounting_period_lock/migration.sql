-- AGCOMS DealerSync ERP — Sprint P2 Migration
-- Adds: ChartOfAccount, AccountingPeriod, JournalEntry, JournalEntryLine, BankTransaction, VatReturn
-- Enables period-lock enforcement for IFRS-compliant financial integrity.

-- ─── Enums ──────────────────────────────────────────────
CREATE TYPE "AccountType" AS ENUM ('ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE');
CREATE TYPE "AccountNormalBalance" AS ENUM ('DEBIT', 'CREDIT');
CREATE TYPE "JournalEntryStatus" AS ENUM ('DRAFT', 'POSTED', 'VOID');
CREATE TYPE "AccountingPeriodStatus" AS ENUM ('OPEN', 'CLOSED', 'LOCKED');
CREATE TYPE "BankTransactionStatus" AS ENUM ('PENDING', 'RECONCILED', 'IGNORED');

-- ─── Chart of Accounts ──────────────────────────────────
CREATE TABLE "chart_of_accounts" (
    "id"            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "branchId"      UUID NOT NULL,
    "code"          VARCHAR(20) NOT NULL,
    "name"          VARCHAR(200) NOT NULL,
    "accountType"   "AccountType" NOT NULL,
    "normalBalance" "AccountNormalBalance" NOT NULL,
    "parentId"      UUID,
    "isActive"      BOOLEAN NOT NULL DEFAULT TRUE,
    "isSystem"      BOOLEAN NOT NULL DEFAULT FALSE,
    "description"   TEXT,
    "isDeleted"     BOOLEAN NOT NULL DEFAULT FALSE,
    "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"     TIMESTAMP(3) NOT NULL,
    "createdById"   UUID NOT NULL,

    CONSTRAINT "chart_of_accounts_branchId_code_key" UNIQUE ("branchId", "code"),
    CONSTRAINT "chart_of_accounts_branchId_fkey"  FOREIGN KEY ("branchId")  REFERENCES "branches"("id"),
    CONSTRAINT "chart_of_accounts_parentId_fkey"  FOREIGN KEY ("parentId")  REFERENCES "chart_of_accounts"("id")
);
CREATE INDEX "chart_of_accounts_branchId_accountType_idx" ON "chart_of_accounts" ("branchId", "accountType");
CREATE INDEX "chart_of_accounts_parentId_idx" ON "chart_of_accounts" ("parentId");

-- ─── Accounting Periods (IFRS period lock enforcement) ──
CREATE TABLE "accounting_periods" (
    "id"            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "branchId"      UUID NOT NULL,
    "name"          VARCHAR(50) NOT NULL,
    "year"          INTEGER NOT NULL,
    "month"         INTEGER,
    "quarter"       INTEGER,
    "startDate"     DATE NOT NULL,
    "endDate"       DATE NOT NULL,
    "status"        "AccountingPeriodStatus" NOT NULL DEFAULT 'OPEN',
    "closedAt"      TIMESTAMP(3),
    "closedById"    UUID,
    "lockedAt"      TIMESTAMP(3),
    "lockedById"    UUID,
    "notes"         TEXT,
    "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"     TIMESTAMP(3) NOT NULL,

    -- NULLS NOT DISTINCT (PostgreSQL 15+): quarter/month are NULL for monthly/quarterly/annual
    -- periods; without this, NULLs compare as distinct and duplicate periods for the same
    -- (branch, year, month) slip through — breaking period close/lock integrity.
    CONSTRAINT "accounting_periods_branchId_year_month_quarter_key" UNIQUE NULLS NOT DISTINCT ("branchId", "year", "month", "quarter"),
    CONSTRAINT "accounting_periods_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "branches"("id")
);
CREATE INDEX "accounting_periods_branchId_status_idx" ON "accounting_periods" ("branchId", "status");
CREATE INDEX "accounting_periods_startDate_endDate_idx" ON "accounting_periods" ("startDate", "endDate");

-- ─── Journal Entries (header) ───────────────────────────
CREATE TABLE "journal_entries" (
    "id"            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "branchId"      UUID NOT NULL,
    "periodId"      UUID NOT NULL,
    "entryNumber"   VARCHAR(50) NOT NULL,
    "entryDate"     DATE NOT NULL,
    "description"   VARCHAR(500) NOT NULL,
    "reference"     VARCHAR(100),
    "status"        "JournalEntryStatus" NOT NULL DEFAULT 'DRAFT',
    "totalDebits"   DECIMAL(18,2) NOT NULL DEFAULT 0,
    "totalCredits"  DECIMAL(18,2) NOT NULL DEFAULT 0,
    "postedAt"      TIMESTAMP(3),
    "postedById"    UUID,
    "voidedAt"      TIMESTAMP(3),
    "voidedById"    UUID,
    "voidReason"    TEXT,
    "reversalOfId"  UUID UNIQUE,
    "isSystem"      BOOLEAN NOT NULL DEFAULT FALSE,
    "metadata"      JSONB,
    "createdAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"     TIMESTAMP(3) NOT NULL,
    "createdById"   UUID NOT NULL,

    CONSTRAINT "journal_entries_branchId_entryNumber_key" UNIQUE ("branchId", "entryNumber"),
    CONSTRAINT "journal_entries_branchId_fkey"     FOREIGN KEY ("branchId")     REFERENCES "branches"("id"),
    CONSTRAINT "journal_entries_periodId_fkey"     FOREIGN KEY ("periodId")     REFERENCES "accounting_periods"("id"),
    CONSTRAINT "journal_entries_reversalOfId_fkey" FOREIGN KEY ("reversalOfId") REFERENCES "journal_entries"("id")
);
CREATE INDEX "journal_entries_branchId_status_entryDate_idx" ON "journal_entries" ("branchId", "status", "entryDate");
CREATE INDEX "journal_entries_periodId_idx" ON "journal_entries" ("periodId");
CREATE INDEX "journal_entries_reference_idx" ON "journal_entries" ("reference");

-- ─── Journal Entry Lines (debit/credit postings) ────────
CREATE TABLE "journal_entry_lines" (
    "id"             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "journalEntryId" UUID NOT NULL,
    "accountId"      UUID NOT NULL,
    "lineNumber"     INTEGER NOT NULL,
    "debitAmount"    DECIMAL(18,2) NOT NULL DEFAULT 0,
    "creditAmount"   DECIMAL(18,2) NOT NULL DEFAULT 0,
    "description"    VARCHAR(500),
    "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "journal_entry_lines_journalEntryId_fkey" FOREIGN KEY ("journalEntryId") REFERENCES "journal_entries"("id") ON DELETE CASCADE,
    CONSTRAINT "journal_entry_lines_accountId_fkey"      FOREIGN KEY ("accountId")      REFERENCES "chart_of_accounts"("id")
);
CREATE INDEX "journal_entry_lines_journalEntryId_lineNumber_idx" ON "journal_entry_lines" ("journalEntryId", "lineNumber");
CREATE INDEX "journal_entry_lines_accountId_idx" ON "journal_entry_lines" ("accountId");

-- ─── Bank Transactions (reconciliation) ─────────────────
CREATE TABLE "bank_transactions" (
    "id"                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "branchId"          UUID NOT NULL,
    "bankAccountId"     UUID NOT NULL,
    "txnDate"           DATE NOT NULL,
    "description"       VARCHAR(500) NOT NULL,
    "reference"         VARCHAR(100),
    "amount"            DECIMAL(18,2) NOT NULL,
    "balance"           DECIMAL(18,2),
    "status"            "BankTransactionStatus" NOT NULL DEFAULT 'PENDING',
    "reconciledAt"      TIMESTAMP(3),
    "reconciledById"    UUID,
    "matchedJournalId"  UUID,
    "importedFromFile"  VARCHAR(255),
    "rawData"           JSONB,
    "createdAt"         TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"         TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bank_transactions_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "branches"("id")
);
CREATE INDEX "bank_transactions_branchId_txnDate_idx" ON "bank_transactions" ("branchId", "txnDate");
CREATE INDEX "bank_transactions_branchId_status_idx" ON "bank_transactions" ("branchId", "status");
CREATE INDEX "bank_transactions_matchedJournalId_idx" ON "bank_transactions" ("matchedJournalId");

-- ─── VAT Returns (legacy alias for FirsVatReturn) ───────
CREATE TABLE "vat_returns" (
    "id"             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "branchId"       UUID NOT NULL,
    "periodYear"     INTEGER NOT NULL,
    "periodMonth"    INTEGER NOT NULL,
    "vatOutput"      DECIMAL(18,2) NOT NULL DEFAULT 0,
    "vatInput"       DECIMAL(18,2) NOT NULL DEFAULT 0,
    "netVatPayable"  DECIMAL(18,2) NOT NULL DEFAULT 0,
    "submittedAt"    TIMESTAMP(3),
    "firsReceiptNo"  VARCHAR(100),
    "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt"      TIMESTAMP(3) NOT NULL,

    CONSTRAINT "vat_returns_branchId_periodYear_periodMonth_key" UNIQUE ("branchId", "periodYear", "periodMonth"),
    CONSTRAINT "vat_returns_branchId_fkey" FOREIGN KEY ("branchId") REFERENCES "branches"("id")
);
CREATE INDEX "vat_returns_branchId_periodYear_periodMonth_idx" ON "vat_returns" ("branchId", "periodYear", "periodMonth");
