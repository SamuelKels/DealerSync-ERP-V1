/**
 * AGCOMS DealerSync ERP — Application Configuration
 * Typed config accessor used across all backend modules.
 */
import { registerAs } from '@nestjs/config';

export const appConfig = registerAs('app', () => ({
  nodeEnv: process.env['NODE_ENV'] ?? 'development',
  port: parseInt(process.env['PORT'] ?? '3001', 10),
  frontendUrl: process.env['FRONTEND_URL'] ?? 'http://localhost:3000',
  portalUrl: process.env['PORTAL_URL'] ?? 'http://localhost:3002',
  portalBaseUrl: process.env['PORTAL_BASE_URL'] ?? 'https://portal.agcoms.ng',
  cors: {
    origins: (process.env['CORS_ORIGINS'] ?? 'http://localhost:3000').split(','),
  },
  jwt: {
    issuer: process.env['JWT_ISSUER'] ?? 'agcoms-dealersync',
    audience: process.env['JWT_AUDIENCE'] ?? 'agcoms-internal',
    accessTtl: parseInt(process.env['JWT_ACCESS_TTL'] ?? '900', 10),
    refreshTtl: parseInt(process.env['JWT_REFRESH_TTL'] ?? '2592000', 10),
  },
  totp: {
    issuer: process.env['TOTP_ISSUER'] ?? 'AGCOMS DealerSync',
    window: parseInt(process.env['TOTP_WINDOW'] ?? '1', 10),
  },
  rateLimit: {
    ttl: parseInt(process.env['RATE_LIMIT_TTL'] ?? '60', 10),
    max: parseInt(process.env['RATE_LIMIT_MAX'] ?? '100', 10),
  },
}));

export type AppConfig = ReturnType<typeof appConfig>;
