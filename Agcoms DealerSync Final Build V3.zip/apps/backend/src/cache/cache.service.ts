/**
 * AGCOMS DealerSync ERP — CacheService
 * Sprint 2: Section 6 — "Redis caching"
 *
 * Implements cache-aside pattern (read: check cache → miss → hit DB → populate cache)
 * Used by: DashboardService (60s TTL), ReportsService (5min TTL), heavy list endpoints
 *
 * Key naming: {namespace}:{branchId}:{params_hash}
 * Tag-based invalidation: when a record mutates, its namespace tag is flushed
 *
 * In the cache-aside pattern:
 *   1. Service calls cache.get(key)
 *   2. On HIT  → return cached value
 *   3. On MISS → execute DB query, call cache.set(key, value, ttl), return value
 *
 * Decorated usage:
 *   @Cacheable({ ttl: 60, namespace: 'dashboard.kpis', keyFn: (args) => args[0] })
 *   async getDashboardKpis(branchId: string) { ... }
 */
import crypto from 'crypto';

import { Injectable, Logger, Optional, Inject } from '@nestjs/common';
import type Redis from 'ioredis';

export const REDIS_CLIENT = 'REDIS_CLIENT';

// ── Cache namespaces ──────────────────────────────────────────
export const CACHE_NS = {
  DASHBOARD_KPIS: 'dash:kpis',
  DASHBOARD_ALERTS: 'dash:alerts',
  REPORT_AR_AGING: 'report:ar_aging',
  REPORT_INVENTORY_VAL: 'report:inv_val',
  REPORT_NADF: 'report:nadf',
  PRODUCT_LIST: 'product:list',
  CUSTOMER_LIST: 'customer:list',
  VENDOR_LIST: 'vendor:list',
  EMPLOYEE_LIST: 'employee:list',
  FEATURE_FLAGS: 'feature_flags',
  ROLES_PERMISSIONS: 'rbac:roles',
} as const;

// ── Cache TTLs (seconds) ──────────────────────────────────────
export const CACHE_TTL = {
  DASHBOARD: 60, // 1 minute — KPIs refresh fast
  REPORTS: 300, // 5 minutes — aging reports are expensive
  PRODUCT_LIST: 120, // 2 minutes
  CUSTOMER_LIST: 120,
  VENDOR_LIST: 120,
  EMPLOYEE_LIST: 180,
  FEATURE_FLAGS: 30, // Feature flags refresh quickly for hot-reload
  ROLES: 300, // RBAC roles change infrequently
} as const;

export interface CacheOptions {
  ttl: number;
  namespace: string;
  branchId?: string;
}

@Injectable()
export class CacheService {
  private readonly logger = new Logger(CacheService.name);
  private readonly PREFIX = 'erp:';

  constructor(@Optional() @Inject(REDIS_CLIENT) private readonly redis: Redis | null) {
    if (!this.redis) {
      this.logger.warn('Redis client not available — caching disabled, all reads go to database');
    }
  }

  // ── Core get/set/del ─────────────────────────────────────────

  async get<T>(key: string): Promise<T | null> {
    if (!this.redis) return null;
    try {
      const raw = await this.redis.get(this.prefix(key));
      if (!raw) return null;
      return JSON.parse(raw) as T;
    } catch (err) {
      this.logger.warn(`Cache GET failed for "${key}": ${String(err)}`);
      return null;
    }
  }

  async set<T>(key: string, value: T, ttlSeconds: number): Promise<void> {
    if (!this.redis) return;
    try {
      await this.redis.setex(this.prefix(key), ttlSeconds, JSON.stringify(value));
    } catch (err) {
      this.logger.warn(`Cache SET failed for "${key}": ${String(err)}`);
    }
  }

  async del(key: string): Promise<void> {
    if (!this.redis) return;
    try {
      await this.redis.del(this.prefix(key));
    } catch (err) {
      this.logger.warn(`Cache DEL failed for "${key}": ${String(err)}`);
    }
  }

  // ── Cache-aside helper ────────────────────────────────────────

  async wrap<T>(key: string, ttl: number, factory: () => Promise<T>): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached !== null) {
      return cached;
    }
    const value = await factory();
    await this.set(key, value, ttl);
    return value;
  }

  // ── Namespace/tag invalidation ─────────────────────────────────

  /**
   * Flush all cache keys matching a pattern.
   * Used when a write operation invalidates a namespace.
   * e.g. invalidateNamespace('dash:kpis', 'branch-uuid') flushes
   *       erp:dash:kpis:branch-uuid:*
   */
  async invalidateNamespace(namespace: string, branchId?: string): Promise<void> {
    if (!this.redis) return;
    try {
      const pattern = this.prefix(branchId ? `${namespace}:${branchId}:*` : `${namespace}:*`);
      const keys = await this.scanKeys(pattern);
      if (keys.length > 0) {
        await this.redis.del(...keys);
        this.logger.debug(`Invalidated ${keys.length} cache keys for namespace "${namespace}"`);
      }
    } catch (err) {
      this.logger.warn(`Cache invalidation failed for "${namespace}": ${String(err)}`);
    }
  }

  /**
   * Flush ALL cache for a given branch.
   * Called when branch settings change or on explicit admin cache-clear.
   */
  async invalidateBranch(branchId: string): Promise<void> {
    if (!this.redis) return;
    const pattern = this.prefix(`*:${branchId}:*`);
    const keys = await this.scanKeys(pattern);
    if (keys.length > 0) {
      await this.redis.del(...keys);
      this.logger.log(`Flushed ${keys.length} cache keys for branch ${branchId}`);
    }
  }

  /**
   * Flush ALL ERP cache keys. Use with caution — only for admin/emergency.
   */
  async flush(): Promise<{ deletedKeys: number }> {
    if (!this.redis) return { deletedKeys: 0 };
    const keys = await this.scanKeys(this.prefix('*'));
    if (keys.length > 0) {
      await this.redis.del(...keys);
    }
    this.logger.warn(`⚠ Full cache flush: deleted ${keys.length} keys`);
    return { deletedKeys: keys.length };
  }

  // ── Key builders ──────────────────────────────────────────────

  /**
   * Build a deterministic cache key from a namespace, optional branchId,
   * and any additional parameters (hashed to keep keys compact).
   */
  buildKey(namespace: string, branchId?: string, params?: Record<string, unknown>): string {
    const parts = [namespace];
    if (branchId) parts.push(branchId);
    if (params && Object.keys(params).length > 0) {
      const hash = crypto
        .createHash('sha1')
        .update(JSON.stringify(params))
        .digest('hex')
        .slice(0, 8);
      parts.push(hash);
    }
    return parts.join(':');
  }

  // ── Dashboard-specific helpers ─────────────────────────────────

  async getDashboardKpis<T>(branchId: string, factory: () => Promise<T>): Promise<T> {
    const key = this.buildKey(CACHE_NS.DASHBOARD_KPIS, branchId);
    return this.wrap(key, CACHE_TTL.DASHBOARD, factory);
  }

  async invalidateDashboard(branchId: string): Promise<void> {
    await this.invalidateNamespace(CACHE_NS.DASHBOARD_KPIS, branchId);
    await this.invalidateNamespace(CACHE_NS.DASHBOARD_ALERTS, branchId);
  }

  // ── Report-specific helpers ────────────────────────────────────

  async getArAgingReport<T>(
    branchId: string,
    params: Record<string, unknown>,
    factory: () => Promise<T>,
  ): Promise<T> {
    const key = this.buildKey(CACHE_NS.REPORT_AR_AGING, branchId, params);
    return this.wrap(key, CACHE_TTL.REPORTS, factory);
  }

  async getInventoryValuation<T>(
    branchId: string,
    params: Record<string, unknown>,
    factory: () => Promise<T>,
  ): Promise<T> {
    const key = this.buildKey(CACHE_NS.REPORT_INVENTORY_VAL, branchId, params);
    return this.wrap(key, CACHE_TTL.REPORTS, factory);
  }

  // ── Feature flags (hot-reload from Redis) ─────────────────────

  async getFeatureFlags<T>(factory: () => Promise<T>): Promise<T> {
    const key = this.buildKey(CACHE_NS.FEATURE_FLAGS);
    return this.wrap(key, CACHE_TTL.FEATURE_FLAGS, factory);
  }

  async invalidateFeatureFlags(): Promise<void> {
    await this.del(this.buildKey(CACHE_NS.FEATURE_FLAGS));
  }

  // ── RBAC roles (rarely change) ────────────────────────────────

  async getRolesPermissions<T>(factory: () => Promise<T>): Promise<T> {
    const key = this.buildKey(CACHE_NS.ROLES_PERMISSIONS);
    return this.wrap(key, CACHE_TTL.ROLES, factory);
  }

  async invalidateRoles(): Promise<void> {
    await this.invalidateNamespace(CACHE_NS.ROLES_PERMISSIONS);
  }

  // ── Internal utilities ─────────────────────────────────────────

  private prefix(key: string): string {
    return `${this.PREFIX}${key}`;
  }

  private async scanKeys(pattern: string): Promise<string[]> {
    if (!this.redis) return [];
    const keys: string[] = [];
    let cursor = '0';
    do {
      const [nextCursor, batch] = await this.redis.scan(cursor, 'MATCH', pattern, 'COUNT', 200);
      cursor = nextCursor;
      keys.push(...batch);
    } while (cursor !== '0');
    return keys;
  }
}
