import { Global, Module } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import Redis from 'ioredis';

import { CacheService, REDIS_CLIENT } from './cache.service';

@Global()
@Module({
  providers: [
    {
      provide: REDIS_CLIENT,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        try {
          return new Redis(config.get<string>('REDIS_URL', 'redis://localhost:6379'), {
            maxRetriesPerRequest: 1,
            connectTimeout: 3000,
            lazyConnect: true,
          });
        } catch {
          return null; // Cache degrades gracefully in dev without Redis
        }
      },
    },
    CacheService,
  ],
  exports: [CacheService],
})
export class CacheModule {}
