/**
 * AGCOMS DealerSync ERP — SecretsService
 * Sprint 2: Section 5 — "Vault or AWS Secrets Manager" + "secrets rotation"
 *
 * Responsibilities:
 *   1. Fetch secrets from AWS Secrets Manager at startup + cache in memory
 *   2. Expose typed accessors for JWT keys, DB credentials, API keys
 *   3. Support hot-reload (re-fetch without restart) on rotation events
 *
 * Rotation strategy:
 *   - JWT RS256 keys:    rotated every 90 days via Lambda rotation function
 *   - DB password:       rotated every 30 days via RDS native rotation
 *   - Typesense API key: rotated every 180 days
 *
 * In development: reads from environment variables directly (no Secrets Manager).
 */
import {
  SecretsManagerClient,
  GetSecretValueCommand,
  DescribeSecretCommand,
} from '@aws-sdk/client-secrets-manager';
import { OnApplicationBootstrap } from '@nestjs/common';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

// ── Secret value shapes ────────────────────────────────────────

interface JwtSecret {
  private_key: string;
  public_key: string;
  key_id: string;
  rotated_at: string;
}

interface DbSecret {
  username: string;
  password: string;
  host: string;
  port: number;
  dbname: string;
}

interface PortalSecret {
  secret: string;
}

// ── In-memory cache (avoids Secrets Manager calls on every request) ─

interface SecretCacheEntry<T> {
  value: T;
  fetchedAt: Date;
  ttlMs: number;
}

@Injectable()
export class SecretsService implements OnApplicationBootstrap {
  private readonly logger = new Logger(SecretsService.name);
  private readonly client: SecretsManagerClient;
  private readonly isDev: boolean;

  // In-memory cache — revalidated every 5 minutes
  private readonly cache = new Map<string, SecretCacheEntry<unknown>>();
  private readonly CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

  constructor(private readonly config: ConfigService) {
    this.isDev = config.get<string>('NODE_ENV', 'development') !== 'production';
    this.client = new SecretsManagerClient({
      region: config.get<string>('AWS_REGION', 'eu-west-1'),
    });
  }

  async onApplicationBootstrap(): Promise<void> {
    if (this.isDev) {
      this.logger.log('Development mode — Secrets Manager disabled, using environment variables');
      return;
    }
    // Pre-warm the most critical secrets at startup
    await Promise.allSettled([
      this.getJwtKeys(),
      this.getDbCredentials(),
      this.getPortalJwtSecret(),
    ]);
    this.logger.log('✅ Secrets pre-warmed from AWS Secrets Manager');
  }

  // ── JWT RS256 keys ────────────────────────────────────────────

  async getJwtKeys(): Promise<JwtSecret> {
    if (this.isDev) {
      return {
        private_key: this.config.getOrThrow<string>('JWT_PRIVATE_KEY'),
        public_key: this.config.getOrThrow<string>('JWT_PUBLIC_KEY'),
        key_id: 'dev-key-1',
        rotated_at: new Date().toISOString(),
      };
    }
    return this.getSecret<JwtSecret>(this.config.getOrThrow<string>('SECRET_JWT_KEYS_ARN'));
  }

  async getJwtPrivateKey(): Promise<string> {
    const keys = await this.getJwtKeys();
    return keys.private_key;
  }

  async getJwtPublicKey(): Promise<string> {
    const keys = await this.getJwtKeys();
    return keys.public_key;
  }

  // ── Database credentials ───────────────────────────────────────

  async getDbCredentials(): Promise<DbSecret> {
    if (this.isDev) {
      const url = this.config.getOrThrow<string>('DATABASE_URL');
      // Parse postgres://user:pass@host:port/db
      const parsed = new URL(url);
      return {
        username: parsed.username,
        password: parsed.password,
        host: parsed.hostname,
        port: parseInt(parsed.port, 10),
        dbname: parsed.pathname.slice(1),
      };
    }
    return this.getSecret<DbSecret>(this.config.getOrThrow<string>('SECRET_DB_PASSWORD_ARN'));
  }

  async buildDatabaseUrl(): Promise<string> {
    const creds = await this.getDbCredentials();
    return `postgresql://${creds.username}:${encodeURIComponent(creds.password)}@${creds.host}:${creds.port}/${creds.dbname}`;
  }

  // ── Portal JWT secret ─────────────────────────────────────────

  async getPortalJwtSecret(): Promise<string> {
    if (this.isDev) {
      return this.config.getOrThrow<string>('PORTAL_JWT_SECRET');
    }
    const s = await this.getSecret<PortalSecret>(
      this.config.getOrThrow<string>('SECRET_PORTAL_JWT_ARN'),
    );
    return s.secret;
  }

  // ── Typesense API key ─────────────────────────────────────────

  async getTypesenseApiKey(): Promise<string> {
    if (this.isDev) {
      return this.config.get<string>('TYPESENSE_API_KEY', 'changeme');
    }
    const s = await this.getSecret<{ api_key: string }>(
      this.config.getOrThrow<string>('SECRET_TYPESENSE_ARN'),
    );
    return s.api_key;
  }

  // ── Sentry DSN ────────────────────────────────────────────────

  async getSentryDsn(): Promise<string | undefined> {
    if (this.isDev) return this.config.get<string>('SENTRY_DSN');
    try {
      const s = await this.getSecret<{ dsn: string }>(
        this.config.getOrThrow<string>('SECRET_SENTRY_ARN'),
      );
      return s.dsn;
    } catch {
      return undefined;
    }
  }

  // ── Hot-reload on rotation event ──────────────────────────────

  /**
   * Called via POST /api/v1/admin/secrets/reload (super_admin only).
   * Clears the in-memory cache so next access re-fetches from Secrets Manager.
   * Useful for triggering hot-reload immediately after manual rotation.
   */
  async reloadSecrets(secretArns: string[]): Promise<{ reloaded: string[] }> {
    for (const arn of secretArns) {
      this.cache.delete(arn);
    }
    this.logger.log(`Secrets cache cleared for ARNs: ${secretArns.join(', ')}`);
    return { reloaded: secretArns };
  }

  // ── Core fetch with in-memory cache ──────────────────────────

  private async getSecret<T>(secretArn: string): Promise<T> {
    // Check in-memory cache
    const cached = this.cache.get(secretArn);
    if (cached) {
      const age = Date.now() - cached.fetchedAt.getTime();
      if (age < cached.ttlMs) {
        return cached.value as T;
      }
    }

    // Fetch from Secrets Manager
    const command = new GetSecretValueCommand({ SecretId: secretArn });
    const response = await this.client.send(command);

    if (!response.SecretString) {
      throw new Error(`Secret ${secretArn} has no SecretString value`);
    }

    const value = JSON.parse(response.SecretString) as T;

    // Cache the result
    this.cache.set(secretArn, {
      value,
      fetchedAt: new Date(),
      ttlMs: this.CACHE_TTL_MS,
    });

    return value;
  }

  // ── Get secret metadata (rotation schedule, last rotated) ─────

  async describeSecret(secretArn: string): Promise<{
    name: string;
    lastRotated?: Date;
    nextRotation?: Date;
    rotationEnabled: boolean;
  }> {
    const response = await this.client.send(new DescribeSecretCommand({ SecretId: secretArn }));
    return {
      name: response.Name ?? secretArn,
      lastRotated: response.LastRotatedDate,
      nextRotation: response.NextRotationDate,
      rotationEnabled: response.RotationEnabled ?? false,
    };
  }
}
