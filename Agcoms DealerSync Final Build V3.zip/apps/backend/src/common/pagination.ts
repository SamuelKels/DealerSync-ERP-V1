/**
 * AGCOMS DealerSync ERP — Pagination utilities
 * Provides cursor-based and offset pagination helpers.
 */

export interface PaginationDto {
  page?: number;
  limit?: number;
  cursor?: string;
}

export interface CursorPaginationOptions<W = any> {
  where?: W;
  cursor?: string;
  limit?: number;
  orderBy?: any;
}

export interface PaginatedResult<T> {
  items: T[];
  total?: number;
  page?: number;
  limit: number;
  hasMore: boolean;
  nextCursor?: string;
}

export function buildPaginationArgs(dto: PaginationDto) {
  const page = Math.max(1, dto.page ?? 1);
  const limit = Math.min(100, Math.max(1, dto.limit ?? 20));
  return { skip: (page - 1) * limit, take: limit, page, limit };
}

export function buildPaginatedResult<T>(
  items: T[],
  total: number,
  page: number,
  limit: number,
): PaginatedResult<T> {
  return { items, total, page, limit, hasMore: page * limit < total };
}

/**
 * Cursor-based pagination helper for Prisma delegates.
 */
export async function paginate<T>(
  delegate: { findMany: (args: any) => Promise<T[]> },
  opts: CursorPaginationOptions,
  _resolveCursor?: (cursorId: string) => Promise<any>,
): Promise<PaginatedResult<T>> {
  const limit = Math.min(100, Math.max(1, opts.limit ?? 20));
  const args: any = {
    where: opts.where ?? {},
    take: limit + 1,
    orderBy: opts.orderBy ?? { createdAt: 'desc' },
  };
  if (opts.cursor) {
    args.cursor = { id: opts.cursor };
    args.skip = 1;
  }
  const items = await delegate.findMany(args);
  const hasMore = items.length > limit;
  const slice = hasMore ? items.slice(0, limit) : items;
  const nextCursor = hasMore ? (slice[slice.length - 1] as any)?.id : undefined;
  return { items: slice, limit, hasMore, nextCursor };
}
