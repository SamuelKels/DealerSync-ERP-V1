/**
 * AGCOMS DealerSync ERP — Authentication & Authorization Guards
 * Sprint 1 Fix: No guards existed — all endpoints were unprotected.
 *
 * JwtAuthGuard   — enforces JWT RS256 authentication on any decorated route
 * PermissionsGuard — checks fine-grained permission strings (e.g. 'sales:write')
 * RolesGuard     — checks role membership (e.g. 'FINANCE_MANAGER')
 *
 * SuperAdmin bypasses all permission/role checks (not auth checks).
 */
import { JwtPayload } from '@agcoms/types';
import { CanActivate, ExecutionContext } from '@nestjs/common';
import { Injectable, SetMetadata, UnauthorizedException, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from '@nestjs/passport';

// ── Metadata keys ─────────────────────────────────────────────────────────
export const IS_PUBLIC_KEY = 'isPublic';
export const REQUIRED_PERMISSIONS = 'requiredPermissions';
export const REQUIRED_ROLES = 'requiredRoles';

// ── Decorators ─────────────────────────────────────────────────────────────
/** Mark a route as public (no JWT required) */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);

/** Require one or more specific permissions */
export const RequirePermission = (...permissions: string[]) =>
  SetMetadata(REQUIRED_PERMISSIONS, permissions);

/** Require one or more specific roles */
export const RequireRole = (...roles: string[]) => SetMetadata(REQUIRED_ROLES, roles);

// ── JwtAuthGuard ───────────────────────────────────────────────────────────
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  constructor(private readonly reflector: Reflector) {
    super();
  }

  canActivate(ctx: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (isPublic) return true;
    return super.canActivate(ctx);
  }

  handleRequest<T extends JwtPayload>(err: Error | null, user: T | false): T {
    if (err || !user) {
      throw err ?? new UnauthorizedException('Authentication required');
    }
    return user;
  }
}

// ── PermissionsGuard ───────────────────────────────────────────────────────
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>(REQUIRED_PERMISSIONS, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const { user } = ctx.switchToHttp().getRequest<{ user: JwtPayload }>();
    if (!user) throw new UnauthorizedException('Authentication required');

    // SuperAdmin bypasses all permission checks
    if (user.isSuperAdmin) return true;

    const hasAll = required.every((p) => (user.permissions ?? []).includes(p));
    if (!hasAll) {
      throw new ForbiddenException(`Insufficient permissions. Required: ${required.join(', ')}`);
    }
    return true;
  }
}

// ── RolesGuard ─────────────────────────────────────────────────────────────
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(ctx: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>(REQUIRED_ROLES, [
      ctx.getHandler(),
      ctx.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const { user } = ctx.switchToHttp().getRequest<{ user: JwtPayload }>();
    if (!user) throw new UnauthorizedException('Authentication required');

    if (user.isSuperAdmin) return true;

    const hasRole = required.some((r) => (user.roles ?? []).includes(r));
    if (!hasRole) {
      throw new ForbiddenException(`Requires one of the following roles: ${required.join(', ')}`);
    }
    return true;
  }
}
