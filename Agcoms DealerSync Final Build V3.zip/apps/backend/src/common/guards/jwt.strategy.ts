/**
 * AGCOMS DealerSync ERP — JWT Strategy
 * Sprint 1 Fix: No auth guards existed. All routes were publicly accessible.
 *
 * Extracts and validates the RS256 JWT from the Authorization header.
 * Attaches the full JwtPayload to request.user for downstream use.
 */
import { JwtPayload } from '@agcoms/types';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  constructor(
    config: ConfigService,
    private readonly prisma: PrismaService,
  ) {
    const publicKeyB64 = config.getOrThrow<string>('JWT_PUBLIC_KEY');
    const publicKey = Buffer.from(publicKeyB64, 'base64').toString('utf8');

    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      algorithms: ['RS256'],
      secretOrKey: publicKey,
    });
  }

  async validate(payload: JwtPayload): Promise<JwtPayload> {
    // Lightweight DB check — ensure session is still valid (not revoked)
    const session = await this.prisma.session.findFirst({
      where: { userId: payload.sub, isRevoked: false },
      select: { id: true },
    });

    if (!session) {
      throw new UnauthorizedException('Session expired or revoked');
    }

    return payload;
  }
}
