import { Global, Module } from '@nestjs/common';
import { LoggerModule } from 'nestjs-pino';

import { FeatureFlagsService } from './feature-flags.service';

@Global()
@Module({
  imports: [LoggerModule.forRoot()],
  providers: [FeatureFlagsService],
  exports: [FeatureFlagsService],
})
export class FeatureFlagsModule {}
