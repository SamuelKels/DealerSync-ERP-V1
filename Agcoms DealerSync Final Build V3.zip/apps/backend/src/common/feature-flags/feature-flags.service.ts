/**
 * AGCOMS DealerSync ERP — Feature Flag Service
 * Master prompt Section 13: "Implement feature-flag capability for:
 *   AI features · integrations · beta workflows · experimental modules"
 *
 * Architecture:
 *   - Flags resolved from environment variables (compile-time defaults)
 *   - Overrides stored in Redis (runtime, per-tenant, no redeploy required)
 *   - Feature flags are READ-ONLY for AI — AI cannot toggle its own flags
 */

import { OnModuleInit } from '@nestjs/common';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectPinoLogger } from 'nestjs-pino';
import { PinoLogger } from 'nestjs-pino';

import { RedisService } from '../../redis/redis.service';

export const FEATURE_FLAGS = {
  // ── AI Features ────────────────────────────────────────
  AI_ASSISTANT: 'FEATURE_AI_ASSISTANT', // AI chat assistant
  AI_INVENTORY_FORECAST: 'FEATURE_AI_INVENTORY_FORECAST', // Demand forecasting
  AI_NLP_SEARCH: 'FEATURE_AI_NLP_SEARCH', // Natural language search
  AI_RECOMMENDATIONS: 'FEATURE_AI_RECOMMENDATIONS', // Stock / vendor recommendations
  AI_SUMMARIZATION: 'FEATURE_AI_SUMMARIZATION', // Document & workflow summaries
  AI_PREDICTIVE_ANALYTICS: 'FEATURE_AI_PREDICTIVE_ANALYTICS', // KPI trend predictions

  // ── Integrations ───────────────────────────────────────
  INTEGRATION_TELEMATICS: 'FEATURE_INTEGRATION_TELEMATICS', // Live GPS/telemetry feed
  INTEGRATION_PAYMENT: 'FEATURE_INTEGRATION_PAYMENT', // Customer portal payments
  INTEGRATION_EMAIL: 'FEATURE_INTEGRATION_EMAIL', // Transactional email

  // ── Beta Workflows ─────────────────────────────────────
  BETA_CUSTOMER_PORTAL: 'FEATURE_BETA_CUSTOMER_PORTAL', // External customer portal
  BETA_MOBILE_OFFLINE: 'FEATURE_BETA_MOBILE_OFFLINE', // Offline-first field ops
  BETA_BULK_IMPORT: 'FEATURE_BETA_BULK_IMPORT', // CSV bulk data import

  // ── Experimental ───────────────────────────────────────
  EXPERIMENTAL_REPORTS: 'FEATURE_EXPERIMENTAL_REPORTS', // Advanced report builder
} as const;

export type FeatureFlagKey = (typeof FEATURE_FLAGS)[keyof typeof FEATURE_FLAGS];

// Safe defaults — all features OFF by default (opt-in)
const DEFAULTS: Record<FeatureFlagKey, boolean> = {
  FEATURE_AI_ASSISTANT: false,
  FEATURE_AI_INVENTORY_FORECAST: false,
  FEATURE_AI_NLP_SEARCH: false,
  FEATURE_AI_RECOMMENDATIONS: false,
  FEATURE_AI_SUMMARIZATION: false,
  FEATURE_AI_PREDICTIVE_ANALYTICS: false,
  FEATURE_INTEGRATION_TELEMATICS: false,
  FEATURE_INTEGRATION_PAYMENT: false,
  FEATURE_INTEGRATION_EMAIL: true, // email on by default
  FEATURE_BETA_CUSTOMER_PORTAL: false,
  FEATURE_BETA_MOBILE_OFFLINE: false,
  FEATURE_BETA_BULK_IMPORT: false,
  FEATURE_EXPERIMENTAL_REPORTS: false,
};

@Injectable()
export class FeatureFlagsService implements OnModuleInit {
  private runtimeOverrides = new Map<string, boolean>();

  constructor(
    private readonly config: ConfigService,
    private readonly redis: RedisService,
    @InjectPinoLogger(FeatureFlagsService.name) private readonly logger: PinoLogger,
  ) {}

  async onModuleInit() {
    // Load any runtime overrides from Redis on startup
    await this.refreshFromRedis();
    this.logger.info({ flags: this.getAllFlags() }, 'Feature flags initialised');
  }

  /**
   * Check whether a feature flag is enabled.
   * Resolution order: Redis override → env var → compiled default
   */
  isEnabled(flag: FeatureFlagKey): boolean {
    // 1. Runtime Redis override (highest priority)
    if (this.runtimeOverrides.has(flag)) {
      return this.runtimeOverrides.get(flag)!;
    }
    // 2. Environment variable
    const envVal = this.config.get<string>(flag);
    if (envVal !== undefined) {
      return envVal === 'true' || envVal === '1';
    }
    // 3. Compiled default
    return DEFAULTS[flag] ?? false;
  }

  /**
   * Override a flag at runtime (stored in Redis, survives pod restarts).
   * NOTE: This action is HUMAN-ONLY — AI cannot call this method.
   * The controller endpoint is protected by `require-permissions: flags:manage` (super_admin only).
   */
  async setFlag(flag: FeatureFlagKey, enabled: boolean, actorId: string): Promise<void> {
    await this.redis.set(`feature_flag:${flag}`, enabled ? 'true' : 'false', 'EX', 86_400 * 30);
    this.runtimeOverrides.set(flag, enabled);
    this.logger.info({ flag, enabled, actorId }, 'Feature flag changed by human operator');
  }

  async refreshFromRedis(): Promise<void> {
    try {
      // Guard the entire hydration behind a timeout so a hung Redis connection can
      // never stall application startup. If Redis is slow or unavailable the flags
      // simply fall back to env vars / compiled defaults.
      await Promise.race([
        (async () => {
          for (const flag of Object.values(FEATURE_FLAGS)) {
            const val = await this.redis.get(`feature_flag:${flag}`);
            if (val !== null) this.runtimeOverrides.set(flag, val === 'true');
          }
        })(),
        new Promise<void>((resolve) => setTimeout(resolve, 2000)),
      ]);
    } catch {
      // Redis unavailable — fall back to env/defaults silently
    }
  }

  getAllFlags(): Record<string, boolean> {
    return Object.values(FEATURE_FLAGS).reduce(
      (acc, flag) => {
        acc[flag] = this.isEnabled(flag);
        return acc;
      },
      {} as Record<string, boolean>,
    );
  }
}
