/**
 * AGCOMS DealerSync ERP — PII Field Registry
 * §5 Security Architecture: "field-level masking"
 *
 * Defines which response fields are PII-sensitive and what permission
 * is required to receive them unmasked. Any field listed here that
 * is present in a response DTO will be replaced with '***' unless
 * the requesting user holds the required permission.
 *
 * Field resolution is recursive — nested objects and arrays are traversed.
 *
 * Permission model:
 *   hr:read_sensitive        → employee salary, bank, tax, pension data
 *   customers:read_financial → customer credit limits, payment history
 *   hr:read_contact          → employee personal contact details
 *
 * SuperAdmin bypasses all masking automatically.
 */

export interface PiiFieldConfig {
  /** The exact field name (case-sensitive) in the response DTO */
  field: string;
  /** Permission required to see the unmasked value */
  requiredPermission: string;
  /** Mask strategy: '***' for text, 0 for numeric, null for nullable */
  maskWith: string | number | null;
  /** Human-readable description for documentation */
  description: string;
}

export const PII_FIELD_REGISTRY: PiiFieldConfig[] = [
  // ── Employee financial PII ─────────────────────────────────────
  {
    field: 'grossSalary',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Employee gross monthly salary',
  },
  {
    field: 'basicSalary',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Employee basic salary component',
  },
  {
    field: 'netPay',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Employee net pay after deductions',
  },
  {
    field: 'housingAllowance',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Housing allowance',
  },
  {
    field: 'transportAllowance',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Transport allowance',
  },
  {
    field: 'otherAllowances',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Other allowances',
  },
  {
    field: 'paye',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'PAYE tax deduction',
  },
  {
    field: 'employeePension',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Employee pension contribution (8%)',
  },
  {
    field: 'employerPension',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Employer pension contribution (10%)',
  },
  {
    field: 'nhf',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'National Housing Fund deduction (2.5%)',
  },
  {
    field: 'totalDeductions',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Total payroll deductions',
  },

  // ── Employee identity PII ──────────────────────────────────────
  {
    field: 'bankAccountNo',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'Employee bank account number',
  },
  {
    field: 'bankName',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'Employee bank name',
  },
  {
    field: 'nin',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'National Identity Number',
  },
  {
    field: 'bvn',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'Bank Verification Number',
  },
  {
    field: 'taxIdentification',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'Tax Identification Number (TIN)',
  },
  {
    field: 'pensionPin',
    requiredPermission: 'hr:read_sensitive',
    maskWith: '***',
    description: 'Pension Fund Administrator PIN',
  },
  {
    field: 'cra',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Consolidated Relief Allowance',
  },
  {
    field: 'taxableIncome',
    requiredPermission: 'hr:read_sensitive',
    maskWith: 0,
    description: 'Taxable income after CRA',
  },

  // ── Customer financial PII ─────────────────────────────────────
  {
    field: 'creditLimit',
    requiredPermission: 'customers:read_financial',
    maskWith: 0,
    description: 'Customer credit limit',
  },
  {
    field: 'creditUsed',
    requiredPermission: 'customers:read_financial',
    maskWith: 0,
    description: 'Customer credit utilisation',
  },
  {
    field: 'availableCredit',
    requiredPermission: 'customers:read_financial',
    maskWith: 0,
    description: 'Available credit balance',
  },

  // ── Employee personal contact ──────────────────────────────────
  {
    field: 'personalEmail',
    requiredPermission: 'hr:read_contact',
    maskWith: '***',
    description: 'Employee personal email address',
  },
  {
    field: 'personalPhone',
    requiredPermission: 'hr:read_contact',
    maskWith: '***',
    description: 'Employee personal phone number',
  },
  {
    field: 'homeAddress',
    requiredPermission: 'hr:read_contact',
    maskWith: '***',
    description: 'Employee home address',
  },
  {
    field: 'nextOfKinPhone',
    requiredPermission: 'hr:read_contact',
    maskWith: '***',
    description: 'Next of kin phone number',
  },
  {
    field: 'nextOfKinName',
    requiredPermission: 'hr:read_contact',
    maskWith: '***',
    description: 'Next of kin name',
  },
];

/** Quick lookup: field name → required permission */
export const PII_FIELD_MAP = new Map<string, PiiFieldConfig>(
  PII_FIELD_REGISTRY.map((c) => [c.field, c]),
);
