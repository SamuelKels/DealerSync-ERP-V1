import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';

import { FileService } from './file.service';

@Module({
  imports: [BullModule.registerQueue({ name: 'malware-scan' })],
  providers: [FileService],
  exports: [FileService],
})
export class FilesModule {}
