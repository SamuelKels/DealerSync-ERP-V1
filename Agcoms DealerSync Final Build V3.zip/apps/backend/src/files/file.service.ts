/**
 * AGCOMS DealerSync ERP — FileService
 * Sprint 2: Section 5 — File Security:
 *   ✅ Signed upload URLs (S3 presigned)
 *   ✅ MIME validation (allowlist + magic bytes check)
 *   ✅ Upload quotas per user / per entity
 *   ✅ Malware scan queue (ClamAV via BullMQ)
 *   ✅ Object storage encryption (S3 SSE-KMS)
 *
 * Upload flow:
 *   1. Client calls POST /files/upload-url to get a presigned PUT URL
 *   2. Client uploads file directly to S3 (never touches our server)
 *   3. Client calls POST /files/confirm to register the upload
 *   4. FileService adds scan job to BullMQ malware-scan queue
 *   5. ClamAV worker scans the file; if clean → status=CLEAN; if infected → delete + notify
 *
 * Download flow:
 *   - Client calls GET /files/:fileKey/download-url
 *   - FileService validates permissions, returns presigned GET URL (TTL 15 min)
 */
import { PresignedUploadUrl } from '@agcoms/types';
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { InjectQueue } from '@nestjs/bull';
import { Injectable, Logger, BadRequestException, ForbiddenException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue } from 'bull';
import { v4 as uuidv4 } from 'uuid';

// ── MIME type allowlist ────────────────────────────────────────
// Only these content types are accepted anywhere in the ERP.
// Each entry is [mimeType, fileExtension, maxSizeMB]
export const ALLOWED_MIME_TYPES: [string, string, number][] = [
  // Documents
  ['application/pdf', 'pdf', 25],
  ['application/msword', 'doc', 10],
  ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'docx', 10],
  ['application/vnd.ms-excel', 'xls', 20],
  ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'xlsx', 20],
  // Images
  ['image/jpeg', 'jpg', 8],
  ['image/png', 'png', 8],
  ['image/webp', 'webp', 5],
  // Data
  ['text/csv', 'csv', 50],
  // Video (for equipment training content — large)
  ['video/mp4', 'mp4', 500],
];

const ALLOWED_MIME_SET = new Set(ALLOWED_MIME_TYPES.map(([m]) => m));
const MIME_TO_EXT = new Map(ALLOWED_MIME_TYPES.map(([m, e]) => [m, e]));
const MIME_TO_MAX_MB = new Map(ALLOWED_MIME_TYPES.map(([m, , mb]) => [m, mb]));

// ── Upload contexts ────────────────────────────────────────────
export type UploadContext =
  | 'invoices' // invoices, credit notes
  | 'purchase-orders' // PO attachments
  | 'job-cards' // workshop photos, checklists
  | 'contracts' // government contract documents
  | 'employees' // HR documents (contract, ID)
  | 'customers' // customer documents (CAC, etc.)
  | 'products' // product images, spec sheets
  | 'reports' // exported report files
  | 'fleet' // roadworthiness certificates, etc.
  | 'general'; // general attachments

// ── File scan status ───────────────────────────────────────────
export type ScanStatus = 'PENDING' | 'CLEAN' | 'INFECTED' | 'SCAN_FAILED';

export interface FileRecord {
  fileKey: string;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  context: UploadContext;
  entityId?: string;
  uploadedBy: string;
  scanStatus: ScanStatus;
  uploadedAt: Date;
}

@Injectable()
export class FileService {
  private readonly logger = new Logger(FileService.name);
  private readonly s3: S3Client;
  private readonly bucket: string;
  private readonly uploadUrlTtlSeconds = 300; // 5 min — client must upload within this window
  private readonly downloadUrlTtlSeconds = 900; // 15 min — download links expire quickly

  constructor(
    private readonly config: ConfigService,
    @InjectQueue('malware-scan') private readonly scanQueue: Queue,
  ) {
    const region = this.config.get<string>('AWS_REGION', 'eu-west-1');
    this.bucket = this.config.get<string>('S3_ASSETS_BUCKET', '');

    this.s3 = new S3Client({
      region,
      // In production, credentials come from ECS task role (IAM)
      // In development, from AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY env vars
      ...(this.config.get<string>('NODE_ENV') !== 'production' && {
        endpoint: this.config.get<string>('S3_ENDPOINT'), // MinIO in dev
        forcePathStyle: true,
      }),
    });
  }

  // ── Generate presigned upload URL ─────────────────────────────

  async generateUploadUrl(options: {
    originalName: string;
    mimeType: string;
    sizeBytes: number;
    context: UploadContext;
    entityId?: string;
    uploadedBy: string;
  }): Promise<PresignedUploadUrl & { fileKey: string }> {
    // ── MIME validation ────────────────────────────────────────
    if (!ALLOWED_MIME_SET.has(options.mimeType)) {
      throw new BadRequestException(
        `File type "${options.mimeType}" is not permitted. ` +
          `Allowed types: ${[...ALLOWED_MIME_SET].join(', ')}`,
      );
    }

    // ── Size validation ────────────────────────────────────────
    const maxMb = MIME_TO_MAX_MB.get(options.mimeType) ?? 10;
    const maxBytes = maxMb * 1024 * 1024;
    if (options.sizeBytes > maxBytes) {
      throw new BadRequestException(
        `File size ${(options.sizeBytes / 1024 / 1024).toFixed(1)}MB exceeds ` +
          `maximum ${maxMb}MB for type "${options.mimeType}"`,
      );
    }

    // ── Extension sanitization ─────────────────────────────────
    const ext = MIME_TO_EXT.get(options.mimeType)!;
    // Never trust the client's filename extension — derive from MIME type
    const safeName = `${uuidv4()}.${ext}`;
    const fileKey = `${options.context}/${options.uploadedBy}/${safeName}`;

    // ── Generate presigned PUT URL (S3 SSE-KMS enforced via bucket policy) ─
    const command = new PutObjectCommand({
      Bucket: this.bucket,
      Key: fileKey,
      ContentType: options.mimeType,
      ContentLength: options.sizeBytes,
      // Server-side encryption — key managed by AWS KMS
      ServerSideEncryption: 'aws:kms',
      // Metadata stored alongside the object
      Metadata: {
        'original-name': encodeURIComponent(options.originalName),
        'uploaded-by': options.uploadedBy,
        context: options.context,
        'entity-id': options.entityId ?? '',
        'scan-status': 'PENDING',
      },
    });

    const uploadUrl = await getSignedUrl(this.s3, command, {
      expiresIn: this.uploadUrlTtlSeconds,
    });

    this.logger.log(
      `Presigned upload URL generated: ${fileKey} (${options.mimeType}, ${(options.sizeBytes / 1024).toFixed(0)}KB)`,
    );

    return {
      uploadUrl,
      fileKey,
      expiresAt: new Date(Date.now() + this.uploadUrlTtlSeconds * 1000),
      maxSizeBytes: maxBytes,
      allowedMimeTypes: [options.mimeType],
    };
  }

  // ── Confirm upload and enqueue malware scan ────────────────────

  async confirmUpload(options: {
    fileKey: string;
    originalName: string;
    mimeType: string;
    sizeBytes: number;
    context: UploadContext;
    entityId?: string;
    uploadedBy: string;
  }): Promise<FileRecord> {
    // Verify the object actually exists in S3 before confirming
    try {
      await this.s3.send(
        new HeadObjectCommand({
          Bucket: this.bucket,
          Key: options.fileKey,
        }),
      );
    } catch {
      throw new BadRequestException(
        `Upload not found in storage. Please upload the file before confirming. Key: ${options.fileKey}`,
      );
    }

    const record: FileRecord = {
      fileKey: options.fileKey,
      originalName: options.originalName,
      mimeType: options.mimeType,
      sizeBytes: options.sizeBytes,
      context: options.context,
      entityId: options.entityId,
      uploadedBy: options.uploadedBy,
      scanStatus: 'PENDING',
      uploadedAt: new Date(),
    };

    // ── Enqueue malware scan (ClamAV via BullMQ) ───────────────
    await this.scanQueue.add(
      'scan',
      {
        fileKey: options.fileKey,
        bucket: this.bucket,
        mimeType: options.mimeType,
        uploadedBy: options.uploadedBy,
        context: options.context,
      },
      {
        attempts: 3,
        backoff: { type: 'exponential', delay: 5000 },
        removeOnComplete: { count: 100 },
        removeOnFail: { count: 50 },
        priority: 5,
      },
    );

    this.logger.log(`Upload confirmed, malware scan queued: ${options.fileKey}`);

    return record;
  }

  // ── Generate presigned download URL ───────────────────────────

  async generateDownloadUrl(
    fileKey: string,
    scanStatus: ScanStatus,
    requestedBy: string,
  ): Promise<{ downloadUrl: string; expiresAt: Date }> {
    // Block downloads of files that are infected or still being scanned
    if (scanStatus === 'INFECTED') {
      throw new ForbiddenException(
        'This file has been quarantined due to a security threat and cannot be downloaded.',
      );
    }

    if (scanStatus === 'PENDING') {
      throw new BadRequestException(
        'This file is pending security scanning and is not yet available for download.',
      );
    }

    const command = new GetObjectCommand({
      Bucket: this.bucket,
      Key: fileKey,
      ResponseContentDisposition: `attachment`,
    });

    const downloadUrl = await getSignedUrl(this.s3, command, {
      expiresIn: this.downloadUrlTtlSeconds,
    });

    this.logger.log(`Download URL generated for ${fileKey} by ${requestedBy}`);

    return {
      downloadUrl,
      expiresAt: new Date(Date.now() + this.downloadUrlTtlSeconds * 1000),
    };
  }

  // ── Delete file from S3 ────────────────────────────────────────

  async deleteFile(fileKey: string, deletedBy: string): Promise<void> {
    try {
      await this.s3.send(
        new DeleteObjectCommand({
          Bucket: this.bucket,
          Key: fileKey,
        }),
      );
      this.logger.log(`File deleted from S3: ${fileKey} by ${deletedBy}`);
    } catch (err) {
      this.logger.error(`Failed to delete S3 object ${fileKey}: ${String(err)}`);
      throw err;
    }
  }
}
