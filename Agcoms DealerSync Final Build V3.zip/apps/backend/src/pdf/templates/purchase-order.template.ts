/**
 * AGCOMS DealerSync ERP — Purchase Order PDF Template
 */
export function purchaseOrderTemplate(data: any): string {
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8">
<style>body{font-family:Arial,sans-serif;font-size:12px;margin:40px;color:#1A1A1A}
h1{color:#1A4D2E}table{width:100%;border-collapse:collapse}
th{background:#1A4D2E;color:white;padding:8px}td{padding:8px;border-bottom:1px solid #E5E7EB}
</style></head>
<body>
<h1>PURCHASE ORDER — ${data.poNumber}</h1>
<p><strong>Vendor:</strong> ${data.vendorName} | <strong>Branch:</strong> ${data.branchName}</p>
<p><strong>Date:</strong> ${data.issueDate}${data.expectedDelivery ? ' | <strong>Expected Delivery:</strong> ' + data.expectedDelivery : ''}</p>
<table>
<thead><tr><th>Description</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead>
<tbody>${data.lines
    .map(
      (l: any) => `<tr><td>${l.description}</td><td>${l.qty}</td>
<td>${data.currency} ${l.unitPrice.toLocaleString()}</td>
<td>${data.currency} ${l.total.toLocaleString()}</td></tr>`,
    )
    .join('')}</tbody>
<tfoot><tr><td colspan="3"><strong>TOTAL</strong></td>
<td><strong>${data.currency} ${data.totalAmount.toLocaleString()}</strong></td></tr></tfoot>
</table>
${data.notes ? `<p><strong>Notes:</strong> ${data.notes}</p>` : ''}
<p style="margin-top:40px;font-size:10px;color:#6B7280">Authorised by AGCOMS International Trading Limited</p>
</body></html>`;
}
