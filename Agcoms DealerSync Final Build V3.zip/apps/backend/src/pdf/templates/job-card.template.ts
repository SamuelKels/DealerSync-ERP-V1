/**
 * AGCOMS DealerSync ERP — Job Card PDF Template
 */
export function jobCardTemplate(data: any): string {
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<style>body{font-family:Arial,sans-serif;font-size:12px;margin:40px;color:#1A1A1A}
h1{color:#1A4D2E}.section{margin:16px 0;padding:12px;background:#F7F4EF;border-radius:6px}
table{width:100%;border-collapse:collapse}th{background:#1A4D2E;color:white;padding:6px}
td{padding:6px;border-bottom:1px solid #E5E7EB}</style></head>
<body>
<h1>WORKSHOP JOB CARD — ${data.jobCardNo}</h1>
<div class="section">
<p><strong>Customer:</strong> ${data.customerName}</p>
<p><strong>Equipment:</strong> ${data.equipment}${data.serialNo ? ' | S/N: ' + data.serialNo : ''}</p>
<p><strong>Technician:</strong> ${data.technicianName}${data.completedAt ? ' | Completed: ' + data.completedAt : ''}</p>
</div>
<div class="section">
<p><strong>Issue:</strong> ${data.issueDescription}</p>
${data.diagnosis ? `<p><strong>Diagnosis:</strong> ${data.diagnosis}</p>` : ''}
${data.workPerformed ? `<p><strong>Work Performed:</strong> ${data.workPerformed}</p>` : ''}
</div>
${
  data.partsUsed.length > 0
    ? `<table><thead><tr><th>Part</th><th>Qty</th><th>Unit Price</th></tr></thead>
<tbody>${data.partsUsed
        .map(
          (p: any) => `<tr><td>${p.name}</td><td>${p.qty}</td>
<td>₦${p.unitPrice.toLocaleString()}</td></tr>`,
        )
        .join('')}</tbody></table>`
    : ''
}
<p><strong>Total Amount: ₦${data.totalAmount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}</strong></p>
</body></html>`;
}
