/**
 * AGCOMS DealerSync ERP — Inventory DTOs
 * Sprint 2 Fix S2-06: No DTOs for product or stock management.
 */
import { ApiProperty, ApiPropertyOptional, PartialType } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsString, IsOptional, IsNumber, IsBoolean, IsUUID, Min, MaxLength } from 'class-validator';

export class CreateProductDto {
  @ApiProperty()
  @IsString()
  @MaxLength(20)
  sku: string;

  @ApiProperty()
  @IsString()
  @MaxLength(300)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;

  @ApiProperty({
    enum: ['TRACTOR', 'CONSTRUCTION', 'IMPLEMENT', 'SPARE_PART', 'CONSUMABLE', 'OTHER'],
  })
  @IsString()
  category: string;

  @ApiProperty({ minimum: 0, description: 'Selling price in NGN' })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  unitPrice: number;

  @ApiPropertyOptional({ minimum: 0 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  costPrice?: number;

  @ApiPropertyOptional({ description: 'Weight in kg (required for WEIGHT landed cost allocation)' })
  @IsOptional()
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  weightKg?: number;

  @ApiPropertyOptional({
    default: false,
    description: 'True for tractors/machinery — each unit tracked by serial number',
  })
  @IsOptional()
  @IsBoolean()
  trackSerial?: boolean;
}

export class UpdateProductDto extends PartialType(CreateProductDto) {}

export class AdjustStockDto {
  @ApiProperty()
  @IsUUID()
  warehouseId: string;

  @ApiProperty()
  @IsUUID()
  productId: string;

  @ApiProperty({ description: 'Positive = increase, negative = decrease' })
  @IsNumber()
  @Type(() => Number)
  quantity: number;

  @ApiProperty({ enum: ['ADJUSTMENT', 'WRITE_OFF', 'FOUND', 'DAMAGE', 'RETURN'] })
  @IsString()
  reason: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  notes?: string;
}
