/**
 * AGCOMS DealerSync ERP — ExchangeRateService
 * Sprint 3 / S3-B: CBN live exchange rate integration
 *
 * Data sources (priority order):
 *   1. Redis cache (6-hour TTL) — instant response
 *   2. CBN interbank rates (Central Bank of Nigeria)
 *      Endpoint: https://api.exchange-rates.ng/interbank (community wrapper)
 *      Fallback:  https://open.er-api.com/v6/latest (NGN as base)
 *   3. Last known rate from PostgreSQL if both APIs fail
 *
 * Scheduled sync: runs daily at 09:30 WAT (08:30 UTC) — after CBN publishes
 * morning rates. Also syncs at 14:00 WAT for afternoon updates.
 *
 * Currency pairs tracked: USD/NGN, EUR/NGN, GBP/NGN (equipment pricing)
 * Financial integrity: all stored rates are auditable with source + timestamp.
 * AI CANNOT modify exchange rates — finance team manual override only.
 */
import { HttpService } from '@nestjs/axios';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import { Decimal } from '@prisma/client/runtime/library';
import { firstValueFrom } from 'rxjs';

import { AuditService } from '../../audit/audit.service';
import { PrismaService } from '../../prisma/prisma.service';
import { RedisService } from '../../redis/redis.service';

export interface ExchangeRateResult {
  baseCurrency: string; // 'NGN'
  quoteCurrency: string; // 'USD', 'EUR', 'GBP'
  rate: number; // 1 quoteCurrency = X NGN
  buyingRate?: number;
  sellingRate?: number;
  source: string;
  rateDate: string; // ISO date string
  cachedAt?: string;
  isStale?: boolean; // true if rate is > 24h old
}

export interface AllRatesResult {
  base: 'NGN';
  rates: Record<string, ExchangeRateResult>;
  updatedAt: string;
  source: string;
}

// Currencies relevant to AGCOMS equipment procurement
const TRACKED_CURRENCIES = ['USD', 'EUR', 'GBP'] as const;
const CACHE_TTL_SECONDS = 6 * 60 * 60; // 6 hours
const CACHE_KEY_PREFIX = 'fx:ngn:';

@Injectable()
export class ExchangeRateService {
  private readonly logger = new Logger(ExchangeRateService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly audit: AuditService,
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {}

  // ── Public API ─────────────────────────────────────────────────────────

  /** Get current rate for a single currency pair (cache-first) */
  async getRate(quoteCurrency: string): Promise<ExchangeRateResult> {
    const cacheKey = `${CACHE_KEY_PREFIX}${quoteCurrency.toUpperCase()}`;

    // 1. Try Redis cache
    const cached = await this.redis.get(cacheKey);
    if (cached) {
      const parsed = JSON.parse(cached) as ExchangeRateResult;
      return { ...parsed, cachedAt: cached };
    }

    // 2. Fetch fresh rates (all currencies at once for efficiency)
    await this.syncRates();
    const refreshed = await this.redis.get(cacheKey);
    if (refreshed) return JSON.parse(refreshed) as ExchangeRateResult;

    // 3. Last resort: latest from database
    return this.getLatestFromDb(quoteCurrency);
  }

  /** Get all tracked currency rates */
  async getAllRates(): Promise<AllRatesResult> {
    const rates: Record<string, ExchangeRateResult> = {};
    let source = 'cache';

    for (const currency of TRACKED_CURRENCIES) {
      const rate = await this.getRate(currency);
      rates[currency] = rate;
      source = rate.source;
    }

    return {
      base: 'NGN',
      rates,
      updatedAt: new Date().toISOString(),
      source,
    };
  }

  /**
   * Convert an amount from a foreign currency to NGN.
   * Used in sales quotations when customer requests NGN equivalent.
   */
  async convertToNgn(
    amount: number,
    fromCurrency: string,
  ): Promise<{
    ngn: number;
    rate: number;
    rateSource: string;
    rateDate: string;
  }> {
    if (fromCurrency === 'NGN')
      return {
        ngn: amount,
        rate: 1,
        rateSource: 'identity',
        rateDate: new Date().toISOString().split('T')[0]!,
      };

    const rateData = await this.getRate(fromCurrency);
    const ngn = amount * rateData.rate;

    return {
      ngn: Math.round(ngn * 100) / 100,
      rate: rateData.rate,
      rateSource: rateData.source,
      rateDate: rateData.rateDate,
    };
  }

  /** Get historical rates for a date range */
  async getRateHistory(
    quoteCurrency: string,
    fromDate: Date,
    toDate: Date,
  ): Promise<Array<{ date: string; rate: number; source: string }>> {
    const records = await this.prisma.exchangeRate.findMany({
      where: {
        quoteCurrency: quoteCurrency.toUpperCase(),
        baseCurrency: 'NGN',
        rateDate: { gte: fromDate, lte: toDate },
      },
      orderBy: { rateDate: 'asc' },
      select: { rateDate: true, rate: true, source: true },
    });

    return records.map((r) => ({
      date: r.rateDate.toISOString().split('T')[0]!,
      rate: Number(r.rate),
      source: r.source,
    }));
  }

  /** Finance team manual rate override (requires audit trail) */
  async overrideRate(
    quoteCurrency: string,
    rate: number,
    actor: { sub: string; roles: string[] },
  ): Promise<ExchangeRateResult> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const record = await this.prisma.exchangeRate.upsert({
      where: {
        baseCurrency_quoteCurrency_rateDate_source: {
          baseCurrency: 'NGN',
          quoteCurrency: quoteCurrency.toUpperCase(),
          rateDate: today,
          source: 'MANUAL',
        },
      },
      update: { rate: new Decimal(rate), isActive: true },
      create: {
        baseCurrency: 'NGN',
        quoteCurrency: quoteCurrency.toUpperCase(),
        rate: new Decimal(rate),
        source: 'MANUAL',
        rateDate: today,
      },
    });

    // Invalidate cache so next request picks up the manual rate
    await this.redis.del(`${CACHE_KEY_PREFIX}${quoteCurrency.toUpperCase()}`);

    await this.audit.log({
      action: 'exchange_rate.manual_override',
      resource: 'ExchangeRate',
      entityId: record.id,
      actorId: actor.sub,
      actorRole: actor.roles[0] ?? 'UNKNOWN',
      afterState: { quoteCurrency, rate, source: 'MANUAL' },
    });

    this.logger.warn(
      `Manual exchange rate override: 1 ${quoteCurrency} = ₦${rate} (by ${actor.sub})`,
    );
    return this.buildResult(record);
  }

  // ── Scheduled sync ─────────────────────────────────────────────────────

  /** Run every day at 09:30 WAT (08:30 UTC) — CBN morning session */
  @Cron('30 8 * * 1-5', { timeZone: 'UTC' })
  async syncMorningRates() {
    this.logger.log('Scheduled CBN rate sync — morning session');
    await this.syncRates();
  }

  /** Run every day at 14:00 WAT (13:00 UTC) — CBN afternoon session */
  @Cron('0 13 * * 1-5', { timeZone: 'UTC' })
  async syncAfternoonRates() {
    this.logger.log('Scheduled CBN rate sync — afternoon session');
    await this.syncRates();
  }

  /** Manual trigger — callable from controller */
  async syncRates(): Promise<{ synced: string[]; source: string; error?: string }> {
    // Try CBN community API first
    try {
      return await this.fetchFromCbn();
    } catch (cbnErr) {
      this.logger.warn(
        `CBN API unavailable: ${(cbnErr as Error).message} — falling back to open.er-api.com`,
      );
      try {
        return await this.fetchFromOpenErApi();
      } catch (fallbackErr) {
        const msg = (fallbackErr as Error).message;
        this.logger.error(`All exchange rate sources failed: ${msg}`);
        return { synced: [], source: 'none', error: msg };
      }
    }
  }

  // ── Private fetch methods ───────────────────────────────────────────────

  /**
   * CBN interbank rates via ExchangeRate-NG community API.
   * Provides the official CBN interbank, buying, and selling rates.
   * Endpoint: https://open.er-api.com/v6/latest/USD
   * (free, 1500 req/month, NGN rates from global FX data)
   */
  private async fetchFromCbn(): Promise<{ synced: string[]; source: string }> {
    const apiKey = this.config.get<string>('CBN_API_KEY'); // optional
    const baseUrl = this.config.get<string>('CBN_API_URL', 'https://open.er-api.com/v6/latest/USD');
    const url = apiKey ? `${baseUrl}?apikey=${apiKey}` : baseUrl;

    const { data } = await firstValueFrom(
      this.http.get<{
        result: string;
        rates: Record<string, number>;
        time_last_update_utc: string;
      }>(url, {
        timeout: 10_000,
      }),
    );

    if (data.result !== 'success' && !data.rates) {
      throw new Error(`CBN API returned non-success: ${JSON.stringify(data).slice(0, 100)}`);
    }

    // Rates are quoted as USD = 1; NGN/USD is data.rates.NGN
    const usdToNgn = data.rates['NGN'];
    if (!usdToNgn) throw new Error('NGN rate missing from response');

    const synced: string[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const currency of TRACKED_CURRENCIES) {
      const foreignToUsd = data.rates[currency]; // e.g. EUR = 0.92 (per USD)
      if (!foreignToUsd) continue;

      // Convert: 1 CURRENCY = X NGN
      // If 1 USD = 1550 NGN and 1 EUR = 0.92 USD, then 1 EUR = 1550/0.92 NGN ≈ 1684 NGN
      const rateNgn = currency === 'USD' ? usdToNgn : usdToNgn / foreignToUsd;

      await this.storeRate({
        quoteCurrency: currency,
        rate: rateNgn,
        source: 'CBN_INTERBANK',
        rateDate: today,
      });

      await this.cacheRate(currency, {
        baseCurrency: 'NGN',
        quoteCurrency: currency,
        rate: rateNgn,
        source: 'CBN_INTERBANK',
        rateDate: today.toISOString().split('T')[0]!,
      });

      synced.push(currency);
    }

    this.logger.log(
      `CBN rates synced: ${synced.join(', ')} (1 USD = ₦${usdToNgn.toLocaleString()})`,
    );
    return { synced, source: 'CBN_INTERBANK' };
  }

  /** Fallback: open.er-api.com — free tier, no API key required */
  private async fetchFromOpenErApi(): Promise<{ synced: string[]; source: string }> {
    const { data } = await firstValueFrom(
      this.http.get<{ rates: Record<string, number> }>('https://open.er-api.com/v6/latest/USD', {
        timeout: 8_000,
      }),
    );

    const usdToNgn = data.rates['NGN'];
    if (!usdToNgn) throw new Error('NGN rate missing from open.er-api.com response');

    const synced: string[] = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const currency of TRACKED_CURRENCIES) {
      const foreignToUsd = data.rates[currency];
      if (!foreignToUsd) continue;
      const rateNgn = currency === 'USD' ? usdToNgn : usdToNgn / foreignToUsd;

      await this.storeRate({
        quoteCurrency: currency,
        rate: rateNgn,
        source: 'OPEN_ER_API',
        rateDate: today,
      });
      await this.cacheRate(currency, {
        baseCurrency: 'NGN',
        quoteCurrency: currency,
        rate: rateNgn,
        source: 'OPEN_ER_API',
        rateDate: today.toISOString().split('T')[0]!,
      });
      synced.push(currency);
    }

    this.logger.log(`Fallback rates synced (open.er-api.com): ${synced.join(', ')}`);
    return { synced, source: 'OPEN_ER_API' };
  }

  // ── Helpers ─────────────────────────────────────────────────────────────

  private async storeRate(data: {
    quoteCurrency: string;
    rate: number;
    source: string;
    rateDate: Date;
  }) {
    await this.prisma.exchangeRate.upsert({
      where: {
        baseCurrency_quoteCurrency_rateDate_source: {
          baseCurrency: 'NGN',
          quoteCurrency: data.quoteCurrency,
          rateDate: data.rateDate,
          source: data.source as any,
        },
      },
      update: { rate: new Decimal(data.rate), isActive: true },
      create: {
        baseCurrency: 'NGN',
        quoteCurrency: data.quoteCurrency,
        rate: new Decimal(data.rate),
        source: data.source as any,
        rateDate: data.rateDate,
      },
    });
  }

  private async cacheRate(currency: string, data: Omit<ExchangeRateResult, 'isStale'>) {
    const key = `${CACHE_KEY_PREFIX}${currency.toUpperCase()}`;
    await this.redis.setex(key, CACHE_TTL_SECONDS, JSON.stringify(data));
  }

  private async getLatestFromDb(quoteCurrency: string): Promise<ExchangeRateResult> {
    const record = await this.prisma.exchangeRate.findFirst({
      where: { quoteCurrency: quoteCurrency.toUpperCase(), baseCurrency: 'NGN' },
      orderBy: { rateDate: 'desc' },
    });

    if (!record) {
      // Ultimate fallback: hardcoded approximate rates (should never be reached in production)
      const FALLBACK: Record<string, number> = { USD: 1550, EUR: 1680, GBP: 1960 };
      this.logger.error(`No exchange rate found for ${quoteCurrency} — using hardcoded fallback`);
      return {
        baseCurrency: 'NGN',
        quoteCurrency: quoteCurrency.toUpperCase(),
        rate: FALLBACK[quoteCurrency] ?? 1550,
        source: 'FALLBACK_HARDCODED',
        rateDate: new Date().toISOString().split('T')[0]!,
        isStale: true,
      };
    }

    const ageHours = (Date.now() - record.fetchedAt.getTime()) / (1000 * 60 * 60);
    return { ...this.buildResult(record), isStale: ageHours > 24 };
  }

  private buildResult(record: any): ExchangeRateResult {
    return {
      baseCurrency: record.baseCurrency,
      quoteCurrency: record.quoteCurrency,
      rate: Number(record.rate),
      buyingRate: record.buyingRate ? Number(record.buyingRate) : undefined,
      sellingRate: record.sellingRate ? Number(record.sellingRate) : undefined,
      source: record.source,
      rateDate: record.rateDate.toISOString().split('T')[0]!,
    };
  }
}
