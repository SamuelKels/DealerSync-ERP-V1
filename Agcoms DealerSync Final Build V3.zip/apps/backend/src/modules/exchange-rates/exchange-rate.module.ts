/**
 * AGCOMS DealerSync ERP — ExchangeRateModule
 * Sprint 3 / S3-B: Registers CBN exchange rate service globally.
 * Exported so SalesModule and other modules can inject ExchangeRateService.
 */
import { HttpModule } from '@nestjs/axios';
import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';

import { ExchangeRateController } from './exchange-rate.controller';
import { ExchangeRateService } from './exchange-rate.service';

@Module({
  imports: [HttpModule.register({ timeout: 15_000, maxRedirects: 3 }), ScheduleModule.forRoot()],
  controllers: [ExchangeRateController],
  providers: [ExchangeRateService],
  exports: [ExchangeRateService], // SalesModule injects for quotation conversion
})
export class ExchangeRateModule {}
