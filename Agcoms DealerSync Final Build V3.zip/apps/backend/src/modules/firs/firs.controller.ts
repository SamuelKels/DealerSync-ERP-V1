/**
 * AGCOMS DealerSync ERP — FIRS Controller
 * Sprint 5 / S5-A: REST endpoints for Nigerian tax filing.
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Get,
  Post,
  Param,
  Body,
  Query,
  Res,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import {
  ApiTags,
  ApiBearerAuth,
  ApiOperation,
  ApiQuery,
  ApiParam,
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsNumber, IsString, IsOptional, IsEnum, IsPositive, Min, Max } from 'class-validator';
import { Response } from 'express';

import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';

import { FirsVatService } from './firs-vat.service';

class ComputeVatDto {
  @ApiProperty({ example: 2025 })
  @IsNumber()
  @Min(2020)
  @Max(2100)
  @Type(() => Number)
  year!: number;

  @ApiProperty({ example: 1, minimum: 1, maximum: 12 })
  @IsNumber()
  @Min(1)
  @Max(12)
  @Type(() => Number)
  month!: number;
}

class SubmitVatDto {
  @ApiProperty({ example: 'FIRS-2025-0123456' })
  @IsString()
  firsReceiptNo!: string;
}

class IssueWhtDto {
  @ApiProperty({ enum: ['CONTRACT', 'CONSULTANCY', 'RENT', 'TECHNICAL'] })
  @IsEnum(['CONTRACT', 'CONSULTANCY', 'RENT', 'TECHNICAL'])
  transactionType!: 'CONTRACT' | 'CONSULTANCY' | 'RENT' | 'TECHNICAL';

  @ApiProperty({ example: 1000000 })
  @IsNumber()
  @IsPositive()
  @Type(() => Number)
  grossAmount!: number;

  @ApiProperty({ example: 'Dangote Farms Ltd' })
  @IsString()
  recipientName!: string;

  @ApiPropertyOptional({ example: '12345678-0001' })
  @IsOptional()
  @IsString()
  recipientTin?: string;

  @ApiProperty({ example: 'Invoice' })
  @IsString()
  referenceType!: string;

  @ApiProperty()
  @IsString()
  referenceId!: string;

  @ApiProperty({ example: 2025 })
  @IsNumber()
  @Min(2020)
  @Max(2100)
  @Type(() => Number)
  year!: number;

  @ApiProperty({ example: 1 })
  @IsNumber()
  @Min(1)
  @Max(12)
  @Type(() => Number)
  month!: number;
}

@ApiTags('firs')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('firs')
export class FirsController {
  constructor(private readonly svc: FirsVatService) {}

  @Post('vat-returns/compute')
  @RequirePermission('finance:write')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Compute monthly VAT return from posted journal entries' })
  computeVat(@Body() dto: ComputeVatDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.computeVatReturn(actor.branchId, dto.year, dto.month, actor);
  }

  @Post('vat-returns/:id/submit')
  @RequirePermission('finance:write')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Mark VAT return as submitted to FIRS TaxPro-Max portal' })
  @ApiParam({ name: 'id', description: 'VAT return UUID' })
  submitVat(@Param('id') id: string, @Body() dto: SubmitVatDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.submitVatReturn(id, dto.firsReceiptNo, actor);
  }

  @Get('vat-returns/:id/excel')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Download TaxPro-Max Excel export' })
  @ApiParam({ name: 'id', description: 'VAT return UUID' })
  async downloadExcel(@Param('id') id: string, @Res() res: Response) {
    const buffer = await this.svc.generateVatExcel(id);
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="VAT-Return-${id}.xlsx"`,
      'Content-Length': buffer.length,
    });
    res.end(buffer);
  }

  @Get('vat-returns')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'List all VAT returns for this branch' })
  listVatReturns(@CurrentUser() actor: JwtPayload) {
    return this.svc.listVatReturns(actor.branchId);
  }

  @Get('schedule')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'Rolling 6-month filing schedule' })
  getSchedule(@CurrentUser() actor: JwtPayload) {
    return this.svc.getFilingSchedule(actor.branchId);
  }

  @Post('wht-certificates')
  @RequirePermission('finance:write')
  @ApiOperation({ summary: 'Issue a WHT deduction certificate' })
  issueWht(@Body() dto: IssueWhtDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.generateWhtCertificate(
      actor.branchId,
      dto.recipientName,
      dto.recipientTin,
      dto.grossAmount,
      dto.transactionType,
      dto.referenceType,
      dto.referenceId,
      dto.year,
      dto.month,
      actor,
    );
  }

  @Get('wht-certificates')
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'List issued WHT certificates' })
  @ApiQuery({ name: 'year', required: false, type: Number })
  listWhtCertificates(@CurrentUser() actor: JwtPayload, @Query('year') year?: string) {
    const y = year ? parseInt(year, 10) : new Date().getFullYear();
    return (this.svc as any).prisma.firsWhtCertificate.findMany({
      where: {
        branchId: actor.branchId,
        issuedAt: { gte: new Date(y, 0, 1), lt: new Date(y + 1, 0, 1) },
      },
      orderBy: { issuedAt: 'desc' },
    });
  }
}
