import { BullModule } from '@nestjs/bull';
import { Module } from '@nestjs/common';

import { FirsVatService, FIRS_FILING_QUEUE } from './firs-vat.service';
import { FirsController } from './firs.controller';

@Module({
  imports: [BullModule.registerQueue({ name: FIRS_FILING_QUEUE })],
  controllers: [FirsController],
  providers: [FirsVatService],
  exports: [FirsVatService],
})
export class FirsModule {}
