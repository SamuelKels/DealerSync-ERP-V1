/**
 * AGCOMS DealerSync ERP — Contracts Controller
 * Sprint 1 Fix: Controller was missing — no HTTP endpoints existed for this module.
 *
 * Base CRUD scaffold. Domain-specific endpoints are in separate files
 * per feature (e.g. crm.customers.controller.ts, crm.leads.controller.ts).
 * Every route requires JWT auth via the global JwtAuthGuard registered in main.ts.
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';

import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';

import { ContractsService } from './contracts.service';

@ApiTags('contracts')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('contracts')
export class ContractsController {
  constructor(private readonly svc: ContractsService) {}

  @Get()
  @RequirePermission('contracts:read')
  @ApiOperation({ summary: 'List contracts records — paginated + branch-scoped' })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'page', required: false, type: Number })
  findAll(@Query() query: Record<string, string>, @CurrentUser() actor: JwtPayload) {
    const branchId = actor.isSuperAdmin ? query['branchId'] : actor.branchId;
    return (this.svc as any).findAll?.({ ...query, branchId }, actor) ?? { items: [], total: 0 };
  }

  @Get(':id')
  @RequirePermission('contracts:read')
  @ApiOperation({ summary: 'Get single contracts by ID' })
  findOne(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).findOne?.(id, actor);
  }

  @Post()
  @RequirePermission('contracts:write')
  @ApiOperation({ summary: 'Create contracts record' })
  create(@Body() dto: Record<string, unknown>, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).create?.(dto, actor);
  }

  @Patch(':id')
  @RequirePermission('contracts:write')
  @ApiOperation({ summary: 'Update contracts record (partial)' })
  update(
    @Param('id') id: string,
    @Body() dto: Record<string, unknown>,
    @CurrentUser() actor: JwtPayload,
  ) {
    return (this.svc as any).update?.(id, dto, actor);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @RequirePermission('contracts:delete')
  @ApiOperation({ summary: 'Soft-delete contracts record' })
  remove(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).remove?.(id, actor);
  }
}
