/**
 * AGCOMS DealerSync ERP — TenderService
 * §7 Module 10 Government Contracts: "tender management"
 *
 * Workflow: DRAFT → SUBMITTED → EVALUATING → AWARDED → CONTRACT_CREATED
 *           (or → REJECTED at any stage)
 *
 * Evaluation: Technical score (0–100) + Commercial score (0–100)
 *             Weights must sum to 100.
 * On AWARDED: createContractFromTender() creates the GovernmentContract.
 */
import { JwtPayload } from '@agcoms/types';
import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';

import { AuditService } from '../../../audit/audit.service';
import { PrismaService } from '../../../prisma/prisma.service';

export type TenderStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'EVALUATING'
  | 'AWARDED'
  | 'CONTRACT_CREATED'
  | 'REJECTED';

export interface TenderBid {
  bidderName: string;
  bidderContact: string;
  technicalScore: number; // 0–100
  commercialScore: number; // 0–100
  proposedAmount: number;
  proposedTimeline: string;
  notes?: string;
}

export interface CreateTenderDto {
  branchId: string;
  title: string;
  description: string;
  referenceNo?: string;
  estimatedValue: number;
  currency: string;
  closingDate: Date;
  technicalWeightPct: number; // Must sum to 100 with commercialWeightPct
  commercialWeightPct: number;
  requirementDocs?: string;
  notes?: string;
}

export interface EvaluateTenderDto {
  bids: TenderBid[];
  evaluationPanel: string; // Names of evaluators
  evaluationNotes?: string;
}

export interface AwardTenderDto {
  winningBidderName: string;
  awardedAmount: number;
  awardRationale: string;
}

@Injectable()
export class TenderService {
  private readonly logger = new Logger(TenderService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  // ── Create tender ─────────────────────────────────────────────

  async createTender(dto: CreateTenderDto, actor: JwtPayload) {
    if (dto.technicalWeightPct + dto.commercialWeightPct !== 100) {
      throw new BadRequestException('Technical and commercial weights must sum to 100%');
    }
    if (dto.closingDate <= new Date()) {
      throw new BadRequestException('Closing date must be in the future');
    }

    const tenderNo = await this.generateTenderNo(dto.branchId);
    const tender = await this.prisma.tender.create({
      data: {
        tenderNo,
        branchId: dto.branchId,
        title: dto.title,
        description: dto.description,
        referenceNo: dto.referenceNo,
        estimatedValue: dto.estimatedValue,
        currency: dto.currency,
        closingDate: dto.closingDate,
        technicalWeightPct: dto.technicalWeightPct,
        commercialWeightPct: dto.commercialWeightPct,
        requirementDocs: dto.requirementDocs,
        notes: dto.notes,
        status: 'DRAFT',
        createdById: actor.sub,
      },
    });

    this.logger.log(`Tender ${tenderNo} created`);
    return tender;
  }

  // ── Submit ────────────────────────────────────────────────────

  async submitTender(id: string, actor: JwtPayload) {
    const tender = await this.findTender(id);
    this.assertTransitionAllowed(tender.status, 'SUBMITTED', id);

    await this.prisma.tender.update({
      where: { id },
      data: { status: 'SUBMITTED', submittedAt: new Date(), submittedById: actor.sub },
    });

    return { id, status: 'SUBMITTED' };
  }

  // ── Evaluate — record bids with scores ───────────────────────

  async evaluateTender(id: string, dto: EvaluateTenderDto, actor: JwtPayload) {
    const tender = await this.findTender(id);
    this.assertTransitionAllowed(tender.status, 'EVALUATING', id);

    // Validate all scores within 0–100
    dto.bids.forEach((bid) => {
      if (bid.technicalScore < 0 || bid.technicalScore > 100)
        throw new BadRequestException(
          `Technical score must be 0–100 for bidder "${bid.bidderName}"`,
        );
      if (bid.commercialScore < 0 || bid.commercialScore > 100)
        throw new BadRequestException(
          `Commercial score must be 0–100 for bidder "${bid.bidderName}"`,
        );
    });

    // Compute weighted composite score
    const bidsWithComposite = dto.bids.map((bid) => ({
      ...bid,
      compositeScore:
        (bid.technicalScore * Number(tender.technicalWeightPct) +
          bid.commercialScore * Number(tender.commercialWeightPct)) /
        100,
    }));

    await this.prisma.$transaction(async (tx: any) => {
      await tx.tender.update({
        where: { id },
        data: {
          status: 'EVALUATING',
          evaluationPanel: dto.evaluationPanel,
          evaluationNotes: dto.evaluationNotes,
          evaluatedAt: new Date(),
          evaluatedById: actor.sub,
        },
      });

      // Store bids
      await tx.tenderBid.deleteMany({ where: { tenderId: id } });
      await tx.tenderBid.createMany({
        data: bidsWithComposite.map((b) => ({
          tenderId: id,
          bidderName: b.bidderName,
          bidderContact: b.bidderContact,
          technicalScore: b.technicalScore,
          commercialScore: b.commercialScore,
          compositeScore: b.compositeScore,
          proposedAmount: b.proposedAmount,
          proposedTimeline: b.proposedTimeline,
          notes: b.notes,
        })),
      });
    });

    // Return ranked bids (highest composite score first)
    const ranked = [...bidsWithComposite].sort((a, b) => b.compositeScore - a.compositeScore);
    return { id, status: 'EVALUATING', rankedBids: ranked };
  }

  // ── Award tender ──────────────────────────────────────────────

  async awardTender(id: string, dto: AwardTenderDto, actor: JwtPayload) {
    const tender = await this.findTender(id);
    if (!['EVALUATING', 'SUBMITTED'].includes(tender.status)) {
      throw new BadRequestException('Tender must be SUBMITTED or EVALUATING to be awarded');
    }

    await this.prisma.tender.update({
      where: { id },
      data: {
        status: 'AWARDED',
        winningBidderName: dto.winningBidderName,
        awardedAmount: dto.awardedAmount,
        awardRationale: dto.awardRationale,
        awardedAt: new Date(),
        awardedById: actor.sub,
      },
    });

    await this.audit.log({
      action: 'tender.awarded',
      resource: 'Tender',
      entityId: id,
      actorId: actor.sub,
      actorRole: actor.roles[0],
      afterState: {
        tenderNo: tender.tenderNo,
        winner: dto.winningBidderName,
        amount: dto.awardedAmount,
      },
    });

    this.events.emit('tender.awarded', {
      tenderId: id,
      tenderNo: tender.tenderNo,
      winner: dto.winningBidderName,
    });
    this.logger.log(`Tender ${tender.tenderNo} awarded to ${dto.winningBidderName}`);
    return { id, status: 'AWARDED', winner: dto.winningBidderName };
  }

  // ── Create Government Contract from awarded tender ────────────

  async createContractFromTender(id: string, actor: JwtPayload) {
    const tender = await this.findTender(id);
    if (tender.status !== 'AWARDED') {
      throw new BadRequestException('Only AWARDED tenders can be converted to contracts');
    }

    const contract = await this.prisma.$transaction(async (tx: any) => {
      const contractNo = await this.generateContractNo(tender.branchId, tx);

      const c = await tx.governmentContract.create({
        data: {
          contractNo,
          tenderId: tender.id,
          branchId: tender.branchId,
          title: tender.title,
          description: tender.description,
          contractorName: tender.winningBidderName ?? '',
          contractValue: tender.awardedAmount ?? tender.estimatedValue,
          currency: tender.currency,
          status: 'ACTIVE',
          signedAt: new Date(),
          createdById: actor.sub,
        },
      });

      await tx.tender.update({
        where: { id },
        data: { status: 'CONTRACT_CREATED', contractId: c.id },
      });

      return c;
    });

    this.logger.log(`Contract ${contract.contractNo} created from tender ${tender.tenderNo}`);
    return contract;
  }

  // ── Analytics ─────────────────────────────────────────────────

  async getTenderAnalytics(branchId: string, year?: number) {
    const targetYear = year ?? new Date().getFullYear();
    const yearStart = new Date(targetYear, 0, 1);
    const yearEnd = new Date(targetYear, 11, 31);

    const [total, won, totalValue, wonValue] = await Promise.all([
      this.prisma.tender.count({
        where: { branchId, createdAt: { gte: yearStart, lte: yearEnd } },
      }),
      this.prisma.tender.count({
        where: {
          branchId,
          status: { in: ['AWARDED', 'CONTRACT_CREATED'] },
          awardedAt: { gte: yearStart, lte: yearEnd },
        },
      }),
      this.prisma.tender.aggregate({
        where: { branchId, createdAt: { gte: yearStart, lte: yearEnd } },
        _sum: { estimatedValue: true },
      }),
      this.prisma.tender.aggregate({
        where: {
          branchId,
          status: { in: ['AWARDED', 'CONTRACT_CREATED'] },
          awardedAt: { gte: yearStart, lte: yearEnd },
        },
        _sum: { awardedAmount: true },
      }),
    ]);

    return {
      year: targetYear,
      totalTenders: total,
      wonTenders: won,
      winRate: total > 0 ? Math.round((won / total) * 1000) / 10 : 0,
      pipelineValue: Number(totalValue._sum.estimatedValue ?? 0),
      wonValue: Number(wonValue._sum.awardedAmount ?? 0),
    };
  }

  // ── Reject tender ─────────────────────────────────────────────

  async rejectTender(id: string, reason: string, actor: JwtPayload) {
    const tender = await this.findTender(id);
    if (['AWARDED', 'CONTRACT_CREATED', 'REJECTED'].includes(tender.status)) {
      throw new BadRequestException(`Cannot reject a ${tender.status} tender`);
    }

    await this.prisma.tender.update({
      where: { id },
      data: {
        status: 'REJECTED',
        rejectionReason: reason,
        rejectedAt: new Date(),
        rejectedById: actor.sub,
      },
    });

    return { id, status: 'REJECTED' };
  }

  // ── Helpers ───────────────────────────────────────────────────

  async listTenders(params: {
    branchId: string;
    status?: TenderStatus;
    page?: number;
    limit?: number;
  }) {
    const { branchId, status, page = 1, limit = 20 } = params;
    const [items, total] = await Promise.all([
      this.prisma.tender.findMany({
        where: { branchId, ...(status ? { status } : {}), isDeleted: false },
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { bids: { orderBy: { compositeScore: 'desc' }, take: 3 } },
      }),
      this.prisma.tender.count({ where: { branchId, isDeleted: false } }),
    ]);
    return { items, total, hasMore: page * limit < total };
  }

  private async findTender(id: string) {
    const t = await this.prisma.tender.findUnique({
      where: { id },
      include: { bids: { orderBy: { compositeScore: 'desc' } } },
    });
    if (!t) throw new NotFoundException(`Tender ${id} not found`);
    return t;
  }

  private assertTransitionAllowed(currentStatus: string, targetStatus: string, _context?: string) {
    const TRANSITIONS: Record<string, string[]> = {
      DRAFT: ['SUBMITTED', 'REJECTED'],
      SUBMITTED: ['EVALUATING', 'AWARDED', 'REJECTED'],
      EVALUATING: ['AWARDED', 'REJECTED'],
      AWARDED: ['CONTRACT_CREATED'],
      CONTRACT_CREATED: [],
      REJECTED: [],
    };
    if (!(TRANSITIONS[currentStatus] ?? []).includes(targetStatus)) {
      throw new BadRequestException(
        `Invalid tender status transition: ${currentStatus} → ${targetStatus}`,
      );
    }
  }

  private async generateTenderNo(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({
      where: { id: branchId },
      select: { code: true },
    });
    const count = await this.prisma.tender.count({ where: { branchId } });
    return `TND-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  }

  private async generateContractNo(branchId: string, tx: any): Promise<string> {
    const branch = await tx.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    const count = await tx.governmentContract.count({ where: { branchId } });
    return `GOV-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;
  }
}
