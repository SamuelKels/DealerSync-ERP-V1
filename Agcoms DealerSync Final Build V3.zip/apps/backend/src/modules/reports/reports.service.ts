/**
 * AGCOMS DealerSync ERP — Reporting & BI Service (Module 11)
 * Report builder · Scheduled exports · Drill-down analytics · KPI engine
 * Excel/PDF export support via BullMQ background jobs
 */
import { InjectQueue } from '@nestjs/bull';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bull';

import { AuditService } from '../../audit/audit.service';
import { PrismaService } from '../../prisma/prisma.service';

export type ReportType =
  | 'TRIAL_BALANCE'
  | 'INCOME_STATEMENT'
  | 'BALANCE_SHEET'
  | 'AR_AGING'
  | 'AP_AGING'
  | 'SALES_SUMMARY'
  | 'INVENTORY_VALUATION'
  | 'PAYROLL_SUMMARY'
  | 'VAT_SUMMARY'
  | 'NADF_DELIVERY'
  | 'FLEET_UTILISATION'
  | 'CUSTOM';

@Injectable()
export class ReportsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    @InjectQueue('reports') private readonly reportsQueue: Queue,
  ) {}

  // ── Saved Reports ─────────────────────────────────────────────────────

  async listSavedReports(actorId: string, branchId: string) {
    return this.prisma.savedReport.findMany({
      where: { isDeleted: false, OR: [{ branchId }, { branchId: null }] },
      include: { createdBy: { select: { firstName: true, lastName: true } } },
      orderBy: { updatedAt: 'desc' },
    });
  }

  async saveReport(
    dto: {
      name: string;
      description?: string;
      reportType: ReportType;
      config: Record<string, any>;
      schedule?: string;
      branchId?: string;
    },
    actorId: string,
  ) {
    const report = await this.prisma.savedReport.create({
      data: { ...dto, reportType: dto.reportType, createdById: actorId },
    });
    await this.audit.log({
      action: 'create',
      resource: 'saved_report',
      entityId: report.id,
      afterState: report,
      actorId,
    });
    return report;
  }

  // ── Report Execution ──────────────────────────────────────────────────

  async runReport(
    reportType: ReportType,
    params: Record<string, any>,
    actorId: string,
    branchId: string,
    isSuperAdmin: boolean,
  ): Promise<any> {
    const effectiveBranch = isSuperAdmin ? (params.branchId ?? null) : branchId;
    switch (reportType) {
      case 'AR_AGING':
        return this.buildArAgingReport(effectiveBranch, params);
      case 'AP_AGING':
        return this.buildApAgingReport(effectiveBranch, params);
      case 'SALES_SUMMARY':
        return this.buildSalesSummary(effectiveBranch, params);
      case 'INVENTORY_VALUATION':
        return this.buildInventoryValuation(effectiveBranch);
      case 'PAYROLL_SUMMARY':
        return this.buildPayrollSummary(effectiveBranch, params);
      case 'NADF_DELIVERY':
        return this.buildNadfDeliveryReport();
      case 'FLEET_UTILISATION':
        return this.buildFleetUtilisationReport(effectiveBranch);
      default:
        return {
          message: `Report type ${reportType} — use finance module for trial balance and income statement`,
        };
    }
  }

  // ── AR Aging Report ───────────────────────────────────────────────────

  private async buildArAgingReport(branchId: string | null, params: any) {
    const asOf = params.asOf ? new Date(params.asOf) : new Date();
    const bf = branchId ? { branchId } : {};
    const invoices = await this.prisma.invoice.findMany({
      where: { ...bf, isDeleted: false, status: { in: ['ISSUED', 'PARTIALLY_PAID'] } },
      include: { customer: { select: { id: true, code: true, name: true } } },
      orderBy: { dueDate: 'asc' },
    });

    const buckets = {
      current: [] as any[],
      days1_30: [] as any[],
      days31_60: [] as any[],
      days61_90: [] as any[],
      over90: [] as any[],
    };
    let totalOutstanding = 0;

    for (const inv of invoices) {
      const outstanding = Number(inv.total) - Number(inv.amountPaid ?? 0);
      if (outstanding <= 0) continue;
      const daysOverdue = inv.dueDate
        ? Math.floor((asOf.getTime() - new Date(inv.dueDate).getTime()) / (1000 * 60 * 60 * 24))
        : 0;
      const row = {
        invoiceCode: inv.code,
        customer: inv.customer?.name,
        customerId: inv.customer?.id,
        dueDate: inv.dueDate,
        outstanding,
        daysOverdue,
      };
      if (daysOverdue <= 0) buckets.current.push(row);
      else if (daysOverdue <= 30) buckets.days1_30.push(row);
      else if (daysOverdue <= 60) buckets.days31_60.push(row);
      else if (daysOverdue <= 90) buckets.days61_90.push(row);
      else buckets.over90.push(row);
      totalOutstanding += outstanding;
    }

    return {
      reportType: 'AR_AGING',
      asOf,
      totalOutstanding,
      summary: {
        current: {
          count: buckets.current.length,
          amount: buckets.current.reduce((s, r) => s + r.outstanding, 0),
        },
        days1_30: {
          count: buckets.days1_30.length,
          amount: buckets.days1_30.reduce((s, r) => s + r.outstanding, 0),
        },
        days31_60: {
          count: buckets.days31_60.length,
          amount: buckets.days31_60.reduce((s, r) => s + r.outstanding, 0),
        },
        days61_90: {
          count: buckets.days61_90.length,
          amount: buckets.days61_90.reduce((s, r) => s + r.outstanding, 0),
        },
        over90: {
          count: buckets.over90.length,
          amount: buckets.over90.reduce((s, r) => s + r.outstanding, 0),
        },
      },
      detail: buckets,
    };
  }

  // ── AP Aging ──────────────────────────────────────────────────────────

  private async buildApAgingReport(branchId: string | null, params: any) {
    const asOf = params.asOf ? new Date(params.asOf) : new Date();
    const bf = branchId ? { branchId } : {};
    const invoices = await this.prisma.vendorInvoice.findMany({
      where: { ...bf, isDeleted: false, matchStatus: { in: ['MATCHED', 'APPROVED'] } },
      include: { purchaseOrder: { include: { vendor: { select: { name: true } } } } },
    });

    const rows = invoices.map((inv) => {
      const daysOverdue = inv.dueDate
        ? Math.max(0, Math.floor((asOf.getTime() - new Date(inv.dueDate).getTime()) / 86_400_000))
        : 0;
      return {
        code: inv.code,
        vendor: inv.purchaseOrder?.vendor?.name,
        dueDate: inv.dueDate,
        total: Number(inv.total),
        daysOverdue,
      };
    });

    return {
      reportType: 'AP_AGING',
      asOf,
      total: rows.reduce((s, r) => s + r.total, 0),
      invoices: rows.sort((a, b) => b.daysOverdue - a.daysOverdue),
    };
  }

  // ── Sales Summary ─────────────────────────────────────────────────────

  private async buildSalesSummary(branchId: string | null, params: any) {
    const from = params.from ? new Date(params.from) : new Date(new Date().getFullYear(), 0, 1);
    const to = params.to ? new Date(params.to) : new Date();
    const bf = branchId ? { branchId } : {};

    const [invoices, salesOrders, quotations] = await Promise.all([
      this.prisma.invoice.aggregate({
        where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
        _sum: { total: true, vatAmount: true },
        _count: { id: true },
      }),
      this.prisma.salesOrder.count({
        where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
      }),
      this.prisma.quotation.count({
        where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
      }),
    ]);

    // Top customers by revenue
    const topCustomers = await this.prisma.invoice.groupBy({
      by: ['customerId'],
      where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
      _sum: { total: true },
      orderBy: { _sum: { total: 'desc' } },
      take: 10,
    });

    return {
      reportType: 'SALES_SUMMARY',
      period: { from, to },
      revenue: Number(invoices._sum.total ?? 0),
      vatCollected: Number(invoices._sum.vatAmount ?? 0),
      invoiceCount: invoices._count.id,
      salesOrders,
      quotations,
      conversionRate: quotations > 0 ? Math.round((salesOrders / quotations) * 100) : 0,
      topCustomers,
    };
  }

  // ── Inventory Valuation ───────────────────────────────────────────────

  private async buildInventoryValuation(branchId: string | null) {
    const stockItems = await this.prisma.stockItem.findMany({
      where: { isDeleted: false, ...(branchId ? { warehouse: { branchId } } : {}) },
      include: {
        product: { select: { sku: true, name: true, category: { select: { name: true } } } },
        warehouse: { select: { name: true, branchId: true } },
      },
    });

    const rows = stockItems.map((item) => ({
      sku: item.product?.sku,
      productName: item.product?.name,
      category: item.product?.category?.name,
      warehouse: item.warehouse?.name,
      qty: Number(item.quantityOnHand),
      landedCost: Number(item.landedCost ?? 0),
      totalValue: Number(item.quantityOnHand) * Number(item.landedCost ?? 0),
    }));

    return {
      reportType: 'INVENTORY_VALUATION',
      totalItems: rows.length,
      totalValue: rows.reduce((s, r) => s + r.totalValue, 0),
      items: rows.sort((a, b) => b.totalValue - a.totalValue),
    };
  }

  // ── Payroll Summary ───────────────────────────────────────────────────

  private async buildPayrollSummary(branchId: string | null, params: any) {
    const bf = branchId ? { branchId } : {};
    const runs = await this.prisma.payrollRun.findMany({
      where: {
        ...bf,
        status: { in: ['APPROVED', 'PROCESSED', 'PAID'] },
        ...(params.year && { periodYear: Number(params.year) }),
      },
      orderBy: [{ periodYear: 'desc' }, { periodMonth: 'desc' }],
      include: { _count: { select: { items: true } } },
    });
    return {
      reportType: 'PAYROLL_SUMMARY',
      runs: runs.map((r) => ({
        code: r.code,
        period: `${r.periodMonth}/${r.periodYear}`,
        status: r.status,
        employees: r._count.items,
        grossTotal: Number(r.totalGross),
        payeTotal: Number(r.totalPaye),
        pensionTotal: Number(r.totalPension),
        netTotal: Number(r.totalNet),
      })),
      ytdGross: runs.reduce((s, r) => s + Number(r.totalGross), 0),
      ytdNet: runs.reduce((s, r) => s + Number(r.totalNet), 0),
      ytdPaye: runs.reduce((s, r) => s + Number(r.totalPaye), 0),
    };
  }

  // ── NADF Delivery ─────────────────────────────────────────────────────

  private async buildNadfDeliveryReport() {
    const contract = await this.prisma.governmentContract.findFirst({
      where: { isDeleted: false, contractType: { contains: 'NADF' } },
      include: { milestones: true, deliverySchedules: true, beneficiaries: true },
    });
    if (!contract) return { reportType: 'NADF_DELIVERY', message: 'No NADF contract found' };
    const totalDelivered = contract.deliverySchedules.reduce(
      (s: any, d: any) => s + Number(d.deliveredQty ?? 0),
      0,
    );
    const totalTarget = Number(contract.totalUnits ?? 0);
    return {
      reportType: 'NADF_DELIVERY',
      contract: {
        code: contract.code,
        name: contract.name,
        value: Number(contract.contractValue),
        status: contract.status,
      },
      deliveryProgress: {
        delivered: totalDelivered,
        target: totalTarget,
        percentage: totalTarget > 0 ? Math.round((totalDelivered / totalTarget) * 100) : 0,
      },
      milestones: contract.milestones.map((m: any) => ({
        name: m.name,
        status: m.status,
        dueDate: m.dueDate,
        completedAt: m.completedAt,
      })),
      schedules: contract.deliverySchedules,
      beneficiaryCount: contract.beneficiaries.length,
    };
  }

  // ── Fleet Utilisation ─────────────────────────────────────────────────

  private async buildFleetUtilisationReport(branchId: string | null) {
    const bf = branchId ? { branchId } : {};
    const assets = await this.prisma.fleetAsset.findMany({
      where: { ...bf, isDeleted: false },
      include: {
        _count: { select: { trips: true, fuelLogs: true, maintenanceLogs: true } },
        maintenanceAlerts: { where: { isActive: true } },
      },
    });
    const fuelAgg = await this.prisma.fuelLog.aggregate({
      where: { fleetAsset: bf },
      _sum: { totalCost: true, litres: true },
    });
    return {
      reportType: 'FLEET_UTILISATION',
      totalAssets: assets.length,
      available: assets.filter((a) => a.status === 'AVAILABLE').length,
      inUse: assets.filter((a) => a.status === 'IN_USE').length,
      maintenance: assets.filter((a) => a.status === 'UNDER_MAINTENANCE').length,
      totalFuelCost: Number(fuelAgg._sum.totalCost ?? 0),
      totalFuelLitres: Number(fuelAgg._sum.litres ?? 0),
      assets: assets.map((a) => ({
        code: a.code,
        name: a.name,
        status: a.status,
        trips: a._count.trips,
        fuelLogs: a._count.fuelLogs,
        activeAlerts: a.maintenanceAlerts.length,
      })),
    };
  }

  // ── Async Export (BullMQ background job) ─────────────────────────────

  async queueExport(
    reportType: ReportType,
    params: any,
    format: 'XLSX' | 'PDF',
    actorId: string,
  ): Promise<{ jobId: string | number | undefined }> {
    const job = await this.reportsQueue.add(
      'export',
      { reportType, params, format, actorId, requestedAt: new Date().toISOString() },
      { attempts: 3, backoff: { type: 'exponential', delay: 5_000 } },
    );
    return { jobId: job.id };
  }

  // ── KPI Analytics ─────────────────────────────────────────────────────

  async getKpiDashboard(branchId: string | null, period: { year: number; month: number }) {
    const from = new Date(period.year, period.month - 1, 1);
    const to = new Date(period.year, period.month, 0);
    const bf = branchId ? { branchId } : {};

    const [revenue, newCustomers, jobCardsCompleted, poValue, payrollCost] = await Promise.all([
      this.prisma.invoice.aggregate({
        where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
        _sum: { total: true },
      }),
      this.prisma.customer.count({
        where: { ...bf, isDeleted: false, createdAt: { gte: from, lte: to } },
      }),
      this.prisma.jobCard.count({
        where: {
          ...bf,
          isDeleted: false,
          status: 'COMPLETED',
          completedAt: { gte: from, lte: to },
        },
      }),
      this.prisma.purchaseOrder.aggregate({
        where: { ...bf, isDeleted: false, status: 'APPROVED', approvedAt: { gte: from, lte: to } },
        _sum: { total: true },
      }),
      this.prisma.payrollRun.aggregate({
        where: { ...bf, periodYear: period.year, periodMonth: period.month },
        _sum: { totalGross: true },
      }),
    ]);

    return {
      period: { year: period.year, month: period.month, from, to },
      kpis: {
        revenue: Number(revenue._sum.total ?? 0),
        newCustomers,
        jobCardsCompleted,
        poValue: Number(poValue._sum.total ?? 0),
        payrollCost: Number(payrollCost._sum.totalGross ?? 0),
      },
    };
  }
}
