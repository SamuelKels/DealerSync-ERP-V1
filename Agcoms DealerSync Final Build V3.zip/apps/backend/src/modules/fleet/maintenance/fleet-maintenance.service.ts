/**
 * AGCOMS DealerSync ERP — FleetMaintenanceService
 * Sprint 6 / S6-A: Predictive maintenance scoring for fleet assets.
 *
 * Scoring algorithm (rule-based, deterministic — AI layer is advisory only):
 *
 *   Input signals (weighted):
 *     1. Engine hours since last service    — weight 30%
 *     2. Fuel efficiency trend              — weight 25%
 *     3. Days since last service            — weight 20%
 *     4. Accumulated engine hours (total)   — weight 15%
 *     5. Reported fault codes               — weight 10%
 *
 *   Risk bands:
 *     0–25:   LOW       — no action needed
 *     26–50:  MEDIUM    — schedule service within 30 days
 *     51–75:  HIGH      — schedule service within 7 days
 *     76–100: CRITICAL  — take asset offline immediately
 *
 * After scoring, Anthropic Claude generates a natural-language advisory
 * for the workshop team. This is advisory only (human_action_required: true).
 *
 * Schedule: BullMQ Cron at 05:00 UTC (06:00 WAT) daily.
 * Scope: all ACTIVE fleet assets across all branches.
 *
 * Context: NADF tractors in rural Nigeria face higher wear from:
 *   - Dusty harmattan conditions (filter clogging)
 *   - Hard laterite soil (hydraulic strain)
 *   - Poor-quality diesel (injector fouling)
 *   These factors are accounted for in the scoring model.
 */
import { InjectQueue } from '@nestjs/bull';
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { Decimal } from '@prisma/client/runtime/library';
import { Queue } from 'bull';

import { PrismaService } from '../../../prisma/prisma.service';
import { AnthropicClientService } from '../../ai/strategies/anthropic-client.service';

export const FLEET_MAINTENANCE_QUEUE = 'fleet-maintenance-scoring';

// Service intervals for John Deere / CAT equipment in Nigerian conditions
const SERVICE_INTERVAL_HOURS = 250; // Every 250 engine hours (Nigeria: shorter than manufacturer 500h)
const SERVICE_INTERVAL_DAYS = 90; // Or 90 days whichever comes first (dusty season)
const CRITICAL_OVERDUE_HOURS = 400; // 400h+ without service = critical
const CRITICAL_OVERDUE_DAYS = 120; // 120+ days without service = critical

export interface MaintenanceScoreResult {
  assetId: string;
  assetCode: string;
  assetName: string;
  riskScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  primaryReason: string;
  recommendations: string[];
  aiAdvisory: string;
  estimatedFailureDate: Date | null;
  engineHours: number;
  daysLastService: number;
}

@Injectable()
export class FleetMaintenanceService {
  private readonly logger = new Logger(FleetMaintenanceService.name);

  constructor(
    @InjectQueue(FLEET_MAINTENANCE_QUEUE)
    private readonly queue: Queue,
    private readonly prisma: PrismaService,
    private readonly anthropic: AnthropicClientService,
  ) {}

  // ── Scheduled daily scoring ──────────────────────────────────────────────
  // 05:00 UTC = 06:00 WAT — before the workshop team starts their day
  @Cron('0 5 * * *', { timeZone: 'UTC' })
  async scheduleDailyScoring() {
    this.logger.log('Daily fleet maintenance scoring started');
    await this.queue.add(
      'score-all-assets',
      {},
      {
        attempts: 3,
        backoff: { type: 'exponential', delay: 30_000 },
        removeOnComplete: 7,
      },
    );
  }

  // ── Score all active assets (called by queue processor) ──────────────────
  async scoreAllAssets(): Promise<{ scored: number; critical: number; high: number }> {
    const assets = await this.prisma.fleetAsset.findMany({
      where: { status: 'ACTIVE', isDeleted: false },
      include: { lastMaintenanceRecord: true },
    });

    let scored = 0;
    let critical = 0;
    let high = 0;

    for (const asset of assets) {
      try {
        const result = await this.scoreAsset(asset.id);
        if (result.riskLevel === 'CRITICAL') critical++;
        if (result.riskLevel === 'HIGH') high++;
        scored++;
      } catch (err) {
        this.logger.error(`Failed to score asset ${asset.assetCode}: ${(err as Error).message}`);
      }
    }

    this.logger.log(`Scoring complete: ${scored} assets | ${critical} CRITICAL | ${high} HIGH`);
    return { scored, critical, high };
  }

  // ── Score a single asset ──────────────────────────────────────────────────
  async scoreAsset(assetId: string): Promise<MaintenanceScoreResult> {
    const asset = await this.prisma.fleetAsset.findUnique({
      where: { id: assetId },
      include: { lastMaintenanceRecord: true },
    });
    if (!asset) throw new Error(`Asset ${assetId} not found`);

    const now = new Date();

    // ── Compute individual signal scores ──────────────────────────────────

    // 1. Engine hours since last service (30% weight)
    const totalEngineHours = Number(asset.engineHours ?? 0);
    const lastServiceHours = Number(asset.lastMaintenanceRecord?.engineHoursAtService ?? 0);
    const hoursSinceService = totalEngineHours - lastServiceHours;
    const hourScore = Math.min(
      100,
      (hoursSinceService / SERVICE_INTERVAL_HOURS) *
        100 *
        (hoursSinceService > CRITICAL_OVERDUE_HOURS ? 1.5 : 1), // Penalty multiplier
    );

    // 2. Fuel efficiency trend (25% weight)
    // Compare last 7 days average vs 30-day average — increasing consumption = degrading engine
    const [recentFuel, historicFuel] = await Promise.all([
      this.prisma.fuelLog.aggregate({
        where: { assetId, loggedAt: { gte: new Date(Date.now() - 7 * 86400_000) } },
        _avg: { fuelConsumedLiters: true, engineHoursConsumed: true },
      }),
      this.prisma.fuelLog.aggregate({
        where: { assetId, loggedAt: { gte: new Date(Date.now() - 30 * 86400_000) } },
        _avg: { fuelConsumedLiters: true, engineHoursConsumed: true },
      }),
    ]);

    let fuelScore = 0;
    const recentEfficiency =
      Number(recentFuel._avg.fuelConsumedLiters ?? 0) /
      Math.max(1, Number(recentFuel._avg.engineHoursConsumed ?? 1));
    const historicEfficiency =
      Number(historicFuel._avg.fuelConsumedLiters ?? 0) /
      Math.max(1, Number(historicFuel._avg.engineHoursConsumed ?? 1));
    if (recentEfficiency > 0 && historicEfficiency > 0) {
      const degradation = (recentEfficiency - historicEfficiency) / historicEfficiency;
      fuelScore = Math.min(100, Math.max(0, degradation * 400)); // 25% degradation → 100 score
    }

    // 3. Days since last service (20% weight)
    const lastServiceDate = asset.lastMaintenanceRecord?.completedAt ?? asset.createdAt;
    const daysSinceService = Math.floor((now.getTime() - lastServiceDate.getTime()) / 86400_000);
    const dayScore = Math.min(
      100,
      (daysSinceService / SERVICE_INTERVAL_DAYS) *
        100 *
        (daysSinceService > CRITICAL_OVERDUE_DAYS ? 1.5 : 1),
    );

    // 4. Accumulated total engine hours (15% weight) — proxy for overall asset age/wear
    const MAX_SAFE_HOURS = 5000;
    const ageScore = Math.min(100, (totalEngineHours / MAX_SAFE_HOURS) * 100);

    // 5. Reported open fault codes (10% weight)
    const openFaults = await this.prisma.fleetFaultCode
      .count({
        where: { assetId, resolvedAt: null, severity: { in: ['HIGH', 'CRITICAL'] } },
      })
      .catch(() => 0);
    const faultScore = Math.min(100, openFaults * 25); // Each critical fault = 25 points

    // ── Composite score (weighted sum) ────────────────────────────────────
    const riskScore = Math.round(
      hourScore * 0.3 + fuelScore * 0.25 + dayScore * 0.2 + ageScore * 0.15 + faultScore * 0.1,
    );

    const riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' =
      riskScore >= 76 ? 'CRITICAL' : riskScore >= 51 ? 'HIGH' : riskScore >= 26 ? 'MEDIUM' : 'LOW';

    // ── Primary reason ────────────────────────────────────────────────────
    const signals = [
      {
        score: hourScore,
        label: `${Math.round(hoursSinceService)}h since last service (interval: ${SERVICE_INTERVAL_HOURS}h)`,
      },
      { score: dayScore, label: `${daysSinceService} days without service` },
      { score: fuelScore, label: 'Fuel efficiency degradation detected' },
      { score: ageScore, label: `High accumulated hours (${Math.round(totalEngineHours)}h)` },
      {
        score: faultScore,
        label: `${openFaults} unresolved critical fault code${openFaults !== 1 ? 's' : ''}`,
      },
    ].sort((a, b) => b.score - a.score);

    const primaryReason = signals[0]?.label ?? 'Multiple risk factors';

    // ── Recommendations (rule-based, deterministic) ───────────────────────
    const recommendations: string[] = [];
    if (hoursSinceService > SERVICE_INTERVAL_HOURS * 0.8)
      recommendations.push(
        `Service overdue: ${Math.round(hoursSinceService - SERVICE_INTERVAL_HOURS)}h past recommended interval`,
      );
    if (daysSinceService > SERVICE_INTERVAL_DAYS * 0.8)
      recommendations.push(
        `Service overdue by time: ${daysSinceService - SERVICE_INTERVAL_DAYS} days`,
      );
    if (fuelScore > 30)
      recommendations.push(
        'Inspect air filter, fuel injectors, and engine seals (fuel consumption elevated)',
      );
    if (openFaults > 0)
      recommendations.push(
        `Resolve ${openFaults} open fault code${openFaults > 1 ? 's' : ''} before next operation`,
      );
    if (riskLevel === 'CRITICAL')
      recommendations.push('⚠️ REMOVE FROM SERVICE immediately — schedule emergency maintenance');
    if (recommendations.length === 0)
      recommendations.push(
        'Continue normal service schedule — next service due at ' +
          new Date(
            lastServiceDate.getTime() + SERVICE_INTERVAL_DAYS * 86400_000,
          ).toLocaleDateString('en-NG'),
      );

    // ── Estimated failure date (extrapolation) ────────────────────────────
    let estimatedFailureDate: Date | null = null;
    if (riskScore > 50 && hoursSinceService > 0) {
      const daysToFailure = Math.max(
        1,
        Math.floor(
          (SERVICE_INTERVAL_HOURS - hoursSinceService) /
            (hoursSinceService / Math.max(1, daysSinceService)),
        ),
      );
      if (daysToFailure < 60) {
        estimatedFailureDate = new Date(Date.now() + daysToFailure * 86400_000);
      }
    }

    // ── AI advisory (Anthropic — advisory only) ───────────────────────────
    let aiAdvisory = '';
    try {
      const advisory = await this.anthropic.call<string>({
        action: 'recommend',
        systemPrompt:
          'You are a fleet maintenance advisor for agricultural equipment in Nigeria. Write concise, actionable maintenance recommendations in plain English for the workshop team. Maximum 3 sentences.',
        userPrompt: `Asset: ${asset.name} (${asset.make} ${asset.model})
Risk score: ${riskScore}/100 (${riskLevel})
Engine hours: ${Math.round(totalEngineHours)}h total | ${Math.round(hoursSinceService)}h since last service
Days since last service: ${daysSinceService}
Fuel efficiency trend: ${fuelScore > 30 ? 'degrading' : 'normal'}
Open fault codes: ${openFaults}
Operating context: Nigeria — consider harmattan dust, hard laterite soil, fuel quality.
Write a 2-3 sentence workshop advisory.`,
        temperature: 0.2,
        maxTokens: 200,
        jsonMode: false,
      });
      aiAdvisory = typeof advisory.result === 'string' ? advisory.result : '';
    } catch (err) {
      this.logger.debug(`AI advisory skipped for ${asset.assetCode}: ${(err as Error).message}`);
    }

    // ── Persist the score ─────────────────────────────────────────────────
    await this.prisma.fleetMaintenanceScore.create({
      data: {
        assetId,
        riskLevel: riskLevel as any,
        riskScore,
        engineHours: new Decimal(totalEngineHours),
        daysLastService: daysSinceService,
        estimatedFailureDate,
        primaryReason,
        recommendations: recommendations as any,
        aiAdvisory: aiAdvisory || null,
      },
    });

    return {
      assetId,
      assetCode: asset.assetCode,
      assetName: asset.name,
      riskScore,
      riskLevel,
      primaryReason,
      recommendations,
      aiAdvisory,
      estimatedFailureDate,
      engineHours: totalEngineHours,
      daysLastService: daysSinceService,
    };
  }

  // ── Query latest scores ───────────────────────────────────────────────────
  async getFleetRiskSummary(branchId: string) {
    // Latest score per asset
    const latestScores = await this.prisma.$queryRaw<Array<Record<string, any>>>`
      SELECT DISTINCT ON (fa.id)
        fa.id           AS "assetId",
        fa.asset_code   AS "assetCode",
        fa.name         AS "assetName",
        fa.make, fa.model, fa.status,
        fms.risk_score  AS "riskScore",
        fms.risk_level  AS "riskLevel",
        fms.primary_reason AS "primaryReason",
        fms.recommendations,
        fms.ai_advisory AS "aiAdvisory",
        fms.estimated_failure_date AS "estimatedFailureDate",
        fms.scored_at   AS "scoredAt"
      FROM fleet_assets fa
      LEFT JOIN fleet_maintenance_scores fms ON fms.asset_id = fa.id
      WHERE fa.branch_id = ${branchId}::uuid
        AND fa.is_deleted = false
      ORDER BY fa.id, fms.scored_at DESC NULLS LAST
    `;

    const summary = {
      total: latestScores.length,
      critical: latestScores.filter((s: any) => s.riskLevel === 'CRITICAL').length,
      high: latestScores.filter((s: any) => s.riskLevel === 'HIGH').length,
      medium: latestScores.filter((s: any) => s.riskLevel === 'MEDIUM').length,
      low: latestScores.filter((s: any) => s.riskLevel === 'LOW').length,
      unscored: latestScores.filter((s: any) => !s.riskLevel).length,
      assets: latestScores,
    };

    return summary;
  }

  async triggerManualScoring(branchId: string): Promise<{ queued: boolean }> {
    await this.queue.add(
      'score-branch-assets',
      { branchId },
      {
        attempts: 2,
        removeOnComplete: 5,
      },
    );
    return { queued: true };
  }
}
