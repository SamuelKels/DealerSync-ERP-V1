/**
 * AGCOMS DealerSync ERP — PredictiveMaintenanceService
 * Sprint 6 / S6-A: Fleet predictive maintenance scoring.
 *
 * Scoring model (rule-based + AI narrative):
 *
 *   Component scores (0–100 each, weighted average):
 *   1. Engine hours since last service    (weight: 35%)
 *      — John Deere 5075E: service every 250h
 *      — John Deere 6120M: service every 250h
 *      — Caterpillar D6T:  service every 500h
 *      — Default:          service every 250h
 *
 *   2. Fuel efficiency deviation          (weight: 25%)
 *      — >20% above baseline: CRITICAL signal
 *      — 10–20% above:        HIGH signal
 *      — Within ±10%:         baseline
 *
 *   3. Days since last service             (weight: 20%)
 *      — AGCOMS policy: no asset exceeds 90 days without service
 *
 *   4. Open service requests               (weight: 20%)
 *      — Unresolved service requests compound risk rapidly
 *
 *   NADF field context:
 *   — Tractors in active NADF deployment get a 1.25× risk multiplier
 *     (harsh field conditions: soil, dust, extended daily hours)
 *   — October–March dry season: dust-related filter clogging risk elevated
 *
 *   Risk bands:
 *   — 0–39:  LOW (green)
 *   — 40–59: MODERATE (amber)
 *   — 60–79: HIGH (red)
 *   — 80–100: CRITICAL (dark red)
 *
 *   AI layer: AnthropicClientService generates a 2-sentence plain-English
 *   recommendation for each HIGH/CRITICAL asset.
 *   All AI outputs wrapped in human_action_required: true advisory.
 */
import { JwtPayload } from '@agcoms/types';
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';

import { AuditService } from '../../../audit/audit.service';
import { PrismaService } from '../../../prisma/prisma.service';
import { AnthropicClientService } from '../../ai/strategies/anthropic-client.service';

// ── Service interval thresholds by equipment type (hours) ────────────────
const SERVICE_INTERVALS: Record<string, number> = {
  'John Deere 5075E': 250,
  'John Deere 6120M': 250,
  'John Deere 7R310': 250,
  'Massey Ferguson 7718': 250,
  'New Holland T7060': 250,
  'Caterpillar D6T': 500,
  'Caterpillar 320': 500,
  'Caterpillar 966M': 500,
  DEFAULT: 250,
};

// AGCOMS fleet policy: no asset goes beyond 90 days without service
const MAX_SERVICE_DAYS = 90;

// NADF field deployment risk multiplier (harsh field conditions)
const NADF_RISK_MULTIPLIER = 1.25;

export interface MaintenanceRiskResult {
  assetId: string;
  assetCode: string;
  assetName: string;
  make: string;
  model: string;
  riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  riskScore: number;
  estimatedDaysToFailure?: number;
  engineHoursNow: number;
  hoursSinceService?: number;
  anomalyFlags: string[];
  aiRecommendation?: string;
  recommendedServiceDate?: Date;
  components: {
    engineHoursScore: number;
    fuelEfficiencyScore: number;
    daysSinceService: number;
    openServicesScore: number;
  };
}

@Injectable()
export class PredictiveMaintenanceService {
  private readonly logger = new Logger(PredictiveMaintenanceService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly anthropic: AnthropicClientService,
  ) {}

  // ── Score all fleet assets for a branch ──────────────────────────────────

  async scoreAllAssets(
    branchId: string,
    actor: JwtPayload,
  ): Promise<{
    scored: number;
    critical: number;
    high: number;
    results: MaintenanceRiskResult[];
  }> {
    const assets = await this.prisma.fleetAsset.findMany({
      where: { branchId, status: { notIn: ['DECOMMISSIONED', 'SOLD'] } },
      include: {
        // Last 5 service records
        serviceHistory: {
          orderBy: { completedAt: 'desc' },
          take: 5,
          select: { completedAt: true, engineHoursAtService: true, serviceType: true },
        },
        // Fuel logs from last 30 days
        fuelLogs: {
          where: { loggedAt: { gte: new Date(Date.now() - 30 * 86400_000) } },
          orderBy: { loggedAt: 'asc' },
          select: { litresAdded: true, engineHoursAtFuel: true, loggedAt: true },
        },
        // Open service requests
        serviceRequests: {
          where: { status: { in: ['OPEN', 'IN_PROGRESS'] } },
          select: { id: true, priority: true },
        },
        // NADF deployment check
        nadfDeployments: {
          where: { status: 'ACTIVE' },
          select: { id: true },
        },
      },
    });

    const results: MaintenanceRiskResult[] = [];
    const now = new Date();

    for (const asset of assets) {
      const score = this.computeRiskScore(asset, now);
      results.push(score);

      // Persist score to DB
      await this.prisma.predictiveMaintenanceScore.create({
        data: {
          assetId: asset.id,
          branchId,
          riskLevel: score.riskLevel as any,
          riskScore: score.riskScore,
          estimatedDaysToFailure: score.estimatedDaysToFailure,
          engineHoursNow: score.engineHoursNow,
          hoursSinceService: score.hoursSinceService,
          anomalyFlags: score.anomalyFlags,
          isActive: true,
        },
      });
    }

    // Deactivate previous scores
    await this.prisma.predictiveMaintenanceScore.updateMany({
      where: { branchId, isActive: true, scoredAt: { lt: new Date(Date.now() - 60_000) } },
      data: { isActive: false },
    });

    // AI recommendations for HIGH/CRITICAL assets
    const highRisk = results.filter((r) => ['HIGH', 'CRITICAL'].includes(r.riskLevel));
    if (highRisk.length > 0) {
      await this.enrichWithAiRecommendations(highRisk);
    }

    const critical = results.filter((r) => r.riskLevel === 'CRITICAL').length;
    const high = results.filter((r) => r.riskLevel === 'HIGH').length;

    this.logger.log(
      `Fleet scoring complete: ${results.length} assets — ${critical} CRITICAL, ${high} HIGH`,
    );

    if (critical > 0 || high > 0) {
      await this.audit.log({
        action: 'fleet.maintenance.scored',
        resource: 'FleetAsset',
        entityId: branchId,
        actorId: actor.sub,
        actorRole: actor.roles[0] ?? 'UNKNOWN',
        afterState: { total: results.length, critical, high },
      });
    }

    return {
      scored: results.length,
      critical,
      high,
      results: results.sort((a, b) => b.riskScore - a.riskScore),
    };
  }

  // ── Get latest scores (read from DB) ─────────────────────────────────────

  async getLatestScores(branchId: string) {
    return this.prisma.predictiveMaintenanceScore.findMany({
      where: { branchId, isActive: true },
      include: {
        asset: {
          select: {
            assetCode: true,
            name: true,
            make: true,
            model: true,
            status: true,
            lastPing: true,
          },
        },
      },
      orderBy: { riskScore: 'desc' },
    });
  }

  // ── Scheduled: run scoring nightly at 02:00 WAT ───────────────────────────
  // Fleet scoring is expensive — run when activity is lowest.
  @Cron('0 1 * * *', { timeZone: 'UTC' }) // 01:00 UTC = 02:00 WAT
  async scheduledScoring() {
    this.logger.log('Scheduled fleet maintenance scoring started');
    const branches = await this.prisma.branch.findMany({
      where: { isActive: true },
      select: { id: true },
    });
    for (const branch of branches) {
      await this.scoreAllAssets(branch.id, {
        sub: 'SYSTEM',
        roles: ['SYSTEM'],
        isSuperAdmin: false,
      } as any).catch((err) =>
        this.logger.error(`Fleet scoring failed for branch ${branch.id}: ${err.message}`),
      );
    }
  }

  // ── Private: compute risk score for a single asset ────────────────────────

  private computeRiskScore(asset: any, now: Date): MaintenanceRiskResult {
    const anomalyFlags: string[] = [];
    const engineHoursNow = asset.engineHours ?? 0;
    const isNadf = (asset.nadfDeployments?.length ?? 0) > 0;

    // ── Component 1: Engine hours since last service ─────────────────────
    const lastService = asset.serviceHistory?.[0];
    const hoursAtService = lastService?.engineHoursAtService ?? 0;
    const hoursSince = engineHoursNow - hoursAtService;
    const serviceInterval =
      SERVICE_INTERVALS[`${asset.make} ${asset.model}`] ?? SERVICE_INTERVALS['DEFAULT']!;
    const hoursRatio = Math.min(hoursSince / serviceInterval, 1.5); // cap at 150%
    const engineHoursScore = Math.round(hoursRatio * 100);

    if (hoursSince > serviceInterval) anomalyFlags.push('SERVICE_OVERDUE');
    if (hoursSince > serviceInterval * 1.2) anomalyFlags.push('SIGNIFICANTLY_OVERDUE');

    // ── Component 2: Fuel efficiency deviation ───────────────────────────
    let fuelScore = 0;
    let fuelEfficiencyTrend: number | null = null;

    if (asset.fuelLogs && asset.fuelLogs.length >= 3) {
      const totalLitres = asset.fuelLogs.reduce(
        (s: number, l: any) => s + Number(l.litresAdded),
        0,
      );
      const totalHours =
        asset.fuelLogs[asset.fuelLogs.length - 1]?.engineHoursAtFuel -
        asset.fuelLogs[0]?.engineHoursAtFuel;
      if (totalHours > 0) {
        const litresPerHour = totalLitres / totalHours;
        // Baseline: ~8 L/h for tractors, ~20 L/h for heavy construction
        const baseline = asset.make === 'Caterpillar' ? 20 : 8;
        fuelEfficiencyTrend = ((litresPerHour - baseline) / baseline) * 100;

        if (fuelEfficiencyTrend > 20) {
          fuelScore = 80;
          anomalyFlags.push('HIGH_FUEL_CONSUMPTION');
        } else if (fuelEfficiencyTrend > 10) {
          fuelScore = 50;
          anomalyFlags.push('ELEVATED_FUEL_CONSUMPTION');
        } else if (fuelEfficiencyTrend < -15) {
          fuelScore = 30; /* Engine running cool/under-loaded */
        } else {
          fuelScore = 10;
        }
      }
    }

    // ── Component 3: Days since last service ──────────────────────────────
    const daysSinceService = lastService?.completedAt
      ? Math.floor((now.getTime() - new Date(lastService.completedAt).getTime()) / 86400_000)
      : 999;
    const daysRatio = Math.min(daysSinceService / MAX_SERVICE_DAYS, 1.5);
    const daysScore = Math.round(daysRatio * 100);

    if (daysSinceService > MAX_SERVICE_DAYS) anomalyFlags.push('DAYS_SINCE_SERVICE_EXCEEDED');

    // ── Component 4: Open service requests ───────────────────────────────
    const openServices = asset.serviceRequests?.length ?? 0;
    const criticalOpenSvcs =
      asset.serviceRequests?.filter((s: any) => s.priority === 'CRITICAL').length ?? 0;
    const openSvcScore = Math.min(openServices * 20 + criticalOpenSvcs * 40, 100);

    if (criticalOpenSvcs > 0) anomalyFlags.push('CRITICAL_SERVICE_REQUEST_OPEN');

    // ── Weighted composite score ──────────────────────────────────────────
    let rawScore =
      engineHoursScore * 0.35 + fuelScore * 0.25 + daysScore * 0.2 + openSvcScore * 0.2;

    // NADF multiplier — harsh field conditions
    if (isNadf) {
      rawScore *= NADF_RISK_MULTIPLIER;
      anomalyFlags.push('NADF_DEPLOYMENT_ACTIVE');
    }

    // Dry season adjustment (October–March in Nigeria)
    const month = now.getMonth() + 1;
    if (month >= 10 || month <= 3) {
      rawScore *= 1.1;
      if (rawScore > 50) anomalyFlags.push('DRY_SEASON_FILTER_RISK');
    }

    const riskScore = Math.min(Math.round(rawScore), 100);

    let riskLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
    if (riskScore >= 80) riskLevel = 'CRITICAL';
    else if (riskScore >= 60) riskLevel = 'HIGH';
    else if (riskScore >= 40) riskLevel = 'MODERATE';
    else riskLevel = 'LOW';

    // Estimate days to failure (inverse of remaining service capacity)
    const remainingHoursCapacity = Math.max(0, serviceInterval - hoursSince);
    const avgDailyHours = 8; // typical field usage assumption
    const estimatedDaysToFailure = Math.round(remainingHoursCapacity / avgDailyHours);

    // Recommended service date
    const recommendedServiceDate =
      riskScore >= 60
        ? new Date(Date.now() + Math.min(estimatedDaysToFailure, 14) * 86400_000)
        : new Date(Date.now() + Math.min(estimatedDaysToFailure, 60) * 86400_000);

    return {
      assetId: asset.id,
      assetCode: asset.assetCode,
      assetName: asset.name,
      make: asset.make ?? '',
      model: asset.model ?? '',
      riskLevel,
      riskScore,
      estimatedDaysToFailure,
      engineHoursNow,
      hoursSinceService: hoursSince,
      anomalyFlags: [...new Set(anomalyFlags)],
      recommendedServiceDate,
      components: {
        engineHoursScore,
        fuelEfficiencyScore: fuelScore,
        daysSinceService,
        openServicesScore: openSvcScore,
      },
    };
  }

  // ── AI narrative recommendations for high-risk assets ────────────────────

  private async enrichWithAiRecommendations(assets: MaintenanceRiskResult[]): Promise<void> {
    const summary = assets.map((a) => ({
      asset: `${a.make} ${a.model} (${a.assetCode})`,
      risk: a.riskLevel,
      score: a.riskScore,
      flags: a.anomalyFlags,
      hoursSince: a.hoursSinceService,
      daysToFailure: a.estimatedDaysToFailure,
    }));

    try {
      const advisory = await this.anthropic.call<string>({
        action: 'recommend',
        systemPrompt:
          'You are a fleet maintenance advisor for agricultural and construction equipment in Nigeria. Be concise and practical.',
        userPrompt: `Write a brief (2 sentences per asset) maintenance recommendation for each of these high-risk fleet assets.
Consider: Nigeria dry season dust, NADF tractor field deployment conditions, spare parts availability in Abuja.

ASSETS:
${JSON.stringify(summary, null, 2)}

Format: one line per asset: "[AssetCode]: [recommendation]"`,
        temperature: 0.2,
        maxTokens: 512,
        jsonMode: false,
      });

      // Parse recommendations back to each asset
      const lines = (advisory.result as string).split('\n').filter(Boolean);
      for (const line of lines) {
        const colonIdx = line.indexOf(':');
        if (colonIdx < 0) continue;
        const code = line
          .slice(0, colonIdx)
          .trim()
          .replace(/^\[|\]$/g, '');
        const rec = line
          .slice(colonIdx + 1)
          .trim()
          .replace(/^\[|\]$/g, '');
        const asset = assets.find((a) => a.assetCode === code || a.assetName.includes(code));
        if (asset) asset.aiRecommendation = rec;
      }
    } catch (err) {
      this.logger.warn(`AI recommendations failed (non-blocking): ${(err as Error).message}`);
    }
  }
}
