import { Process, Processor } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bull';

import { FleetMaintenanceService, FLEET_MAINTENANCE_QUEUE } from './fleet-maintenance.service';

@Processor(FLEET_MAINTENANCE_QUEUE)
export class FleetMaintenanceProcessor {
  private readonly logger = new Logger(FleetMaintenanceProcessor.name);

  constructor(private readonly svc: FleetMaintenanceService) {}

  @Process('score-all-assets')
  async scoreAll(_job: Job) {
    this.logger.log('Processing: score-all-assets');
    return this.svc.scoreAllAssets();
  }

  @Process('score-branch-assets')
  async scoreBranch(job: Job<{ branchId: string }>) {
    this.logger.log(`Processing: score-branch-assets for ${job.data.branchId}`);
    return this.svc.scoreAllAssets();
  }
}
