/**
 * AGCOMS DealerSync ERP — WhatsApp Message Templates
 * Sprint 3 / S3-A: Template definitions for Meta Business API
 *
 * IMPORTANT: These templates must be submitted to and APPROVED by Meta
 * before use. Template names must match exactly what is approved.
 * Approval typically takes 24-48 hours via the Meta Business Suite.
 *
 * Template language: en (English) — can be extended to ha (Hausa) / yo (Yoruba)
 *
 * Variable convention: {{1}}, {{2}} etc. as required by Meta template format.
 * Each template includes: name, language, category, and variable slots.
 *
 * Meta template categories:
 *   MARKETING    — promotional content
 *   UTILITY      — transactional, account updates (faster approval)
 *   AUTHENTICATION — OTP and verification
 */

export type WhatsappTemplateKey =
  | 'INVOICE_DELIVERY'
  | 'QUOTATION_SHARE'
  | 'SERVICE_UPDATE'
  | 'PAYMENT_REMINDER'
  | 'NADF_DELIVERY_CONFIRM';

export interface TemplateDefinition {
  name: string; // Must match approved name in Meta Business Suite
  language: string; // 'en', 'ha', 'yo'
  category: 'UTILITY' | 'MARKETING' | 'AUTHENTICATION';
  description: string;
  bodyTemplate: string; // Human-readable preview with {{variables}}
  variables: string[]; // Variable names in order
}

export const WHATSAPP_TEMPLATES: Record<WhatsappTemplateKey, TemplateDefinition> = {
  INVOICE_DELIVERY: {
    name: 'agcoms_invoice_delivery',
    language: 'en',
    category: 'UTILITY',
    description: 'Sent when an invoice is issued to a customer',
    bodyTemplate:
      'Dear {{1}}, your invoice *{{2}}* from AGCOMS International for ₦{{3}} has been issued and is due on {{4}}. ' +
      'Please log in to your customer portal to view and download: {{5}}\n\n' +
      'For enquiries, contact us on +234 901 234 5678.',
    variables: [
      'customerName', // {{1}} e.g. "Alhaji Musa"
      'invoiceNumber', // {{2}} e.g. "INV-ABJ-2025-0042"
      'totalAmount', // {{3}} e.g. "14,500,000.00"
      'dueDate', // {{4}} e.g. "15 Feb 2025"
      'portalLink', // {{5}} e.g. "https://portal.agcoms.ng/invoices/uuid"
    ],
  },

  QUOTATION_SHARE: {
    name: 'agcoms_quotation_share',
    language: 'en',
    category: 'UTILITY',
    description: 'Sent when a quotation is issued to a customer',
    bodyTemplate:
      'Dear {{1}}, your quotation *{{2}}* from AGCOMS International is ready. ' +
      'Equipment: {{3}} | Total: ₦{{4}} | Valid until: {{5}}.\n\n' +
      'View and accept your quotation: {{6}}\n\n' +
      'Reply to this message or call +234 901 234 5678 to proceed.',
    variables: [
      'customerName', // {{1}}
      'quotationNumber', // {{2}} e.g. "QUO-ABJ-2025-0018"
      'equipmentSummary', // {{3}} e.g. "2× John Deere 6120M Tractors"
      'totalAmount', // {{4}}
      'validUntil', // {{5}}
      'portalLink', // {{6}}
    ],
  },

  SERVICE_UPDATE: {
    name: 'agcoms_service_update',
    language: 'en',
    category: 'UTILITY',
    description: 'Sent when a workshop job card status changes',
    bodyTemplate:
      'AGCOMS Workshop Update 🔧\n\n' +
      'Job Card: *{{1}}*\n' +
      'Equipment: {{2}}\n' +
      'Status: {{3}}\n' +
      '{{4}}\n\n' +
      'Technician: {{5}} | Est. completion: {{6}}\n\n' +
      'Track your service: {{7}}',
    variables: [
      'jobCardNumber', // {{1}} e.g. "JOB-ABJ-2025-0007"
      'equipmentName', // {{2}} e.g. "John Deere 6120M (SN: X123456)"
      'status', // {{3}} e.g. "IN PROGRESS"
      'statusNote', // {{4}} e.g. "Parts ordered, awaiting delivery."
      'technicianName', // {{5}} e.g. "Ibrahim Musa"
      'estimatedCompletion', // {{6}} e.g. "Wednesday 15 Jan"
      'portalLink', // {{7}}
    ],
  },

  PAYMENT_REMINDER: {
    name: 'agcoms_payment_reminder',
    language: 'en',
    category: 'UTILITY',
    description: 'Sent for overdue invoices (automated, not marketing)',
    bodyTemplate:
      'Dear {{1}}, this is a reminder that invoice *{{2}}* for ₦{{3}} was due on {{4}} ' +
      'and remains outstanding.\n\n' +
      'Outstanding balance: ₦{{5}}\n\n' +
      'Please make payment or contact our accounts team on +234 901 234 5678 ' +
      'to discuss payment arrangements.\n\n' +
      'Pay via your portal: {{6}}',
    variables: [
      'customerName', // {{1}}
      'invoiceNumber', // {{2}}
      'originalAmount', // {{3}}
      'dueDate', // {{4}}
      'outstandingBalance', // {{5}}
      'portalLink', // {{6}}
    ],
  },

  NADF_DELIVERY_CONFIRM: {
    name: 'agcoms_nadf_delivery',
    language: 'en',
    category: 'UTILITY',
    description: 'Sent to NADF beneficiaries confirming tractor delivery',
    bodyTemplate:
      '✅ Tractor Delivery Confirmed\n\n' +
      'Dear {{1}},\n\n' +
      'We confirm delivery of your tractor under the NADF programme:\n\n' +
      '• Beneficiary No: {{2}}\n' +
      '• Equipment: {{3}}\n' +
      '• Serial No: {{4}}\n' +
      '• Delivery location: {{5}}, {{6}} LGA\n' +
      '• Date: {{7}}\n\n' +
      'Your beneficiary ID is your reference for all future NADF correspondence. ' +
      'For support, contact AGCOMS on +234 901 234 5678.',
    variables: [
      'beneficiaryName', // {{1}}
      'beneficiaryNo', // {{2}} e.g. "GOVABJ20250001-0042"
      'equipmentName', // {{3}} e.g. "John Deere 5075E Tractor"
      'serialNumber', // {{4}}
      'state', // {{5}} e.g. "Kaduna"
      'lga', // {{6}} e.g. "Zaria"
      'deliveryDate', // {{7}} e.g. "15 January 2025"
    ],
  },
};
