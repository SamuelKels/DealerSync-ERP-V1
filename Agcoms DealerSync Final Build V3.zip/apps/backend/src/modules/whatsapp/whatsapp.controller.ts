/**
 * AGCOMS DealerSync ERP — WhatsApp Controller
 * Sprint 3 / S3-A: REST endpoints for WhatsApp management
 *
 * GET  /api/v1/whatsapp/status                — delivery stats (paginated)
 * POST /api/v1/whatsapp/send                  — send ad-hoc message
 * GET  /api/v1/whatsapp/customers/:id/opt-in  — get customer opt-in status
 * PUT  /api/v1/whatsapp/customers/:id/opt-in  — update customer opt-in preferences
 * GET  /api/v1/whatsapp/webhook               — Meta webhook verification (GET)
 * POST /api/v1/whatsapp/webhook               — Meta webhook delivery receipts (POST)
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Get,
  Post,
  Put,
  Param,
  Body,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  ApiTags,
  ApiBearerAuth,
  ApiOperation,
  ApiQuery,
  ApiParam,
  ApiExcludeEndpoint,
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';
import { IsString, IsOptional, IsBoolean, IsUUID, IsArray } from 'class-validator';

import { CurrentUser } from '../../common/decorators/current-user.decorator';
import {
  JwtAuthGuard,
  PermissionsGuard,
  RequirePermission,
  Public,
} from '../../common/guards/auth.guards';

import { WhatsappService } from './whatsapp.service';

class SendWhatsappRequestDto {
  @ApiProperty({ example: '+2348012345678' })
  @IsString()
  recipientPhone: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  recipientName?: string;

  @ApiProperty({
    enum: [
      'INVOICE_DELIVERY',
      'QUOTATION_SHARE',
      'SERVICE_UPDATE',
      'PAYMENT_REMINDER',
      'NADF_DELIVERY_CONFIRM',
    ],
  })
  @IsString()
  templateKey: string;

  @ApiProperty({ type: [String], description: 'Template variables in order' })
  @IsArray()
  variables: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  referenceType?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsUUID()
  referenceId?: string;
}

class UpdateOptInDto {
  @ApiProperty({ example: '+2348012345678' })
  @IsString()
  whatsappPhone: string;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  optedIn?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  invoiceAlerts?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  quotationAlerts?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  serviceAlerts?: boolean;

  @ApiPropertyOptional({ default: true })
  @IsOptional()
  @IsBoolean()
  paymentReminders?: boolean;
}

@ApiTags('whatsapp')
@Controller('whatsapp')
export class WhatsappController {
  constructor(
    private readonly svc: WhatsappService,
    private readonly config: ConfigService,
  ) {}

  // ── Webhook (public — no JWT, verified by Meta token) ───────────────────

  /**
   * Meta webhook verification: GET request with hub.verify_token
   * Must be @Public and return the hub.challenge string exactly.
   */
  @Get('webhook')
  @Public()
  @ApiExcludeEndpoint() // Don't expose in Swagger (internal Meta endpoint)
  verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
  ): string {
    const expectedToken = this.config.getOrThrow<string>('WHATSAPP_WEBHOOK_VERIFY_TOKEN');
    if (mode === 'subscribe' && token === expectedToken) {
      return challenge; // Echo challenge back to Meta
    }
    throw new Error('Invalid webhook verification token');
  }

  /**
   * Meta webhook delivery receipts and incoming messages.
   * Meta sends this on every delivery status change (sent/delivered/read/failed).
   */
  @Post('webhook')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiExcludeEndpoint()
  async handleWebhook(@Body() body: any): Promise<{ status: string }> {
    await this.svc.processWebhook(body);
    return { status: 'ok' };
  }

  // ── Authenticated endpoints ─────────────────────────────────────────────

  @Get('status')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('whatsapp:read')
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Get WhatsApp delivery statistics for this branch' })
  @ApiQuery({ name: 'days', required: false, type: Number })
  getStats(@CurrentUser() actor: JwtPayload, @Query('days') days?: string) {
    return this.svc.getDeliveryStats(actor.branchId, parseInt(days ?? '30', 10));
  }

  @Post('send')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('whatsapp:send')
  @ApiBearerAuth('JWT')
  @HttpCode(HttpStatus.ACCEPTED)
  @ApiOperation({ summary: 'Queue a WhatsApp message for delivery' })
  send(@Body() dto: SendWhatsappRequestDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.sendMessage({
      ...dto,
      templateKey: dto.templateKey as any,
      branchId: actor.branchId,
      sentById: actor.sub,
    });
  }

  @Get('customers/:customerId/opt-in')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('crm:read')
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Get WhatsApp opt-in preferences for a customer' })
  @ApiParam({ name: 'customerId' })
  getOptIn(@Param('customerId') customerId: string) {
    return this.svc.getOptInStatus(customerId);
  }

  @Put('customers/:customerId/opt-in')
  @UseGuards(JwtAuthGuard, PermissionsGuard)
  @RequirePermission('crm:write')
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Update customer WhatsApp notification preferences' })
  @ApiParam({ name: 'customerId' })
  updateOptIn(@Param('customerId') customerId: string, @Body() dto: UpdateOptInDto) {
    const { whatsappPhone, ...preferences } = dto;
    return this.svc.setOptIn(customerId, whatsappPhone, preferences);
  }
}
