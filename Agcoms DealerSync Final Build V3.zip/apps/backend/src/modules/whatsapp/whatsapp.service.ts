/**
 * AGCOMS DealerSync ERP — WhatsAppService
 * Sprint 3 / S3-A: Meta WhatsApp Business Cloud API integration
 *
 * Architecture:
 *   1. Caller invokes sendMessage() — adds job to BullMQ queue (non-blocking)
 *   2. WhatsAppQueueProcessor picks up the job, calls Meta API
 *   3. Meta delivers to recipient's WhatsApp
 *   4. Meta sends delivery/read receipts to our webhook endpoint
 *   5. Webhook updates WhatsappLog status in the database
 *
 * Meta API: https://graph.facebook.com/v18.0/{phone_number_id}/messages
 * Auth: Bearer token (System User token from Meta Business Suite)
 * Rate limit: 1000 messages/second at Scale tier (Tier 3)
 *
 * Nigerian market notes:
 *   - 90%+ WhatsApp penetration in Nigeria
 *   - Works on 2G networks (important for rural NADF farm areas)
 *   - Supports Hausa / Yoruba template variants (future)
 *   - Must comply with Meta template pre-approval process
 */
import { HttpService } from '@nestjs/axios';
import { InjectQueue } from '@nestjs/bull';
import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue } from 'bull';
import { firstValueFrom } from 'rxjs';

import { AuditService } from '../../audit/audit.service';
import { PrismaService } from '../../prisma/prisma.service';

import { WHATSAPP_TEMPLATES, type WhatsappTemplateKey } from './templates/whatsapp.templates';

export const WHATSAPP_QUEUE = 'whatsapp-messages';

export interface SendWhatsappDto {
  recipientPhone: string; // E.164 format: +2348012345678
  recipientName?: string;
  templateKey: WhatsappTemplateKey;
  variables: string[]; // Ordered array matching template {{1}}, {{2}}…
  referenceType?: string; // 'Invoice', 'Quotation', 'JobCard', 'Beneficiary'
  referenceId?: string; // UUID of the reference entity
  branchId: string;
  sentById?: string;
}

export interface WhatsappJobPayload extends SendWhatsappDto {
  logId: string; // WhatsappLog.id — created before queuing
}

@Injectable()
export class WhatsappService {
  private readonly logger = new Logger(WhatsappService.name);
  private readonly phoneNumberId: string;
  private readonly accessToken: string;
  private readonly apiVersion = 'v18.0';
  private readonly baseUrl = 'https://graph.facebook.com';

  constructor(
    @InjectQueue(WHATSAPP_QUEUE)
    private readonly queue: Queue<WhatsappJobPayload>,
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {
    this.phoneNumberId = this.config.getOrThrow<string>('WHATSAPP_PHONE_NUMBER_ID');
    this.accessToken = this.config.getOrThrow<string>('WHATSAPP_ACCESS_TOKEN');
  }

  // ── Public send API ───────────────────────────────────────────────────

  /**
   * Queue a WhatsApp message for delivery.
   * Returns immediately — actual delivery happens asynchronously.
   * Checks opt-in preferences before queuing.
   */
  async sendMessage(dto: SendWhatsappDto): Promise<{ logId: string; queued: boolean }> {
    // Normalise phone number to E.164
    const phone = this.normalisePhone(dto.recipientPhone);

    // Check opt-in (skip for NADF delivery confirmations — regulatory requirement)
    if (dto.templateKey !== 'NADF_DELIVERY_CONFIRM') {
      const optedIn = await this.isOptedIn(phone, dto.templateKey);
      if (!optedIn) {
        this.logger.debug(`WhatsApp skipped: ${phone} not opted-in for ${dto.templateKey}`);
        return { logId: '', queued: false };
      }
    }

    // Validate variable count matches template
    const template = WHATSAPP_TEMPLATES[dto.templateKey];
    if (!template) throw new BadRequestException(`Unknown template: ${dto.templateKey}`);
    if (dto.variables.length !== template.variables.length) {
      throw new BadRequestException(
        `Template ${dto.templateKey} requires ${template.variables.length} variables, got ${dto.variables.length}`,
      );
    }

    // Create audit log entry (QUEUED status)
    const log = await this.prisma.whatsappLog.create({
      data: {
        recipientPhone: phone,
        recipientName: dto.recipientName,
        templateType: dto.templateKey as any,
        templateName: template.name,
        status: 'QUEUED',
        payload: { variables: dto.variables, template: template.name } as any,
        referenceType: dto.referenceType,
        referenceId: dto.referenceId,
        branchId: dto.branchId,
        sentById: dto.sentById,
      },
    });

    // Add to BullMQ queue (retries on failure, exponential backoff)
    await this.queue.add(
      { ...dto, recipientPhone: phone, logId: log.id },
      {
        attempts: 3,
        backoff: { type: 'exponential', delay: 5_000 },
        removeOnComplete: 100, // Keep last 100 completed jobs
        removeOnFail: 50,
      },
    );

    this.logger.log(`WhatsApp queued: ${dto.templateKey} → ${phone} (logId: ${log.id})`);
    return { logId: log.id, queued: true };
  }

  /**
   * Send directly to Meta API (called by the queue processor).
   * This is the actual HTTP call — kept separate for testability.
   */
  async dispatchToMeta(payload: WhatsappJobPayload): Promise<{ messageId: string }> {
    const template = WHATSAPP_TEMPLATES[payload.templateKey];

    const body = {
      messaging_product: 'whatsapp',
      to: payload.recipientPhone,
      type: 'template',
      template: {
        name: template.name,
        language: { code: template.language },
        components: [
          {
            type: 'body',
            parameters: payload.variables.map((v) => ({ type: 'text', text: String(v) })),
          },
        ],
      },
    };

    const url = `${this.baseUrl}/${this.apiVersion}/${this.phoneNumberId}/messages`;

    const { data } = await firstValueFrom(
      this.http.post<{ messages: Array<{ id: string }> }>(url, body, {
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
        timeout: 15_000,
      }),
    );

    const messageId = data.messages?.[0]?.id ?? 'unknown';
    this.logger.log(`Meta API dispatched: ${messageId} → ${payload.recipientPhone}`);
    return { messageId };
  }

  /** Update log status after successful/failed delivery */
  async updateLogStatus(
    logId: string,
    status: 'SENT' | 'DELIVERED' | 'READ' | 'FAILED',
    messageId?: string,
    error?: string,
  ): Promise<void> {
    await this.prisma.whatsappLog.update({
      where: { id: logId },
      data: {
        status: status as any,
        messageId: messageId,
        errorMessage: error,
        statusUpdatedAt: new Date(),
      },
    });
  }

  // ── Webhook processing ─────────────────────────────────────────────────

  /**
   * Process incoming webhook from Meta.
   * Meta sends delivery/read receipts and incoming message notifications.
   * Called by WhatsappController.webhook().
   */
  async processWebhook(body: any): Promise<void> {
    const entry = body?.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;

    // Delivery/read status updates
    const statuses = value?.statuses ?? [];
    for (const status of statuses) {
      const metaStatus = status.status as string; // 'sent', 'delivered', 'read', 'failed'
      const messageId = status.id as string;

      const log = await this.prisma.whatsappLog.findFirst({
        where: { messageId },
      });
      if (!log) continue;

      const mapped: Record<string, 'SENT' | 'DELIVERED' | 'READ' | 'FAILED'> = {
        sent: 'SENT',
        delivered: 'DELIVERED',
        read: 'READ',
        failed: 'FAILED',
      };

      const newStatus = mapped[metaStatus];
      if (newStatus) {
        await this.updateLogStatus(log.id, newStatus, messageId, status.errors?.[0]?.message);
        this.logger.debug(`Webhook: ${messageId} → ${newStatus}`);
      }
    }

    // Incoming messages (future: auto-reply capability)
    const messages = value?.messages ?? [];
    for (const msg of messages) {
      this.logger.debug(`Incoming WhatsApp from ${msg.from}: ${msg.type}`);
      // Future: route to customer service queue
    }
  }

  // ── Convenience methods for each template ─────────────────────────────

  async sendInvoiceNotification(params: {
    phone: string;
    customerName: string;
    invoiceNumber: string;
    totalAmount: string;
    dueDate: string;
    portalLink: string;
    branchId: string;
    invoiceId: string;
    sentById?: string;
  }) {
    return this.sendMessage({
      recipientPhone: params.phone,
      recipientName: params.customerName,
      templateKey: 'INVOICE_DELIVERY',
      variables: [
        params.customerName,
        params.invoiceNumber,
        params.totalAmount,
        params.dueDate,
        params.portalLink,
      ],
      referenceType: 'Invoice',
      referenceId: params.invoiceId,
      branchId: params.branchId,
      sentById: params.sentById,
    });
  }

  async sendQuotationNotification(params: {
    phone: string;
    customerName: string;
    quotationNumber: string;
    equipmentSummary: string;
    totalAmount: string;
    validUntil: string;
    portalLink: string;
    branchId: string;
    quotationId: string;
    sentById?: string;
  }) {
    return this.sendMessage({
      recipientPhone: params.phone,
      recipientName: params.customerName,
      templateKey: 'QUOTATION_SHARE',
      variables: [
        params.customerName,
        params.quotationNumber,
        params.equipmentSummary,
        params.totalAmount,
        params.validUntil,
        params.portalLink,
      ],
      referenceType: 'Quotation',
      referenceId: params.quotationId,
      branchId: params.branchId,
      sentById: params.sentById,
    });
  }

  async sendServiceUpdate(params: {
    phone: string;
    customerName: string;
    jobCardNumber: string;
    equipmentName: string;
    status: string;
    statusNote: string;
    technicianName: string;
    estimatedCompletion: string;
    portalLink: string;
    branchId: string;
    jobCardId: string;
  }) {
    return this.sendMessage({
      recipientPhone: params.phone,
      recipientName: params.customerName,
      templateKey: 'SERVICE_UPDATE',
      variables: [
        params.jobCardNumber,
        params.equipmentName,
        params.status,
        params.statusNote,
        params.technicianName,
        params.estimatedCompletion,
        params.portalLink,
      ],
      referenceType: 'JobCard',
      referenceId: params.jobCardId,
      branchId: params.branchId,
    });
  }

  async sendPaymentReminder(params: {
    phone: string;
    customerName: string;
    invoiceNumber: string;
    originalAmount: string;
    dueDate: string;
    outstandingBalance: string;
    portalLink: string;
    branchId: string;
    invoiceId: string;
  }) {
    return this.sendMessage({
      recipientPhone: params.phone,
      recipientName: params.customerName,
      templateKey: 'PAYMENT_REMINDER',
      variables: [
        params.customerName,
        params.invoiceNumber,
        params.originalAmount,
        params.dueDate,
        params.outstandingBalance,
        params.portalLink,
      ],
      referenceType: 'Invoice',
      referenceId: params.invoiceId,
      branchId: params.branchId,
    });
  }

  async sendNadfDeliveryConfirmation(params: {
    phone: string;
    beneficiaryName: string;
    beneficiaryNo: string;
    equipmentName: string;
    serialNumber: string;
    state: string;
    lga: string;
    deliveryDate: string;
    branchId: string;
    beneficiaryId: string;
  }) {
    return this.sendMessage({
      recipientPhone: params.phone,
      recipientName: params.beneficiaryName,
      templateKey: 'NADF_DELIVERY_CONFIRM',
      variables: [
        params.beneficiaryName,
        params.beneficiaryNo,
        params.equipmentName,
        params.serialNumber,
        params.state,
        params.lga,
        params.deliveryDate,
      ],
      referenceType: 'Beneficiary',
      referenceId: params.beneficiaryId,
      branchId: params.branchId,
    });
  }

  // ── Opt-in management ──────────────────────────────────────────────────

  async setOptIn(
    customerId: string,
    whatsappPhone: string,
    preferences: Partial<{
      optedIn: boolean;
      invoiceAlerts: boolean;
      quotationAlerts: boolean;
      serviceAlerts: boolean;
      paymentReminders: boolean;
    }>,
  ) {
    const phone = this.normalisePhone(whatsappPhone);
    return this.prisma.customerWhatsappPreference.upsert({
      where: { customerId },
      update: { whatsappPhone: phone, ...preferences, updatedAt: new Date() },
      create: { customerId, whatsappPhone: phone, ...preferences },
    });
  }

  async getOptInStatus(customerId: string) {
    return this.prisma.customerWhatsappPreference.findUnique({
      where: { customerId },
    });
  }

  async getDeliveryStats(branchId: string, days = 30) {
    const since = new Date();
    since.setDate(since.getDate() - days);

    const stats = await this.prisma.whatsappLog.groupBy({
      by: ['status'],
      where: { branchId, createdAt: { gte: since } },
      _count: { status: true },
    });

    return {
      period: `last ${days} days`,
      branchId,
      breakdown: stats.reduce(
        (acc, s) => ({ ...acc, [s.status]: s._count.status }),
        {} as Record<string, number>,
      ),
      total: stats.reduce((sum, s) => sum + s._count.status, 0),
    };
  }

  // ── Private helpers ────────────────────────────────────────────────────

  private normalisePhone(raw: string): string {
    // Strip spaces, dashes
    let phone = raw.replace(/[\s\-()]/g, '');
    // Nigerian local format: 0XX → +234XX
    if (phone.startsWith('0') && phone.length === 11) {
      phone = `+234${phone.slice(1)}`;
    }
    // Ensure + prefix
    if (!phone.startsWith('+')) phone = `+${phone}`;
    return phone;
  }

  private async isOptedIn(phone: string, templateKey: WhatsappTemplateKey): Promise<boolean> {
    const pref = await this.prisma.customerWhatsappPreference.findFirst({
      where: { whatsappPhone: phone },
    });
    if (!pref || !pref.optedIn) return false;

    const fieldMap: Partial<Record<WhatsappTemplateKey, keyof typeof pref>> = {
      INVOICE_DELIVERY: 'invoiceAlerts',
      QUOTATION_SHARE: 'quotationAlerts',
      SERVICE_UPDATE: 'serviceAlerts',
      PAYMENT_REMINDER: 'paymentReminders',
    };

    const field = fieldMap[templateKey];
    return field ? Boolean(pref[field]) : true;
  }
}
