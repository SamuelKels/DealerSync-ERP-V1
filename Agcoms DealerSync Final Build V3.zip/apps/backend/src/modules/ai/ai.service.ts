/**
 * AGCOMS DealerSync ERP — AiService (Anthropic claude-sonnet-4-20250514)
 * Sprint 4 / S4-A: Full Anthropic API wiring for Module 13 AI Intelligence Layer.
 *
 * Capabilities:
 *   1. forecastInventoryDemand — 90-day velocity + Nigerian seasonal patterns
 *   2. scoreInvoiceRisk        — collection risk scoring with recommended actions
 *   3. summariseServiceReport  — customer-ready WhatsApp/email job card summary
 *   4. nlpSearch               — natural language → structured ERP search filters
 *
 * All outputs: AiAdvisory<T> { result, human_action_required: true, governance }
 * Governance:  AnthropicClientService blocks BLOCKED_ACTIONS at call level
 */
import { JwtPayload } from '@agcoms/types';
import { Injectable, Logger } from '@nestjs/common';

import { CacheService } from '../../cache/cache.service';
import { FeatureFlagsService } from '../../common/feature-flags/feature-flags.service';
import { PrismaService } from '../../prisma/prisma.service';

import { AnthropicClientService, AiAdvisory } from './strategies/anthropic-client.service';

export interface InventoryForecastItem {
  productId: string;
  sku: string;
  productName: string;
  currentStock: number;
  averageDailySales: number;
  daysOfStockLeft: number;
  reorderQuantity: number;
  urgency: 'IMMEDIATE' | 'THIS_WEEK' | 'THIS_MONTH' | 'ADEQUATE';
  reasoning: string;
  confidence: number;
}
export interface InvoiceRiskScore {
  invoiceId: string;
  invoiceNo: string;
  customerName: string;
  amountOutstanding: number;
  daysOverdue: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  riskScore: number;
  recommendedAction: string;
  reasoning: string;
}
export interface NlpSearchFilters {
  category?: string;
  maxPrice?: number;
  minPrice?: number;
  keywords?: string[];
  availability?: 'IN_STOCK' | 'ALL';
  interpretation: string;
  confidence: number;
}

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);

  constructor(
    private readonly anthropic: AnthropicClientService,
    private readonly prisma: PrismaService,
    private readonly cache: CacheService,
    private readonly flags: FeatureFlagsService,
  ) {}

  // ── 1. Inventory demand forecasting ────────────────────────────────────
  async forecastInventoryDemand(
    branchId: string,
    _actor: JwtPayload,
  ): Promise<AiAdvisory<InventoryForecastItem[]>> {
    await this.requireFlag('ai.inventory_forecast');
    const ninetyDaysAgo = new Date(Date.now() - 90 * 86400_000);

    const [salesData, stockLevels] = await Promise.all([
      this.prisma.salesOrderLine.groupBy({
        by: ['productId'],
        where: {
          salesOrder: {
            branchId,
            status: { notIn: ['CANCELLED', 'DRAFT'] },
            createdAt: { gte: ninetyDaysAgo },
          },
        },
        _sum: { quantity: true },
      }),
      this.prisma.stockItem.groupBy({
        by: ['productId'],
        where: { status: 'AVAILABLE', product: { branchId, isActive: true } },
        _sum: { quantity: true },
      }),
    ]);

    const productIds = [
      ...new Set([...salesData.map((s) => s.productId), ...stockLevels.map((s) => s.productId)]),
    ];
    const products = await this.prisma.product.findMany({
      where: { id: { in: productIds } },
      select: { id: true, sku: true, name: true, category: true },
    });
    const productMap = new Map(products.map((p) => [p.id, p]));

    const stockContext = stockLevels.map((s) => {
      const p = productMap.get(s.productId);
      const sales = salesData.find((d) => d.productId === s.productId);
      const avgDaily = sales ? Number(sales._sum.quantity) / 90 : 0;
      return {
        productId: s.productId,
        sku: p?.sku ?? 'UNKNOWN',
        name: p?.name ?? 'Unknown',
        category: p?.category ?? 'OTHER',
        currentStock: Number(s._sum.quantity),
        soldLast90d: Number(sales?._sum.quantity ?? 0),
        avgDailySales: Math.round(avgDaily * 100) / 100,
        daysOfStockLeft: avgDaily > 0 ? Math.floor(Number(s._sum.quantity) / avgDaily) : 999,
      };
    });

    const advisory = await this.anthropic.call<{ forecasts: InventoryForecastItem[] }>({
      action: 'forecast',
      systemPrompt:
        'You are an inventory planning specialist for Nigerian agricultural equipment. Return only valid JSON.',
      userPrompt: `Analyse inventory for branch ${branchId}. Current date: ${new Date().toLocaleDateString('en-NG')}.
Consider Nigerian agricultural seasons: NADF tractor deployment (Q1/Q2), harmattan spare parts demand (Oct–Feb), planting season (Apr–Jun).
DATA: ${JSON.stringify(stockContext)}
Return ONLY valid JSON: {"forecasts":[{"productId":"","sku":"","productName":"","currentStock":0,"averageDailySales":0,"daysOfStockLeft":0,"reorderQuantity":0,"urgency":"IMMEDIATE|THIS_WEEK|THIS_MONTH|ADEQUATE","reasoning":"","confidence":0.9}]}
Include ONLY products needing attention (urgency != ADEQUATE).`,
      temperature: 0,
      maxTokens: 2048,
      jsonMode: true,
    });
    this.logger.log(`Inventory forecast: ${advisory.result.forecasts?.length ?? 0} items flagged`);
    return { ...advisory, result: advisory.result.forecasts ?? [] };
  }

  // ── 2. Invoice collection risk scoring ─────────────────────────────────
  async scoreInvoiceRisk(
    branchId: string,
    _actor: JwtPayload,
  ): Promise<AiAdvisory<InvoiceRiskScore[]>> {
    await this.requireFlag('ai.assistant');

    const overdueInvoices = await this.prisma.invoice.findMany({
      where: {
        branchId,
        status: { in: ['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'] },
        dueDate: { lt: new Date() },
      },
      include: {
        customer: {
          select: {
            name: true,
            creditLimit: true,
            invoices: {
              where: { status: 'PAID', createdAt: { gte: new Date(Date.now() - 180 * 86400_000) } },
              select: { id: true },
            },
          },
        },
      },
      orderBy: { dueDate: 'asc' },
      take: 50,
    });

    if (overdueInvoices.length === 0) {
      const empty = await this.anthropic.call<{ scores: InvoiceRiskScore[] }>({
        action: 'classify',
        systemPrompt: 'Return only valid JSON.',
        userPrompt: 'Return: {"scores":[]}',
        jsonMode: true,
        temperature: 0,
      });
      return { ...empty, result: [] };
    }

    const context = overdueInvoices.map((inv) => ({
      invoiceId: inv.id,
      invoiceNo: inv.invoiceNo,
      customerName: inv.customer.name,
      outstanding: Number(inv.totalAmount) - Number(inv.amountPaid),
      daysOverdue: Math.floor((Date.now() - (inv.dueDate?.getTime() ?? 0)) / 86400_000),
      creditLimit: Number(inv.customer.creditLimit),
      paidLast6m: inv.customer.invoices.length,
    }));

    const advisory = await this.anthropic.call<{ scores: InvoiceRiskScore[] }>({
      action: 'classify',
      systemPrompt:
        'You are a credit risk analyst for a Nigerian B2B equipment company. Return only valid JSON.',
      userPrompt: `Score collection risk for these overdue invoices. Consider Nigerian business payment patterns, government vs private sector.
DATA: ${JSON.stringify(context)}
Return ONLY valid JSON: {"scores":[{"invoiceId":"","invoiceNo":"","customerName":"","amountOutstanding":0,"daysOverdue":0,"riskLevel":"LOW|MEDIUM|HIGH|CRITICAL","riskScore":0,"recommendedAction":"","reasoning":""}]}`,
      temperature: 0,
      maxTokens: 2048,
      jsonMode: true,
    });
    this.logger.log(`Invoice risk scored: ${advisory.result.scores?.length ?? 0} invoices`);
    return { ...advisory, result: advisory.result.scores ?? [] };
  }

  // ── 3. Service report summarisation ────────────────────────────────────
  async summariseServiceReport(jobCardId: string, _actor: JwtPayload): Promise<AiAdvisory<string>> {
    await this.requireFlag('ai.assistant');

    const jobCard = await this.prisma.jobCard.findUnique({
      where: { id: jobCardId },
      include: {
        serviceRequest: { include: { customer: { select: { name: true } } } },
        assignedTechnician: { select: { firstName: true, lastName: true } },
        partsUsed: { include: { product: { select: { name: true, sku: true } } } },
      },
    });
    if (!jobCard) throw new Error(`Job card ${jobCardId} not found`);

    const ctx = {
      customer: jobCard.serviceRequest?.customer?.name ?? 'Customer',
      equipment:
        `${jobCard.serviceRequest?.make ?? ''} ${jobCard.serviceRequest?.model ?? ''}`.trim(),
      issue: jobCard.serviceRequest?.issueDescription,
      diagnosis: (jobCard as any).diagnosis,
      workDone: (jobCard as any).workPerformed,
      partsUsed: jobCard.partsUsed?.map((p: any) => `${p.quantity}× ${p.product.name}`).join(', '),
      labourHours: (jobCard as any).actualLabourHours,
      technician: jobCard.assignedTechnician
        ? `${jobCard.assignedTechnician.firstName} ${jobCard.assignedTechnician.lastName}`
        : 'AGCOMS technician',
      completedAt: jobCard.completedAt?.toLocaleDateString('en-NG'),
      recommendations: (jobCard as any).recommendations,
    };

    return this.anthropic.call<string>({
      action: 'summarize',
      systemPrompt:
        'You are a professional service writer for an agricultural equipment dealership in Nigeria. Write clear, friendly 2-4 paragraph customer-facing summaries. Address the customer by name. Sign off from "AGCOMS Workshop Team".',
      userPrompt: `Write a customer-friendly service report summary.\nDATA: ${JSON.stringify(ctx)}`,
      temperature: 0.3,
      maxTokens: 1024,
      jsonMode: false,
    });
  }

  // ── 4. NLP equipment catalogue search ──────────────────────────────────
  async nlpSearch(
    query: string,
    _branchId: string,
    _actor: JwtPayload,
  ): Promise<AiAdvisory<NlpSearchFilters>> {
    await this.requireFlag('ai.nlp_search');

    const cacheKey = `ai:nlp:${Buffer.from(query).toString('base64').slice(0, 32)}`;
    const cached = await this.cache.get<string>(cacheKey);
    if (cached) {
      this.logger.debug(`NLP cache hit: "${query}"`);
      return this.wrapInAiAdvisory(JSON.parse(cached) as NlpSearchFilters, 'search');
    }

    const advisory = await this.anthropic.call<NlpSearchFilters>({
      action: 'search',
      systemPrompt:
        'You are a search intent parser for a Nigerian agricultural equipment catalogue. Return only valid JSON.',
      userPrompt: `Parse: "${query}"
Products: tractors (John Deere/Massey Ferguson/New Holland), construction (Caterpillar), implements, spare parts. Prices in NGN.
Return ONLY valid JSON: {"category":"TRACTOR|CONSTRUCTION|IMPLEMENT|SPARE_PART|CONSUMABLE|null","maxPrice":null,"minPrice":null,"keywords":[],"availability":"IN_STOCK|ALL","interpretation":"what user wants","confidence":0.9}`,
      temperature: 0,
      maxTokens: 256,
      jsonMode: true,
    });

    await this.cache.set(cacheKey, JSON.stringify(advisory.result), 3600);
    return advisory;
  }

  // ── Governance (used by controller + unit tests) ────────────────────────
  assertAiActionPermitted(action: string): void {
    this.anthropic.assertActionPermitted(action);
  }

  wrapInAiAdvisory<T>(result: T, action: string): AiAdvisory<T> {
    return {
      result,
      human_action_required: true,
      governance: {
        model: 'advisory',
        generated_at: new Date().toISOString(),
        action,
        disclaimer: 'AI advisory — human approval required.',
        input_tokens: 0,
        output_tokens: 0,
      },
    };
  }

  private async requireFlag(flag: string): Promise<void> {
    const enabled = this.flags.isEnabled(flag as any);
    if (!enabled) throw new Error(`AI feature '${flag}' is disabled via feature flags.`);
  }
}
