import { Module } from '@nestjs/common';

import { AiController } from './ai.controller';
import { AiService } from './ai.service';
import { AnthropicClientService } from './strategies/anthropic-client.service';

@Module({
  controllers: [AiController],
  providers: [AiService, AnthropicClientService],
  exports: [AiService, AnthropicClientService],
})
export class AiModule {}
