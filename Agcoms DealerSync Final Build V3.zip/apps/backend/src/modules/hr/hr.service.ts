// AGCOMS DealerSync — HR & Payroll Service (Module 9)
// Nigerian payroll compliance: PAYE, Pension (PenCom), NHF
// AI CANNOT: approve payroll, alter payslips, modify salary records

import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';

import { AuditService } from '../../audit/audit.service';
import { PrismaService } from '../../prisma/prisma.service';

// ── Nigerian PAYE Tax Calculator ──────────────────────────────
// Personal Income Tax Act (PITA) 2011 as amended
// CRA = Higher of (₦200,000 or 1% of Gross Income) + 20% of Gross Income
function calculatePAYE(annualGross: number): {
  cra: number;
  chargeableIncome: number;
  annualTax: number;
  monthlyTax: number;
} {
  const cra = Math.max(200_000, annualGross * 0.01) + annualGross * 0.2;
  const chargeableIncome = Math.max(0, annualGross - cra);
  let tax = 0;
  let remaining = chargeableIncome;
  // Progressive tax bands (Section 4, PITA)
  const bands = [
    { limit: 300_000, rate: 0.07 },
    { limit: 300_000, rate: 0.11 },
    { limit: 500_000, rate: 0.15 },
    { limit: 500_000, rate: 0.19 },
    { limit: 1_600_000, rate: 0.21 },
    { limit: Infinity, rate: 0.24 },
  ];
  for (const band of bands) {
    if (remaining <= 0) break;
    const taxable = Math.min(remaining, band.limit);
    tax += taxable * band.rate;
    remaining -= taxable;
  }
  // Minimum tax: 1% of gross if calculated tax < 1% of gross
  const minTax = annualGross * 0.01;
  const annualTax = Math.max(tax, minTax);
  return { cra, chargeableIncome, annualTax, monthlyTax: annualTax / 12 };
}

@Injectable()
export class HrService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextEmpNo() {
    const count = await this.prisma.employee.count();
    return `EMP-${String(count + 1).padStart(4, '0')}`;
  }
  private async nextCode(prefix: string, model: string) {
    const year = new Date().getFullYear();
    const count = await (this.prisma as any)[model].count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `${prefix}-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Departments ───────────────────────────────────────────────────────────

  async listDepartments(branchId: string, isSuperAdmin: boolean, actorBranchId: string) {
    const allowedBranch = isSuperAdmin ? branchId : actorBranchId;
    return this.prisma.department.findMany({
      where: { isActive: true, ...(allowedBranch && { branchId: allowedBranch }) },
      include: {
        manager: { select: { id: true, firstName: true, lastName: true } },
        _count: { select: { employees: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async createDepartment(dto: any, actorId: string) {
    const dept = await this.prisma.department.create({ data: { ...dto } });
    await this.audit.log({
      action: 'create',
      resource: 'department',
      entityId: dept.id,
      afterState: dept,
      actorId,
    });
    return dept;
  }

  // ── Employees ─────────────────────────────────────────────────────────────

  async listEmployees(query: any, actorBranchId: string, isSuperAdmin: boolean) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.departmentId && { departmentId: query.departmentId }),
      ...(query.status && { status: query.status }),
      ...(query.search && {
        OR: [
          { firstName: { contains: query.search, mode: 'insensitive' } },
          { lastName: { contains: query.search, mode: 'insensitive' } },
          { employeeNo: { contains: query.search, mode: 'insensitive' } },
        ],
      }),
    };
    const [items, total] = await Promise.all([
      this.prisma.employee.findMany({
        where,
        include: {
          department: { select: { id: true, name: true } },
          branch: { select: { id: true, name: true } },
        },
        orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }],
        take: query.limit ?? 20,
      }),
      this.prisma.employee.count({ where }),
    ]);
    return { items, total };
  }

  async getEmployee(id: string, actorBranchId: string, isSuperAdmin: boolean) {
    const emp = await this.prisma.employee.findFirst({
      where: { id, isDeleted: false },
      include: {
        department: true,
        branch: true,
        reportsTo: { select: { id: true, firstName: true, lastName: true, jobTitle: true } },
        _count: { select: { directReports: true, leaveRequests: true } },
      },
    });
    if (!emp) throw new NotFoundException('Employee not found');
    if (!isSuperAdmin && emp.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    return emp;
  }

  async createEmployee(dto: any, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    const employeeNo = await this.nextEmpNo();
    const emp = await this.prisma.employee.create({
      data: { ...dto, employeeNo, status: 'ACTIVE', createdById: actorId },
    });
    await this.audit.log({
      action: 'create',
      resource: 'employee',
      entityId: emp.id,
      afterState: { ...emp, bankAccountNo: '[REDACTED]', bvn: '[REDACTED]' },
      actorId,
    });
    this.events.emit('hr.employee.created', { employeeId: emp.id });
    return emp;
  }

  async updateEmployee(
    id: string,
    dto: any,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const existing = await this.getEmployee(id, actorBranchId, isSuperAdmin);
    const updated = await this.prisma.employee.update({
      where: { id },
      data: { ...dto, updatedAt: new Date() },
    });
    await this.audit.log({
      action: 'update',
      resource: 'employee',
      entityId: id,
      beforeState: { grossSalary: existing.grossSalary, status: existing.status },
      afterState: { grossSalary: updated.grossSalary, status: updated.status },
      actorId,
    });
    return updated;
  }

  async terminateEmployee(
    id: string,
    dto: { terminationDate: Date; reason: string },
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const emp = await this.getEmployee(id, actorBranchId, isSuperAdmin);
    if (emp.status === 'TERMINATED') throw new BadRequestException('Employee already terminated');
    const updated = await this.prisma.employee.update({
      where: { id },
      data: {
        status: 'TERMINATED',
        terminationDate: dto.terminationDate,
        terminationReason: dto.reason,
        updatedAt: new Date(),
      },
    });
    await this.audit.log({
      action: 'terminate',
      resource: 'employee',
      entityId: id,
      beforeState: { status: 'ACTIVE' },
      afterState: { status: 'TERMINATED', reason: dto.reason },
      actorId,
    });
    this.events.emit('hr.employee.terminated', { employeeId: id });
    return updated;
  }

  // ── Leave Management ──────────────────────────────────────────────────────

  async requestLeave(dto: any, actorId: string) {
    const employee = await this.prisma.employee.findUnique({ where: { id: dto.employeeId } });
    if (!employee) throw new NotFoundException('Employee not found');
    const code = await this.nextCode('LV', 'leaveRequest');
    // Check balance
    const balance = await this.prisma.leaveBalance.findFirst({
      where: {
        employeeId: dto.employeeId,
        leaveTypeId: dto.leaveTypeId,
        year: new Date().getFullYear(),
      },
    });
    if (balance && Number(balance.remaining) < dto.daysRequested) {
      throw new BadRequestException(
        `Insufficient leave balance. Available: ${balance.remaining} days`,
      );
    }
    const req = await this.prisma.leaveRequest.create({
      data: { ...dto, code, status: 'SUBMITTED' },
    });
    // Reserve days in balance
    if (balance) {
      await this.prisma.leaveBalance.update({
        where: { id: balance.id },
        data: {
          pending: { increment: dto.daysRequested },
          remaining: { decrement: dto.daysRequested },
        },
      });
    }
    await this.audit.log({
      action: 'create',
      resource: 'leave_request',
      entityId: req.id,
      afterState: req,
      actorId,
    });
    this.events.emit('hr.leave.requested', { leaveId: req.id, employeeId: dto.employeeId });
    return req;
  }

  async approveLeave(id: string, actorId: string) {
    const req = await this.prisma.leaveRequest.findUnique({ where: { id } });
    if (!req) throw new NotFoundException('Leave request not found');
    if (req.status !== 'SUBMITTED')
      throw new BadRequestException('Only SUBMITTED requests can be approved');
    const updated = await this.prisma.leaveRequest.update({
      where: { id },
      data: {
        status: 'APPROVED',
        approvedById: actorId,
        approvedAt: new Date(),
        updatedAt: new Date(),
      },
    });
    // Convert pending to taken in balance
    await this.prisma.leaveBalance.updateMany({
      where: {
        employeeId: req.employeeId,
        leaveTypeId: req.leaveTypeId,
        year: new Date().getFullYear(),
      },
      data: { pending: { decrement: req.daysRequested }, taken: { increment: req.daysRequested } },
    });
    await this.audit.log({
      action: 'approve',
      resource: 'leave_request',
      entityId: id,
      beforeState: { status: req.status },
      afterState: { status: 'APPROVED' },
      actorId,
    });
    return updated;
  }

  async listLeaveRequests(query: any, _actorBranchId?: string, _isSuperAdmin?: boolean) {
    const where = {
      ...(query.employeeId && { employeeId: query.employeeId }),
      ...(query.status && { status: query.status }),
      ...(query.leaveTypeId && { leaveTypeId: query.leaveTypeId }),
    };
    return this.prisma.leaveRequest.findMany({
      where,
      include: {
        employee: { select: { firstName: true, lastName: true, employeeNo: true } },
        leaveType: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: query.limit ?? 20,
    });
  }

  // ── Attendance ────────────────────────────────────────────────────────────

  async recordAttendance(dto: any, actorId: string) {
    const existing = await this.prisma.attendanceRecord.findUnique({
      where: { employeeId_date: { employeeId: dto.employeeId, date: new Date(dto.date) } },
    });
    if (existing) throw new ConflictException('Attendance already recorded for this date');
    const record = await this.prisma.attendanceRecord.create({
      data: { ...dto, date: new Date(dto.date), recordedById: actorId },
    });
    return record;
  }

  async getAttendanceSummary(employeeId: string, year: number, month: number) {
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 0);
    const records = await this.prisma.attendanceRecord.findMany({
      where: { employeeId, date: { gte: start, lte: end } },
      orderBy: { date: 'asc' },
    });
    const summary = { present: 0, absent: 0, late: 0, halfDay: 0, onLeave: 0, totalHours: 0 };
    records.forEach((r) => {
      if (r.status === 'PRESENT') summary.present++;
      else if (r.status === 'ABSENT') summary.absent++;
      else if (r.status === 'LATE') {
        summary.late++;
        summary.present++;
      } else if (r.status === 'HALF_DAY') summary.halfDay++;
      else if (r.status === 'ON_LEAVE') summary.onLeave++;
      if (r.hoursWorked) summary.totalHours += Number(r.hoursWorked);
    });
    return { records, summary };
  }

  // ── Payroll Processing ────────────────────────────────────────────────────

  async createPayrollRun(
    year: number,
    month: number,
    branchId: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    if (!isSuperAdmin && branchId !== actorBranchId) throw new ForbiddenException('Access denied');
    const existing = await this.prisma.payrollRun.findFirst({
      where: { periodYear: year, periodMonth: month, branchId },
    });
    if (existing) throw new ConflictException(`Payroll run already exists for ${month}/${year}`);
    const code = `PAY-${year}-${String(month).padStart(2, '0')}`;
    const run = await this.prisma.payrollRun.create({
      data: {
        code,
        status: 'DRAFT',
        periodYear: year,
        periodMonth: month,
        branchId,
        createdById: actorId,
      },
    });
    await this.audit.log({
      action: 'create',
      resource: 'payroll_run',
      entityId: run.id,
      afterState: run,
      actorId,
    });
    return run;
  }

  async calculatePayroll(
    runId: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const run = await this.prisma.payrollRun.findUnique({ where: { id: runId } });
    if (!run) throw new NotFoundException('Payroll run not found');
    if (!isSuperAdmin && run.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    if (!['DRAFT', 'CALCULATED'].includes(run.status))
      throw new BadRequestException('Cannot recalculate this payroll run');

    const employees = await this.prisma.employee.findMany({
      where: { branchId: run.branchId, status: 'ACTIVE', isDeleted: false },
    });
    if (employees.length === 0)
      throw new BadRequestException('No active employees found in this branch');

    const items = employees.map((emp) => {
      const annualGross = Number(emp.grossSalary) * 12;
      const paye = calculatePAYE(annualGross);

      // Pension: 8% employee, 10% employer on (basic + housing + transport)
      const pensionableEarnings =
        Number(emp.basicSalary) + Number(emp.housingAllowance) + Number(emp.transportAllowance);
      const employeePension = pensionableEarnings * 0.08;
      const employerPension = pensionableEarnings * 0.1;

      // NHF: 2.5% of basic salary (capped at pension contribution)
      const nhfDeduction = Number(emp.basicSalary) * 0.025;

      const totalDeductions = paye.monthlyTax + employeePension + nhfDeduction;
      const netPay = Number(emp.grossSalary) - totalDeductions;

      return {
        payrollRunId: runId,
        employeeId: emp.id,
        status: 'CALCULATED' as const,
        basicSalary: emp.basicSalary,
        housingAllowance: emp.housingAllowance,
        transportAllowance: emp.transportAllowance,
        otherAllowances: emp.otherAllowances,
        grossSalary: emp.grossSalary,
        consolidatedRelief: paye.cra / 12,
        chargeableIncome: paye.chargeableIncome / 12,
        payeeTax: paye.monthlyTax,
        employeePension,
        employerPension,
        nhfDeduction,
        otherDeductions: 0,
        totalDeductions,
        netPay,
        daysWorked: 22,
      };
    });

    const totals = items.reduce(
      (acc, item) => ({
        totalGross: acc.totalGross + Number(item.grossSalary),
        totalBasic: acc.totalBasic + Number(item.basicSalary),
        totalPaye: acc.totalPaye + item.payeeTax,
        totalPension: acc.totalPension + item.employeePension,
        totalNhf: acc.totalNhf + item.nhfDeduction,
        totalDeductions: acc.totalDeductions + item.totalDeductions,
        totalNet: acc.totalNet + item.netPay,
        employerPension: acc.employerPension + item.employerPension,
      }),
      {
        totalGross: 0,
        totalBasic: 0,
        totalPaye: 0,
        totalPension: 0,
        totalNhf: 0,
        totalDeductions: 0,
        totalNet: 0,
        employerPension: 0,
      },
    );

    await this.prisma.$transaction(async (tx: any) => {
      // Delete previous calculation if recalculating
      await tx.payrollItem.deleteMany({ where: { payrollRunId: runId } });
      await tx.payrollItem.createMany({ data: items });
      await tx.payrollRun.update({
        where: { id: runId },
        data: { status: 'CALCULATED', ...totals, updatedAt: new Date() },
      });
    });

    await this.audit.log({
      action: 'calculate',
      resource: 'payroll_run',
      entityId: runId,
      afterState: { ...totals, employeeCount: employees.length },
      actorId,
    });
    return { runId, employeeCount: employees.length, ...totals };
  }

  async approvePayroll(
    runId: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const run = await this.prisma.payrollRun.findUnique({ where: { id: runId } });
    if (!run) throw new NotFoundException('Payroll run not found');
    if (!isSuperAdmin && run.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    if (run.status !== 'CALCULATED')
      throw new BadRequestException('Payroll must be CALCULATED before approval');
    // AI GOVERNANCE: payroll approval is strictly HUMAN ONLY
    const updated = await this.prisma.payrollRun.update({
      where: { id: runId },
      data: {
        status: 'APPROVED',
        approvedById: actorId,
        approvedAt: new Date(),
        updatedAt: new Date(),
      },
    });
    await this.audit.log({
      action: 'approve',
      resource: 'payroll_run',
      entityId: runId,
      beforeState: { status: 'CALCULATED' },
      afterState: { status: 'APPROVED' },
      actorId,
    });
    this.events.emit('hr.payroll.approved', { runId, actorId });
    return updated;
  }

  async getPayrollStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };
    const [totalEmployees, activeEmployees, pendingLeave, pendingPayroll] = await Promise.all([
      this.prisma.employee.count({ where: { ...branchFilter, isDeleted: false } }),
      this.prisma.employee.count({
        where: { ...branchFilter, isDeleted: false, status: 'ACTIVE' },
      }),
      this.prisma.leaveRequest.count({ where: { status: 'SUBMITTED', employee: branchFilter } }),
      this.prisma.payrollRun.count({
        where: { ...branchFilter, status: { in: ['DRAFT', 'CALCULATED', 'PENDING_APPROVAL'] } },
      }),
    ]);
    const payrollThisMonth = await this.prisma.payrollRun.findFirst({
      where: {
        ...branchFilter,
        periodYear: new Date().getFullYear(),
        periodMonth: new Date().getMonth() + 1,
        status: { in: ['APPROVED', 'PROCESSED', 'PAID'] },
      },
      select: { totalNet: true, totalGross: true, status: true },
    });
    return { totalEmployees, activeEmployees, pendingLeave, pendingPayroll, payrollThisMonth };
  }
}
