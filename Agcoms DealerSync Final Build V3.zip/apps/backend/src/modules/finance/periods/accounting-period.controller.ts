/**
 * AGCOMS DealerSync ERP — AccountingPeriodController (Sprint P2)
 *
 * REST endpoints for accounting period lifecycle management.
 */
import {
  Controller, Get, Post, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiParam, ApiQuery } from '@nestjs/swagger';
import { IsNumber, IsString, IsOptional, IsEnum, Min, Max, IsUUID, IsDateString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

import { AccountingPeriodService } from './accounting-period.service';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../../common/guards/auth.guards';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { JwtPayload } from '@agcoms/types';

class CreatePeriodRequestDto {
  @ApiProperty({ format: 'uuid' })
  @IsUUID()
  branchId!: string;

  @ApiProperty({ example: 2025 })
  @IsNumber() @Min(2020) @Max(2100) @Type(() => Number)
  year!: number;

  @ApiPropertyOptional({ example: 1, minimum: 1, maximum: 12 })
  @IsOptional() @IsNumber() @Min(1) @Max(12) @Type(() => Number)
  month?: number;

  @ApiPropertyOptional({ example: 1, minimum: 1, maximum: 4 })
  @IsOptional() @IsNumber() @Min(1) @Max(4) @Type(() => Number)
  quarter?: number;

  @ApiProperty({ example: '2025-01-01' })
  @IsDateString()
  startDate!: string;

  @ApiProperty({ example: '2025-01-31' })
  @IsDateString()
  endDate!: string;

  @ApiPropertyOptional()
  @IsOptional() @IsString()
  notes?: string;
}

@ApiTags('finance: accounting periods')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('finance/periods')
export class AccountingPeriodController {
  constructor(private readonly svc: AccountingPeriodService) {}

  @Get()
  @RequirePermission('finance:read')
  @ApiOperation({ summary: 'List accounting periods (filterable by branch, year, status)' })
  @ApiQuery({ name: 'branchId', required: false, type: String })
  @ApiQuery({ name: 'year',     required: false, type: Number })
  @ApiQuery({ name: 'status',   required: false, enum: ['OPEN', 'CLOSED', 'LOCKED'] })
  listPeriods(
    @CurrentUser() actor: JwtPayload,
    @Query('branchId') branchId?: string,
    @Query('year')     year?:     string,
    @Query('status')   status?:   'OPEN' | 'CLOSED' | 'LOCKED',
  ) {
    return this.svc.listPeriods(
      { branchId, year: year ? parseInt(year, 10) : undefined, status },
      actor,
    );
  }

  @Post()
  @RequirePermission('finance:write')
  @ApiOperation({ summary: 'Create a new accounting period' })
  createPeriod(@Body() dto: CreatePeriodRequestDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.createPeriod(dto, actor);
  }

  @Post(':id/close')
  @RequirePermission('finance:close-period')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Close an accounting period (allows correction journals via reversal)' })
  @ApiParam({ name: 'id', description: 'Accounting period UUID' })
  closePeriod(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return this.svc.closePeriod(id, actor);
  }

  @Post(':id/lock')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Hard-lock an accounting period (no further changes allowed — super-admin only)' })
  @ApiParam({ name: 'id', description: 'Accounting period UUID' })
  lockPeriod(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return this.svc.lockPeriod(id, actor);
  }

  @Post(':id/reopen')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Reopen a CLOSED period (super-admin only — LOCKED periods cannot be reopened)' })
  @ApiParam({ name: 'id', description: 'Accounting period UUID' })
  reopenPeriod(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return this.svc.reopenPeriod(id, actor);
  }
}
