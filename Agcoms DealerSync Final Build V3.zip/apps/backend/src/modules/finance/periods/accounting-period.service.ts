/**
 * AGCOMS DealerSync ERP — AccountingPeriodService (Sprint P2)
 *
 * Manages monthly/quarterly/annual accounting period close cycles.
 * Period locking is a hard barrier — no journal entry can be posted, modified,
 * or voided in a LOCKED period. CLOSED periods allow correction journals
 * (via reversal entries) but no direct modification of posted entries.
 *
 * IFRS / SEC compliance:
 *   - Period state transitions: OPEN → CLOSED → LOCKED (no reverse)
 *   - Locking requires super-admin role (enforced at controller layer)
 *   - All transitions audit-logged with actor, timestamp, IP
 *   - AI cannot lock or close periods (enforced by AiGovernanceService)
 */
import { Injectable, BadRequestException, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { AuditService } from '../../../audit/audit.service';
import { JwtPayload } from '@agcoms/types';

export interface CreatePeriodDto {
  branchId: string;
  year:     number;
  month?:   number;          // 1-12 for monthly
  quarter?: number;          // 1-4 for quarterly
  startDate: string;         // ISO date
  endDate:   string;         // ISO date
  notes?:    string;
}

export interface PeriodStatusFilter {
  branchId?: string;
  year?:     number;
  status?:   'OPEN' | 'CLOSED' | 'LOCKED';
}

@Injectable()
export class AccountingPeriodService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit:  AuditService,
  ) {}

  // ── List periods (with optional filters) ────────────────────
  async listPeriods(filter: PeriodStatusFilter, actor: JwtPayload) {
    const where: any = {};
    if (filter.branchId)               where.branchId = filter.branchId;
    else if (!actor.isSuperAdmin)      where.branchId = actor.branchId; // non-admin: own branch only
    if (filter.year   !== undefined)   where.year     = filter.year;
    if (filter.status !== undefined)   where.status   = filter.status;

    return this.prisma.accountingPeriod.findMany({
      where,
      orderBy: [{ year: 'desc' }, { month: 'desc' }, { quarter: 'desc' }],
    });
  }

  // ── Create a new period ─────────────────────────────────────
  async createPeriod(dto: CreatePeriodDto, actor: JwtPayload) {
    if (!actor.isSuperAdmin && dto.branchId !== actor.branchId) {
      throw new ForbiddenException('Cannot create periods for other branches');
    }
    if (dto.month && dto.quarter) {
      throw new BadRequestException('Period cannot be both monthly and quarterly');
    }

    // Format display name
    let name: string;
    if (dto.month)        name = `${dto.year}-${String(dto.month).padStart(2, '0')}`;
    else if (dto.quarter) name = `${dto.year}-Q${dto.quarter}`;
    else                  name = `FY${dto.year}`;

    const period = await this.prisma.accountingPeriod.create({
      data: {
        branchId:  dto.branchId,
        name,
        year:      dto.year,
        month:     dto.month   ?? null,
        quarter:   dto.quarter ?? null,
        startDate: new Date(dto.startDate),
        endDate:   new Date(dto.endDate),
        status:    'OPEN',
        notes:     dto.notes ?? null,
      },
    });

    await this.audit.log({
      action:      'finance.period.created',
      resource:    'AccountingPeriod',
      entityId:    period.id,
      actorId:     actor.sub,
      actorRole:   actor.roles?.[0] ?? 'UNKNOWN',
      afterState:  period,
    });

    return period;
  }

  // ── Check if a period is locked (used by journal posting) ───
  async isPeriodLocked(periodId: string): Promise<boolean> {
    const period = await this.prisma.accountingPeriod.findUnique({
      where: { id: periodId },
      select: { status: true } as any,
    });
    if (!period) throw new NotFoundException(`Period ${periodId} not found`);
    return period.status === 'LOCKED';
  }

  // ── Resolve which period a date belongs to ──────────────────
  async resolvePeriodForDate(branchId: string, date: Date) {
    const period = await this.prisma.accountingPeriod.findFirst({
      where: {
        branchId,
        startDate: { lte: date },
        endDate:   { gte: date },
      },
    });
    if (!period) {
      throw new BadRequestException(
        `No accounting period defined for ${date.toISOString().slice(0, 10)} in branch ${branchId}. Create one first.`
      );
    }
    return period;
  }

  // ── Close a period (soft close — allows correction journals) ─
  async closePeriod(id: string, actor: JwtPayload) {
    if (!actor.isSuperAdmin && !actor.permissions?.includes('finance:close-period')) {
      throw new ForbiddenException('Closing accounting periods requires the finance:close-period permission');
    }

    const period = await this.prisma.accountingPeriod.findUnique({ where: { id } });
    if (!period) throw new NotFoundException(`Period ${id} not found`);
    if (period.status === 'CLOSED') throw new BadRequestException('Period is already closed');
    if (period.status === 'LOCKED') throw new BadRequestException('Period is locked (cannot reopen)');

    // Verify all DRAFT journal entries in this period are either POSTED or VOIDED
    const drafts = await this.prisma.journalEntry.count({
      where: { periodId: id, status: 'DRAFT' } as any,
    });
    if (drafts > 0) {
      throw new BadRequestException(
        `Cannot close period: ${drafts} draft journal entries remain. Post or void them first.`
      );
    }

    // Verify trial balance is zero (debits == credits)
    const aggregate = await this.prisma.journalEntry.aggregate({
      where: { periodId: id, status: 'POSTED' } as any,
      _sum: { totalDebits: true, totalCredits: true } as any,
    });
    const totalDr = Number((aggregate as any)._sum?.totalDebits  ?? 0);
    const totalCr = Number((aggregate as any)._sum?.totalCredits ?? 0);
    if (Math.abs(totalDr - totalCr) > 0.01) {
      throw new BadRequestException(
        `Cannot close period: trial balance out of balance (debits ${totalDr.toFixed(2)} vs credits ${totalCr.toFixed(2)})`
      );
    }

    const updated = await this.prisma.accountingPeriod.update({
      where: { id },
      data:  { status: 'CLOSED', closedAt: new Date(), closedById: actor.sub } as any,
    });

    await this.audit.log({
      action:       'finance.period.closed',
      resource:     'AccountingPeriod',
      entityId:     id,
      actorId:      actor.sub,
      actorRole:    actor.roles?.[0] ?? 'UNKNOWN',
      beforeState:  { status: period.status },
      afterState:   { status: 'CLOSED', closedAt: updated.closedAt },
    });

    return updated;
  }

  // ── Lock a period (HARD lock — no further changes allowed) ──
  async lockPeriod(id: string, actor: JwtPayload) {
    // Hard lock requires super-admin
    if (!actor.isSuperAdmin) {
      throw new ForbiddenException('Locking accounting periods requires super-admin role');
    }

    const period = await this.prisma.accountingPeriod.findUnique({ where: { id } });
    if (!period) throw new NotFoundException(`Period ${id} not found`);
    if (period.status === 'LOCKED') throw new BadRequestException('Period is already locked');
    if (period.status === 'OPEN') {
      throw new BadRequestException('Period must be CLOSED before it can be LOCKED');
    }

    const updated = await this.prisma.accountingPeriod.update({
      where: { id },
      data:  { status: 'LOCKED', lockedAt: new Date(), lockedById: actor.sub } as any,
    });

    await this.audit.log({
      action:       'finance.period.locked',
      resource:     'AccountingPeriod',
      entityId:     id,
      actorId:      actor.sub,
      actorRole:    actor.roles?.[0] ?? 'UNKNOWN',
      beforeState:  { status: period.status },
      afterState:   { status: 'LOCKED', lockedAt: updated.lockedAt },
    });

    return updated;
  }

  // ── Reopen a CLOSED period (NOT possible for LOCKED) ────────
  async reopenPeriod(id: string, actor: JwtPayload) {
    if (!actor.isSuperAdmin) {
      throw new ForbiddenException('Reopening accounting periods requires super-admin role');
    }

    const period = await this.prisma.accountingPeriod.findUnique({ where: { id } });
    if (!period) throw new NotFoundException(`Period ${id} not found`);
    if (period.status === 'LOCKED') {
      throw new BadRequestException('LOCKED periods cannot be reopened (immutable)');
    }
    if (period.status === 'OPEN') {
      throw new BadRequestException('Period is already open');
    }

    const updated = await this.prisma.accountingPeriod.update({
      where: { id },
      data:  { status: 'OPEN', closedAt: null, closedById: null } as any,
    });

    await this.audit.log({
      action:       'finance.period.reopened',
      resource:     'AccountingPeriod',
      entityId:     id,
      actorId:      actor.sub,
      actorRole:    actor.roles?.[0] ?? 'UNKNOWN',
      beforeState:  { status: period.status },
      afterState:   { status: 'OPEN' },
    });

    return updated;
  }
}
