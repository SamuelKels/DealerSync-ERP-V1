import { Module } from '@nestjs/common';

import { FinanceController } from './finance.controller';
import { FinanceService } from './finance.service';
import { AccountingPeriodController } from './periods/accounting-period.controller';
import { AccountingPeriodService } from './periods/accounting-period.service';

@Module({
  controllers: [FinanceController, AccountingPeriodController],
  providers:   [FinanceService,   AccountingPeriodService],
  exports:     [FinanceService,   AccountingPeriodService],
})
export class FinanceModule {}
