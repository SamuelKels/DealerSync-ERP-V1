/**
 * AGCOMS DealerSync ERP — Finance DTOs
 * Sprint 2 Fix S2-06: No DTOs — double-entry journals had no input validation.
 * Financial integrity requires validated, typed input at the API boundary.
 */
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsString,
  IsOptional,
  IsEnum,
  IsNumber,
  IsArray,
  ValidateNested,
  IsDateString,
  IsUUID,
  Min,
  MaxLength,
} from 'class-validator';

export enum JournalEntryType {
  MANUAL = 'MANUAL',
  INVOICE = 'INVOICE',
  PAYMENT = 'PAYMENT',
  PAYROLL = 'PAYROLL',
  LANDED_COST = 'LANDED_COST',
  ADJUSTMENT = 'ADJUSTMENT',
}

export class JournalLineDto {
  @ApiProperty({ description: 'Account UUID from chart of accounts' })
  @IsUUID()
  accountId: string;

  @ApiProperty({ minimum: 0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  debitAmount: number;

  @ApiProperty({ minimum: 0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  creditAmount: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;
}

export class CreateJournalEntryDto {
  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty({ example: '2025-01-15' })
  @IsDateString()
  entryDate: string;

  @ApiProperty({ maxLength: 500 })
  @IsString()
  @MaxLength(500)
  description: string;

  @ApiProperty({ enum: JournalEntryType, default: JournalEntryType.MANUAL })
  @IsEnum(JournalEntryType)
  entryType: JournalEntryType;

  @ApiProperty({ type: [JournalLineDto], minItems: 2 })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => JournalLineDto)
  lines: JournalLineDto[];
}

export class CreateBudgetLineDto {
  @ApiProperty()
  @IsUUID()
  accountId: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(200)
  description?: string;

  @ApiProperty({ minimum: 0 })
  @IsNumber()
  @Min(0)
  @Type(() => Number)
  amount: number;
}

export class CreateBudgetDto {
  @ApiProperty()
  @IsUUID()
  branchId: string;

  @ApiProperty()
  @IsUUID()
  periodId: string;

  @ApiProperty()
  @IsString()
  @MaxLength(200)
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(1000)
  notes?: string;

  @ApiProperty({ type: [CreateBudgetLineDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateBudgetLineDto)
  lines: CreateBudgetLineDto[];
}
