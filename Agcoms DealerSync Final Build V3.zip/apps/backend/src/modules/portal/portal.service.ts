/**
 * AGCOMS DealerSync ERP — Customer Portal Service (Module 12)
 * External-facing portal for AGCOMS customers.
 *
 * Features:
 *   - External JWT authentication (separate from internal users)
 *   - Quotation viewing (read-only, customer's own records only)
 *   - Invoice viewing + payment initiation (gated by FEATURE_INTEGRATION_PAYMENT)
 *   - Service request tracking (own equipment only)
 *   - RFQ submission
 *   - Equipment ownership history
 *
 * Security:
 *   - Portal tokens are scoped to customerId only (cannot access other customers)
 *   - All portal queries add customerId to every where clause
 *   - Feature flag: FEATURE_BETA_CUSTOMER_PORTAL must be enabled
 */
import {
  Injectable,
  NotFoundException,
  UnauthorizedException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import { hash as argon2Hash, verify as argon2Verify } from '@node-rs/argon2';

import { AuditService } from '../../audit/audit.service';
import { FeatureFlagsService } from '../../common/feature-flags/feature-flags.service';
import { FEATURE_FLAGS } from '../../common/feature-flags/feature-flags.service';
import { PaginationDto, paginate } from '../../common/pagination';
import { PrismaService } from '../../prisma/prisma.service';

export interface PortalJwtPayload {
  sub: string; // customerId
  email: string;
  type: 'portal'; // distinguishes portal tokens from internal tokens
  iat?: number;
  exp?: number;
}

@Injectable()
export class PortalService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
    private readonly flags: FeatureFlagsService,
    private readonly events: EventEmitter2,
  ) {}

  private requirePortalFlag() {
    if (!this.flags.isEnabled(FEATURE_FLAGS.BETA_CUSTOMER_PORTAL)) {
      throw new ForbiddenException(
        'Customer portal is not yet available. Please contact AGCOMS for access.',
      );
    }
  }

  // ── Portal Authentication ──────────────────────────────────────────────

  async portalLogin(
    email: string,
    password: string,
    ip: string,
  ): Promise<{ accessToken: string; customer: any }> {
    this.requirePortalFlag();
    const customer = await this.prisma.customer.findFirst({
      where: { email: email.toLowerCase(), isDeleted: false, status: 'ACTIVE' },
    });
    if (!customer || !customer.portalPasswordHash) {
      throw new UnauthorizedException('Invalid credentials');
    }
    const valid = await argon2Verify(customer.portalPasswordHash, password);
    if (!valid) {
      await this.audit.log({
        action: 'portal_login_failed',
        resource: 'customer',
        entityId: customer.id,
        afterState: { ip },
        actorId: customer.id,
      });
      throw new UnauthorizedException('Invalid credentials');
    }
    const payload: PortalJwtPayload = { sub: customer.id, email: customer.email!, type: 'portal' };
    const accessToken = await this.jwt.signAsync(payload, {
      // Single source of truth, fail-closed — must match portal.controller verify.
      secret: this.config.getOrThrow<string>('PORTAL_JWT_SECRET'),
      expiresIn: '8h',
    });
    await this.audit.log({
      action: 'portal_login',
      resource: 'customer',
      entityId: customer.id,
      afterState: { ip },
      actorId: customer.id,
    });
    return {
      accessToken,
      customer: {
        id: customer.id,
        code: customer.code,
        name: customer.name,
        email: customer.email,
      },
    };
  }

  async setPortalPassword(customerId: string, password: string, actorId: string): Promise<void> {
    if (password.length < 10)
      throw new BadRequestException('Portal password must be at least 10 characters');
    const hash = await argon2Hash(password, { memoryCost: 65536, timeCost: 3, parallelism: 4 });
    await this.prisma.customer.update({
      where: { id: customerId },
      data: { portalPasswordHash: hash },
    });
    await this.audit.log({
      action: 'portal_password_set',
      resource: 'customer',
      entityId: customerId,
      afterState: {},
      actorId,
    });
  }

  // ── Quotations (read-only, customer-scoped) ────────────────────────────

  async getMyQuotations(customerId: string, query: PaginationDto & { status?: string }) {
    this.requirePortalFlag();
    const where = {
      customerId,
      isDeleted: false,
      ...(query.status && { status: query.status as any }),
    };
    return paginate(
      this.prisma.quotation,
      { where, cursor: query.cursor, limit: query.limit ?? 10 },
      (id) => this.prisma.quotation.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getMyQuotation(customerId: string, quotationId: string) {
    this.requirePortalFlag();
    const quotation = await this.prisma.quotation.findFirst({
      where: { id: quotationId, customerId, isDeleted: false },
      include: { lines: { include: { product: { select: { sku: true, name: true } } } } },
    });
    if (!quotation) throw new NotFoundException('Quotation not found');
    return quotation;
  }

  // ── Invoices ──────────────────────────────────────────────────────────

  async getMyInvoices(customerId: string, query: PaginationDto & { status?: string }) {
    this.requirePortalFlag();
    const where = {
      customerId,
      isDeleted: false,
      ...(query.status && { status: query.status as any }),
    };
    return paginate(
      this.prisma.invoice,
      { where, cursor: query.cursor, limit: query.limit ?? 10 },
      (id) => this.prisma.invoice.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getMyInvoice(customerId: string, invoiceId: string) {
    this.requirePortalFlag();
    const invoice = await this.prisma.invoice.findFirst({
      where: { id: invoiceId, customerId, isDeleted: false },
      include: { lines: { include: { product: { select: { sku: true, name: true } } } } },
    });
    if (!invoice) throw new NotFoundException('Invoice not found');
    return invoice;
  }

  async initiatePayment(customerId: string, invoiceId: string, amount: number) {
    this.requirePortalFlag();
    if (!this.flags.isEnabled(FEATURE_FLAGS.INTEGRATION_PAYMENT)) {
      throw new ForbiddenException(
        'Online payment is not enabled. Please pay by bank transfer and send remittance advice to your account manager.',
      );
    }
    const invoice = await this.getMyInvoice(customerId, invoiceId);
    if (Number(invoice.amountDue) <= 0)
      throw new BadRequestException('Invoice is already fully paid');
    // Payment gateway integration hook (Paystack / Flutterwave)
    // Returns a checkout URL — human clicks it to complete payment
    const reference = `AGCOMS-${invoice.code}-${Date.now()}`;
    this.events.emit('portal.payment.initiated', { customerId, invoiceId, amount, reference });
    return {
      reference,
      checkoutUrl: `https://checkout.paystack.com/${reference}`, // placeholder
      amount,
      currency: 'NGN',
      message: 'Payment session created. Complete payment on the checkout page.',
    };
  }

  // ── Service Tracking ──────────────────────────────────────────────────

  async getMyServiceRequests(customerId: string, query: PaginationDto) {
    this.requirePortalFlag();
    const where = { customerId, isDeleted: false };
    return paginate(
      this.prisma.serviceRequest,
      { where, cursor: query.cursor, limit: query.limit ?? 10 },
      (id) => this.prisma.serviceRequest.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getMyServiceRequest(customerId: string, srId: string) {
    this.requirePortalFlag();
    const sr = await this.prisma.serviceRequest.findFirst({
      where: { id: srId, customerId, isDeleted: false },
      include: {
        jobCards: {
          select: {
            id: true,
            code: true,
            status: true,
            assignedTo: { select: { firstName: true } },
            estimatedHours: true,
            completedAt: true,
          },
        },
      },
    });
    if (!sr) throw new NotFoundException('Service request not found');
    return sr;
  }

  // ── RFQ Submission ────────────────────────────────────────────────────

  async submitRfq(
    customerId: string,
    dto: {
      subject: string;
      description: string;
      requiredBy?: Date;
      items: { description: string; quantity: number; unit?: string }[];
    },
  ) {
    this.requirePortalFlag();
    const customer = await this.prisma.customer.findFirst({
      where: { id: customerId, isDeleted: false },
    });
    if (!customer) throw new NotFoundException('Customer not found');

    const year = new Date().getFullYear();
    const count = await this.prisma.rfq.count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    const code = `RFQ-${year}-${String(count + 1).padStart(4, '0')}`;

    const rfq = await this.prisma.rfq.create({
      data: {
        code,
        customerId,
        subject: dto.subject,
        description: dto.description,
        requiredBy: dto.requiredBy,
        status: 'SUBMITTED',
        branchId: customer.branchId,
        submittedViaPortal: true,
        items: {
          create: dto.items.map((item, i) => ({
            lineNumber: i + 1,
            description: item.description,
            quantity: item.quantity,
            unit: item.unit ?? 'unit',
          })),
        },
      },
      include: { items: true },
    });

    await this.audit.log({
      action: 'portal_rfq_submitted',
      resource: 'rfq',
      entityId: rfq.id,
      afterState: { code: rfq.code, customerId },
      actorId: customerId,
    });
    this.events.emit('portal.rfq.submitted', { rfqId: rfq.id, customerId });
    return rfq;
  }

  // ── Equipment Ownership History ───────────────────────────────────────

  async getMyEquipment(customerId: string) {
    this.requirePortalFlag();
    // Equipment linked to customer via sales invoices + service requests
    const stockItems = await this.prisma.stockItem.findMany({
      where: {
        isDeleted: false,
        serviceRequests: { some: { customerId } },
      },
      include: {
        product: { select: { sku: true, name: true, description: true } },
        serviceRequests: {
          where: { customerId },
          select: { id: true, code: true, status: true, faultDescription: true, reportedAt: true },
          orderBy: { reportedAt: 'desc' },
          take: 5,
        },
        warranties: {
          where: { customerId, status: 'ACTIVE' },
          select: { id: true, warrantyType: true, startDate: true, endDate: true, status: true },
        },
      },
    });

    return stockItems.map((item) => ({
      id: item.id,
      sku: item.product?.sku,
      name: item.product?.name,
      serialNumber: item.serialNumber,
      activeWarranty: item.warranties[0] ?? null,
      serviceHistory: item.serviceRequests,
    }));
  }

  // ── Portal Dashboard ──────────────────────────────────────────────────

  async getPortalDashboard(customerId: string) {
    this.requirePortalFlag();
    const [openInvoices, openSRs, openRfqs, equipmentCount] = await Promise.all([
      this.prisma.invoice.count({
        where: { customerId, isDeleted: false, status: { in: ['ISSUED', 'PARTIALLY_PAID'] } },
      }),
      this.prisma.serviceRequest.count({
        where: { customerId, isDeleted: false, status: { notIn: ['COMPLETED', 'CANCELLED'] } },
      }),
      this.prisma.rfq.count({
        where: { customerId, status: { in: ['SUBMITTED', 'UNDER_REVIEW'] } },
      }),
      this.prisma.stockItem.count({
        where: { isDeleted: false, serviceRequests: { some: { customerId } } },
      }),
    ]);
    const overdueInvoice = await this.prisma.invoice.findFirst({
      where: {
        customerId,
        isDeleted: false,
        status: { in: ['ISSUED', 'PARTIALLY_PAID'] },
        dueDate: { lt: new Date() },
      },
      orderBy: { dueDate: 'asc' },
      select: { code: true, amountDue: true, dueDate: true },
    });
    return { openInvoices, openSRs, openRfqs, equipmentCount, overdueInvoice };
  }
}
