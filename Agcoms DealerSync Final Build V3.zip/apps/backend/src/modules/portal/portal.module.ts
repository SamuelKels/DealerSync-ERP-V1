import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';

import { PortalController } from './portal.controller';
import { PortalService } from './portal.service';

@Module({
  imports: [
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (cfg: ConfigService) => ({
        // Aligned to the single PORTAL_JWT_SECRET used by sign (service) and verify
        // (controller). Fail closed — no 'fallback' default.
        secret: cfg.getOrThrow<string>('PORTAL_JWT_SECRET'),
      }),
    }),
  ],
  controllers: [PortalController],
  providers: [PortalService],
  exports: [PortalService],
})
export class PortalModule {}
