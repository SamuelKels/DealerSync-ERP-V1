// AGCOMS DealerSync — Workshop & Service Module
// Handles: ServiceRequest, JobCard, Parts, Checklist, ServiceInvoice, Warranty, PM
// Audit: all state transitions logged; AI cannot close job cards or approve invoices
import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';

import { AuditService } from '../../audit/audit.service';
import { paginate } from '../../common/pagination';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class WorkshopService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextCode(prefix: any, model: any) {
    const year = new Date().getFullYear();
    const count = await this.prisma[model].count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `${prefix}-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  // ── Service Requests ──────────────────────────────────────────────────────

  async listServiceRequests(query: any, actorBranchId: any, isSuperAdmin: any) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.customerId && { customerId: query.customerId }),
      ...(query.priority && { priority: query.priority }),
    };
    return paginate(
      this.prisma.serviceRequest,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.serviceRequest.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getServiceRequest(id: any, actorBranchId: any, isSuperAdmin: any) {
    const sr = await this.prisma.serviceRequest.findFirst({
      where: { id, isDeleted: false },
      include: {
        customer: { select: { id: true, code: true, name: true, phone: true } },
        stockItem: { include: { product: { select: { id: true, sku: true, name: true } } } },
        branch: { select: { id: true, code: true, name: true } },
        jobCards: {
          select: { id: true, code: true, status: true, assignedToId: true, totalCost: true },
        },
        warranty: true,
        createdBy: { select: { id: true, firstName: true, lastName: true } },
      },
    });
    if (!sr) throw new NotFoundException('Service request not found');
    if (!isSuperAdmin && sr.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    return sr;
  }

  async createServiceRequest(dto: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId)
      throw new ForbiddenException('Cannot create SR for another branch');
    const code = await this.nextCode('SR', 'serviceRequest');
    const sr = await this.prisma.serviceRequest.create({
      data: { code, ...dto, status: 'OPEN', reportedAt: new Date(), createdById: actorId },
    });
    await this.audit.log({
      action: 'create',
      resource: 'service_request',
      entityId: sr.id,
      afterState: sr,
      actorId,
    });
    this.events.emit('workshop.service_request.created', { srId: sr.id });
    return sr;
  }

  async acknowledgeServiceRequest(id: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    const sr = await this.getServiceRequest(id, actorBranchId, isSuperAdmin);
    if (sr.status !== 'OPEN') throw new BadRequestException('SR already acknowledged');
    const updated = await this.prisma.serviceRequest.update({
      where: { id },
      data: {
        status: 'ASSIGNED',
        acknowledgedAt: new Date(),
        acknowledgedById: actorId,
        updatedAt: new Date(),
      },
    });
    await this.audit.log({
      action: 'acknowledge',
      resource: 'service_request',
      entityId: id,
      beforeState: { status: sr.status },
      afterState: { status: 'ASSIGNED' },
      actorId,
    });
    return updated;
  }

  // ── Job Cards ─────────────────────────────────────────────────────────────

  async listJobCards(query: any, actorBranchId: any, isSuperAdmin: any) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.assignedToId && { assignedToId: query.assignedToId }),
      ...(query.serviceType && { serviceType: query.serviceType }),
    };
    return paginate(
      this.prisma.jobCard,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.jobCard.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getJobCard(id: any, actorBranchId: any, isSuperAdmin: any) {
    const jc = await this.prisma.jobCard.findFirst({
      where: { id, isDeleted: false },
      include: {
        serviceRequest: {
          include: {
            customer: { select: { id: true, name: true, phone: true } },
            stockItem: { include: { product: true } },
          },
        },
        assignedTo: { select: { id: true, firstName: true, lastName: true } },
        supervisor: { select: { id: true, firstName: true, lastName: true } },
        partsUsed: { include: { product: { select: { id: true, sku: true, name: true } } } },
        checklist: { orderBy: { sortOrder: 'asc' } },
        serviceInvoice: true,
        branch: { select: { id: true, code: true, name: true } },
      },
    });
    if (!jc) throw new NotFoundException('Job card not found');
    if (!isSuperAdmin && jc.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    return jc;
  }

  async createJobCard(dto: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId)
      throw new ForbiddenException('Cannot create job card for another branch');
    const code = await this.nextCode('JC', 'jobCard');
    const jc = await this.prisma.jobCard.create({
      data: {
        code,
        serviceRequestId: dto.serviceRequestId,
        branchId: dto.branchId,
        serviceType: dto.serviceType,
        assignedToId: dto.assignedToId,
        supervisorId: dto.supervisorId,
        estimatedHours: dto.estimatedHours,
        labourRate: dto.labourRate ?? 0,
        requiresApproval: dto.requiresApproval ?? false,
        createdById: actorId,
        checklist: dto.checklistItems
          ? {
              create: dto.checklistItems.map((item: any, i: any) => ({
                section: item.section,
                itemCode: item.itemCode,
                description: item.description,
                sortOrder: i,
              })),
            }
          : undefined,
      },
    });
    // Update SR status to IN_PROGRESS
    await this.prisma.serviceRequest.update({
      where: { id: dto.serviceRequestId },
      data: { status: 'IN_PROGRESS', updatedAt: new Date() },
    });
    await this.audit.log({
      action: 'create',
      resource: 'job_card',
      entityId: jc.id,
      afterState: jc,
      actorId,
    });
    this.events.emit('workshop.job_card.created', {
      jobCardId: jc.id,
      technicianId: dto.assignedToId,
    });
    return jc;
  }

  async updateJobCardStatus(id: any, status: any, data: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    const jc = await this.getJobCard(id, actorBranchId, isSuperAdmin);
    const updates: any = { status, updatedAt: new Date() };
    if (status === 'IN_PROGRESS' && !jc.startedAt) updates.startedAt = new Date();
    if (status === 'COMPLETED') {
      // HUMAN APPROVAL required — AI cannot complete job cards
      updates.completedAt = new Date();
      if (data?.actualHours) updates.actualHours = data.actualHours;
      if (data?.diagnosis) updates.diagnosis = data.diagnosis;
      if (data?.workPerformed) updates.workPerformed = data.workPerformed;
      if (data?.technicianNotes) updates.technicianNotes = data.technicianNotes;
      if (data?.recommendations) updates.recommendations = data.recommendations;
      // Recalculate totals
      const labourCost = (jc.labourRate ? Number(jc.labourRate) : 0) * (data?.actualHours ?? 0);
      const parts = await this.prisma.jobCardPart.aggregate({
        where: { jobCardId: id },
        _sum: { lineTotal: true },
      });
      const partsCost = Number(parts._sum.lineTotal ?? 0);
      updates.labourCost = labourCost;
      updates.partsCost = partsCost;
      updates.totalCost = labourCost + partsCost;
    }
    const updated = await this.prisma.jobCard.update({ where: { id }, data: updates });
    await this.audit.log({
      action: `job_card_${status.toLowerCase()}`,
      resource: 'job_card',
      entityId: id,
      beforeState: { status: jc.status },
      afterState: { status },
      actorId,
    });
    if (status === 'COMPLETED') this.events.emit('workshop.job_card.completed', { jobCardId: id });
    return updated;
  }

  // ── Parts Allocation ──────────────────────────────────────────────────────

  async allocatePart(jobCardId: any, dto: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    const jc = await this.getJobCard(jobCardId, actorBranchId, isSuperAdmin);
    if (!['OPEN', 'IN_PROGRESS', 'AWAITING_PARTS'].includes(jc.status)) {
      throw new BadRequestException('Cannot allocate parts to a job card in current status');
    }

    const part = await this.prisma.jobCardPart.create({
      data: {
        jobCardId,
        productId: dto.productId,
        stockItemId: dto.stockItemId,
        description: dto.description,
        quantity: dto.quantity,
        unitCost: dto.unitCost,
        lineTotal: dto.quantity * dto.unitCost,
        issuedById: actorId,
      },
    });

    // Deduct from stock if stockItemId provided
    if (dto.stockItemId) {
      const stockItem = await this.prisma.stockItem.findUnique({ where: { id: dto.stockItemId } });
      if (stockItem) {
        const newQty = Number(stockItem.quantityOnHand) - dto.quantity;
        if (newQty < 0) throw new BadRequestException('Insufficient stock for this part');
        await this.prisma.$transaction([
          this.prisma.stockItem.update({
            where: { id: dto.stockItemId },
            data: {
              quantityOnHand: newQty,
              quantityAvailable: newQty - Number(stockItem.quantityReserved),
            },
          }),
          this.prisma.stockMovement.create({
            data: {
              stockItemId: dto.stockItemId,
              type: 'SALES_DISPATCH',
              quantity: dto.quantity,
              quantityBefore: stockItem.quantityOnHand,
              quantityAfter: newQty,
              reference: jc.code,
              referenceType: 'JOB_CARD',
              createdById: actorId,
            },
          }),
        ]);
      }
    }

    await this.audit.log({
      action: 'allocate_part',
      resource: 'job_card',
      entityId: jobCardId,
      afterState: { partId: part.id, quantity: dto.quantity },
      actorId,
    });
    this.events.emit('workshop.part.allocated', { jobCardId, partId: part.id });
    return part;
  }

  // ── Checklist ─────────────────────────────────────────────────────────────

  async updateChecklistItem(checklistId: any, status: any, notes: any, actorId: any) {
    const item = await this.prisma.jobCardChecklist.findUnique({ where: { id: checklistId } });
    if (!item) throw new NotFoundException('Checklist item not found');
    return this.prisma.jobCardChecklist.update({
      where: { id: checklistId },
      data: { status, notes, completedById: actorId, completedAt: new Date() },
    });
  }

  // ── Service Invoice ───────────────────────────────────────────────────────

  async createServiceInvoice(jobCardId: any, dto: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    const jc = await this.getJobCard(jobCardId, actorBranchId, isSuperAdmin);
    if (jc.status !== 'COMPLETED')
      throw new BadRequestException('Job card must be COMPLETED before invoicing');
    if (jc.serviceInvoice)
      throw new ConflictException('Service invoice already exists for this job card');

    const code = await this.nextCode('SINV', 'serviceInvoice');
    const subtotal = Number(jc.labourCost) + Number(jc.partsCost) + Number(jc.externalCost);
    const vatAmount = subtotal * 0.075;
    const total = subtotal + vatAmount;

    const invoice = await this.prisma.serviceInvoice.create({
      data: {
        code,
        jobCardId,
        customerId: jc.serviceRequest?.customerId,
        branchId: jc.branchId,
        labourAmount: jc.labourCost,
        partsAmount: jc.partsCost,
        subtotal,
        vatAmount,
        total,
        amountDue: total,
        dueDate: dto.dueDate,
        notes: dto.notes,
        createdById: actorId,
      },
    });

    // Mark job card as INVOICED
    await this.prisma.jobCard.update({
      where: { id: jobCardId },
      data: { status: 'INVOICED', updatedAt: new Date() },
    });
    await this.audit.log({
      action: 'create',
      resource: 'service_invoice',
      entityId: invoice.id,
      afterState: invoice,
      actorId,
    });
    this.events.emit('workshop.service_invoice.created', { invoiceId: invoice.id, jobCardId });
    return invoice;
  }

  // ── Warranty ──────────────────────────────────────────────────────────────

  async createWarranty(dto: any, actorId: any) {
    const warranty = await this.prisma.equipmentWarranty.create({
      data: { ...dto, status: 'ACTIVE', createdById: actorId },
    });
    await this.audit.log({
      action: 'create',
      resource: 'warranty',
      entityId: warranty.id,
      afterState: warranty,
      actorId,
    });
    return warranty;
  }

  async listWarranties(query: any) {
    const where = {
      isDeleted: false,
      ...(query.status && { status: query.status }),
      ...(query.customerId && { customerId: query.customerId }),
    };
    return paginate(
      this.prisma.equipmentWarranty,
      { where, cursor: query.cursor, limit: query.limit },
      (id) =>
        this.prisma.equipmentWarranty.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  // ── Preventive Maintenance ────────────────────────────────────────────────

  async listPMSchedules(query: any, actorBranchId: any, isSuperAdmin: any) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.overdue && { nextDueDate: { lte: new Date() }, status: 'SCHEDULED' }),
    };
    return paginate(
      this.prisma.preventiveMaintenance,
      { where, cursor: query.cursor, limit: query.limit },
      (id) =>
        this.prisma.preventiveMaintenance.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async createPMSchedule(dto: any, actorId: any, actorBranchId: any, isSuperAdmin: any) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    const pm = await this.prisma.preventiveMaintenance.create({
      data: { ...dto, status: 'SCHEDULED', createdById: actorId },
    });
    await this.audit.log({
      action: 'create',
      resource: 'pm_schedule',
      entityId: pm.id,
      afterState: pm,
      actorId,
    });
    return pm;
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getWorkshopStats(actorBranchId: any, isSuperAdmin: any) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };
    const [openSRs, openJobCards, inProgress, overduepm, techUtilization, revenueMonth] =
      await Promise.all([
        this.prisma.serviceRequest.count({
          where: { ...branchFilter, isDeleted: false, status: { in: ['OPEN', 'ASSIGNED'] } },
        }),
        this.prisma.jobCard.count({ where: { ...branchFilter, isDeleted: false, status: 'OPEN' } }),
        this.prisma.jobCard.count({
          where: { ...branchFilter, isDeleted: false, status: 'IN_PROGRESS' },
        }),
        this.prisma.preventiveMaintenance.count({
          where: {
            ...branchFilter,
            isDeleted: false,
            status: 'SCHEDULED',
            nextDueDate: { lte: new Date() },
          },
        }),
        this.prisma.jobCard.groupBy({
          by: ['assignedToId'],
          where: { ...branchFilter, isDeleted: false, status: { in: ['OPEN', 'IN_PROGRESS'] } },
          _count: { id: true },
        }),
        this.prisma.serviceInvoice.aggregate({
          where: {
            ...branchFilter,
            isDeleted: false,
            createdAt: { gte: new Date(new Date().setDate(1)) },
          },
          _sum: { total: true },
        }),
      ]);
    return {
      openSRs,
      openJobCards,
      inProgress,
      overduepm,
      activeTechnicians: techUtilization.length,
      monthlyRevenue: Number(revenueMonth._sum.total ?? 0),
    };
  }
}
