/**
 * AGCOMS DealerSync ERP — Passkey Controller
 * Sprint 5 / S5-C: FIDO2 WebAuthn endpoints.
 *
 * Registration flow (requires existing JWT session):
 *   GET  /auth/passkey/register/options   — generate challenge for current user
 *   POST /auth/passkey/register/verify    — verify and store authenticator
 *
 * Authentication flow (no prior auth needed):
 *   POST /auth/passkey/authenticate/options — generate challenge (optionally filter by email)
 *   POST /auth/passkey/authenticate/verify  — verify assertion, return access token
 *
 * Management (requires JWT):
 *   GET    /auth/passkey/list          — list registered passkeys
 *   DELETE /auth/passkey/:id           — revoke a passkey
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  UseGuards,
  HttpCode,
  HttpStatus,
  Req,
} from '@nestjs/common';
import {
  ApiTags,
  ApiBearerAuth,
  ApiOperation,
  ApiParam,
  ApiProperty,
  ApiPropertyOptional,
} from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';
import { Request } from 'express';

import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { JwtAuthGuard, Public } from '../../../common/guards/auth.guards';

import { PasskeyService } from './passkey.service';

class VerifyRegistrationDto {
  @ApiProperty({ description: 'Challenge ID returned from /register/options' })
  @IsString()
  challengeId: string;

  @ApiProperty({ description: 'WebAuthn credential response from browser' })
  response: any;

  @ApiPropertyOptional({ example: 'iPhone 15 Pro' })
  @IsOptional()
  @IsString()
  deviceName?: string;
}

class AuthOptionsDto {
  @ApiPropertyOptional({
    example: 'user@agcoms.ng',
    description: 'Email to pre-filter credentials',
  })
  @IsOptional()
  @IsString()
  email?: string;
}

class VerifyAuthDto {
  @ApiProperty({ description: 'Challenge ID returned from /authenticate/options' })
  @IsString()
  challengeId: string;

  @ApiProperty({ description: 'WebAuthn assertion response from browser' })
  response: any;
}

@ApiTags('auth-passkey')
@Controller('auth/passkey')
export class PasskeyController {
  constructor(private readonly svc: PasskeyService) {}

  // ── Registration (requires authenticated session) ─────────────────────

  @Get('register/options')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Generate passkey registration challenge for the current user' })
  getRegistrationOptions(@CurrentUser() actor: JwtPayload) {
    return this.svc.generateRegistrationOptions(actor.sub);
  }

  @Post('register/verify')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify passkey registration and store authenticator' })
  verifyRegistration(@Body() dto: VerifyRegistrationDto, @CurrentUser() actor: JwtPayload) {
    return this.svc.verifyRegistration(actor.sub, dto.challengeId, dto.response, dto.deviceName);
  }

  // ── Authentication (no prior auth needed) ────────────────────────────

  @Post('authenticate/options')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Generate passkey authentication challenge' })
  getAuthOptions(@Body() dto: AuthOptionsDto) {
    return this.svc.generateAuthenticationOptions(dto.email);
  }

  @Post('authenticate/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify passkey assertion and return access token' })
  verifyAuthentication(@Body() dto: VerifyAuthDto, @Req() req: Request) {
    const ip = req.ip ?? 'unknown';
    return this.svc.verifyAuthentication(dto.challengeId, dto.response, ip);
  }

  // ── Management ────────────────────────────────────────────────────────

  @Get('list')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'List all registered passkeys for the current user' })
  listPasskeys(@CurrentUser() actor: JwtPayload) {
    return this.svc.listPasskeys(actor.sub);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Revoke a registered passkey' })
  @ApiParam({ name: 'id', description: 'PasskeyAuthenticator UUID' })
  revokePasskey(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return this.svc.revokePasskey(id, actor.sub);
  }
}
