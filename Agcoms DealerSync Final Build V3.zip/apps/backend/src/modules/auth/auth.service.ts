import { randomBytes, createHash } from 'crypto';

import { JwtPayload } from '@agcoms/types';
import { ForbiddenException, Injectable, Logger, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { hash, verify } from '@node-rs/argon2';
import { User } from '@prisma/client';
import { authenticator } from 'otplib';
import * as qrcode from 'qrcode';

import { AuditService } from '../../audit/audit.service';
import { AppConfig } from '../../config/app.config';
import { PrismaService } from '../../prisma/prisma.service';

const ACCOUNT_LOCK_ATTEMPTS = 5;
const ACCOUNT_LOCK_MINUTES = 15;
const RESET_TOKEN_TTL_MINUTES = 30;
const MFA_CHALLENGE_TTL_MINUTES = 5;
const MFA_MAX_ATTEMPTS = 3;

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly appCfg: AppConfig;

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
  ) {
    this.appCfg = this.config.getOrThrow<AppConfig>('app');
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  private hashToken(raw: string): string {
    return createHash('sha256').update(raw).digest('hex');
  }

  private generateSecureToken(): string {
    return randomBytes(48).toString('hex');
  }

  async resolvePermissions(userId: string): Promise<string[]> {
    const rows = await this.prisma.userRole.findMany({
      where: { userId },
      include: {
        role: {
          include: { permissions: { include: { permission: true } } },
        },
      },
    });
    const codes = new Set<string>();
    for (const ur of rows) {
      for (const rp of ur.role.permissions) {
        codes.add(rp.permission.code);
      }
    }
    return Array.from(codes);
  }

  // ── Token generation ─────────────────────────────────────────────────────

  async generateTokens(
    user: User,
    sessionId: string,
    roles: string[],
    permissions: string[],
  ): Promise<{ accessToken: string; refreshToken: string; expiresIn: number }> {
    const payload: Omit<JwtPayload, 'iat' | 'exp'> = {
      sub: user.id,
      email: user.email,
      firstName: (user as any).firstName ?? '',
      lastName: (user as any).lastName ?? '',
      branchId: user.branchId,
      branchCode: (user as any).branchCode ?? '',
      branchIds: (user as any).branchIds ?? [user.branchId],
      roles,
      permissions,
      // Super-admin status derives from the SUPER_ADMIN role, not a User column
      // (the User model has no isSuperAdmin field — it is role-based by design).
      isSuperAdmin: roles.includes('SUPER_ADMIN'),
      type: 'internal',
      sessionId,
      iss: this.appCfg.jwt.issuer,
      aud: this.appCfg.jwt.audience,
    };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwt.signAsync(payload, { expiresIn: this.appCfg.jwt.accessTtl }),
      this.generateSecureToken(),
    ]);

    return { accessToken, refreshToken, expiresIn: this.appCfg.jwt.accessTtl };
  }

  // ── Login ─────────────────────────────────────────────────────────────────

  async login(
    email: string,
    password: string,
    meta: { ip?: string; ua?: string; deviceFingerprint?: string },
  ) {
    const user = await this.prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    // Always record attempt before throwing (timing-safe)
    const recordAttempt = async (succeeded: boolean, failReason?: string) => {
      await this.prisma.loginAttempt.create({
        data: {
          email: email.toLowerCase().trim(),
          userId: user?.id,
          ipAddress: meta.ip,
          userAgent: meta.ua,
          succeeded,
          failReason,
          mfaRequired: user?.mfaEnabled ?? false,
        },
      });
    };

    if (!user || !user.passwordHash) {
      await recordAttempt(false, 'user_not_found');
      throw new UnauthorizedException({
        code: 'INVALID_CREDENTIALS',
        message: 'Invalid credentials',
      });
    }

    if (user.deletedAt) {
      await recordAttempt(false, 'user_archived');
      throw new ForbiddenException({ code: 'ACCOUNT_ARCHIVED', message: 'Account unavailable' });
    }

    // Account lock check
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      await recordAttempt(false, 'account_locked');
      const until = user.lockedUntil.toISOString();
      throw new ForbiddenException({
        code: 'ACCOUNT_LOCKED',
        message: `Account locked until ${until}. Contact your administrator.`,
      });
    }

    if (user.status !== 'active') {
      await recordAttempt(false, `status_${user.status}`);
      throw new ForbiddenException({
        code: `ACCOUNT_${user.status.toUpperCase()}`,
        message: 'Account unavailable',
      });
    }

    // Verify password
    const valid = await verify(user.passwordHash, password);
    if (!valid) {
      const attempts = user.failedLoginAttempts + 1;
      const shouldLock = attempts >= ACCOUNT_LOCK_ATTEMPTS;
      await this.prisma.user.update({
        where: { id: user.id },
        data: {
          failedLoginAttempts: attempts,
          lockedUntil: shouldLock ? new Date(Date.now() + ACCOUNT_LOCK_MINUTES * 60_000) : null,
        },
      });
      await recordAttempt(false, 'wrong_password');

      await this.audit.record({
        action: 'login_failed',
        resource: 'users',
        resourceId: user.id,
        actorUserId: user.id,
        ipAddress: meta.ip,
        userAgent: meta.ua,
      });

      throw new UnauthorizedException({
        code: 'INVALID_CREDENTIALS',
        message: 'Invalid credentials',
      });
    }

    // Reset failed attempts
    if (user.failedLoginAttempts > 0) {
      await this.prisma.user.update({
        where: { id: user.id },
        data: { failedLoginAttempts: 0, lockedUntil: null },
      });
    }

    // MFA required
    if (user.mfaEnabled) {
      const challenge = await this.prisma.mfaChallenge.create({
        data: {
          userId: user.id,
          expiresAt: new Date(Date.now() + MFA_CHALLENGE_TTL_MINUTES * 60_000),
          ipAddress: meta.ip,
        },
      });
      await recordAttempt(true, undefined);
      await this.audit.record({
        action: 'mfa_challenged',
        resource: 'users',
        resourceId: user.id,
        actorUserId: user.id,
        ipAddress: meta.ip,
        userAgent: meta.ua,
      });
      return { requiresMfa: true, mfaChallengeId: challenge.id };
    }

    return this.createSession(user, meta);
  }

  // ── MFA verification ──────────────────────────────────────────────────────

  async verifyMfa(
    challengeId: string,
    code: string,
    meta: { ip?: string; ua?: string; deviceFingerprint?: string },
  ) {
    const challenge = await this.prisma.mfaChallenge.findUnique({ where: { id: challengeId } });

    if (!challenge || challenge.consumedAt || challenge.expiresAt < new Date()) {
      throw new UnauthorizedException({
        code: 'MFA_CHALLENGE_INVALID',
        message: 'Invalid or expired MFA challenge',
      });
    }

    if (challenge.attempts >= MFA_MAX_ATTEMPTS) {
      throw new ForbiddenException({ code: 'MFA_MAX_ATTEMPTS', message: 'Too many MFA attempts' });
    }

    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: challenge.userId } });
    if (!user.mfaSecretEncrypted) {
      throw new UnauthorizedException({
        code: 'MFA_NOT_CONFIGURED',
        message: 'MFA not configured',
      });
    }

    authenticator.options = { window: this.appCfg.totp.window };
    const valid = authenticator.check(code, user.mfaSecretEncrypted);

    await this.prisma.mfaChallenge.update({
      where: { id: challengeId },
      data: { attempts: { increment: 1 }, consumedAt: valid ? new Date() : undefined },
    });

    if (!valid) {
      await this.audit.record({
        action: 'mfa_failed',
        resource: 'users',
        resourceId: user.id,
        actorUserId: user.id,
        ipAddress: meta.ip,
        userAgent: meta.ua,
      });
      throw new UnauthorizedException({ code: 'MFA_INVALID', message: 'Invalid MFA code' });
    }

    await this.audit.record({
      action: 'mfa_succeeded',
      resource: 'users',
      resourceId: user.id,
      actorUserId: user.id,
      ipAddress: meta.ip,
      userAgent: meta.ua,
    });

    return this.createSession(user, meta);
  }

  private async createSession(
    user: User,
    meta: { ip?: string; ua?: string; deviceFingerprint?: string },
  ) {
    const roles = await this.prisma.userRole.findMany({
      where: { userId: user.id },
      select: { role: { select: { code: true } } },
    });
    const roleCodes = roles.map((r) => r.role.code);
    const permissions = await this.resolvePermissions(user.id);

    const refreshToken = this.generateSecureToken();
    const expiresAt = new Date(Date.now() + this.appCfg.jwt.refreshTtl * 1000);

    const session = await this.prisma.session.create({
      data: {
        userId: user.id,
        branchId: user.branchId,
        refreshTokenHash: this.hashToken(refreshToken),
        deviceFingerprint: meta.deviceFingerprint,
        userAgent: meta.ua,
        ipAddress: meta.ip,
        expiresAt,
      },
    });

    const { accessToken, expiresIn } = await this.generateTokens(
      user,
      session.id,
      roleCodes,
      permissions,
    );

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), lastLoginIp: meta.ip },
    });

    await this.audit.record({
      action: 'login',
      resource: 'users',
      resourceId: user.id,
      actorUserId: user.id,
      actorRole: roleCodes[0],
      ipAddress: meta.ip,
      userAgent: meta.ua,
    });

    return {
      requiresMfa: false,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: roleCodes,
        permissions,
        branchId: user.branchId,
        mfaEnabled: user.mfaEnabled,
      },
      tokens: {
        accessToken,
        refreshToken,
        expiresIn,
        tokenType: 'Bearer' as const,
      },
    };
  }

  // ── Refresh token rotation ────────────────────────────────────────────────

  async refresh(rawToken: string, meta: { ip?: string; ua?: string }) {
    const hash = this.hashToken(rawToken);
    const session = await this.prisma.session.findFirst({
      where: { OR: [{ refreshTokenHash: hash }, { previousTokenHash: hash }] },
      include: { user: true },
    });

    if (!session || session.revokedAt || session.expiresAt < new Date()) {
      throw new UnauthorizedException({
        code: 'SESSION_INVALID',
        message: 'Invalid or expired session',
      });
    }

    // Detect token reuse (replay attack)
    if (session.previousTokenHash === hash) {
      // Revoke entire session — family reuse detected
      await this.prisma.session.update({
        where: { id: session.id },
        data: { revokedAt: new Date(), revokedReason: 'token_reuse_detected' },
      });
      this.logger.warn(`Token reuse detected for session ${session.id}, user ${session.userId}`);
      await this.audit.record({
        action: 'logout',
        resource: 'sessions',
        resourceId: session.id,
        actorUserId: session.userId,
        ipAddress: meta.ip,
        afterState: { revokedReason: 'token_reuse_detected' },
      });
      throw new UnauthorizedException({
        code: 'TOKEN_REUSE',
        message: 'Session revoked due to security concern',
      });
    }

    const { user } = session;
    if (user.status !== 'active') {
      throw new ForbiddenException({
        code: `ACCOUNT_${user.status.toUpperCase()}`,
        message: 'Account unavailable',
      });
    }

    const newRawToken = this.generateSecureToken();
    const newExpiresAt = new Date(Date.now() + this.appCfg.jwt.refreshTtl * 1000);

    await this.prisma.session.update({
      where: { id: session.id },
      data: {
        refreshTokenHash: this.hashToken(newRawToken),
        previousTokenHash: hash,
        expiresAt: newExpiresAt,
        lastUsedAt: new Date(),
        ipAddress: meta.ip,
        userAgent: meta.ua,
      },
    });

    const roleCodes = (
      await this.prisma.userRole.findMany({
        where: { userId: user.id },
        select: { role: { select: { code: true } } },
      })
    ).map((r) => r.role.code);
    const permissions = await this.resolvePermissions(user.id);

    const { accessToken, expiresIn } = await this.generateTokens(
      user,
      session.id,
      roleCodes,
      permissions,
    );

    return {
      tokens: { accessToken, refreshToken: newRawToken, expiresIn, tokenType: 'Bearer' as const },
    };
  }

  // ── Logout ────────────────────────────────────────────────────────────────

  async logout(sessionId: string, userId: string, meta: { ip?: string }) {
    await this.prisma.session.updateMany({
      where: { id: sessionId, userId, revokedAt: null },
      data: { revokedAt: new Date(), revokedReason: 'user_logout' },
    });
    await this.audit.record({
      action: 'logout',
      resource: 'sessions',
      resourceId: sessionId,
      actorUserId: userId,
      ipAddress: meta.ip,
    });
  }

  async logoutAll(userId: string, meta: { ip?: string }) {
    await this.prisma.session.updateMany({
      where: { userId, revokedAt: null },
      data: { revokedAt: new Date(), revokedReason: 'user_logout_all' },
    });
    await this.audit.record({
      action: 'logout',
      resource: 'sessions',
      resourceId: userId,
      actorUserId: userId,
      ipAddress: meta.ip,
      afterState: { scope: 'all_sessions' },
    });
  }

  // ── Password reset ────────────────────────────────────────────────────────

  async requestPasswordReset(email: string, meta: { ip?: string }) {
    const user = await this.prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });
    // Always return success to prevent user enumeration
    if (!user || user.deletedAt || user.status === 'archived') return;

    const token = this.generateSecureToken();
    await this.prisma.passwordReset.create({
      data: {
        userId: user.id,
        tokenHash: this.hashToken(token),
        expiresAt: new Date(Date.now() + RESET_TOKEN_TTL_MINUTES * 60_000),
        ipAddress: meta.ip,
      },
    });
    // In production: queue email delivery via BullMQ
    this.logger.log(`Password reset token generated for ${email} (send via email queue)`);
    // TODO Phase 1: dispatch email via BullMQ job { type: 'email.password_reset', token }
  }

  async resetPassword(token: string, newPassword: string, meta: { ip?: string }) {
    const tokenHash = this.hashToken(token);
    const reset = await this.prisma.passwordReset.findUnique({ where: { tokenHash: tokenHash } });

    if (!reset || reset.consumedAt || reset.expiresAt < new Date()) {
      throw new UnauthorizedException({
        code: 'RESET_TOKEN_INVALID',
        message: 'Invalid or expired reset token',
      });
    }

    const passwordHash = await hash(newPassword, {
      memoryCost: 19_456,
      timeCost: 2,
      parallelism: 1,
    });

    await this.prisma.$transaction([
      this.prisma.passwordReset.update({
        where: { id: reset.id },
        data: { consumedAt: new Date() },
      }),
      this.prisma.user.update({
        where: { id: reset.userId },
        data: {
          passwordHash,
          passwordChangedAt: new Date(),
          failedLoginAttempts: 0,
          lockedUntil: null,
        },
      }),
      // Revoke all sessions on password reset
      this.prisma.session.updateMany({
        where: { userId: reset.userId, revokedAt: null },
        data: { revokedAt: new Date(), revokedReason: 'password_reset' },
      }),
    ]);

    await this.audit.record({
      action: 'update',
      resource: 'users',
      resourceId: reset.userId,
      actorUserId: reset.userId,
      ipAddress: meta.ip,
      afterState: { passwordChanged: true },
    });
  }

  async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string,
    sessionId: string,
    meta: { ip?: string },
  ) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.passwordHash) throw new ForbiddenException('No password set');

    const valid = await verify(user.passwordHash, currentPassword);
    if (!valid)
      throw new UnauthorizedException({
        code: 'WRONG_PASSWORD',
        message: 'Current password incorrect',
      });

    const passwordHash = await hash(newPassword, {
      memoryCost: 19_456,
      timeCost: 2,
      parallelism: 1,
    });

    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: userId },
        data: { passwordHash, passwordChangedAt: new Date() },
      }),
      this.prisma.session.updateMany({
        where: { userId, revokedAt: null, NOT: { id: sessionId } },
        data: { revokedAt: new Date(), revokedReason: 'password_changed' },
      }),
    ]);

    await this.audit.record({
      action: 'update',
      resource: 'users',
      resourceId: userId,
      actorUserId: userId,
      ipAddress: meta.ip,
      afterState: { passwordChanged: true },
    });
  }

  // ── MFA setup ─────────────────────────────────────────────────────────────

  async setupMfa(userId: string, password: string) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.passwordHash) throw new ForbiddenException('No password set');

    const valid = await verify(user.passwordHash, password);
    if (!valid)
      throw new UnauthorizedException({ code: 'WRONG_PASSWORD', message: 'Incorrect password' });
    if (user.mfaEnabled)
      throw new ForbiddenException({
        code: 'MFA_ALREADY_ENABLED',
        message: 'MFA is already enabled',
      });

    authenticator.options = {};
    const secret = authenticator.generateSecret();
    const otpauthUrl = authenticator.keyuri(user.email, this.appCfg.totp.issuer, secret);
    const qrDataUrl = await qrcode.toDataURL(otpauthUrl);

    // Store secret temporarily — confirmed on verifyMfaSetup
    await this.prisma.user.update({
      where: { id: userId },
      data: { mfaSecretEncrypted: secret }, // In prod: encrypt with KMS key before storing
    });

    return { secret, otpauthUrl, qrDataUrl };
  }

  async verifyMfaSetup(userId: string, code: string, meta: { ip?: string }) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.mfaSecretEncrypted) {
      throw new ForbiddenException({
        code: 'MFA_SETUP_NOT_INITIATED',
        message: 'MFA setup not initiated',
      });
    }
    if (user.mfaEnabled) {
      throw new ForbiddenException({ code: 'MFA_ALREADY_ENABLED', message: 'MFA already enabled' });
    }

    authenticator.options = { window: this.appCfg.totp.window };
    const valid = authenticator.check(code, user.mfaSecretEncrypted);
    if (!valid)
      throw new UnauthorizedException({ code: 'MFA_INVALID', message: 'Invalid TOTP code' });

    await this.prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: true },
    });

    await this.audit.record({
      action: 'update',
      resource: 'users',
      resourceId: userId,
      actorUserId: userId,
      ipAddress: meta.ip,
      afterState: { mfaEnabled: true },
    });
  }

  async disableMfa(userId: string, password: string, meta: { ip?: string }) {
    const user = await this.prisma.user.findUniqueOrThrow({ where: { id: userId } });
    if (!user.passwordHash) throw new ForbiddenException('No password set');

    const valid = await verify(user.passwordHash, password);
    if (!valid)
      throw new UnauthorizedException({ code: 'WRONG_PASSWORD', message: 'Incorrect password' });

    await this.prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: false, mfaSecretEncrypted: null },
    });

    await this.audit.record({
      action: 'update',
      resource: 'users',
      resourceId: userId,
      actorUserId: userId,
      ipAddress: meta.ip,
      afterState: { mfaEnabled: false },
    });
  }
}
