/**
 * AGCOMS DealerSync ERP — Auth Controller
 *
 * Authentication surface implemented by AuthService:
 *   - POST /auth/login        (public, throttled)  — password → access token (+ MFA challenge)
 *   - POST /auth/mfa/verify   (public, throttled)  — MFA code  → access token
 *   - POST /auth/refresh      (public, throttled)  — rotate tokens (refresh token from cookie)
 *   - POST /auth/logout       (authenticated)      — revoke current session
 *   - POST /auth/logout-all   (authenticated)      — revoke all sessions
 *
 * §5 Security model:
 *   - Refresh token is delivered as an HttpOnly, SameSite=Strict cookie (never exposed to JS).
 *   - Access token is returned in the body for use as a Bearer token (short-lived).
 *   - Login / MFA / refresh are @Public (no JWT yet) but rate-limited against brute force.
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Post,
  Body,
  Req,
  Res,
  UseGuards,
  HttpCode,
  HttpStatus,
  UnauthorizedException,
} from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import type { Request, Response } from 'express';

import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { JwtAuthGuard, Public } from '../../common/guards/auth.guards';

import { AuthService } from './auth.service';
import { LoginDto, MfaVerifyDto } from './dto/auth.dto';

const REFRESH_COOKIE = 'refresh_token';

function reqMeta(req: Request): { ip?: string; ua?: string } {
  const ip =
    (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ??
    req.socket?.remoteAddress ??
    undefined;
  return { ip, ua: req.headers['user-agent'] };
}

@ApiTags('authentication')
@Controller('auth')
export class AuthController {
  constructor(private readonly svc: AuthService) {}

  // Sets the refresh token as a hardened HttpOnly cookie scoped to the auth routes.
  private setRefreshCookie(res: Response, refreshToken: string): void {
    res.cookie(REFRESH_COOKIE, refreshToken, {
      httpOnly: true,
      sameSite: 'strict',
      secure: process.env['NODE_ENV'] === 'production',
      path: '/api/v1/auth',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });
  }

  private clearRefreshCookie(res: Response): void {
    res.clearCookie(REFRESH_COOKIE, { path: '/api/v1/auth' });
  }

  // Splits the service result: refresh token → cookie, everything else → body.
  private respondWithSession(res: Response, result: any): unknown {
    if (result?.tokens?.refreshToken) {
      this.setRefreshCookie(res, result.tokens.refreshToken);
      const { refreshToken: _omit, ...safeTokens } = result.tokens;
      return { ...result, tokens: safeTokens };
    }
    return result; // MFA-challenge response (no tokens yet)
  }

  @Post('login')
  @Public()
  @HttpCode(HttpStatus.OK)
  @Throttle({ global: { limit: 5, ttl: 60_000 } })
  @ApiOperation({ summary: 'Authenticate with email + password. Returns an access token or an MFA challenge.' })
  async login(@Body() dto: LoginDto, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const result = await this.svc.login(dto.email, dto.password, reqMeta(req));
    return this.respondWithSession(res, result);
  }

  @Post('mfa/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  @Throttle({ global: { limit: 5, ttl: 60_000 } })
  @ApiOperation({ summary: 'Complete login by verifying the MFA (TOTP) code.' })
  async verifyMfa(@Body() dto: MfaVerifyDto, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const result = await this.svc.verifyMfa(dto.challengeToken, dto.code, reqMeta(req));
    return this.respondWithSession(res, result);
  }

  @Post('refresh')
  @Public()
  @HttpCode(HttpStatus.OK)
  @Throttle({ global: { limit: 20, ttl: 60_000 } })
  @ApiOperation({ summary: 'Rotate tokens using the HttpOnly refresh cookie (or a refreshToken body field).' })
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response, @Body('refreshToken') bodyToken?: string) {
    const cookies = (req as Request & { cookies?: Record<string, string> }).cookies;
    const token = cookies?.[REFRESH_COOKIE] ?? bodyToken;
    if (!token || typeof token !== 'string') {
      throw new UnauthorizedException('Refresh token is required');
    }
    const result = await this.svc.refresh(token, reqMeta(req));
    return this.respondWithSession(res, result);
  }

  @Post('logout')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Revoke the current session and clear the refresh cookie.' })
  async logout(@CurrentUser() actor: JwtPayload, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    await this.svc.logout(actor.sessionId, actor.sub, reqMeta(req));
    this.clearRefreshCookie(res);
    return { success: true };
  }

  @Post('logout-all')
  @UseGuards(JwtAuthGuard)
  @ApiBearerAuth('JWT')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Revoke all sessions for the current user and clear the refresh cookie.' })
  async logoutAll(@CurrentUser() actor: JwtPayload, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    await this.svc.logoutAll(actor.sub, reqMeta(req));
    this.clearRefreshCookie(res);
    return { success: true };
  }
}
