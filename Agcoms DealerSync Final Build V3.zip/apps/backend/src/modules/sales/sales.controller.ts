/**
 * AGCOMS DealerSync ERP — Sales Controller
 * Sprint 1 Fix: Controller was missing — no HTTP endpoints existed for this module.
 *
 * Base CRUD scaffold. Domain-specific endpoints are in separate files
 * per feature (e.g. crm.customers.controller.ts, crm.leads.controller.ts).
 * Every route requires JWT auth via the global JwtAuthGuard registered in main.ts.
 */
import { JwtPayload } from '@agcoms/types';
import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';

import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { JwtAuthGuard, PermissionsGuard, RequirePermission } from '../../common/guards/auth.guards';

import { SalesService } from './sales.service';

@ApiTags('sales')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('sales/quotations')
export class SalesController {
  constructor(private readonly svc: SalesService) {}

  @Get()
  @RequirePermission('sales:read')
  @ApiOperation({ summary: 'List sales records — paginated + branch-scoped' })
  @ApiQuery({ name: 'limit', required: false, type: Number })
  @ApiQuery({ name: 'page', required: false, type: Number })
  findAll(@Query() query: Record<string, string>, @CurrentUser() actor: JwtPayload) {
    const branchId = actor.isSuperAdmin ? query['branchId'] : actor.branchId;
    return (this.svc as any).findAll?.({ ...query, branchId }, actor) ?? { items: [], total: 0 };
  }

  @Get(':id')
  @RequirePermission('sales:read')
  @ApiOperation({ summary: 'Get single sales by ID' })
  findOne(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).findOne?.(id, actor);
  }

  @Post()
  @RequirePermission('sales:write')
  @ApiOperation({ summary: 'Create sales record' })
  create(@Body() dto: Record<string, unknown>, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).create?.(dto, actor);
  }

  @Patch(':id')
  @RequirePermission('sales:write')
  @ApiOperation({ summary: 'Update sales record (partial)' })
  update(
    @Param('id') id: string,
    @Body() dto: Record<string, unknown>,
    @CurrentUser() actor: JwtPayload,
  ) {
    return (this.svc as any).update?.(id, dto, actor);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @RequirePermission('sales:delete')
  @ApiOperation({ summary: 'Soft-delete sales record' })
  remove(@Param('id') id: string, @CurrentUser() actor: JwtPayload) {
    return (this.svc as any).remove?.(id, actor);
  }
}
