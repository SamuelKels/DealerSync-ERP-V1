import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  Prisma,
  QuotationStatus,
  SalesOrderStatus,
  InvoiceStatus,
  Currency,
} from '@prisma/client';

import { AuditService } from '../../audit/audit.service';
import { PaginationDto, paginate } from '../../common/pagination';
import { PrismaService } from '../../prisma/prisma.service';

// ── DTOs ────────────────────────────────────────────────────────────────────

export interface QuotationLineInput {
  productId: string;
  description: string;
  quantity: number;
  unitPrice: number;
  discountPct?: number;
  vatRate?: number;
  notes?: string;
}

export interface CreateQuotationDto {
  customerId: string;
  rfqId?: string;
  branchId: string;
  currency?: Currency;
  exchangeRate?: number;
  validUntil?: Date;
  paymentTerms?: number;
  deliveryTerms?: string;
  notes?: string;
  internalNotes?: string;
  lines: QuotationLineInput[];
}

export interface CreateSalesOrderDto {
  customerId: string;
  quotationId?: string;
  branchId: string;
  currency?: Currency;
  exchangeRate?: number;
  paymentTerms?: number;
  deliveryAddress?: string;
  expectedDelivery?: Date;
  notes?: string;
  lines: {
    productId: string;
    description: string;
    quantity: number;
    unitPrice: number;
    discountPct?: number;
    vatRate?: number;
  }[];
}

export interface CreateInvoiceDto {
  customerId: string;
  salesOrderId?: string;
  branchId: string;
  currency?: Currency;
  exchangeRate?: number;
  dueDate?: Date;
  paymentTerms?: number;
  notes?: string;
  lines: {
    productId?: string;
    description: string;
    quantity: number;
    unitPrice: number;
    vatRate?: number;
  }[];
}

// ── Pricing engine ────────────────────────────────────────────────────────────

interface LineCalc {
  unitPrice: number;
  quantity: number;
  discountPct: number;
  vatRate: number;
}

function calculateLine(input: LineCalc) {
  const gross = input.unitPrice * input.quantity;
  const discountAmt = gross * (input.discountPct / 100);
  const net = gross - discountAmt;
  const vatAmount = net * (input.vatRate / 100);
  const lineTotal = net + vatAmount;
  return { gross, discountAmt, net, vatAmount, lineTotal };
}

function calculateTotals(
  lines: { lineTotal: number; vatAmount: number; discountAmt: number; gross: number }[],
) {
  const subtotal = lines.reduce((s, l) => s + l.gross - l.discountAmt, 0);
  const vatAmount = lines.reduce((s, l) => s + l.vatAmount, 0);
  const discountAmount = lines.reduce((s, l) => s + l.discountAmt, 0);
  const total = subtotal + vatAmount;
  return { subtotal, vatAmount, discountAmount, total };
}

// ── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class SalesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly events: EventEmitter2,
  ) {}

  private async nextCode(prefix: string, model: keyof typeof this.prisma): Promise<string> {
    const year = new Date().getFullYear();
    const count = await (this.prisma[model] as any).count({
      where: { createdAt: { gte: new Date(`${year}-01-01`) } },
    });
    return `${prefix}-${year}-${String(count + 1).padStart(4, '0')}`;
  }

  private assertBranch(dto: { branchId: string }, actorBranchId: string, isSuperAdmin: boolean) {
    if (!isSuperAdmin && dto.branchId !== actorBranchId) {
      throw new ForbiddenException('Cannot operate on another branch');
    }
  }

  // ── Quotations ────────────────────────────────────────────────────────────

  async listQuotations(
    query: PaginationDto & { branchId?: string; status?: QuotationStatus; customerId?: string },
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where: Prisma.QuotationWhereInput = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.customerId && { customerId: query.customerId }),
    };
    return paginate(
      this.prisma.quotation,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.quotation.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async getQuotation(id: string, actorBranchId: string, isSuperAdmin: boolean) {
    const q = await this.prisma.quotation.findFirst({
      where: { id, isDeleted: false },
      include: {
        customer: { select: { id: true, code: true, name: true, email: true, phone: true } },
        branch: { select: { id: true, code: true, name: true } },
        lines: {
          include: { product: { select: { id: true, sku: true, name: true } } },
          orderBy: { lineNumber: 'asc' },
        },
        createdBy: { select: { id: true, firstName: true, lastName: true } },
        approvedBy: { select: { id: true, firstName: true, lastName: true } },
      },
    });
    if (!q) throw new NotFoundException('Quotation not found');
    if (!isSuperAdmin && q.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    return q;
  }

  async createQuotation(
    dto: CreateQuotationDto,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    this.assertBranch(dto, actorBranchId, isSuperAdmin);

    const code = await this.nextCode('QTN', 'quotation');

    // Calculate line amounts using pricing engine
    const computedLines = dto.lines.map((l, i) => {
      const calc = calculateLine({
        unitPrice: l.unitPrice,
        quantity: l.quantity,
        discountPct: l.discountPct ?? 0,
        vatRate: l.vatRate ?? 7.5,
      });
      return { ...l, lineNumber: i + 1, ...calc };
    });

    const totals = calculateTotals(computedLines);

    const quotation = await this.prisma.quotation.create({
      data: {
        code,
        customerId: dto.customerId,
        rfqId: dto.rfqId,
        branchId: dto.branchId,
        currency: dto.currency ?? 'NGN',
        exchangeRate: dto.exchangeRate ?? 1,
        subtotal: totals.subtotal,
        vatAmount: totals.vatAmount,
        discountAmount: totals.discountAmount,
        total: totals.total,
        validUntil: dto.validUntil,
        paymentTerms: dto.paymentTerms ?? 30,
        deliveryTerms: dto.deliveryTerms,
        notes: dto.notes,
        internalNotes: dto.internalNotes,
        createdById: actorId,
        lines: {
          create: computedLines.map((l) => ({
            lineNumber: l.lineNumber,
            productId: l.productId,
            description: l.description,
            quantity: l.quantity,
            unit: 'unit',
            unitPrice: l.unitPrice,
            discountPct: l.discountPct ?? 0,
            discountAmt: l.discountAmt,
            vatRate: l.vatRate ?? 7.5,
            vatAmount: l.vatAmount,
            lineTotal: l.lineTotal,
            notes: l.notes,
          })),
        },
      },
      include: { lines: true },
    });

    await this.audit.log({
      action: 'create',
      resource: 'quotation',
      entityId: quotation.id,
      afterState: quotation,
      actorId,
    });
    this.events.emit('sales.quotation.created', { quotationId: quotation.id });
    return quotation;
  }

  async submitQuotationForApproval(
    id: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const q = await this.getQuotation(id, actorBranchId, isSuperAdmin);
    if (q.status !== 'DRAFT')
      throw new BadRequestException('Only DRAFT quotations can be submitted');

    const updated = await this.prisma.quotation.update({
      where: { id },
      data: { status: 'PENDING_APPROVAL', submittedAt: new Date(), submittedById: actorId },
    });

    await this.audit.log({
      action: 'submit_for_approval',
      resource: 'quotation',
      entityId: id,
      beforeState: { status: q.status },
      afterState: { status: 'PENDING_APPROVAL' },
      actorId,
    });
    this.events.emit('sales.quotation.submitted', { quotationId: id });
    return updated;
  }

  async approveQuotation(
    id: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const q = await this.getQuotation(id, actorBranchId, isSuperAdmin);
    if (q.status !== 'PENDING_APPROVAL')
      throw new BadRequestException('Only PENDING_APPROVAL quotations can be approved');

    // AI GOVERNANCE: approval is a human action — this endpoint is only reachable
    // by users with the quotes:approve permission. The AI layer can only recommend.
    const updated = await this.prisma.quotation.update({
      where: { id },
      data: { status: 'APPROVED', approvedAt: new Date(), approvedById: actorId },
    });

    await this.audit.log({
      action: 'approve',
      resource: 'quotation',
      entityId: id,
      beforeState: { status: q.status },
      afterState: { status: 'APPROVED' },
      actorId,
    });
    this.events.emit('sales.quotation.approved', { quotationId: id, actorId });
    return updated;
  }

  async rejectQuotation(
    id: string,
    reason: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const q = await this.getQuotation(id, actorBranchId, isSuperAdmin);
    if (q.status !== 'PENDING_APPROVAL')
      throw new BadRequestException('Only pending quotations can be rejected');

    const updated = await this.prisma.quotation.update({
      where: { id },
      data: {
        status: 'REJECTED',
        rejectedAt: new Date(),
        rejectedById: actorId,
        rejectionReason: reason,
      },
    });

    await this.audit.log({
      action: 'reject',
      resource: 'quotation',
      entityId: id,
      beforeState: { status: q.status },
      afterState: { status: 'REJECTED', reason },
      actorId,
    });
    return updated;
  }

  async convertQuotationToSalesOrder(
    quotationId: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const q = await this.getQuotation(quotationId, actorBranchId, isSuperAdmin);
    if (q.status !== 'APPROVED')
      throw new BadRequestException('Only APPROVED quotations can be converted');

    const soCode = await this.nextCode('SO', 'salesOrder');

    const salesOrder = await this.prisma.$transaction(async (tx: any) => {
      const so = await tx.salesOrder.create({
        data: {
          code: soCode,
          customerId: q.customerId,
          quotationId: q.id,
          branchId: q.branchId,
          currency: q.currency,
          exchangeRate: q.exchangeRate,
          subtotal: q.subtotal,
          vatAmount: q.vatAmount,
          discountAmount: q.discountAmount,
          total: q.total,
          paymentTerms: q.paymentTerms,
          deliveryTerms: q.deliveryTerms,
          notes: q.notes,
          createdById: actorId,
          lines: {
            create: q.lines.map((l: any, i: any) => ({
              lineNumber: i + 1,
              productId: l.productId,
              description: l.description,
              quantity: l.quantity,
              unit: l.unit,
              unitPrice: l.unitPrice,
              discountPct: l.discountPct,
              vatRate: l.vatRate,
              lineTotal: l.lineTotal,
            })),
          },
        },
        include: { lines: true },
      });

      // Mark quotation as converted
      await tx.quotation.update({
        where: { id: quotationId },
        data: { status: 'CONVERTED' },
      });

      return so;
    });

    await this.audit.log({
      action: 'convert_to_so',
      resource: 'quotation',
      entityId: quotationId,
      afterState: { salesOrderId: salesOrder.id },
      actorId,
    });
    this.events.emit('sales.order.created', { salesOrderId: salesOrder.id });
    return salesOrder;
  }

  // ── Sales Orders ──────────────────────────────────────────────────────────

  async listSalesOrders(
    query: PaginationDto & { branchId?: string; status?: SalesOrderStatus },
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where: Prisma.SalesOrderWhereInput = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
    };
    return paginate(
      this.prisma.salesOrder,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.salesOrder.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async confirmSalesOrder(
    id: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const so = await this.prisma.salesOrder.findFirst({ where: { id, isDeleted: false } });
    if (!so) throw new NotFoundException('Sales order not found');
    if (!isSuperAdmin && so.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    if (so.status !== 'DRAFT') throw new BadRequestException('Only DRAFT orders can be confirmed');

    const updated = await this.prisma.salesOrder.update({
      where: { id },
      data: { status: 'CONFIRMED', confirmedAt: new Date(), confirmedById: actorId },
    });

    await this.audit.log({
      action: 'confirm',
      resource: 'sales_order',
      entityId: id,
      beforeState: { status: so.status },
      afterState: { status: 'CONFIRMED' },
      actorId,
    });
    this.events.emit('sales.order.confirmed', { salesOrderId: id });
    return updated;
  }

  // ── Invoices ──────────────────────────────────────────────────────────────
  // ACID-compliant: invoices are immutable once ISSUED.
  // Corrections go through CreditNote workflow.

  async listInvoices(
    query: PaginationDto & { branchId?: string; status?: InvoiceStatus; customerId?: string },
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const allowedBranch = isSuperAdmin ? query.branchId : actorBranchId;
    const where: Prisma.InvoiceWhereInput = {
      isDeleted: false,
      ...(allowedBranch && { branchId: allowedBranch }),
      ...(query.status && { status: query.status }),
      ...(query.customerId && { customerId: query.customerId }),
    };
    return paginate(
      this.prisma.invoice,
      { where, cursor: query.cursor, limit: query.limit },
      (id) => this.prisma.invoice.findFirst({ where: { id }, select: { createdAt: true } }),
    );
  }

  async createInvoice(
    dto: CreateInvoiceDto,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    this.assertBranch(dto, actorBranchId, isSuperAdmin);
    const code = await this.nextCode('INV', 'invoice');

    const computedLines = dto.lines.map((l, i) => {
      const vatRate = l.vatRate ?? 7.5;
      const net = l.unitPrice * l.quantity;
      const vatAmount = net * (vatRate / 100);
      return { ...l, lineNumber: i + 1, net, vatRate, vatAmount, lineTotal: net + vatAmount };
    });

    const subtotal = computedLines.reduce((s, l) => s + l.net, 0);
    const vatAmount = computedLines.reduce((s, l) => s + l.vatAmount, 0);
    const total = subtotal + vatAmount;

    const invoice = await this.prisma.invoice.create({
      data: {
        code,
        customerId: dto.customerId,
        salesOrderId: dto.salesOrderId,
        branchId: dto.branchId,
        currency: dto.currency ?? 'NGN',
        exchangeRate: dto.exchangeRate ?? 1,
        subtotal,
        vatAmount,
        whtAmount: 0,
        discountAmount: 0,
        total,
        amountPaid: 0,
        amountDue: total,
        dueDate: dto.dueDate,
        paymentTerms: dto.paymentTerms ?? 30,
        notes: dto.notes,
        createdById: actorId,
        lines: {
          create: computedLines.map((l) => ({
            lineNumber: l.lineNumber,
            productId: l.productId,
            description: l.description,
            quantity: l.quantity,
            unit: 'unit',
            unitPrice: l.unitPrice,
            vatRate: l.vatRate,
            vatAmount: l.vatAmount,
            lineTotal: l.lineTotal,
          })),
        },
      },
      include: { lines: true },
    });

    await this.audit.log({
      action: 'create',
      resource: 'invoice',
      entityId: invoice.id,
      afterState: invoice,
      actorId,
    });
    return invoice;
  }

  async issueInvoice(id: string, actorId: string, actorBranchId: string, isSuperAdmin: boolean) {
    const inv = await this.prisma.invoice.findFirst({ where: { id, isDeleted: false } });
    if (!inv) throw new NotFoundException('Invoice not found');
    if (!isSuperAdmin && inv.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    if (inv.status !== 'DRAFT') throw new BadRequestException('Only DRAFT invoices can be issued');

    // ACID: once issued, financial amounts are locked
    const updated = await this.prisma.invoice.update({
      where: { id },
      data: { status: 'ISSUED', issuedAt: new Date() },
    });

    await this.audit.log({
      action: 'issue',
      resource: 'invoice',
      entityId: id,
      beforeState: { status: inv.status },
      afterState: { status: 'ISSUED' },
      actorId,
    });
    this.events.emit('sales.invoice.issued', { invoiceId: id });
    return updated;
  }

  async recordPayment(
    id: string,
    amount: number,
    paymentRef: string,
    actorId: string,
    actorBranchId: string,
    isSuperAdmin: boolean,
  ) {
    const inv = await this.prisma.invoice.findFirst({ where: { id, isDeleted: false } });
    if (!inv) throw new NotFoundException('Invoice not found');
    if (!isSuperAdmin && inv.branchId !== actorBranchId)
      throw new ForbiddenException('Access denied');
    if (!['ISSUED', 'PARTIALLY_PAID', 'OVERDUE'].includes(inv.status)) {
      throw new BadRequestException('Cannot record payment on this invoice');
    }
    if (amount > Number(inv.amountDue)) {
      throw new BadRequestException('Payment exceeds amount due');
    }

    const newPaid = Number(inv.amountPaid) + amount;
    const newDue = Number(inv.total) - newPaid;
    const newStatus = newDue <= 0 ? 'PAID' : 'PARTIALLY_PAID';

    const updated = await this.prisma.invoice.update({
      where: { id },
      data: { amountPaid: newPaid, amountDue: newDue, status: newStatus, paymentRef },
    });

    await this.audit.log({
      action: 'payment_recorded',
      resource: 'invoice',
      entityId: id,
      beforeState: { amountPaid: inv.amountPaid, amountDue: inv.amountDue, status: inv.status },
      afterState: { amountPaid: newPaid, amountDue: newDue, status: newStatus },
      actorId,
    });

    if (newStatus === 'PAID') {
      this.events.emit('sales.invoice.paid', { invoiceId: id });
    }

    return updated;
  }

  // ── Stats ─────────────────────────────────────────────────────────────────

  async getSalesStats(actorBranchId: string, isSuperAdmin: boolean) {
    const branchFilter = isSuperAdmin ? {} : { branchId: actorBranchId };
    const year = new Date().getFullYear();
    const yearStart = new Date(`${year}-01-01`);

    const [quotations, orders, invoiceStats, overdueCount] = await Promise.all([
      this.prisma.quotation.groupBy({
        by: ['status'],
        where: { ...branchFilter, isDeleted: false, createdAt: { gte: yearStart } },
        _count: { id: true },
      }),
      this.prisma.salesOrder.groupBy({
        by: ['status'],
        where: { ...branchFilter, isDeleted: false, createdAt: { gte: yearStart } },
        _count: { id: true },
      }),
      this.prisma.invoice.aggregate({
        where: {
          ...branchFilter,
          isDeleted: false,
          status: { in: ['ISSUED', 'PARTIALLY_PAID', 'PAID'] },
        },
        _sum: { total: true, amountPaid: true, amountDue: true },
        _count: { id: true },
      }),
      this.prisma.invoice.count({
        where: {
          ...branchFilter,
          isDeleted: false,
          status: 'OVERDUE',
          dueDate: { lt: new Date() },
        },
      }),
    ]);

    return {
      quotations,
      orders,
      revenue: Number(invoiceStats._sum.amountPaid ?? 0),
      totalInvoiced: Number(invoiceStats._sum.total ?? 0),
      outstandingAR: Number(invoiceStats._sum.amountDue ?? 0),
      invoiceCount: invoiceStats._count.id,
      overdueCount,
    };
  }
}
