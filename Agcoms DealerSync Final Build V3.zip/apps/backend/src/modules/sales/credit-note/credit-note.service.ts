/**
 * AGCOMS DealerSync ERP — CreditNoteService
 * Sprint 5: Section 7 Module 5 — "Credit notes workflow"
 *
 * A Credit Note is a negative invoice that:
 *   - Reduces the customer's outstanding balance
 *   - Creates a reversing journal entry (Dr Revenue / Cr AR)
 *   - Links back to the original invoice
 *   - Can be applied against a future invoice or refunded
 *
 * Workflow:
 *   DRAFT → ISSUED → APPLIED (against invoice) or REFUNDED
 *
 * Accounting treatment (IFRS):
 *   Dr  Revenue / Sales (4xxx)          [amount ex-VAT]
 *   Dr  VAT Liability (2xxx)            [VAT portion]
 *   Cr  Accounts Receivable (1xxx)      [total including VAT]
 */
import { JwtPayload } from '@agcoms/types';
import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';

import { AuditService } from '../../../audit/audit.service';
import { PrismaService } from '../../../prisma/prisma.service';

export interface CreateCreditNoteDto {
  originalInvoiceId: string;
  branchId: string;
  reason: string;
  creditType: 'FULL' | 'PARTIAL' | 'RETURN';
  lines: {
    description: string;
    quantity: number;
    unitPrice: number;
    vatRate: number;
  }[];
  notes?: string;
}

export interface ApplyCreditNoteDto {
  invoiceId: string; // Invoice to apply this credit against
  amountToApply: number;
}

@Injectable()
export class CreditNoteService {
  private readonly logger = new Logger(CreditNoteService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly events: EventEmitter2,
    private readonly audit: AuditService,
  ) {}

  // ── Create credit note ────────────────────────────────────────

  async createCreditNote(dto: CreateCreditNoteDto, actor: JwtPayload) {
    const originalInvoice = await this.prisma.invoice.findFirst({
      where: { id: dto.originalInvoiceId, branchId: dto.branchId },
      include: { customer: true, lines: true },
    });
    if (!originalInvoice) throw new NotFoundException('Original invoice not found');

    if (['DRAFT', 'CANCELLED'].includes(originalInvoice.status)) {
      throw new BadRequestException(
        `Cannot create a credit note against a ${originalInvoice.status} invoice`,
      );
    }

    // Calculate totals
    const lineData = dto.lines.map((l) => {
      const lineSubtotal = l.quantity * l.unitPrice;
      const vatAmount = lineSubtotal * (l.vatRate / 100);
      return {
        ...l,
        subtotal: lineSubtotal,
        vatAmount,
        lineTotal: lineSubtotal + vatAmount,
      };
    });
    const subtotal = lineData.reduce((s, l) => s + l.subtotal, 0);
    const vatAmount = lineData.reduce((s, l) => s + l.vatAmount, 0);
    const totalAmount = subtotal + vatAmount;

    // Validate partial credit doesn't exceed invoice balance
    const invoiceBalance = Number(originalInvoice.totalAmount) - Number(originalInvoice.amountPaid);
    if (totalAmount > invoiceBalance + 0.01) {
      throw new BadRequestException(
        `Credit note total (₦${totalAmount.toLocaleString()}) exceeds invoice balance (₦${invoiceBalance.toLocaleString()})`,
      );
    }

    const cnNo = await this.generateCreditNoteNo(dto.branchId);

    const creditNote = await this.prisma.$transaction(async (tx: any) => {
      // 1. Create the credit note record
      const cn = await tx.creditNote.create({
        data: {
          creditNoteNo: cnNo,
          originalInvoiceId: dto.originalInvoiceId,
          customerId: originalInvoice.customerId,
          branchId: dto.branchId,
          reason: dto.reason,
          creditType: dto.creditType,
          status: 'DRAFT',
          currency: originalInvoice.currency,
          subtotalAmount: subtotal,
          vatAmount,
          totalAmount,
          notes: dto.notes,
          createdById: actor.sub,
          lines: {
            create: lineData.map((l) => ({
              description: l.description,
              quantity: l.quantity,
              unitPrice: l.unitPrice,
              vatRate: l.vatRate,
              vatAmount: l.vatAmount,
              lineTotal: l.lineTotal,
            })),
          },
        },
        include: { lines: true, customer: true },
      });

      return cn;
    });

    await this.audit.log({
      action: 'credit_note.created',
      resource: 'CreditNote',
      entityId: creditNote.id,
      actorId: actor.sub,
      actorRole: actor.roles[0],
      afterState: { cnNo, originalInvoiceId: dto.originalInvoiceId, totalAmount },
    });

    this.logger.log(`Credit note ${cnNo} created for invoice ${originalInvoice.invoiceNo}`);
    return creditNote;
  }

  // ── Issue credit note (DRAFT → ISSUED) ───────────────────────

  async issueCreditNote(creditNoteId: string, actor: JwtPayload) {
    const cn = await this.prisma.creditNote.findUnique({
      where: { id: creditNoteId },
      include: { originalInvoice: true },
    });
    if (!cn) throw new NotFoundException('Credit note not found');
    if (cn.status !== 'DRAFT')
      throw new BadRequestException('Only DRAFT credit notes can be issued');

    // Post the accounting journal entry (ACID transaction)
    await this.prisma.$transaction(async (tx: any) => {
      // Find accounting accounts
      const [arAccount, revenueAccount, vatAccount] = await Promise.all([
        tx.account.findFirst({ where: { branchId: cn.branchId, code: { startsWith: '1100' } } }), // AR
        tx.account.findFirst({ where: { branchId: cn.branchId, code: { startsWith: '4000' } } }), // Revenue
        tx.account.findFirst({ where: { branchId: cn.branchId, code: { startsWith: '2300' } } }), // VAT Liability
      ]);

      if (!arAccount || !revenueAccount) {
        throw new BadRequestException(
          'Required accounting accounts not found. Ensure Chart of Accounts is configured.',
        );
      }

      // Create reversing journal entry
      const entryNo = await this.generateJournalNo(cn.branchId, tx);
      await tx.journalEntry.create({
        data: {
          entryNo,
          entryDate: new Date(),
          description: `Credit note ${cn.creditNoteNo} — ${cn.reason}`,
          entryType: 'CREDIT_NOTE',
          status: 'POSTED',
          branchId: cn.branchId,
          referenceType: 'CreditNote',
          referenceId: cn.id,
          currency: cn.currency,
          totalDebits: Number(cn.totalAmount),
          totalCredits: Number(cn.totalAmount),
          createdById: actor.sub,
          lines: {
            create: [
              // Dr Revenue (reduces revenue)
              {
                accountId: revenueAccount.id,
                description: `Credit note ${cn.creditNoteNo}`,
                debitAmount: Number(cn.subtotalAmount),
                creditAmount: 0,
              },
              // Dr VAT Liability (reduces VAT payable)
              ...(Number(cn.vatAmount) > 0 && vatAccount
                ? [
                    {
                      accountId: vatAccount.id,
                      description: `VAT credit note ${cn.creditNoteNo}`,
                      debitAmount: Number(cn.vatAmount),
                      creditAmount: 0,
                    },
                  ]
                : []),
              // Cr Accounts Receivable (reduces what customer owes)
              {
                accountId: arAccount.id,
                description: `Credit note ${cn.creditNoteNo}`,
                debitAmount: 0,
                creditAmount: Number(cn.totalAmount),
              },
            ],
          },
        },
      });

      // Update credit note status
      await tx.creditNote.update({
        where: { id: creditNoteId },
        data: { status: 'ISSUED', issuedAt: new Date() },
      });
    });

    await this.audit.log({
      action: 'credit_note.issued',
      resource: 'CreditNote',
      entityId: creditNoteId,
      actorId: actor.sub,
      actorRole: actor.roles[0],
      afterState: { creditNoteNo: cn.creditNoteNo, totalAmount: Number(cn.totalAmount) },
    });

    this.events.emit('credit_note.issued', {
      creditNoteId,
      customerId: cn.customerId,
      amount: Number(cn.totalAmount),
    });

    this.logger.log(`Credit note ${cn.creditNoteNo} issued and posted to ledger`);
    return { creditNoteId, creditNoteNo: cn.creditNoteNo, status: 'ISSUED' };
  }

  // ── Apply credit note against an invoice ─────────────────────

  async applyCreditNote(creditNoteId: string, dto: ApplyCreditNoteDto, _actor?: JwtPayload) {
    const cn = await this.prisma.creditNote.findUnique({ where: { id: creditNoteId } });
    const invoice = await this.prisma.invoice.findUnique({ where: { id: dto.invoiceId } });

    if (!cn) throw new NotFoundException('Credit note not found');
    if (!invoice) throw new NotFoundException('Invoice not found');
    if (cn.status !== 'ISSUED')
      throw new BadRequestException('Only ISSUED credit notes can be applied');
    if (cn.customerId !== invoice.customerId)
      throw new BadRequestException('Credit note and invoice must belong to the same customer');
    if (dto.amountToApply > Number(cn.totalAmount) - Number(cn.amountApplied ?? 0)) {
      throw new BadRequestException('Apply amount exceeds available credit note balance');
    }

    await this.prisma.$transaction(async (tx: any) => {
      const newAmountApplied = Number(cn.amountApplied ?? 0) + dto.amountToApply;
      const isFullyApplied = Math.abs(newAmountApplied - Number(cn.totalAmount)) < 0.01;

      await tx.creditNote.update({
        where: { id: creditNoteId },
        data: {
          amountApplied: newAmountApplied,
          status: isFullyApplied ? 'APPLIED' : 'ISSUED',
        },
      });

      // Reduce the invoice balance
      const newAmountPaid = Number(invoice.amountPaid) + dto.amountToApply;
      const isPaid = newAmountPaid >= Number(invoice.totalAmount) - 0.01;

      await tx.invoice.update({
        where: { id: dto.invoiceId },
        data: {
          amountPaid: newAmountPaid,
          status: isPaid ? 'PAID' : newAmountPaid > 0 ? 'PARTIALLY_PAID' : invoice.status,
        },
      });
    });

    this.logger.log(
      `Credit note ${cn.creditNoteNo} applied ₦${dto.amountToApply.toLocaleString()} to invoice ${invoice.invoiceNo}`,
    );
    return { success: true, amountApplied: dto.amountToApply };
  }

  // ── List credit notes ─────────────────────────────────────────

  async listCreditNotes(params: {
    branchId?: string;
    customerId?: string;
    status?: string;
    page?: number;
    limit?: number;
  }) {
    const { branchId, customerId, status, page = 1, limit = 20 } = params;
    const where: any = { isDeleted: false };
    if (branchId) where.branchId = branchId;
    if (customerId) where.customerId = customerId;
    if (status) where.status = status;

    const [items, total] = await Promise.all([
      this.prisma.creditNote.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          customer: { select: { name: true } },
          originalInvoice: { select: { invoiceNo: true } },
        },
      }),
      this.prisma.creditNote.count({ where }),
    ]);

    return { items, total, hasMore: page * limit < total };
  }

  // ── Helpers ───────────────────────────────────────────────────

  private async generateCreditNoteNo(branchId: string): Promise<string> {
    const branch = await this.prisma.branch.findUnique({
      where: { id: branchId },
      select: { code: true },
    });
    const count = await this.prisma.creditNote.count({ where: { branchId } });
    return `CN-${branch?.code ?? 'HQ'}-${new Date().getFullYear()}-${String(count + 1).padStart(5, '0')}`;
  }

  private async generateJournalNo(branchId: string, tx: any): Promise<string> {
    const count = await tx.journalEntry.count({ where: { branchId } });
    const branch = await tx.branch.findUnique({ where: { id: branchId }, select: { code: true } });
    return `JNL-${branch?.code ?? 'HQ'}-${String(count + 1).padStart(6, '0')}`;
  }
}
