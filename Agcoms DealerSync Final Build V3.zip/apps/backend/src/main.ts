/**
 * AGCOMS DealerSync ERP — Application Bootstrap
 * §5 Security Architecture: Zero Trust by Default
 *
 * IMPORTANT: tracing import MUST be first — OTEL patches Node.js built-ins
 * before any other module loads them.
 */
// eslint-disable-next-line import/order
import './tracing';

// Keep the process alive when background BullMQ queues fail to connect to Redis
// in the sandbox (these are not fatal errors — the queues will retry once Redis is reachable).
process.on('unhandledRejection', (reason) => {
  // eslint-disable-next-line no-console
  console.warn('[unhandledRejection]', reason instanceof Error ? reason.message : reason);
});
process.on('uncaughtException', (err) => {
  // eslint-disable-next-line no-console
  console.warn('[uncaughtException]', err.message);
});

import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { IoAdapter } from '@nestjs/platform-socket.io';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';

import { AppModule } from './app.module';
import { GlobalExceptionFilter } from './common/filters/global-exception.filter';
import { PiiMaskInterceptor } from './common/interceptors/pii-mask.interceptor';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log'],
  });

  // §5 Realtime: Socket.IO adapter — required for WebSocket gateways to bind
  app.useWebSocketAdapter(new IoAdapter(app));

  const config = app.get(ConfigService);
  const isDev = config.get<string>('NODE_ENV') !== 'production';

  // ── Security middleware ───────────────────────────────────────
  // §5: Helmet — sets secure HTTP headers
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'", "'nonce-{NONCE}'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'https:'],
          connectSrc: ["'self'", config.get<string>('APP_URL') ?? ''],
          fontSrc: ["'self'", 'https:'],
          objectSrc: ["'none'"],
          upgradeInsecureRequests: isDev ? null : [],
        },
      },
      crossOriginEmbedderPolicy: false, // Allow PDF.js worker
    }),
  );

  // §5: CORS whitelisting
  app.enableCors({
    origin: (config.get<string>('CORS_ORIGINS') ?? 'http://localhost:3000').split(','),
    methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    exposedHeaders: ['X-Total-Count', 'X-Request-Id'],
    credentials: true,
    maxAge: 86400,
  });

  // Cookie parsing (for HttpOnly refresh tokens)
  app.use(cookieParser());

  // Gzip compression
  app.use(compression());

  // ── Validation pipe (global) ──────────────────────────────────
  // §5: Request validation — class-validator + class-transformer
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // Strip undeclared properties
      forbidNonWhitelisted: true, // 400 if extra properties sent
      transform: true, // Auto-transform types
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );

  // ── Global interceptors ───────────────────────────────────────
  // Order matters: Transform → PII Mask (PII runs after transform wraps)
  app.useGlobalInterceptors(
    new (await import('./common/interceptors/transform.interceptor')).TransformInterceptor(),
    new (await import('./common/interceptors/transform.interceptor')).LoggingInterceptor(),
    new PiiMaskInterceptor(),
  );

  // ── Global exception filter ───────────────────────────────────
  app.useGlobalFilters(new GlobalExceptionFilter());

  // ── API versioning ────────────────────────────────────────────
  // §13: API versioning at /api/v1
  app.setGlobalPrefix('api/v1');

  // ── Swagger / OpenAPI ─────────────────────────────────────────
  // §3: OpenAPI 3.0 + Swagger documentation
  if (isDev) {
    const swaggerConfig = new DocumentBuilder()
      .setTitle('AGCOMS DealerSync ERP API')
      .setDescription(
        'Production-grade ERP for agricultural & industrial equipment dealership. AGCOMS International Trading Limited, Abuja, Nigeria.',
      )
      .setVersion('1.0.0')
      .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'JWT')
      .addCookieAuth('refresh_token')
      .addServer('http://localhost:3001', 'Development')
      .addServer('https://api.dealersync.agcoms.ng', 'Production')
      .addTag('auth', 'Authentication & session management')
      .addTag('crm', 'Customer relationship management')
      .addTag('inventory', 'Inventory & warehousing')
      .addTag('sales', 'Quotations, orders & invoices')
      .addTag('procurement', 'Purchase orders & vendor management')
      .addTag('workshop', 'Service requests & job cards')
      .addTag('fleet', 'Fleet assets & GPS tracking')
      .addTag('finance', 'Accounting, journals & reporting')
      .addTag('hr', 'Human resources & payroll')
      .addTag('contracts', 'Government contracts & NADF')
      .addTag('reports', 'Business intelligence & analytics')
      .addTag('ai', 'AI intelligence layer')
      .addTag('portal', 'Customer portal')
      .addTag('health', 'Health & readiness checks')
      .build();

    const document = SwaggerModule.createDocument(app, swaggerConfig);
    SwaggerModule.setup('api/docs', app, document, {
      swaggerOptions: {
        persistAuthorization: true,
        tagsSorter: 'alpha',
      },
    });
  }

  // ── Graceful shutdown ─────────────────────────────────────────
  // §11: Container requirements — graceful shutdowns
  app.enableShutdownHooks();

  const port = config.get<number>('PORT', 3001);
  await app.listen(port);

  console.log(`\n🚀 AGCOMS DealerSync ERP API`);
  console.log(`   Env:     ${config.get('NODE_ENV')}`);
  console.log(`   Port:    ${port}`);
  if (isDev) console.log(`   Swagger: http://localhost:${port}/api/docs`);
  console.log(`   Health:  http://localhost:${port}/api/v1/health\n`);
}

bootstrap().catch((err) => {
  console.error('Failed to start application:', err);
  process.exit(1);
});
