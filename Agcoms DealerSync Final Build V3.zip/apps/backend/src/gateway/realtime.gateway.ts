/**
 * AGCOMS DealerSync ERP — Real-time WebSocket Gateway
 * Sprint 5: Section 3 — "Realtime: Socket.IO"
 *           Section 7 Module 2 — "real-time KPIs"
 *           Section 7 Module 14 — fleet live GPS
 *           Section 7 Module 7 — job card status push
 *
 * Events emitted to clients:
 *   kpi:update           → dashboard KPI refresh (branch-scoped room)
 *   fleet:gps            → GPS reading for a specific asset
 *   fleet:alert          → critical fleet alert (e.g. roadworthy expired)
 *   jobcard:status       → job card status changed
 *   inventory:alert      → stock below reorder point
 *   invoice:paid         → payment received notification
 *   po:approved          → purchase order approved
 *   notification:push    → generic user notification
 *
 * Room strategy:
 *   - 'branch:{branchId}' → all staff in a branch receive branch events
 *   - 'user:{userId}'     → private user-specific events
 *   - 'fleet:{assetId}'   → asset-specific GPS stream
 *
 * Security:
 *   - JWT validation on connection (WsJwtGuard)
 *   - Branch isolation enforced on join
 *   - Rate limiting via throttler
 */
import { JwtPayload } from '@agcoms/types';
import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { OnEvent } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  OnGatewayInit,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

import { SecretsService } from '../secrets/secrets.service';

// ── Events ────────────────────────────────────────────────────

export const SOCKET_EVENTS = {
  // Server → Client
  KPI_UPDATE: 'kpi:update',
  FLEET_GPS: 'fleet:gps',
  FLEET_ALERT: 'fleet:alert',
  JOB_CARD_STATUS: 'jobcard:status',
  INVENTORY_ALERT: 'inventory:alert',
  INVOICE_PAID: 'invoice:paid',
  PO_APPROVED: 'po:approved',
  NOTIFICATION: 'notification:push',
  STOCK_COUNT_UPDATE: 'stockcount:update',
  // Client → Server
  JOIN_BRANCH: 'join:branch',
  LEAVE_BRANCH: 'leave:branch',
  SUBSCRIBE_ASSET: 'subscribe:asset',
} as const;

// ── Connected client state ────────────────────────────────────

interface AuthenticatedSocket extends Socket {
  data: {
    user: JwtPayload;
  };
}

@WebSocketGateway({
  cors: {
    origin: (origin: string, cb: (err: Error | null, allow?: boolean) => void) => cb(null, true),
    credentials: true,
  },
  namespace: '/',
  transports: ['websocket', 'polling'],
})
export class RealtimeGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  server!: Server;

  private readonly logger = new Logger(RealtimeGateway.name);
  // Track connected sockets: userId → Set<socketId>
  private readonly connections = new Map<string, Set<string>>();

  constructor(
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly secrets: SecretsService,
  ) {}

  afterInit(server: Server) {
    this.logger.log('Socket.IO gateway initialised');
    if (server?.engine) {
      server.engine.on('connection_error', (err: Error) => {
        this.logger.warn(`Socket.IO connection error: ${err.message}`);
      });
    }
  }

  // ── Connection handling ───────────────────────────────────────

  async handleConnection(socket: AuthenticatedSocket) {
    try {
      const token = this.extractToken(socket);
      if (!token) {
        socket.disconnect(true);
        return;
      }

      const publicKey = await this.secrets.getJwtPublicKey();
      const payload = await this.jwtService.verifyAsync<JwtPayload>(token, {
        algorithms: ['RS256'],
        publicKey,
      });

      socket.data.user = payload;

      // Auto-join user's branch room
      const branchRoom = `branch:${payload.branchId}`;
      await socket.join(branchRoom);

      // Join personal notification room
      const userRoom = `user:${payload.sub}`;
      await socket.join(userRoom);

      // Track connection
      if (!this.connections.has(payload.sub)) {
        this.connections.set(payload.sub, new Set());
      }
      this.connections.get(payload.sub)!.add(socket.id);

      socket.emit('connected', {
        userId: payload.sub,
        branchId: payload.branchId,
        rooms: [branchRoom, userRoom],
      });

      this.logger.debug(`Socket connected: ${payload.email} [${socket.id}]`);
    } catch (err) {
      this.logger.warn(`Socket auth failed: ${String(err)}`);
      socket.disconnect(true);
    }
  }

  handleDisconnect(socket: AuthenticatedSocket) {
    const userId = socket.data.user?.sub;
    if (userId) {
      const userConnections = this.connections.get(userId);
      userConnections?.delete(socket.id);
      if (userConnections?.size === 0) this.connections.delete(userId);
    }
    this.logger.debug(`Socket disconnected: ${socket.id}`);
  }

  // ── Client-initiated subscriptions ───────────────────────────

  @SubscribeMessage(SOCKET_EVENTS.JOIN_BRANCH)
  async handleJoinBranch(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() branchId: string,
  ) {
    const user = socket.data.user;
    // Super admins can join any branch; others only their own
    if (!user.isSuperAdmin && user.branchId !== branchId) {
      socket.emit('error', { message: 'Unauthorized: cannot join another branch room' });
      return;
    }
    await socket.join(`branch:${branchId}`);
    socket.emit('joined', { room: `branch:${branchId}` });
  }

  @SubscribeMessage(SOCKET_EVENTS.SUBSCRIBE_ASSET)
  async handleSubscribeAsset(
    @ConnectedSocket() socket: AuthenticatedSocket,
    @MessageBody() assetId: string,
  ) {
    await socket.join(`fleet:${assetId}`);
    socket.emit('subscribed', { room: `fleet:${assetId}` });
  }

  // ── Event listeners (NestJS domain events → Socket.IO push) ──

  @OnEvent('dashboard.kpis.updated')
  handleKpiUpdate(payload: { branchId: string; kpis: Record<string, unknown> }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.KPI_UPDATE, {
      kpis: payload.kpis,
      updatedAt: new Date().toISOString(),
    });
  }

  @OnEvent('fleet.gps.received')
  handleFleetGps(payload: {
    assetId: string;
    assetNo: string;
    branchId: string;
    lat: number;
    lng: number;
    speedKph: number;
    recordedAt: string;
  }) {
    // Emit to asset room (subscribers watching this specific asset)
    this.server.to(`fleet:${payload.assetId}`).emit(SOCKET_EVENTS.FLEET_GPS, payload);
    // Emit to branch room (branch ops dashboard)
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.FLEET_GPS, payload);
  }

  @OnEvent('fleet.alert.triggered')
  handleFleetAlert(payload: {
    assetId: string;
    assetNo: string;
    branchId: string;
    alertType: string;
    message: string;
  }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.FLEET_ALERT, {
      ...payload,
      triggeredAt: new Date().toISOString(),
    });
  }

  @OnEvent('jobcard.status.changed')
  handleJobCardStatus(payload: {
    jobCardId: string;
    jobCardNo: string;
    branchId: string;
    previousStatus: string;
    newStatus: string;
    technicianId?: string;
  }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.JOB_CARD_STATUS, payload);
    // Also notify the assigned technician personally
    if (payload.technicianId) {
      this.server.to(`user:${payload.technicianId}`).emit(SOCKET_EVENTS.JOB_CARD_STATUS, payload);
    }
  }

  @OnEvent('inventory.stock.low')
  handleStockAlert(payload: {
    stockItemId: string;
    sku: string;
    productName: string;
    branchId: string;
    currentQty: number;
    reorderPoint: number;
  }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.INVENTORY_ALERT, payload);
  }

  @OnEvent('invoice.paid')
  handleInvoicePaid(payload: {
    invoiceId: string;
    invoiceNo: string;
    branchId: string;
    customerId: string;
    amountPaid: number;
    currency: string;
  }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.INVOICE_PAID, payload);
  }

  @OnEvent('purchase_order.approved')
  handlePoApproved(payload: {
    poId: string;
    poNo: string;
    branchId: string;
    vendorName: string;
    totalAmount: number;
    approvedBy: string;
  }) {
    this.server.to(`branch:${payload.branchId}`).emit(SOCKET_EVENTS.PO_APPROVED, payload);
  }

  @OnEvent('inventory.reconciled')
  handleStockCountUpdate(payload: { countId: string; countNo: string; adjustments: number }) {
    this.server.emit(SOCKET_EVENTS.STOCK_COUNT_UPDATE, payload);
  }

  // ── Utility methods (called by other services) ────────────────

  /**
   * Push a notification to a specific user (for approvals, assignments, etc.)
   */
  pushUserNotification(
    userId: string,
    notification: {
      type: string;
      title: string;
      message: string;
      href?: string;
      data?: Record<string, unknown>;
    },
  ) {
    this.server.to(`user:${userId}`).emit(SOCKET_EVENTS.NOTIFICATION, {
      ...notification,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    });
  }

  /** Broadcast to an entire branch */
  broadcastToBranch(branchId: string, event: string, payload: unknown) {
    this.server.to(`branch:${branchId}`).emit(event, payload);
  }

  /** Number of currently connected users */
  getConnectionCount(): number {
    return this.connections.size;
  }

  // ── Helpers ───────────────────────────────────────────────────

  private extractToken(socket: Socket): string | null {
    // Try Authorization header first, then cookie, then query param
    const authHeader = socket.handshake.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) return authHeader.slice(7);

    const cookieHeader = socket.handshake.headers.cookie ?? '';
    const match = /access_token=([^;]+)/.exec(cookieHeader);
    if (match?.[1]) return decodeURIComponent(match[1]);

    const queryToken = socket.handshake.query['token'];
    if (typeof queryToken === 'string') return queryToken;

    return null;
  }
}
