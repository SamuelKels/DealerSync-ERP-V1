/**
 * AGCOMS DealerSync ERP — ReadModelModule
 * Sprint 4 / S4-B: Global module — any domain module can inject ReadModelService.
 * In production: DATABASE_URL_READ_REPLICA → RDS read replica endpoint.
 * In development: falls back to DATABASE_URL (primary) — still separates pool exhaustion.
 */
import { Global, Module } from '@nestjs/common';

import { ReadModelService } from './read-model.service';

@Global()
@Module({ providers: [ReadModelService], exports: [ReadModelService] })
export class ReadModelModule {}
