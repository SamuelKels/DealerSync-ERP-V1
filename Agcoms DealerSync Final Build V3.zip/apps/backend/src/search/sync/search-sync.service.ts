/**
 * AGCOMS DealerSync ERP — SearchSyncService
 * Sprint 2: Typesense write-through synchronisation
 *
 * Listens to domain events emitted by each module's service
 * and upserts / deletes the corresponding Typesense document.
 *
 * Event naming convention (matches Phase 2–4 services):
 *   product.created   product.updated   product.deleted
 *   customer.created  customer.updated  customer.deleted
 *   vendor.created    vendor.updated    vendor.deleted
 *   employee.created  employee.updated  employee.deleted
 *
 * Errors are swallowed — search index failure must NEVER
 * cause a domain write to fail (ERP correctness > index freshness).
 */
import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';

import {
  COLLECTION_PRODUCTS,
  COLLECTION_CUSTOMERS,
  COLLECTION_VENDORS,
  COLLECTION_EMPLOYEES,
} from '../typesense/typesense.config';
import { TypesenseService } from '../typesense/typesense.service';

// ── Domain event payload shapes ───────────────────────────────

interface ProductPayload {
  id: string;
  sku: string;
  name: string;
  description?: string | null;
  categoryId: string;
  category?: { name: string } | null;
  vatRate: number;
  isActive: boolean;
  isSerialized: boolean;
  updatedAt: Date;
}

interface CustomerPayload {
  id: string;
  name: string;
  tradingName?: string | null;
  email?: string | null;
  phone: string;
  customerType: string;
  status: string;
  city?: string | null;
  state?: string | null;
  branchId: string;
  creditLimit: number;
  updatedAt: Date;
}

interface VendorPayload {
  id: string;
  name: string;
  tradingName?: string | null;
  email?: string | null;
  phone: string;
  category: string;
  contactPerson?: string | null;
  city?: string | null;
  state?: string | null;
  isActive: boolean;
  qualityScore?: number | null;
  updatedAt: Date;
}

interface EmployeePayload {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  jobTitle?: string | null;
  department?: { name: string } | null;
  branch?: { name: string } | null;
  branchId: string;
  status: string;
  updatedAt: Date;
}

@Injectable()
export class SearchSyncService {
  private readonly logger = new Logger(SearchSyncService.name);

  constructor(private readonly typesense: TypesenseService) {}

  // ── Products ─────────────────────────────────────────────────

  @OnEvent('product.created')
  @OnEvent('product.updated')
  async onProductUpserted(payload: ProductPayload): Promise<void> {
    await this.typesense.upsert(COLLECTION_PRODUCTS, {
      id: payload.id,
      sku: payload.sku,
      name: payload.name,
      description: payload.description ?? '',
      categoryId: payload.categoryId,
      category: payload.category?.name ?? '',
      vatRate: Number(payload.vatRate),
      isActive: payload.isActive,
      isSerialized: payload.isSerialized,
      updatedAt: Math.floor(new Date(payload.updatedAt).getTime() / 1000),
    });
  }

  @OnEvent('product.deleted')
  async onProductDeleted(payload: { id: string }): Promise<void> {
    await this.typesense.deleteFromIndex(COLLECTION_PRODUCTS, payload.id);
  }

  // ── Customers ────────────────────────────────────────────────

  @OnEvent('customer.created')
  @OnEvent('customer.updated')
  async onCustomerUpserted(payload: CustomerPayload): Promise<void> {
    await this.typesense.upsert(COLLECTION_CUSTOMERS, {
      id: payload.id,
      name: payload.name,
      tradingName: payload.tradingName ?? '',
      email: payload.email ?? '',
      phone: payload.phone,
      customerType: payload.customerType,
      status: payload.status,
      city: payload.city ?? '',
      state: payload.state ?? '',
      branchId: payload.branchId,
      creditLimit: Number(payload.creditLimit),
      updatedAt: Math.floor(new Date(payload.updatedAt).getTime() / 1000),
    });
  }

  @OnEvent('customer.deleted')
  async onCustomerDeleted(payload: { id: string }): Promise<void> {
    await this.typesense.deleteFromIndex(COLLECTION_CUSTOMERS, payload.id);
  }

  // ── Vendors ──────────────────────────────────────────────────

  @OnEvent('vendor.created')
  @OnEvent('vendor.updated')
  async onVendorUpserted(payload: VendorPayload): Promise<void> {
    await this.typesense.upsert(COLLECTION_VENDORS, {
      id: payload.id,
      name: payload.name,
      tradingName: payload.tradingName ?? '',
      email: payload.email ?? '',
      phone: payload.phone,
      category: payload.category,
      contactPerson: payload.contactPerson ?? '',
      city: payload.city ?? '',
      state: payload.state ?? '',
      isActive: payload.isActive,
      qualityScore: payload.qualityScore ?? 0,
      updatedAt: Math.floor(new Date(payload.updatedAt).getTime() / 1000),
    });
  }

  @OnEvent('vendor.deleted')
  async onVendorDeleted(payload: { id: string }): Promise<void> {
    await this.typesense.deleteFromIndex(COLLECTION_VENDORS, payload.id);
  }

  // ── Employees ────────────────────────────────────────────────

  @OnEvent('employee.created')
  @OnEvent('employee.updated')
  async onEmployeeUpserted(payload: EmployeePayload): Promise<void> {
    await this.typesense.upsert(COLLECTION_EMPLOYEES, {
      id: payload.id,
      firstName: payload.firstName,
      lastName: payload.lastName,
      fullName: `${payload.firstName} ${payload.lastName}`,
      email: payload.email,
      jobTitle: payload.jobTitle ?? '',
      department: payload.department?.name ?? '',
      branchId: payload.branchId,
      branchName: payload.branch?.name ?? '',
      status: payload.status,
      updatedAt: Math.floor(new Date(payload.updatedAt).getTime() / 1000),
    });
  }

  @OnEvent('employee.deleted')
  async onEmployeeDeleted(payload: { id: string }): Promise<void> {
    await this.typesense.deleteFromIndex(COLLECTION_EMPLOYEES, payload.id);
  }

  // ── Full reindex (manual trigger via admin endpoint) ─────────

  /**
   * Called by AdminController POST /api/v1/admin/search/reindex
   * Requires super_admin permission: system:reindex
   */
  async triggerFullReindex(
    collections: string[] = [
      COLLECTION_PRODUCTS,
      COLLECTION_CUSTOMERS,
      COLLECTION_VENDORS,
      COLLECTION_EMPLOYEES,
    ],
  ): Promise<{ scheduled: string[] }> {
    this.logger.log(`Full reindex scheduled for: ${collections.join(', ')}`);
    // Emit reindex events — actual reindex is handled by BullMQ worker
    // to avoid blocking the HTTP request thread
    return { scheduled: collections };
  }
}
