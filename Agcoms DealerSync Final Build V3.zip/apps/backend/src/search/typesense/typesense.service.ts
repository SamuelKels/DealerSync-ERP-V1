/**
 * AGCOMS DealerSync ERP — TypesenseService
 * Sprint 2: Section 13 — "AI Intelligence Layer: NLP search"
 *           Section 3   — "Search: Typesense"
 *
 * Provides:
 *   - searchProducts()  — full-text + facet search on product catalogue
 *   - searchCustomers() — CRM customer search with branch isolation
 *   - searchVendors()   — procurement vendor search
 *   - searchEmployees() — HR employee directory search
 *   - globalSearch()    — multi-collection search (command palette / ⌘K)
 *   - upsert()          — write-through sync helper
 *   - delete()          — delete from index on soft-delete
 *
 * All search methods degrade gracefully: if Typesense is unreachable,
 * the calling service falls back to Prisma ILIKE query.
 */
import { Injectable, Inject, Logger } from '@nestjs/common';
import { Client } from 'typesense';

import {
  COLLECTION_PRODUCTS,
  COLLECTION_CUSTOMERS,
  COLLECTION_VENDORS,
  COLLECTION_EMPLOYEES,
  TYPESENSE_CLIENT,
} from './typesense.config';
// ── Search result types ───────────────────────────────────────

export interface SearchHit<T = Record<string, unknown>> {
  id: string;
  score: number;
  document: T;
}

export interface SearchResults<T = Record<string, unknown>> {
  hits: SearchHit<T>[];
  found: number;
  query: string;
  facets?: Record<string, { value: string; count: number }[]>;
  searchTimeMs: number;
}

export interface GlobalSearchResult {
  collection: string;
  label: string;
  id: string;
  subtitle?: string;
  href: string;
}

// ── Search parameter types ────────────────────────────────────

export interface ProductSearchParams {
  query: string;
  categoryId?: string;
  isActive?: boolean;
  isSerialized?: boolean;
  page?: number;
  limit?: number;
}

export interface CustomerSearchParams {
  query: string;
  branchId?: string;
  customerType?: string;
  status?: string;
  city?: string;
  page?: number;
  limit?: number;
}

export interface VendorSearchParams {
  query: string;
  category?: string;
  isActive?: boolean;
  city?: string;
  page?: number;
  limit?: number;
}

export interface EmployeeSearchParams {
  query: string;
  branchId?: string;
  department?: string;
  status?: string;
  page?: number;
  limit?: number;
}

@Injectable()
export class TypesenseService {
  private readonly logger = new Logger(TypesenseService.name);

  constructor(@Inject(TYPESENSE_CLIENT) private readonly client: Client) {}

  // ── Products ────────────────────────────────────────────────

  async searchProducts(params: ProductSearchParams): Promise<SearchResults> {
    const filters: string[] = [];
    if (params.categoryId) filters.push(`categoryId:=${params.categoryId}`);
    if (params.isActive !== undefined) filters.push(`isActive:=${params.isActive}`);
    if (params.isSerialized !== undefined) filters.push(`isSerialized:=${params.isSerialized}`);

    return this.search(COLLECTION_PRODUCTS, {
      q: params.query || '*',
      query_by: 'name,sku,description,category',
      query_by_weights: '4,3,1,2',
      filter_by: filters.join(' && ') || undefined,
      facet_by: 'category,isActive,isSerialized',
      sort_by: '_text_match:desc,updatedAt:desc',
      per_page: params.limit ?? 20,
      page: params.page ?? 1,
    });
  }

  // ── Customers ───────────────────────────────────────────────

  async searchCustomers(params: CustomerSearchParams): Promise<SearchResults> {
    const filters: string[] = [];
    // Branch isolation — enforced server-side (Section 5)
    if (params.branchId) filters.push(`branchId:=${params.branchId}`);
    if (params.customerType) filters.push(`customerType:=${params.customerType}`);
    if (params.status) filters.push(`status:=${params.status}`);
    if (params.city) filters.push(`city:=${params.city}`);

    return this.search(COLLECTION_CUSTOMERS, {
      q: params.query || '*',
      query_by: 'name,tradingName,email,phone',
      query_by_weights: '4,3,2,1',
      filter_by: filters.join(' && ') || undefined,
      facet_by: 'customerType,status,city,branchId',
      sort_by: '_text_match:desc,updatedAt:desc',
      per_page: params.limit ?? 20,
      page: params.page ?? 1,
    });
  }

  // ── Vendors ─────────────────────────────────────────────────

  async searchVendors(params: VendorSearchParams): Promise<SearchResults> {
    const filters: string[] = [];
    if (params.category) filters.push(`category:=${params.category}`);
    if (params.isActive !== undefined) filters.push(`isActive:=${params.isActive}`);
    if (params.city) filters.push(`city:=${params.city}`);

    return this.search(COLLECTION_VENDORS, {
      q: params.query || '*',
      query_by: 'name,tradingName,contactPerson,city',
      query_by_weights: '4,3,2,1',
      filter_by: filters.join(' && ') || undefined,
      facet_by: 'category,isActive,city',
      sort_by: '_text_match:desc,updatedAt:desc',
      per_page: params.limit ?? 20,
      page: params.page ?? 1,
    });
  }

  // ── Employees ───────────────────────────────────────────────

  async searchEmployees(params: EmployeeSearchParams): Promise<SearchResults> {
    const filters: string[] = [];
    if (params.branchId) filters.push(`branchId:=${params.branchId}`);
    if (params.department) filters.push(`department:=${params.department}`);
    if (params.status) filters.push(`status:=${params.status}`);

    return this.search(COLLECTION_EMPLOYEES, {
      q: params.query || '*',
      query_by: 'fullName,email,jobTitle,department',
      query_by_weights: '4,3,2,1',
      filter_by: filters.join(' && ') || undefined,
      facet_by: 'department,branchName,status',
      sort_by: '_text_match:desc,updatedAt:desc',
      per_page: params.limit ?? 20,
      page: params.page ?? 1,
    });
  }

  // ── Global search (command palette) ─────────────────────────

  async globalSearch(query: string, branchId?: string, limit = 5): Promise<GlobalSearchResult[]> {
    if (!query || query.trim().length < 2) return [];

    const results: GlobalSearchResult[] = [];

    // Search all 4 collections in parallel
    const [products, customers, vendors, employees] = await Promise.allSettled([
      this.search(COLLECTION_PRODUCTS, {
        q: query,
        query_by: 'name,sku',
        per_page: limit,
        page: 1,
      }),
      this.search(COLLECTION_CUSTOMERS, {
        q: query,
        query_by: 'name,email,phone',
        filter_by: branchId ? `branchId:=${branchId}` : undefined,
        per_page: limit,
        page: 1,
      }),
      this.search(COLLECTION_VENDORS, {
        q: query,
        query_by: 'name,contactPerson',
        per_page: limit,
        page: 1,
      }),
      this.search(COLLECTION_EMPLOYEES, {
        q: query,
        query_by: 'fullName,email,jobTitle',
        filter_by: branchId ? `branchId:=${branchId}` : undefined,
        per_page: limit,
        page: 1,
      }),
    ]);

    if (products.status === 'fulfilled') {
      products.value.hits.forEach((h) => {
        const doc = h.document as { name: string; sku: string };
        results.push({
          collection: 'products',
          label: doc.name,
          id: h.id,
          subtitle: `SKU: ${doc.sku}`,
          href: `/inventory/products/${h.id}`,
        });
      });
    }

    if (customers.status === 'fulfilled') {
      customers.value.hits.forEach((h) => {
        const doc = h.document as { name: string; customerType: string };
        results.push({
          collection: 'customers',
          label: doc.name,
          id: h.id,
          subtitle: doc.customerType,
          href: `/crm/customers/${h.id}`,
        });
      });
    }

    if (vendors.status === 'fulfilled') {
      vendors.value.hits.forEach((h) => {
        const doc = h.document as { name: string; category: string };
        results.push({
          collection: 'vendors',
          label: doc.name,
          id: h.id,
          subtitle: `Vendor · ${doc.category}`,
          href: `/procurement/vendors/${h.id}`,
        });
      });
    }

    if (employees.status === 'fulfilled') {
      employees.value.hits.forEach((h) => {
        const doc = h.document as { fullName: string; jobTitle?: string };
        results.push({
          collection: 'employees',
          label: doc.fullName,
          id: h.id,
          subtitle: doc.jobTitle,
          href: `/hr/employees/${h.id}`,
        });
      });
    }

    return results;
  }

  // ── Write-through upsert ─────────────────────────────────────

  async upsert(collection: string, document: Record<string, unknown>): Promise<void> {
    try {
      await this.client.collections(collection).documents().upsert(document);
    } catch (err) {
      // Log but never throw — search index failure must not break ERP writes
      this.logger.warn(
        `Typesense upsert failed for ${collection}/${String(document['id'])}: ${String(err)}`,
      );
    }
  }

  // ── Delete from index ────────────────────────────────────────

  async deleteFromIndex(collection: string, id: string): Promise<void> {
    try {
      await this.client.collections(collection).documents(id).delete();
    } catch (err) {
      this.logger.warn(`Typesense delete failed for ${collection}/${id}: ${String(err)}`);
    }
  }

  // ── Internal search with graceful fallback ───────────────────

  private async search(
    collection: string,
    searchParams: Record<string, unknown>,
  ): Promise<SearchResults> {
    const start = Date.now();
    try {
      const response = await this.client
        .collections(collection)
        .documents()
        .search(searchParams as any);

      const hits: SearchHit[] = (response.hits ?? []).map((hit) => ({
        id: String((hit.document as Record<string, unknown>)['id'] ?? ''),
        score: hit.text_match ?? 0,
        document: hit.document as Record<string, unknown>,
      }));

      // Extract facet counts for filter UI
      const facets: Record<string, { value: string; count: number }[]> = {};
      for (const fc of response.facet_counts ?? []) {
        facets[fc.field_name] = (fc.counts ?? []).map((c) => ({
          value: String(c.value),
          count: c.count,
        }));
      }

      return {
        hits,
        found: response.found ?? 0,
        query: String(searchParams['q'] ?? ''),
        facets,
        searchTimeMs: Date.now() - start,
      };
    } catch (err) {
      this.logger.warn(
        `Typesense search failed on "${collection}" — degrading to empty results: ${String(err)}`,
      );
      // Return empty results — calling service will fall back to Prisma ILIKE
      return {
        hits: [],
        found: 0,
        query: String(searchParams['q'] ?? ''),
        searchTimeMs: Date.now() - start,
      };
    }
  }
}
