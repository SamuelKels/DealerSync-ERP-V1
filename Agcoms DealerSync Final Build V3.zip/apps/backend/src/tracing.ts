/**
 * AGCOMS DealerSync ERP — OpenTelemetry Tracing Bootstrap
 *
 * This file MUST be imported before any other import in main.ts so that
 * OTEL patches Node.js built-ins (http, https, pg, etc.) before the application
 * code loads them. Importing it after NestJS bootstraps will produce incomplete traces.
 *
 * Section 9 (Observability): OpenTelemetry tracing + OTLP exporter to Grafana Tempo.
 *
 * Environment variables:
 *   OTEL_ENABLED              = "true" | "false"  (default: "false" in dev)
 *   OTEL_SERVICE_NAME         = service name       (default: "dealersync-backend")
 *   OTEL_EXPORTER_OTLP_ENDPOINT = OTLP endpoint   (default: "http://localhost:4318")
 *   NODE_ENV                  = determines whether to activate tracing
 */
import { diag, DiagConsoleLogger, DiagLogLevel } from '@opentelemetry/api';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { Resource } from '@opentelemetry/resources';
import { NodeSDK } from '@opentelemetry/sdk-node';
import { SemanticResourceAttributes } from '@opentelemetry/semantic-conventions';

const OTEL_ENABLED =
  process.env['OTEL_ENABLED'] === 'true' ||
  (process.env['NODE_ENV'] === 'production' && process.env['OTEL_ENABLED'] !== 'false');

if (OTEL_ENABLED) {
  // Enable OTEL diagnostic logging at WARN level in development
  if (process.env['NODE_ENV'] !== 'production') {
    diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.WARN);
  }

  const serviceName = process.env['OTEL_SERVICE_NAME'] ?? 'dealersync-backend';
  const otlpEndpoint = process.env['OTEL_EXPORTER_OTLP_ENDPOINT'] ?? 'http://localhost:4318';

  const exporter = new OTLPTraceExporter({
    url: `${otlpEndpoint}/v1/traces`,
    headers: {},
  });

  const sdk = new NodeSDK({
    resource: new Resource({
      [SemanticResourceAttributes.SERVICE_NAME]: serviceName,
      [SemanticResourceAttributes.SERVICE_VERSION]: process.env['npm_package_version'] ?? '2.0.0',
      [SemanticResourceAttributes.DEPLOYMENT_ENVIRONMENT]: process.env['NODE_ENV'] ?? 'development',
    }),
    traceExporter: exporter,
    instrumentations: [
      getNodeAutoInstrumentations({
        // Instrument HTTP, HTTPS, Express (NestJS), PostgreSQL (pg), Redis (ioredis), Bull
        '@opentelemetry/instrumentation-http': { enabled: true },
        '@opentelemetry/instrumentation-express': { enabled: true },
        '@opentelemetry/instrumentation-pg': { enabled: true },
        '@opentelemetry/instrumentation-ioredis': { enabled: true },
        // Disable noisy instrumentations
        '@opentelemetry/instrumentation-fs': { enabled: false },
        '@opentelemetry/instrumentation-dns': { enabled: false },
      }),
    ],
  });

  // Start the SDK — must complete before app bootstrap
  sdk.start();

  // Graceful shutdown — flush pending spans before process exit
  const shutdown = () => {
    sdk
      .shutdown()
      .then(() => process.exit(0))
      .catch((err) => {
        console.error('OTEL SDK shutdown error:', err);
        process.exit(1);
      });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  console.log(`[OTEL] Tracing enabled — service: ${serviceName}, endpoint: ${otlpEndpoint}`);
} else {
  // Tracing disabled — log only in non-production to avoid noise
  if (process.env['NODE_ENV'] !== 'production') {
    console.log('[OTEL] Tracing disabled (set OTEL_ENABLED=true to activate)');
  }
}
