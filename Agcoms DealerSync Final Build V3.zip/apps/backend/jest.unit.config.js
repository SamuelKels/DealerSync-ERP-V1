// jest.unit.config.js — §10 "80% service-layer coverage"
/** @type {import('@jest/types').Config.InitialOptions} */
module.exports = {
  displayName:    'unit',
  preset:         'ts-jest',
  testEnvironment: 'node',
  rootDir:        '.',
  testMatch:      ['<rootDir>/src/**/*.spec.ts', '<rootDir>/test/unit/**/*.spec.ts'],
  testPathIgnorePatterns: ['<rootDir>/test/integration/', '<rootDir>/test/_pending/'],
  moduleNameMapper: {
    '^@agcoms/(.*)$': '<rootDir>/../../packages/$1/src/index',
  },
  transform: {
    '^.+\\.ts$': ['ts-jest', {
      tsconfig: '<rootDir>/tsconfig.jest.json',
      diagnostics: { warnOnly: true },
    }],
  },
  coverageDirectory:   '<rootDir>/coverage/unit',
  collectCoverageFrom: [
    'src/**/*.service.ts',
    '!src/**/*.spec.ts',
    '!src/**/*.d.ts',
    '!src/main.ts',
    '!src/prisma/**',
  ],
  coverageReporters: ['text', 'lcov', 'html'],
  // §10: "minimum 80% service-layer coverage"
  coverageThresholds: {
    global: {
      branches:   80,
      functions:  80,
      lines:      80,
      statements: 80,
    },
    // Per-file thresholds for critical financial services
    './src/finance/finance.service.ts': {
      branches:   90,
      functions:  90,
      lines:      90,
      statements: 90,
    },
    './src/sales/sales.service.ts': {
      branches:   85,
      functions:  85,
      lines:      85,
      statements: 85,
    },
  },
  verbose: true,
  forceExit: true,
  clearMocks: true,
};
