// tests/e2e/auth/auth.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Authentication flow', () => {
  test.use({ storageState: { cookies: [], origins: [] } }); // Start unauthenticated

  test('redirects unauthenticated users to /login', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login/);
  });

  test('shows validation error for invalid email format', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'not-an-email');
    await page.fill('input[type="password"]', 'password');
    await page.click('button[type="submit"]');
    await expect(page.locator('text=valid email')).toBeVisible();
  });

  test('shows error for wrong credentials', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'wrong@agcoms.ng');
    await page.fill('input[type="password"]', 'WrongPassword1!');
    await page.click('button[type="submit"]');
    // Toast notification should appear
    await expect(page.locator('[data-sonner-toast]')).toBeVisible({ timeout: 5000 });
  });

  test('successful login redirects to dashboard', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', process.env.TEST_ADMIN_EMAIL ?? 'admin@agcoms.ng');
    await page.fill('input[type="password"]', process.env.TEST_ADMIN_PASS ?? 'SecureP@ssword123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard', { timeout: 15_000 });
    await expect(page).toHaveURL(/\/dashboard/);
  });

  test('shows/hides password on toggle', async ({ page }) => {
    await page.goto('/login');
    const passwordInput = page.locator('input[type="password"]');
    await expect(passwordInput).toHaveAttribute('type', 'password');
    await page.click('button[aria-label*="Show password"], button[aria-label*="show"]');
    await expect(page.locator('input[type="text"]').first()).toBeVisible();
  });

  test('logout clears session and redirects to login', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', process.env.TEST_ADMIN_EMAIL ?? 'admin@agcoms.ng');
    await page.fill('input[type="password"]', process.env.TEST_ADMIN_PASS ?? 'SecureP@ssword123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/dashboard');

    // Click logout in sidebar
    await page.click('button[aria-label="Sign out"]');
    await expect(page).toHaveURL(/\/login/);

    // Verify session is cleared — direct nav to dashboard should redirect
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/\/login/);
  });
});

test.describe('Authenticated dashboard (smoke)', () => {
  // Uses pre-authenticated session from auth.setup.ts

  test('dashboard renders KPI cards', async ({ page }) => {
    await page.goto('/dashboard');
    // Wait for at least one KPI value to load (skeleton → data)
    await page.waitForSelector('.font-heading', { timeout: 10_000 });
    await expect(
      page.locator('h1:has-text("morning"), h1:has-text("afternoon"), h1:has-text("evening")'),
    ).toBeVisible();
  });

  test('sidebar shows all 14 module nav links', async ({ page }) => {
    await page.goto('/dashboard');
    const nav = page.locator('nav[aria-label="Main navigation"]');
    for (const module of [
      'Dashboard',
      'CRM',
      'Inventory',
      'Sales',
      'Procurement',
      'Workshop',
      'Fleet',
      'Finance',
    ]) {
      await expect(nav.locator(`text=${module}`)).toBeVisible();
    }
  });

  test('command palette opens with ⌘K', async ({ page }) => {
    await page.goto('/dashboard');
    await page.keyboard.press('Meta+k');
    await expect(page.locator('input[placeholder*="Search"]').last()).toBeVisible({
      timeout: 3000,
    });
    await page.keyboard.press('Escape');
    await expect(page.locator('input[placeholder*="Search"]').last()).not.toBeVisible();
  });

  test('sidebar collapses and expands', async ({ page }) => {
    await page.goto('/dashboard');
    const collapseBtn = page.locator(
      'button[aria-label*="Collapse sidebar"], button[aria-label*="Expand sidebar"]',
    );
    await collapseBtn.click();
    // After collapse, sidebar should be narrow (60px)
    const sidebar = page.locator('aside');
    const box = await sidebar.boundingBox();
    expect(box?.width).toBeLessThan(100);
  });
});
