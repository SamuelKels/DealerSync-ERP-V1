// tests/e2e/global-setup.ts
import { chromium, type FullConfig } from '@playwright/test';
import path from 'path';
import fs from 'fs';

const API_URL = process.env.API_URL ?? 'http://localhost:3000/api/v1';

export default async function globalSetup(config: FullConfig) {
  console.log('\n🔧 E2E Global Setup: authenticating test users...\n');

  // Ensure auth directory exists
  const authDir = path.join(__dirname, '.auth');
  if (!fs.existsSync(authDir)) fs.mkdirSync(authDir, { recursive: true });

  const browser = await chromium.launch();
  const page = await browser.newPage();

  try {
    // ── Step 1: Get CSRF token ─────────────────────────────────
    const csrfRes = await page.request.get(`${API_URL}/auth/csrf-token`);
    const { csrfToken } = (await csrfRes.json()) as { csrfToken: string };

    // ── Step 2: Login as admin ─────────────────────────────────
    const loginRes = await page.request.post(`${API_URL}/auth/login`, {
      data: {
        email: process.env.TEST_ADMIN_EMAIL ?? 'admin@agcoms.ng',
        password: process.env.TEST_ADMIN_PASSWORD ?? 'SecureP@ssword123',
      },
      headers: { 'X-CSRF-Token': csrfToken },
    });

    if (!loginRes.ok()) {
      throw new Error(`Login failed: ${loginRes.status()} ${await loginRes.text()}`);
    }

    const loginData = (await loginRes.json()) as { accessToken: string; user: { id: string } };

    // ── Step 3: Save auth state for test reuse ────────────────
    // Navigate to app and set the token in memory
    const baseURL =
      config.projects.find((p) => p.name === 'chromium')?.use?.baseURL ?? 'http://localhost:3001';
    await page.goto(baseURL);
    await page.evaluate((token) => {
      (window as any).__erp_access_token = token;
    }, loginData.accessToken);

    await page.context().storageState({ path: path.join(authDir, 'admin.json') });
    console.log('✅ Admin auth state saved');
  } catch (err) {
    console.error('❌ Global setup failed:', err);
    throw err;
  } finally {
    await browser.close();
  }
}
