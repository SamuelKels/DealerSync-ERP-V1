/**
 * AGCOMS DealerSync ERP — Frontend UI Smoke Tests
 *
 * Runs against a live frontend instance. Checks that the Next.js app boots,
 * serves the expected pages, and critical auth routes are reachable.
 */
import { test, expect } from '@playwright/test';

test.describe('Frontend UI smoke tests', () => {
  test('Home page loads and redirects to login', async ({ page }) => {
    await page.goto('/');
    // Unauthenticated users should land on login
    await expect(page).toHaveURL(/\/(login|auth\/login)/);
  });

  test('Login page renders with email and password fields', async ({ page }) => {
    await page.goto('/auth/login');
    await expect(page.locator('input[type="email"]')).toBeVisible();
    await expect(page.locator('input[type="password"]')).toBeVisible();
  });

  test('Login page includes AGCOMS branding', async ({ page }) => {
    await page.goto('/auth/login');
    // Page title should reference AGCOMS or DealerSync
    const title = await page.title();
    expect(title.toLowerCase()).toMatch(/agcoms|dealersync/);
  });

  test('ERP dashboard redirects unauthenticated users to login', async ({ page }) => {
    await page.goto('/erp/dashboard');
    // Should redirect away from ERP routes
    await expect(page).not.toHaveURL(/\/erp\/dashboard/);
  });

  test('404 page returns 404 status', async ({ page }) => {
    const response = await page.goto('/this-page-does-not-exist-12345');
    expect(response?.status()).toBe(404);
  });
});
