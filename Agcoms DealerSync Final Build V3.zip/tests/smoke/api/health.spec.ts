/**
 * AGCOMS DealerSync ERP — API Smoke Tests
 *
 * Runs against a live backend instance. These are executed in CI after staging
 * deployment (Step 10a of the CI/CD pipeline) to verify the deployed build
 * is accepting requests before manual approval to promote to production.
 *
 * Not a substitute for unit/integration tests — just a quick sanity check
 * that the process booted, routes mapped, and HTTP is responding.
 */
import { test, expect } from '@playwright/test';

const API_BASE = process.env['API_URL'] ?? 'http://localhost:3001';

test.describe('Backend API smoke tests', () => {
  // ── Health checks ─────────────────────────────────────────────

  test('GET /api/v1/health/live returns 200 with ok status', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/v1/health/live`);
    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body.data.status).toBe('ok');
    expect(body.data.timestamp).toBeTruthy();
    expect(body.meta.durationMs).toBeLessThan(500);
  });

  test('GET /api/v1/health/ready returns 200 or 503', async ({ request }) => {
    // ready probe checks DB + Redis — may be 503 if dependencies are unavailable
    // but the endpoint itself must respond (not 404, not 500)
    const response = await request.get(`${API_BASE}/api/v1/health/ready`);
    expect([200, 503]).toContain(response.status());
    const body = await response.json();
    // Body must have status field regardless of up/down
    expect(body.data).toBeDefined();
  });

  // ── Swagger/OpenAPI docs ───────────────────────────────────────

  test('GET /api/docs returns 200 (Swagger UI)', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/docs`);
    // Swagger UI returns HTML
    expect(response.status()).toBe(200);
    const contentType = response.headers()['content-type'];
    expect(contentType).toContain('text/html');
  });

  test('GET /api/docs-json returns 200 (OpenAPI JSON spec)', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/docs-json`);
    expect(response.status()).toBe(200);
    const spec = await response.json();
    // OpenAPI 3.0 spec must have the required top-level fields
    expect(spec.openapi).toMatch(/^3\./);
    expect(spec.info.title).toContain('AGCOMS');
    expect(spec.paths).toBeTruthy();
  });

  // ── Security headers ──────────────────────────────────────────

  test('Response includes required security headers (Helmet.js)', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/v1/health/live`);
    const headers = response.headers();

    // Helmet.js mandatory headers
    expect(headers['x-content-type-options']).toBe('nosniff');
    expect(headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(headers['strict-transport-security']).toContain('max-age=');
    expect(headers['x-xss-protection']).toBe('0'); // Helmet disables legacy X-XSS-Protection
    expect(headers['content-security-policy']).toBeTruthy();
  });

  // ── Authentication routes respond (without auth) ──────────────

  test('POST /api/v1/auth/login without credentials returns 400 or 401', async ({ request }) => {
    const response = await request.post(`${API_BASE}/api/v1/auth/login`, {
      data: {},
    });
    // Must be 400 (bad request / validation) or 401 (unauthorized)
    // NOT 404 (route missing) or 500 (server error)
    expect([400, 401]).toContain(response.status());
  });

  test('GET /api/v1/crm/customers without auth returns 401', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/v1/crm/customers`);
    expect(response.status()).toBe(401);
  });

  test('GET /api/v1/finance/accounts without auth returns 401', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/v1/finance/accounts`);
    expect(response.status()).toBe(401);
  });

  test('GET /api/v1/firs/vat-returns without auth returns 401', async ({ request }) => {
    const response = await request.get(`${API_BASE}/api/v1/firs/vat-returns`);
    expect(response.status()).toBe(401);
  });

  // ── API versioning ────────────────────────────────────────────

  test('Non-versioned route returns 404 (not 200)', async ({ request }) => {
    // Ensure requests to /api/health (without /v1) are not accidentally served
    const response = await request.get(`${API_BASE}/api/health`);
    expect(response.status()).toBe(404);
  });
});
