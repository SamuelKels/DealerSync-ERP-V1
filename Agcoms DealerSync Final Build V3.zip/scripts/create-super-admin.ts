/**
 * AGCOMS DealerSync ERP — Production Super-Admin Provisioning
 *
 * Creates (or re-activates) a single SUPER_ADMIN user against a REAL database.
 * Unlike scripts/seed.ts (demo data, hardcoded password), this script:
 *   - Takes credentials from CLI flags or environment variables (no hardcoded secrets)
 *   - Validates password strength
 *   - Hashes with @node-rs/argon2 — the SAME algorithm auth.service.ts verifies against
 *   - Aligns to the REAL schema: passwordHash, status enum, UserRole join, role-by-code
 *   - Is idempotent (safe to re-run; updates the existing user instead of duplicating)
 *   - Assigns the SUPER_ADMIN role, which is how the app derives super-admin status
 *     (the User model has no isSuperAdmin column — super-admin is role-based)
 *
 * Prerequisites (run first):
 *   pnpm install --frozen-lockfile
 *   npx prisma generate
 *   npx prisma migrate deploy
 *
 * Usage:
 *   # via flags
 *   npx ts-node scripts/create-super-admin.ts \
 *     --email admin@agcoms.ng --first Emeka --last Okonkwo --branch ABV-HQ
 *
 *   # via environment variables (password is ALWAYS read from env, never a flag,
 *   # so it does not land in shell history or process listings)
 *   SUPERADMIN_PASSWORD='********' npx ts-node scripts/create-super-admin.ts \
 *     --email admin@agcoms.ng --first Emeka --last Okonkwo --branch ABV-HQ
 *
 *   # if no password env var is set and the terminal is interactive, the script
 *   # prompts for it (input hidden)
 *
 * Flags:
 *   --email   (required)  Super-admin email address
 *   --first   (required)  First name
 *   --last    (required)  Last name
 *   --branch  (optional)  Branch code to attach (e.g. ABV-HQ). If omitted, the
 *                         first branch found is used; if none exist, branchId stays null.
 *   --force   (optional)  Reset the password of an existing user with this email
 *
 * Environment:
 *   SUPERADMIN_PASSWORD   Plaintext password (preferred over interactive prompt for CI)
 *   DATABASE_URL          Standard Prisma connection string (required)
 */

import { PrismaClient } from '@prisma/client';
import { hash } from '@node-rs/argon2';
import * as readline from 'node:readline';

const prisma = new PrismaClient();

const SUPER_ADMIN_ROLE_CODE = 'SUPER_ADMIN';
const SUPER_ADMIN_ROLE_NAME = 'Super Administrator';

// ── Argument parsing ─────────────────────────────────────────────────────
function parseArgs(argv: string[]): Record<string, string | boolean> {
  const out: Record<string, string | boolean> = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) {
      const key = a.slice(2);
      const next = argv[i + 1];
      if (next && !next.startsWith('--')) {
        out[key] = next;
        i++;
      } else {
        out[key] = true;
      }
    }
  }
  return out;
}

// ── Password strength ──────────────────────────────────────────────────────
function validatePassword(pw: string): string[] {
  const errs: string[] = [];
  if (pw.length < 12) errs.push('at least 12 characters');
  if (!/[a-z]/.test(pw)) errs.push('a lowercase letter');
  if (!/[A-Z]/.test(pw)) errs.push('an uppercase letter');
  if (!/[0-9]/.test(pw)) errs.push('a digit');
  if (!/[^A-Za-z0-9]/.test(pw)) errs.push('a symbol');
  // Reject the known demo seed password outright
  if (pw === 'DealerSync@2025!') errs.push('a value other than the demo seed password');
  return errs;
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ── Hidden interactive prompt (fallback when no env password) ──────────────
function promptHidden(question: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const stdout = process.stdout as NodeJS.WriteStream & { _writeToOutput?: (s: string) => void };
    // Mute echo
    let muted = false;
    const origWrite = stdout.write.bind(stdout);
    (stdout as any).write = (chunk: any, ...args: any[]) => {
      if (muted && typeof chunk === 'string' && chunk !== question) return true;
      return origWrite(chunk, ...args);
    };
    rl.question(question, (answer) => {
      (stdout as any).write = origWrite;
      stdout.write('\n');
      rl.close();
      resolve(answer);
    });
    muted = true;
  });
}

// ── Main ───────────────────────────────────────────────────────────────────
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  const email = (args.email as string)?.toLowerCase().trim();
  const firstName = args.first as string;
  const lastName = args.last as string;
  const branchCode = args.branch as string | undefined;
  const force = Boolean(args.force);

  // ── Validate inputs ──────────────────────────────────────────────────────
  const inputErrors: string[] = [];
  if (!email) inputErrors.push('--email is required');
  else if (!isValidEmail(email)) inputErrors.push('--email is not a valid email address');
  if (!firstName) inputErrors.push('--first (first name) is required');
  if (!lastName) inputErrors.push('--last (last name) is required');

  if (inputErrors.length) {
    console.error('\n❌ Invalid arguments:');
    for (const e of inputErrors) console.error(`   - ${e}`);
    console.error('\nRun with --help-equivalent: see the header of this file for usage.\n');
    process.exit(1);
  }

  // ── Resolve password ─────────────────────────────────────────────────────
  let password = process.env.SUPERADMIN_PASSWORD ?? '';
  if (!password) {
    if (!process.stdin.isTTY) {
      console.error(
        '\n❌ No password provided. Set SUPERADMIN_PASSWORD or run in an interactive terminal.\n',
      );
      process.exit(1);
    }
    password = await promptHidden('Enter super-admin password (input hidden): ');
    const confirm = await promptHidden('Confirm password: ');
    if (password !== confirm) {
      console.error('\n❌ Passwords do not match.\n');
      process.exit(1);
    }
  }

  const pwErrors = validatePassword(password);
  if (pwErrors.length) {
    console.error('\n❌ Password does not meet policy. It must contain:');
    for (const e of pwErrors) console.error(`   - ${e}`);
    console.error('');
    process.exit(1);
  }

  console.log('\n🔐 AGCOMS DealerSync — Super-Admin Provisioning\n');

  // ── 1. Ensure the SUPER_ADMIN role exists ────────────────────────────────
  const role = await prisma.role.upsert({
    where: { code: SUPER_ADMIN_ROLE_CODE },
    update: {},
    create: {
      code: SUPER_ADMIN_ROLE_CODE,
      name: SUPER_ADMIN_ROLE_NAME,
      description: 'Full system access. Bypasses branch isolation. Created by provisioning script.',
      isSystem: true,
    },
  });
  console.log(`  ✓ SUPER_ADMIN role present (${role.id})`);

  // ── 2. Resolve branch (optional) ─────────────────────────────────────────
  let branchId: string | null = null;
  if (branchCode) {
    const branch = await prisma.branch.findUnique({ where: { code: branchCode } });
    if (!branch) {
      console.error(`\n❌ Branch with code "${branchCode}" not found. Create the branch first.\n`);
      process.exit(1);
    }
    branchId = branch.id;
    console.log(`  ✓ Branch resolved: ${branch.name} (${branch.code})`);
  } else {
    const firstBranch = await prisma.branch.findFirst({ orderBy: { createdAt: 'asc' } });
    if (firstBranch) {
      branchId = firstBranch.id;
      console.log(`  ✓ No --branch given; defaulting to: ${firstBranch.name} (${firstBranch.code})`);
    } else {
      console.log('  ⚠ No branches exist; super-admin will be created with no branch (branchId=null)');
    }
  }

  // ── 3. Hash the password with argon2 (matches auth.service verify) ────────
  const passwordHash = await hash(password);

  // ── 4. Create or update the user ─────────────────────────────────────────
  const existing = await prisma.user.findUnique({ where: { email } });

  if (existing && !force) {
    // Idempotent: ensure the role link and active status, but DO NOT silently
    // overwrite an existing password unless --force is supplied.
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: existing.id, roleId: role.id } },
      update: {},
      create: { userId: existing.id, roleId: role.id },
    });
    await prisma.user.update({
      where: { id: existing.id },
      data: { status: 'active', deletedAt: null },
    });
    console.log(`\n  ✓ User ${email} already existed — ensured active status + SUPER_ADMIN role.`);
    console.log('    (Password left unchanged. Re-run with --force to reset it.)\n');
  } else {
    const user = await prisma.user.upsert({
      where: { email },
      update: {
        passwordHash,
        firstName,
        lastName,
        status: 'active',
        branchId,
        deletedAt: null,
        passwordChangedAt: new Date(),
      },
      create: {
        email,
        passwordHash,
        firstName,
        lastName,
        status: 'active',
        branchId,
        acceptedTermsAt: new Date(),
        passwordChangedAt: new Date(),
      },
    });
    await prisma.userRole.upsert({
      where: { userId_roleId: { userId: user.id, roleId: role.id } },
      update: {},
      create: { userId: user.id, roleId: role.id },
    });
    const action = existing ? 'updated (password reset)' : 'created';
    console.log(`\n  ✓ Super-admin ${action}: ${email} (${user.id})\n`);
  }

  console.log('✅ Done. The super-admin can now sign in at the ERP login page.');
  console.log('   Reminder: enable MFA on this account immediately after first login.\n');
}

main()
  .catch((err) => {
    console.error('\n❌ Provisioning failed:', err instanceof Error ? err.message : err);
    process.exit(1);
  })
  .finally(() => {
    void prisma.$disconnect();
  });
